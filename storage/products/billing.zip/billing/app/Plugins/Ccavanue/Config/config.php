<?php


return [

    'name'              => 'Ccavenue',

    'author'            => 'Ladybird Web Solution',

    'description'       => 'This is the first plugin for the Agore. It will give you Ccavenue payment gateway',

    'version'           => '1.0.0',

    'setting_page_url'  => 'payment-gateway/ccavenue',

];
