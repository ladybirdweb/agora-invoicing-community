<?php

/**
 * log the actions in log files
 * @param string $context
 * @param string $message
 * @param string $level
 * @param array $array
 */
function loging($context, $message, $level = 'error', $array = [])
{

    \Log::$level($message . ":-:-:-" . $context, $array);
}
/**
 * find a key exists in an array
 * @param string $key
 * @param array $array
 * @return string
 */
function checkArray($key, $array)
{
    $value = "";
    if (is_array($array) && array_key_exists($key, $array)) {
        $value = $array[$key];
    }
    return $value;
}
/**
 * get the image type
 * @param string $type
 * @return string
 */
function mime($type)
{
    if ($type == 'jpg' ||
            $type == 'png' ||
            $type == 'PNG' ||
            $type == 'JPG' ||
            $type == 'jpeg' ||
            $type == 'JPEG' ||
            $type == 'gif' ||
            $type == 'GIF' ||
            $type == 'image/jpeg' ||
            $type == 'image/jpg' ||
            $type == 'image/gif' ||
            $type == "application/octet-stream" ||
            $type == "image/png" ||
            starts_with($type, 'image')) {
        return "image";
    }
}
/**
 * remove underscore of the string
 * @param string $string
 * @return string
 */
function removeUnderscore($string)
{
    if (str_contains($string, '_') === true) {
        $string = str_replace('_', ' ', $string);
    }
    return ucfirst($string);
}
/**
 * check itil module on/off
 * @return boolean
 */
function isItil()
{
    $check = false;
    if (\Schema::hasTable('sd_releases') && \Schema::hasTable('sd_changes') && \Schema::hasTable('sd_problem')) {
        $check = true;
    }
    return $check;
}
/**
 * check asset module on/off
 * @return boolean
 */
function isAsset()
{
    $check = false;
    if (view()->exists('service::assets.index')) {
        $check = true;
    }
    return $check;
}
/**
 * check the itil enable
 * @return boolean
 */
function itilEnabled()
{
    $check = false;
    if (\Schema::hasTable('common_settings')) {
        $settings = \DB::table('common_settings')->where('option_name', 'itil')->first();
        if ($settings && $settings->status == 1) {
            $check = true;
        }
    }
    return $check;
}
/**
 * check bill module enables
 * @return boolean
 */
function isBill()
{
    $check = false;
    if (\Schema::hasTable('common_settings')) {
        $settings = \DB::table('common_settings')->where('option_name', 'bill')->first();
        if ($settings && $settings->status == 1) {
            $check = true;
        }
    }
    return $check;
}
/**
 * check cron url on/off
 * @return boolean
 */
function isCronUrl()
{
    $check    = false;
    $settings = \DB::table('common_settings')->where('option_name', 'cron_url')->first();
    if ($settings && $settings->status == 1) {
        $check = true;
    }

    return $check;
}
/**
 * render the html for delete popup
 * @param mixed $id
 * @param string $url
 * @param string $title
 * @param string $class
 * @param string $btn_name
 * @param string $button_check
 * @return string
 */
function deletePopUp($id, $url, $title = "Delete", $class = "btn btn-primary btn-xs", $btn_name
= "Delete", $button_check = true)
{
    $button = "";
    if ($button_check == true) {
        $button = '<a href="#delete" class="' . $class . '" data-toggle="modal" data-target="#delete' . $id . '"><i class="fa fa-trash" style="color:white;">&nbsp;&nbsp;</i>' . $btn_name . '</a>&nbsp;&nbsp;';
    }
    return $button . '<div class="modal fade" id="delete' . $id . '">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                <h4 class="modal-title">' . $title . '</h4>
                            </div>
                            <div class="modal-body">
                                <div class="row">
                                <div class="col-md-12">
                                <p>Are you sure ?</p>
                                </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" id="close" class="btn btn-default pull-left" data-dismiss="modal"><i class="fa fa-times" aria-hidden="true">&nbsp;&nbsp;</i>Close</button>
                                <a href="' . $url . '" class="btn btn-danger"><i class="fa fa-trash" aria-hidden="true">&nbsp;&nbsp;</i>Delete</a>
                            </div>
                        </div>
                    </div>
                </div>';
}
/**
 * check installed 
 * @return boolean
 */
function isInstall()
{
    $check = false;
    $env   = base_path('.env');
    if (\File::exists($env) && env('DB_INSTALL') == 1) {
        $check = true;
    }
    return $check;
}
/**
 * 
 * @param string $date
 * @param integer $hour
 * @param integer $min
 * @param integer $sec
 * @param string $tz
 * @return \Carbon\Carbon 
 */
function faveotime($date, $hour = 0, $min = 0, $sec = 0, $tz = "")
{
    if (is_bool($hour) && $hour == true) {
        $hour = $date->hour;
    }
    if (is_bool($min) && $min == true) {
        $min = $date->minute;
    }
    if (is_bool($sec) && $sec == true) {
        $sec = $date->second;
    }
    if (!$tz) {
        $tz = timezone();
    }
    $date1 = \Carbon\Carbon::create($date->year, $date->month, $date->day, $hour, $min, $sec, $tz);
    return $date1->hour($hour)->minute($min)->second($sec);
}
/**
 * 
 * @param array $array
 * @return int
 */
function sla($array = [])
{
    $userid         = checkArray('user_id', $array);
    $type           = checkArray('type', $array);
    $department     = checkArray('department', $array);
    $source         = checkArray('source', $array);
    $priority       = checkArray('priority', $array);
    $helptopic      = checkArray('helptopic', $array);
    $label          = checkArray('label', $array);
    $tag            = checkArray('tag', $array);
    $org_department = NULL;
    $company        = NULL;
    if ($userid) {
        $company = App\Model\helpdesk\Agent_panel\User_org::where('user_id', $userid)->select('org_id', 'org_department')->first();
        if (isMicroOrg() && $company) {
            $org_deaprtment = $company->org_department;
        }
    }
    $slaid = "";
    if (slaCondition() == 'any') {
        $slaid = slaAny($type, $department, $source, $company, $helptopic, $org_department, $label, $tag, $priority);
    }
    else {
        $slaid = slaAll($type, $department, $source, $company, $helptopic, $org_department, $label, $tag, $priority);
    }
    if ($slaid) {
        return $slaid;
    }
    else {
        $sla_value = \App\Model\helpdesk\Manage\Sla\Sla_plan::
                where('status', 1)
                ->orderBy('order')
                ->join('sla_targets', function ($join) use ($priority) {
                    return $join->on('sla_plan.id', '=', 'sla_targets.sla_id')
                            ->where('sla_targets.priority_id', '=', $priority);
                })
                ->first();
        if ($sla_value) {
            return $sla_value->id;
        }
    }
    $default = \App\Model\helpdesk\Manage\Sla\Sla_plan::where('status', 1)
            ->where('is_default', 1)
            ->first();
    if ($default) {
        return $default->id;
    }
}
function slaAll($type, $department, $source, $company, $helptopic, $org_department, $label, $tag, $priority)
{
    $array     = [
        'apply_sla_depertment'   => $department,
        'apply_sla_company'      => $company,
        'apply_sla_tickettype'   => $type,
        'apply_sla_ticketsource' => $source,
        'apply_sla_helptopic'    => $helptopic,
        'apply_sla_orgdepts'     => $org_department,
        'apply_sla_labels'       => $label,
        'apply_sla_tags'         => $tag,
    ];
    $sla_array = \App\Model\helpdesk\Manage\Sla\Sla_plan::
            where('status', 1)
            ->orderBy('order')
            ->join('sla_targets', function ($join) use ($priority) {
                return $join->on('sla_plan.id', '=', 'sla_targets.sla_id')
                        ->where('sla_targets.priority_id', '=', $priority);
            })
            ->select('sla_plan.id', 'apply_sla_depertment', 'apply_sla_company', 'apply_sla_tickettype', 'apply_sla_ticketsource', 'apply_sla_helptopic', 'apply_sla_orgdepts', 'apply_sla_labels', 'apply_sla_tags')
            ->get()
            ->toArray()
    ;
    $va   = [];
    $slas = collect($sla_array)->keyBy('id');
    if ($slas) {
        foreach ($slas as $key => $sla) {
            array_forget($sla, 'id');
            $va[$key] = array_filter($sla);
        }
    }
    if ($va) {
        $values = array_filter($va);
        foreach ($values as $sla_id => $value) {
            if (is_array($value)) {
                foreach ($value as $k => $v) {
                    $check[] = checkEnforcement($k, $v, $array);
                }
                $counts = array_count_values($check);
                if (checkArray(1, $counts)) {
                    if (count($value) == $counts[1]) {
                        return $sla_id;
                    }
                }
            }
        }
    }
}
function checkEnforcement($enforce, $enforce_value, $array)
{
    $check = 0;
    if (in_array(checkArray($enforce, $array), $enforce_value)) {
        $check = 1;
    }
    return $check;
}
function slaAny($type, $department, $source, $company, $helptopic, $org_department, $label, $tag, $priority)
{
    $sla = \App\Model\helpdesk\Manage\Sla\Sla_plan::
            where('status', 1)
            ->orderBy('order')
            ->join('sla_targets', function ($join) use ($priority) {
                return $join->on('sla_plan.id', '=', 'sla_targets.sla_id')
                        ->where('sla_targets.priority_id', '=', $priority);
            })
            ->where(function($query)use($type, $department, $source, $company, $helptopic, $org_department, $label, $tag) {
        $query
        ->where(function($query)use($type, $department, $source, $company, $helptopic, $org_department, $label, $tag) {
            $query
            ->when($type, function($query)use($type) {
                $query->orWhereRaw("find_in_set($type,apply_sla_tickettype)");
            })
            ->when($department, function($query)use($department) {
                $query->orWhereRaw("find_in_set($department,apply_sla_depertment)");
            })
            ->when($source, function($query)use($source) {
                $query->orWhereRaw("find_in_set($source,apply_sla_ticketsource)");
            })
            ->when($company, function($query)use($company) {
                $query->orWhereRaw("find_in_set($company->org_id,apply_sla_company)");
            })
            ->when($helptopic, function($query)use($helptopic) {
                $query->orWhereRaw("find_in_set($helptopic,apply_sla_helptopic)");
            })
            ->when($org_department, function($query)use($org_department) {
                $query->orWhereRaw("find_in_set($org_department,apply_sla_orgdepts)");
            })
            ->when($label, function($query)use($label) {
                $query->orWhereRaw("find_in_set('$label',apply_sla_labels)");
            })
            ->when($tag, function($query)use($tag) {
                $query->orWhereRaw("find_in_set('$tag',apply_sla_tags)");
            })
            ;
        })
        ;
    });
    $all = $sla->get();
    if ($all->count() > 0) {
        $collection = $all->mapWithKeys(function($value)use($type, $department, $source, $company, $helptopic, $org_department, $label, $tag) {
            $array = [$value->id => 0];
            if (is_array($value->apply_sla_tickettype) && in_array($type, $value->apply_sla_tickettype)) {
                $array[$value->id] ++;
            }
            if (is_array($value->apply_sla_depertment) && in_array($department, $value->apply_sla_depertment)) {
                $array[$value->id] ++;
            }
            if (is_array($value->apply_sla_ticketsource) && in_array($source, $value->apply_sla_ticketsource)) {
                $array[$value->id] ++;
            }
            if (is_array($value->apply_sla_company) && in_array($company, $value->apply_sla_company)) {
                $array[$value->id] ++;
            }
            if (is_array($value->apply_sla_helptopic) && in_array($helptopic, $value->apply_sla_helptopic)) {
                $array[$value->id] ++;
            }
            if (is_array($value->apply_sla_orgdepts) && in_array($org_department, $value->apply_sla_orgdepts)) {
                $array[$value->id] ++;
            }
            if (is_array($value->apply_sla_labels) && in_array($label, $value->apply_sla_labels)) {
                $array[$value->id] ++;
            }
            if (is_array($value->apply_sla_tags) && in_array($tag, $value->apply_sla_tags)) {
                $array[$value->id] ++;
            }
            return $array;
        })
        ;
        $array = $collection->toArray();
        if ($array) {
            $maxs = array_keys($array, max($array));
            return $maxs[0];
        }
    }
}
/**
 * get carbon instance
 * @param string $date
 * @param string $glue
 * @param string $format
 * @param boolean $flag
 * @return \Carbon\Carbon
 */
function getCarbon($date, $glue = '-', $format = "Y-m-d", $flag = true)
{
    //dd($date,$glue);
    $parse = explode($glue, $date);
    if ($format == "Y-m-d") {
        $day   = $parse[2];
        $month = $parse[1];
        $year  = $parse[0];
    }

    if ($format == "m-d-Y") {
        $month = $parse[0];
        $day   = $parse[1];
        $year  = $parse[2];
    }

    $hour   = 0;
    $minute = 0;
    $second = 0;
    if ($format == "Y-m-d H:m:i") {
        $day   = $parse[2];
        $month = $parse[1];
        $year  = $parse[0];
    }
    if (!$flag) {
        $hour   = 23;
        $minute = 59;
        $second = 59;
    }
    $carbon = \Carbon\Carbon::create($year, $month, $day, $hour, $minute, $second);
    return $carbon;
}
/**
 * create carbon instance
 * @param string $date
 * @param string $tz
 * @param string $format
 * @return \Carbon\Carbon
 */
function createCarbon($date, $tz = "", $format = "")
{
    if (!$tz) {
        $tz = timezone();
    }
    if (!$format) {
        $format = dateformat();
    }
    return \Carbon\Carbon::parse($date)->tz($tz)->format($format);
}
/**
 * parse the carbon
 * @param string $date
 * @return \Carbon\Carbon
 */
function carbon($date)
{
    return \Carbon\Carbon::parse($date);
}
/**
 * get the priority from sla
 * @param integer $slaid
 * @return integer
 */
function priority($slaid)
{
    if ($slaid) {
        $sla         = new App\Http\Controllers\SLA\Sla($slaid);
        $priority_id = $sla->priority;
        return $priority_id;
    }
    else {
        $priority = App\Model\helpdesk\Ticket\Ticket_Priority::select('priority_id')->first();
        return $priority->priority_id;
    }
}
/**
 * get system timezone
 * @return string
 */
function timezone()
{
    if (\Auth::check()) {
        $auth_timezone = \Auth::user()->agent_tzone;
        if ($auth_timezone && !is_numeric($auth_timezone)) {
            return \Auth::user()->agent_tzone;
        }
    }
    $system = App\Model\helpdesk\Settings\System::select('time_zone')->first();
    $tz     = "UTC";
    if ($system) {
        $tz = $system->time_zone;
    }
    return $tz;
}
/**
 * get system date format
 * @return string
 */
function dateformat()
{
    $system = App\Model\helpdesk\Settings\System::select('date_time_format')->first();
    $format = "Y-m-d H:m:i";
    if ($system) {
        $format = $system->date_time_format;
    }
    return $format;
}
/**
 * generate url with application url
 * @param string $route
 * @return string
 */
function faveoUrl($route)
{
    $url    = \Config::get('app.url');
    $system = App\Model\helpdesk\Settings\System::select('url')->first();
    if ($system && $system->url) {
        $url = $system->url;
    }
    if (!str_finish($url, '/')) {
        $url = $url . "/";
    }
    //dd($url."/".$route);
    return $url . "/" . $route;
}
/**
 * @category function to UTF encoding
 * @param string name
 * @return string name
 */
function utfEncoding($name)
{
    $title = "";
    $array = imap_mime_header_decode($name);
    if (is_array($array) && count($array) > 0) {
        if ($array[0]->charset != 'UTF-8') {
            $name = imap_utf8($name);
        }
        else {
            foreach ($array as $text) {
                $title .= $text->text;
            }
            $name = $title;
        }
    }
    if ((ord($name) >= 97 && ord($name) <= 122) || (ord($name) >= 65 && ord($name)
            <= 90)) {
        $name = ucfirst($name);
    }
    return $name;
}
/**
 * get the role of the user
 * @param integer $id
 * @return string
 */
function role($id)
{
    $user = \App\User::where('id', $id)->select('role')->first();
    if ($user) {
        return $user->role;
    }
}
/**
 * get the ticket title
 * @param integer $ticketid
 * @return string
 */
function title($ticketid)
{
    $thread = firstThread($ticketid);
    if ($thread) {
        return utfEncoding($thread->title);
    }
}
/**
 * get the requester of the ticket
 * @param integer $ticketid
 * @return integer
 */
function requester($ticketid)
{
    $ticket = ticket($ticketid);
    if ($ticket) {
        return $ticket->user_id;
    }
}
/**
 * get the thread
 * @param integer $threadid
 * @return \App\Model\helpdesk\Utility\Ticket_thread
 */
function thread($threadid)
{
    return App\Model\helpdesk\Utility\Ticket_thread::where('id', $threadid)
                    ->select('title', 'user_id', 'id', 'poster', 'is_internal')
                    ->first();
}
/**
 * get the poster
 * @param integer $threadid
 * @return string
 */
function poster($threadid)
{
    $thread = thread($threadid);
    if ($thread) {
        return $thread->poster;
    }
}
/**
 * get the type of the thread
 * @param integer $threadid
 * @return string
 */
function threadType($threadid)
{
    $thread = thread($threadid);
    if ($thread) {
        return $thread->thread_type;
    }
}
/**
 * get the last responder
 * @param integer $ticketid
 * @return mixed
 */
function lastResponder($ticketid)
{
    $thread = App\Model\helpdesk\Utility\Ticket_thread::where('ticket_id', $ticketid)
            ->whereNotNull('user_id')
            ->where('user_id', '')
            ->where('is_internal', 0)
            ->orderBy('id', 'desc')
            ->first();
    if ($thread) {
        return $thread->user_id;
    }
}
/**
 * get the ticket
 * @param integer $ticketid
 * @return \App\Model\helpdesk\Ticket\Tickets
 */
function ticket($ticketid)
{
    return App\Model\helpdesk\Ticket\Tickets::where('id', $ticketid)
                    ->select('user_id', 'assigned_to', 'sla', 'priority_id', 'dept_id', 'source', 'duedate')
                    ->first();
}
/**
 * get the first thread of the ticket
 * @param integer $ticketid
 * @return \App\Model\helpdesk\Utility\Ticket_thread
 */
function firstThread($ticketid)
{
    return App\Model\helpdesk\Utility\Ticket_thread::where('ticket_id', $ticketid)
                    ->whereNotNull('title')
                    ->where('title', '!=', '')
                    ->select('title', 'user_id', 'id', 'poster', 'is_internal')
                    ->first();
}
/**
 * get the last thread of the ticket
 * @param integer $ticketid
 * @return \App\Model\helpdesk\Utility\Ticket_thread
 */
function lastThread($ticketid)
{
    return App\Model\helpdesk\Utility\Ticket_thread::where('ticket_id', $ticketid)
                    ->orderBy('id', 'desc')
                    ->first();
}
/**
 * get the default source
 * @param integer $ticketid
 * @return string
 */
function source($ticketid)
{
    $ticket = ticket($ticketid);
    if ($ticket) {
        return $ticket->source;
    }
}
/**
 * get the duedate in utc
 * @param integer $ticketid
 * @return \Carbon\Carbon
 */
function dueDateUTC($ticketid)
{
    $ticket = ticket($ticketid);
    if ($ticket) {
        return $ticket->duedate;
    }
}
/**
 * get the duedate
 * @param integer $ticketid
 * @return \Carbon\Carbon
 */
function dueDate($ticketid)
{
    $ticket = ticket($ticketid);
    if ($ticket) {
        return $ticket->duedate->tz(timezone());
    }
}
/**
 * get the date from a string
 * @param string $str
 * @return string
 */
function getDateFromString($str)
{
    $reg   = '/\d{2}\/\d{2}\/\d{4}.\d{2}:\d{2}:\d{2}/';
    $match = preg_match($reg, $str, $matches);
    if (!$matches) {
        $reg   = '/\d{2}\-\d{2}\-\d{4}.\d{2}:\d{2}:\d{2}/';
        $match = preg_match($reg, $str, $matches);
    }
    if (!$matches) {
        $reg   = '/\d{2}\.\d{2}\.\d{4}.\d{2}:\d{2}:\d{2}/';
        $match = preg_match($reg, $str, $matches);
    }
    if (!$matches) {
        $reg   = '/\d{4}\.\d{2}\.\d{2}.\d{2}:\d{2}:\d{2}/';
        $match = preg_match($reg, $str, $matches);
    }
    if (!$matches) {
        $reg   = '/\d{4}\/\d{2}\/\d{2}.\d{2}:\d{2}:\d{2}/';
        $match = preg_match($reg, $str, $matches);
    }
    if (!$matches) {
        $reg   = '/\d{4}\-\d{2}\-\d{2}.\d{2}:\d{2}:\d{2}/';
        $match = preg_match($reg, $str, $matches);
    }
    if ($match) {
        $date   = checkArray(0, $matches);
        $carbon = carbon($date);
        return $carbon;
    }
}
/**
 * convert the string to hours
 * @param string $time
 * @param string $format
 * @return string
 */
function convertToHours($time, $format = '%02d:%02d')
{
    if ($time < 1) {
        return;
    }
    $hours   = floor($time / 60);
    $minutes = ($time % 60);
    return sprintf($format, $hours, $minutes);
}
/**
 * collapse the array 
 * @param array $array
 * @return array
 */
function collapse($array)
{
    $arrays = [];
    if (count($array) > 0) {
        foreach ($array as $key => $value) {
            if (is_array($value)) {
                foreach ($value as $k => $v) {
                    if (!is_array($v)) {
                        $arrays[$k] = $v;
                    }
                }
            }
        }
    }
    return $arrays;
}
/**
 * delete the files
 * @param string $dir
 * @return mixed
 */
function delTree($dir)
{
    $files = array_diff(scandir($dir), array('.', '..'));
    foreach ($files as $file) {
        (is_dir("$dir/$file")) ? delTree("$dir/$file") : unlink("$dir/$file");
    }
    return rmdir($dir);
}
/**
 * get date into human readable formate
 * @param \Carbon\Carbon $carbon
 * @return string
 */
function humanReadingDate($carbon)
{
    //$now = \Carbon\Carbon::now()->tz(timezone());
    return $carbon->diffForHumans();
}
/**
 * return date into string format according to default timezone and format
 * @param mixed $date
 * @param string $format
 * @param string $tz
 * @return string
 */
function faveoDate($date = "", $format = "", $tz = "")
{
    if (!$date) {
        $date = \Carbon\Carbon::now();
    }
    if (!is_object($date)) {
        $date = carbon($date);
    }
    if (!$format || !$tz) {
        $system = App\Model\helpdesk\Settings\System::select('time_zone', 'date_time_format')->first();
    }
    if (!$format) {
        $format = $system->date_time_format;
    }
    if (!$tz) {
        $tz = timezone();
    }
    try {
        if ($format == "human-read") {
            return $date->tz($tz)->diffForHumans();
        }
        return $date->tz($tz)->format($format);
    } catch (\Exception $ex) {
        return "invalid";
    }
}
/**
 * get the domain
 * @return string
 */
function domainUrl()
{
    return sprintf(
            "%s://%s", isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off' ? 'https'
                        : 'http', $_SERVER['SERVER_NAME']
    );
}
/**
 * get the ticket number of a ticket
 * @param integer $ticketid
 * @return integer
 */
function ticketNumber($ticketid)
{
    return App\Model\helpdesk\Ticket\Tickets::where('id', $ticketid)
                    ->select('ticket_number')
                    ->value('ticket_number');
}
/**
 * check a plugin is on/off
 * @param string $plugin
 * @return boolean
 */
function isPlugin($plugin = 'ServiceDesk')
{
    $plugin = \DB::table('plugins')->where('name', $plugin)->where('status', 1)->count();
    $check  = false;
    if ($plugin > 0) {
        $check = true;
    }
    return $check;
}
/**
 * get the default storage
 * @return string
 */
function storageDrive()
{
    $drive    = 'local';
    $settings = \DB::table('common_settings')->where('option_name', 'storage')
                    ->where('optional_field', 'default')->first();
    if ($settings && $settings->option_value) {
        $drive = $settings->option_value;
    }
    return $drive;
}
/**
 * get maximum file upload size
 * @staticvar integer $max_size
 * @return integer
 */
function file_upload_max_size()
{
    static $max_size = -1;

    if ($max_size < 0) {
        // Start with post_max_size.
        $max_size = parse_size(ini_get('post_max_size'));

        // If upload_max_size is less, then reduce. Except if upload_max_size is
        // zero, which indicates no limit.
        $upload_max = parse_size(ini_get('upload_max_filesize'));
        if ($upload_max > 0 && $upload_max < $max_size) {
            $max_size = $upload_max;
        }
    }
    return ($max_size / 1024) / 1024;
}
function parse_size($size)
{
    $unit = preg_replace('/[^bkmgtpezy]/i', '', $size); // Remove the non-unit characters from the size.
    $size = preg_replace('/[^0-9\.]/', '', $size); // Remove the non-numeric characters from the size.
    if ($unit) {
        // Find the position of the unit in the ordered string which is the power of magnitude to multiply a kilobyte by.
        return round($size * pow(1024, stripos('bkmgtpezy', $unit[0])));
    }
    else {
        return round($size);
    }
}
/**
 * @category funcion to get the value of account activation method
 * @param object of model CommonSettings : $settings
 * @var string $value
 * @return string $value: value of activation option fetched from DB
 */
function getAccountActivationOptionValue()
{
    $value = App\Model\helpdesk\Settings\CommonSettings::select('option_value')->where('option_name', '=', 'account_actvation_option')->first();
    return $value->option_value;
}
/**
 * @category Funcion to set validation rule for email
 * @param null
 * @return string : validation rule
 */
function getEmailValidation()
{
    $value           = getAccountActivationOptionValue();
    $email_mandatory = App\Model\helpdesk\Settings\CommonSettings::select('status')->where('option_name', '=', 'email_mandatory')->first();
    if ($value == 'email' || $value == 'email,mobile' || $email_mandatory->status
            == 1) {
        return 'required|max:50|email|unique:users,email';
    }
    else {
        return 'max:50|email|unique:users,email';
    }
}
/**
 * @category Funcion to set validation rule for mobile and code
 * @param string $field : name of field
 * @return string : validation rule
 */
function getMobileValidation($field)
{
    $value = getAccountActivationOptionValue();
    if (strpos($value, 'mobile') !== false) {
        return 'required|numeric|max:999999999999999|unique:users,mobile';
    }
    else {
        return 'numeric|max:999999999999999|unique:users,mobile';
    }
}
/**
 * get default department id
 * @return integer
 */
function defaultDepartmentId()
{
    $id     = "";
    $system = \App\Model\helpdesk\Settings\System::select('department')->first();
    if ($system) {
        $id = $system->department;
    }
    else {
        $department = App\Model\helpdesk\Agent\Department::select('id')->first();
        $id         = $department->id;
    }
    return $id;
}
function isMicroOrg()
{
    $check = false;
    if (\Schema::hasTable('common_settings')) {
        $settings = \DB::table('common_settings')->where('option_name', 'micro_organization_status')->first();
        if ($settings && $settings->status == 1) {
            $check = true;
        }
    }
    return $check;
}
/**
 * @category function to return array values if status id 
 * @param string purpose of status
 * @return array ids of status with purpose passed as string
 */
function getStatusArray($status)
{
    $type   = new App\Model\helpdesk\Ticket\TicketStatusType();
    $values = $type->select('name', 'id')
            ->whereIn('name', [$status])
            ->with(['status' => function ($query) {
                    $query->select('id as status_id', 'name', 'purpose_of_status');
                }])
            ->get()
            ->pluck('status')
            ->flatten()
            ->pluck('status_id')
            ->toArray()
    ;
    return $values;
}
function isCustomMail()
{
    $check   = false;
    $drive   = config('mail.driver');
    $default = [
        'smtp'     => true,
        'mail'     => true,
        'sendmail' => true,
        'mailgun'  => true,
        'mandrill' => true,
        'log'      => true
    ];
    // dd($drive, $default);
    if (!checkArray($drive, $default)) {
        $check = true;
    }
    return $check;
}
function departmentByHelptopic($helptopic_id)
{
    $help_topic = \App\Model\helpdesk\Manage\Help_topic::where('id', '=', $helptopic_id)->select('department')->first();
    if ($help_topic) {
        $department_id = $help_topic->department;
    }
    else {
        $department_id = defaultDepartmentId();
    }
    return $department_id;
}
function commonSettings($option, $option_field)
{
    return \App\Model\helpdesk\Settings\CommonSettings::where('option_name', $option)
                    ->where('optional_field', $option_field)
                    ->value('option_value');
}
/**
 * @category function to get GMT for system timezone
 * @param null
 * @var $system, $tz
 * @return string GMT value of timezone
 */
function getGMT($fetch_id = false)
{
    $system = \App\Model\helpdesk\Settings\System::select('time_zone')->first();
    $tz     = \DB::table('timezone')->select('location', 'id')->where('name', '=', $system->time_zone)->first();
    if ($fetch_id) {
        return $tz->id;
    }
    $tz = explode(")", substr($tz->location, stripos($tz->location, 'T') + 1));
    return $tz[0];
}
/**
 * get the default type id
 * @return int
 */
function defaultType()
{
    return App\Model\helpdesk\Manage\Tickettype::where('status', 1)
                    ->where('is_default', 1)
                    ->value('id');
}
function canRegister()
{
    $check  = true;
    $common = \App\Model\helpdesk\Settings\CommonSettings::where('option_name', 'user_registration')
            ->select('status')
            ->value('status');
    if ($common == 1) {
        $check = false;
    }
    return $check;
}
function array_keys_exists(array $keys, array $arr)
{
    foreach ($keys as $key) {
        if (array_key_exists($key, $arr)) {
            return true;
        }
    }
    return false;
}
function slaCondition()
{
    $codition = "all";
    $value    = commonSettings('sla_condition', '');
    if ($value) {
        $codition = $value;
    }
    return $codition;
}
function apiSettings($key)
{
    return \App\Model\Api\ApiSetting::where('key', $key)->value('value');
}
