<?php

namespace App\Model\kb;

use App\BaseModel;

class Footer3 extends BaseModel
{
    protected $table = 'footer3';
    protected $fillable = ['title', 'footer'];
}
