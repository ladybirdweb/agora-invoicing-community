<?php

namespace App\Model\Common;

use App\BaseModel;

class Country extends BaseModel
{
    protected $table = 'countries';
}
