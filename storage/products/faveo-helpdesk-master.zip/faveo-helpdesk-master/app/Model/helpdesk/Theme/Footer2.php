<?php

namespace App\Model\helpdesk\Theme;

use Illuminate\Database\Eloquent\Model;

class Footer2 extends Model
{
    protected $table = 'footer2';
    protected $fillable = ['title', 'footer'];
}
