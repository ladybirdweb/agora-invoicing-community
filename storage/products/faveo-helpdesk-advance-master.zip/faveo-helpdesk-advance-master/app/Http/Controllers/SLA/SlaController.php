<?php

namespace App\Http\Controllers\SLA;

// controllers
use App\Http\Controllers\Controller;
// requests
use App\Http\Requests\helpdesk\SlaRequest;
use App\Http\Requests\helpdesk\SlaUpdateRequest;
// models
use App\Model\helpdesk\Manage\Sla\Sla_plan;
use App\Model\helpdesk\Settings\Ticket;
use App\Model\helpdesk\Manage\Sla\SlaTargets;
use App\Model\helpdesk\Agent\Department;
use App\Model\helpdesk\Settings\Company;
use App\Model\helpdesk\Manage\Tickettype;
use App\Model\helpdesk\Ticket\Ticket_source;
use App\Model\helpdesk\Manage\Sla\SlaApproachesResponse;
use App\Model\helpdesk\Manage\Sla\SlaApproachesResolution;
use App\Model\helpdesk\Manage\Sla\SlaViolatedResponse;
use App\Model\helpdesk\Manage\Sla\SlaViolatedResolved;
use App\Model\helpdesk\Manage\Sla\SlaApproachEscalate;
use App\Model\helpdesk\Manage\Sla\SlaViolatedEscalate;
use App\Model\helpdesk\Agent_panel\Organization;
use App\Model\helpdesk\Manage\Help_topic;
use App\Model\helpdesk\Agent_panel\OrganizationDepartment;
use App\Model\helpdesk\Filters\Label;
use App\Model\helpdesk\Filters\Tag;
//classes
use App\User;
use DB;
use Exception;
use Lang;
use Illuminate\Http\Request;
use App\Model\helpdesk\Manage\Sla\SlaCustomEnforcements;

/**
 * SlaController.
 *
 * @author      Ladybird <info@ladybirdweb.com>
 */
class SlaController extends Controller {

    /**
     * Create a new controller instance.
     *
     * @return type void
     */
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('roles');
    }

    /**
     * Display a listing of the resource.
     *
     * @param type Sla_plan $sla
     *
     * @return type Response
     */
    public function index(Sla_plan $sla)
    {
        try {
            $condition = slaCondition();
            $slas = $sla->orderBy('order')->get();
            /* Declare a Variable $slas to store all Values From Sla_plan Table */
            /* Listing the values From Sla_plan Table */
            return view('themes.default1.admin.helpdesk.manage.sla.index', compact('slas', 'condition'));
        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }

    /**
     * Display a listing of the resource.
     *
     * @param type Sla_plan $sla
     *
     * @return type Response
     */
    public function getIndex()
    {
        try {
            return \DataTables::of(Sla_plan::whereIn('status', [0, 1])->get())
                            ->editColumn('name', function($model) {
                                if ($model->is_default > 0) {
                                    if (strlen($model->name) > 25) {
                                        return '<p title="' . $model->name . '">' . mb_substr($model->name, 0, 30, 'UTF-8') . '...</p> ( Default )';
                                    } else {
                                        return "$model->name ( Default )";
                                    }
                                } else {
                                    if (strlen($model->name) > 25) {
                                        return '<p title="' . $model->name . '">' . mb_substr($model->name, 0, 30, 'UTF-8') . '...</p>';
                                    } else {
                                        return $model->name;
                                    }
                                }
                            })
                            ->editColumn('status', function($model) {
                                if ($model->status == 1) {
                                    return '<p class="btn btn-xs btn-default" style="pointer-events:none;color:green">' . Lang::get('lang.active') . '</p>';
                                } elseif ($model->status == 0) {
                                    return '<p class="btn btn-xs btn-default" style="pointer-events:none;color:red">' . Lang::get('lang.inactive') . '</p>';
                                }
                            })
                            ->editColumn('priority', function($model) {
                                $priority = "";
                                if ($model->target && $model->target->priority) {
                                    $priority = $model->target->priority->priority;
                                }
                                return $priority;
                            })
                            ->editColumn('created_at', function($model) {
                                return faveoDate($model->created_at);
                            })
                            ->editColumn('action', function ($model) {
                                if ($model->is_default > 0) {
                                    return '<a href="' . route('sla.edit', $model->id) . '" class="btn btn-primary btn-xs">
                                    <i class="fa fa-edit" style="color:white;"> </i>&nbsp;
                                     ' . \Lang::get('lang.edit') . '</a>&nbsp; <a href="#" class="btn btn-primary btn-xs" disabled="disabled">
                                     <i class="fa fa-trash" style="color:white;"> </i>&nbsp;
                                     ' . \Lang::get('lang.delete') . '</a>';
                                } else {

                                    $url = url('sla_plan/delete/' . $model->id);
                                    $confirmation = deletePopUp($model->id, $url, "Delete", 'btn btn-primary btn-xs');
                                    return '<a href="' . route('sla.edit', $model->id) . '" class="btn btn-primary btn-xs">
                                    <i class="fa fa-edit" style="color:white;"> </i>&nbsp;
                                     ' . \Lang::get('lang.edit') . '</a>&nbsp; 
                                     ' . $confirmation;
                                }
                            })
                            ->rawColumns(['name', 'status', 'action'])
                            ->make();
        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }

    /**
     * This method return organization department 
     * @param Request $request
     * @return type array
     */
    public function getMicroDepartment(Request $request)
    {
        $comapany = $request->input('comapany');
        $term = $request->input('term');

        $data = [];
        if ($comapany) {
            $orgId = Organization::whereIn('name', $comapany)->pluck('id')->toArray();
            $departments = DB::table('organization_dept')->where('org_deptname', 'LIKE', '%' . $term . '%')->whereIn('org_id', $orgId)->pluck('org_deptname', 'id')->toArray();

            if (count($departments)) {
                foreach ($departments as $key => $value) {
                    $data[] = ['label' => $value, 'value' => $key];
                }
            }
        }
        return $data;
    }

    /**
     * This method return departments
     * @param Request $request
     * @return type array
     */
    public function getDepartment(Request $request)
    {
        $term = $request->input('term');
        $selectDepts = Department::where('name', 'LIKE', '%' . $term . '%')->pluck('name', 'id')->toArray();
        $data = [];
        if (count($selectDepts)) {
            foreach ($selectDepts as $key => $value) {
                $data[] = ['label' => $value, 'value' => $key];
            }
        }
        return $data;
    }

    /**
     * This method return ticket sources
     * @param \Illuminate\Http\Request $request
     * @return type array
     */
    public function getTicketsources(Request $request)
    {
        $term = $request->input('term');
        $selectSources = Ticket_source::where('value', 'LIKE', '%' . $term . '%')->pluck('value', 'id')->toArray();
        $data = [];
        if (count($selectSources)) {
            foreach ($selectSources as $key => $value) {
                $data[] = ['label' => $value, 'value' => $key];
            }
        }
        return $data;
    }

    /**
     * This method return ticket types
     * @param \Illuminate\Http\Request $request
     * @return type array
     */
    public function getType(Request $request)
    {
        $term = $request->input('term');
        $selectTypes = Tickettype::where('name', 'LIKE', '%' . $term . '%')->where('status', '1')->pluck('name', 'id')->toArray();
        $data = [];
        if (count($selectTypes)) {
            foreach ($selectTypes as $key => $value) {
                $data[] = ['label' => $value, 'value' => $key];
            }
        }
        return $data;
    }

    /**
     * this method return organization
     * @param \Illuminate\Http\Request $request
     * @return type array
     */
    public function getCompany(Request $request)
    {
        $term = $request->input('term');
        $organization = new Organization();
        $selectOrgs = Organization::where('name', 'LIKE', '%' . $term . '%')->pluck('name', 'id')->toArray();
        $data = [];
        if (count($selectOrgs)) {
            foreach ($selectOrgs as $key => $value) {
                $data[] = ['label' => $value, 'value' => $key];
            }
        }
        return $data;
    }

    /**
     * This method return help-topic
     * @param \Illuminate\Http\Request $request
     * @return type array
     */
    public function getHelptopic(Request $request)
    {
        $term = $request->input('term');
        $selectHelptopics = Help_topic::where('topic', 'LIKE', '%' . $term . '%')->where('status', '1')->pluck('topic', 'id')->toArray();
        $data = [];
        if (count($selectHelptopics)) {
            foreach ($selectHelptopics as $key => $value) {
                $data[] = ['label' => $value, 'value' => $key];
            }
        }
        return $data;
    }

    /**
     * This method return labels
     * @param \Illuminate\Http\Request $request
     * @return type array
     */
    public function getSlaLabel(Request $request)
    {
        $term = $request->input('term');
        $selectLabels = Label::where('title', 'LIKE', '%' . $term . '%')->where('status', '1')->pluck('title', 'id')->toArray();
        $data = [];
        if (count($selectLabels)) {
            foreach ($selectLabels as $key => $value) {
                $data[] = ['label' => $value, 'value' => $key];
            }
        }
        return $data;
    }

    /**
     * This method return tages
     * @param \Illuminate\Http\Request $request
     * @return type array
     */
    public function getSlaTag(Request $request)
    {
        $term = $request->input('term');
        $selectTags = Tag::where('name', 'LIKE', '%' . $term . '%')->pluck('name', 'id')->toArray();
        $data = [];
        if (count($selectTags)) {
            foreach ($selectTags as $key => $value) {
                $data[] = ['label' => $value, 'value' => $key];
            }
        }
        return $data;
    }

    /**
     * this method Display active agent and admin as a array format. 
     * @param \Illuminate\Http\Request $request
     * @return type array
     */
    public function getAssigner(Request $request)
    {
        try {
            $default = array('assigner', 'admin', 'department manager', 'team lead');
            $term = $request->input('term');
            $user = User::where('email', 'LIKE', '%' . $term . '%')->where('role', '!=', 'user')->where('active', 1)->where('ban', '!=', 1)->where('is_delete', '!=', 1)->pluck('email', 'id')->toArray();

            $default = array_merge($user, $default);
            $fixed = [];
            foreach ($default as $value) {
                if (preg_match('/^' . $term . '/', $value))
                    array_push($fixed, $value);
            }

            $defaultArray=array_map('ucfirst',array_diff($fixed, $user));
            return array_merge($user, $defaultArray);
        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return type Response
     */
    public function create()
    {
        try {
            $label = Label::all();
            $tag = Tag::all();

            /* Direct to Create Page */
            return view('themes.default1.admin.helpdesk.manage.sla.create', compact('label', 'tag'));
        } catch (Exception $e) {

            return redirect()->back()->with('fails', $e->getMessage());
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return type Response
     */
    public function autofill()
    {
        try {
            /* Direct to Create Page */
            return view('themes.default1.admin.helpdesk.manage.sla.getautocomplete');
        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param type Sla_plan   $sla
     * @param type SlaRequest $request
     *
     * @return type Response
     */
    public function store(SlaRequest $request)
    {
        try {

            $orgDeptStatus = \App\Model\helpdesk\Settings\CommonSettings::where('option_name', 'micro_organization_status')->select('status')->first();
            if ($orgDeptStatus->status != 0) {
                $applySlaCompany = $request->apply_sla_companys;
                $applySlaOrgdept = $request->apply_sla_orgdept;
                if ($applySlaOrgdept) {
                    if (!$applySlaCompany) {
                        return redirect()->back()->with('fails', Lang::get('lang.please_select_company'));
                    }
                }
            }
            $sla = new Sla_plan();
            $sla->name = $request->name;
            $sla->admin_note = $request->admin_note;
            $sla->status = $request->status;
            $sla->save();
            $this->slaPlan($sla->id, $request->apply_sla_helptopic, $request->apply_sla_orgdept, $request->apply_sla_depertments, $request->apply_sla_companys, $request->apply_sla_tickettypes, $request->apply_sla_ticketsources, $request->apply_sla_labels, $request->apply_sla_tags);
            $applySla = Sla_plan::where('id', $sla->id)->first();
            $applySla->save();
            $this->saveCustomSLAEnforcements($request, $applySla);
            if ($request->approaches_response_escalate_time != 'null' && $request->approaches_response_escalate_person != null) {
                //sla approaches
                $emails = $request->approaches_response_escalate_person;
            }
            if ($request->approaches_response_escalate_time != 'null' && $emails != null) {
                $emails = array_map('strtolower', $request->approaches_response_escalate_person);
                $approachesEscalatePersonUserids = User::whereIn('email', $emails)->pluck('id')->toArray();
                $arrayName = array_intersect($emails, ['assigner', 'department manager', 'team lead', 'admin']);
                $responseEscalatePerson = implode(",", array_merge($approachesEscalatePersonUserids, $arrayName));
                if ($responseEscalatePerson) {
                    $this->slaApproachEscalate($sla->id, $request->approaches_response_escalate_time, 'response', $responseEscalatePerson);
                }
            }
            if ($request->approaches_resolution_escalate_time != 'null' && $request->approaches_resolution_escalate_person != null) {
                $resolutionEmails = array_map('strtolower', $request->approaches_resolution_escalate_person);
                $approachesEscalatePersonUserids = User::whereIn('email', $resolutionEmails)->pluck('id')->toArray();
                $arrayName = array_intersect($resolutionEmails, ['assigner', 'department manager', 'team lead', 'admin']);
                $resolutionEscalatePerson = implode(",", array_merge($approachesEscalatePersonUserids, $arrayName));
                if ($resolutionEscalatePerson) {
                    $this->slaApproachEscalate($sla->id, $request->approaches_resolution_escalate_time, 'resolution', $resolutionEscalatePerson);
                }
            }
            // violated
            if ($request->violated_response_escalate_time != 'null' && $request->violated_response_escalate_person != null) {
                $responseEmails = array_map('strtolower',$request->violated_response_escalate_person);
                $violatedEscalatePersonUserids = User::whereIn('email', $responseEmails)->pluck('id')->toArray();
                $arrayName = array_intersect($responseEmails, ['assigner', 'department manager', 'team lead', 'admin']);
                $violatedRespondedEscalatePerson = implode(",", array_merge($violatedEscalatePersonUserids, $arrayName));
                if ($violatedRespondedEscalatePerson) {
                    $this->slaViolatedEscalate($sla->id, $request->violated_response_escalate_time, 'response', $violatedRespondedEscalatePerson);
                }
            }
            for ($j = 0; $j < 5; $j++) {
                $violatedescalateTime = $request->input('violated_resolution_escalate_time' . $j);
                if ($violatedescalateTime && $request->input('violated_resolution_escalate_person' . $j) != null) {
                    $violatedResolvedEmails = array_map('strtolower',$request->input('violated_resolution_escalate_person' . $j));
                    $violatedEscalatePersonUserids = User::whereIn('email', $violatedResolvedEmails)->pluck('id')->toArray();
                    $arrayName = array_intersect($violatedResolvedEmails, ['assigner', 'department manager', 'team lead', 'admin']);
                    $slaViolatedResolvedUsers = implode(",", array_merge($violatedEscalatePersonUserids, $arrayName));
                    $violatedescalateTime = implode(",", $violatedescalateTime);
                    $this->slaViolatedEscalate($sla->id, $violatedescalateTime, 'resolution', $slaViolatedResolvedUsers);
                }
            }
            $targets = new SlaTargets;
            $targets->sla_id = $sla->id;
            $targets->priority_id = $request->sla_priority;
            $targets->respond_within = $request->response_count . '-' . $request->response_duration;
            $targets->resolve_within = $request->resolve_count . '-' . $request->resolve_duration;
            $targets->business_hour_id = $request->business_hour;
            $targets->send_email = $request->send_email;
            $targets->in_app = $request->in_app_notification;
            if ($request->filled('send_sms')) {
                $targets->send_sms = $request->send_sms;
            } else {
                $targets->send_sms = 0;
            }
            $targets->save();
            Sla_plan::where('id', $sla->id)->update(array('sla_target' => $targets->id));
            // Default sla
            if ($request->input('default_sla') == "1") {
                Sla_plan::where('is_default', '>', '0')
                        ->update(['is_default' => '0']);
                Sla_plan::where('id', '=', $sla->id)
                        ->update(['is_default' => 1, 'status' => 1]);
            }
            /* redirect to Index page with Success Message */
            return redirect('sla')->with('success', Lang::get('lang.sla_plan_saved_successfully'));
        } catch (Exception $e) {

            /* redirect to Index page with Fails Message */
            return redirect('sla')->with('fails', Lang::get('lang.sla_plan_can_not_create') . '<li>' . $e->getMessage() . '</li>');
        }
    }

    /**
     * 
     * @param type $id of Sla_plan
     * @param type $applySlaHelptopic
     * @param type $applySlaOrgdept
     * @param type $applySlaDepertment
     * @param type $applySlaCompanys
     * @param type $applySlaTickettypes
     * @param type $applySlaTicketSources
     * @param type $applySlaLabels
     * @param type $applySlaTags
     */
    private function slaPlan($id, $applySlaHelptopic, $applySlaOrgdept, $applySlaDepertment, $applySlaCompanys, $applySlaTickettypes, $applySlaTicketSources, $applySlaLabels, $applySlaTags)
    {

        $applySla = Sla_plan::where('id', $id)->first();

        $applySla->apply_sla_helptopic = ($applySlaHelptopic) ? implode(",", $applySlaHelptopic) : null;
        $applySla->apply_sla_orgdepts = ($applySlaOrgdept) ? implode(",", $applySlaOrgdept) : null;
        $applySla->apply_sla_depertment = ($applySlaDepertment) ? implode(",", $applySlaDepertment) : null;
        $applySla->apply_sla_company = ($applySlaCompanys) ? implode(",", $applySlaCompanys) : null;
        $applySla->apply_sla_tickettype = ($applySlaTickettypes) ? implode(",", $applySlaTickettypes) : null;
        $applySla->apply_sla_ticketsource = ($applySlaTicketSources) ? implode(",", $applySlaTicketSources) : null;
        $applySla->apply_sla_labels = ($applySlaLabels) ? implode(",", $applySlaLabels) : null;
        $applySla->apply_sla_tags = ($applySlaTags) ? implode(",", $applySlaTags) : null;

        $applySla->save();
    }

    /**
     * this method store value in sal approach escalate table
     * @param type $slaPlan
     * @param type $escalateTime
     * @param type $escalateType
     * @param type $escalatePerson
     */
    private function slaApproachEscalate($slaPlan, $escalateTime, $escalateType, $escalatePerson)
    {
        $newEscalate = new SlaApproachEscalate();
        $newEscalate->sla_plan = $slaPlan;
        $newEscalate->escalate_time = $escalateTime;
        $newEscalate->escalate_type = $escalateType;
        $newEscalate->escalate_person = $escalatePerson;
        $newEscalate->save();
    }

    /**
     * this method store value in sal Violated escalate table
     * @param type $slaPlan
     * @param type $escalateTime
     * @param type $escalateType
     * @param type $escalatePerson
     */
    private function slaViolatedEscalate($slaPlan, $escalateTime, $escalateType, $escalatePerson)
    {
        $newEscalate = new SlaViolatedEscalate();
        $newEscalate->sla_plan = $slaPlan;
        $newEscalate->escalate_time = $escalateTime;
        $newEscalate->escalate_type = $escalateType;
        $newEscalate->escalate_person = $escalatePerson;
        $newEscalate->save();
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param type int      $id
     * @param type Sla_plan $sla
     *
     * @return type Response
     */
    public function edit($id)
    {
        try {
            $approaches_response_escalate_person = [];
            $approaches_resolution_escalate_person = [];
            $violated_response_escalate_person = [];
            $violated_resolution_escalate_person = [];
            $apply_sla_depertment = [];
            $apply_sla_company = [];
            $apply_sla_tickettype = [];
            $apply_sla_ticketsource = [];
            $sla_target_priority_id = null;
            /* Direct to edit page along values of perticular field using Id */
            $slas = Sla_plan::whereId($id)->first();
            if ($slas) {
                if ($slas->apply_sla_helptopic == "") {
                    $apply_sla_helptopic = "";
                } else {
                    $helptopic = Help_topic::whereIn('id', $slas->apply_sla_helptopic)->pluck('topic', 'id')->toArray();
                    foreach ($helptopic as $key => $value) {
                        $apply_sla_helptopic[] = ['label' => $value, 'value' => $key];
                    }
                }
                // organization department
                if ($slas->apply_sla_orgdepts == "") {
                    $apply_sla_orgdepts = "";
                } else {

                    $orgdepts = OrganizationDepartment::whereIn('id', $slas->apply_sla_orgdepts)->pluck('org_deptname', 'id')->toArray();

                    foreach ($orgdepts as $key => $value) {
                        $apply_sla_orgdepts[] = ['label' => $value, 'value' => $key];
                    }
                }

                if ($slas->apply_sla_depertment == "") {
                    $apply_sla_depertment = "";
                } else {
                    $depertments = Department::whereIn('id', $slas->apply_sla_depertment)->pluck('name', 'id')->toArray();
                    foreach ($depertments as $key => $value) {
                        $apply_sla_depertment[] = ['label' => $value, 'value' => $key];
                    }
                }


                if ($slas->apply_sla_company == "") {
                    $apply_sla_company = "";
                } else {
                    $company = Organization::whereIn('id', $slas->apply_sla_company)->pluck('name', 'id')->toArray();
                     foreach ($company as $key => $value) {
                        $apply_sla_company[] = ['label' => $value, 'value' => $key];
                    }
                }

                if ($slas->apply_sla_tickettype == "") {
                    $apply_sla_tickettype = "";
                } else {
                    $tickettypes = Tickettype::whereIn('id', $slas->apply_sla_tickettype)->pluck('name', 'id')->toArray();
                    foreach ($tickettypes as $key => $value) {
                        $apply_sla_tickettype[] = ['label' => $value, 'value' => $key];
                    }
                }
                if ($slas->apply_sla_ticketsource == "") {
                    $apply_sla_ticketsource = "";
                } else {
                    $ticketsources = Ticket_source::whereIn('id', $slas->apply_sla_ticketsource)->pluck('value', 'id')->toArray();
                    foreach ($ticketsources as $key => $value) {
                        $apply_sla_ticketsource[] = ['label' => $value, 'value' => $key];
                    }
                }
                if ($slas->apply_sla_labels == "") {
                    $apply_sla_labels = "";
                } else {

                    $tages = Label::whereIn('id', $slas->apply_sla_labels)->pluck('title', 'id')->toArray();
                    foreach ($tages as $key => $value) {
                        $apply_sla_labels[] = ['label' => $value, 'value' => $key];
                    }
                   
                }
                if ($slas->apply_sla_tags == "") {
                    $apply_sla_tags = "";
                } else {

                    $tages = Tag::whereIn('id', $slas->apply_sla_tags)->pluck('name', 'id')->toArray();
                    foreach ($tages as $key => $value) {
                        $apply_sla_tags[] = ['label' => $value, 'value' => $key];
                    }
                }
            } else {
                return redirect()->to('400')->with('fails', Lang::get('lang.not_found'));
            }
            $sla_approaches_response_time = SlaApproachEscalate::where('sla_plan', '=', $id)->where('escalate_type', '=', 'response')->pluck('escalate_time')->toArray();
            $sla_approaches_response = SlaApproachEscalate::where('sla_plan', '=', $id)->where('escalate_type', '=', 'response')->pluck('escalate_person', 'escalate_time')->toArray();
            if (!empty($sla_approaches_response_time)) {
                foreach ($sla_approaches_response as $key => $value) {
                    $sla_approaches_response_person1 = str_replace('_', " ", $value);
                    $sla_approaches_response_person = array_filter($sla_approaches_response_person1, 'strlen');
                    $definite_articles = array('assigner', 'department manager', 'team lead', 'admin');
                    $response_person_user_ids = array_diff($sla_approaches_response_person, $definite_articles);
                    if ($response_person_user_ids) {
                        foreach ($response_person_user_ids as $response_person_user_id) {
                            $sla_approaches_response_person_user_emails[] = user::where('id', '=', $response_person_user_id)->pluck('email')->first();
                        }
                    
                        $sla_approaches_response_fixed_person = array_map('ucfirst', array_diff($sla_approaches_response_person, $response_person_user_ids));

                        $sla_approaches_response_person = [array_merge($sla_approaches_response_fixed_person, $sla_approaches_response_person_user_emails)];



                        $sla_approaches_response_persons = array_combine($sla_approaches_response_time, $sla_approaches_response_person);



                    } else {

                      
                        $sla_approaches_response_persons = array_combine($sla_approaches_response_time, [array_map('ucfirst',$sla_approaches_response_person)]);
                    }
                }
            } else {
                $sla_approaches_response_persons = [];
            }

            $sla_approaches_resolution_time = SlaApproachEscalate::where('sla_plan', $id)->where('escalate_type', 'resolution')->pluck('escalate_time')->toArray();
            $sla_approaches_resolution = SlaApproachEscalate::where('sla_plan', $id)->where('escalate_type', 'resolution')->pluck('escalate_person', 'escalate_time')->toArray();
            ;
            if (!empty($sla_approaches_resolution_time)) {
                foreach ($sla_approaches_resolution as $key => $value) {
                    $sla_approaches_resolution_person1 = str_replace('_', " ", $value);
                    $sla_approaches_resolution_person = array_filter($sla_approaches_resolution_person1, 'strlen');
                    $definite_articles = array('assigner', 'department manager', 'team lead', 'admin');
                    $responded_person_user_ids = array_diff($sla_approaches_resolution_person, $definite_articles);
                    if ($responded_person_user_ids) {
                        foreach ($responded_person_user_ids as $responded_person_user_id) {
                            $sla_approaches_resolution_person_user_emails[] = user::where('id', $responded_person_user_id)->pluck('email')->first();
                        }
                        $sla_approaches_resolution_fixed_person = array_map('ucfirst',array_diff($sla_approaches_resolution_person, $responded_person_user_ids));
                        $sla_approaches_resolution_person = array_merge($sla_approaches_resolution_person_user_emails, $sla_approaches_resolution_fixed_person);
                        $sla_approaches_resolution_persons = array_combine($sla_approaches_resolution_time, [$sla_approaches_resolution_person]);
                    } else {
                        $sla_approaches_resolution_persons = array_combine($sla_approaches_resolution_time, [array_map('ucfirst',$sla_approaches_resolution_person)]);
                    }
                }
            } else {
                $sla_approaches_resolution_persons = [];
            }
            $sla_violated_responded_time = SlaViolatedEscalate::where('sla_plan', $id)->where('escalate_type', 'response')->pluck('escalate_time')->toArray();

            $sla_violated_responded = SlaViolatedEscalate::where('sla_plan', $id)->where('escalate_type', 'response')->pluck('escalate_person', 'escalate_time')->toArray();
            if (!empty($sla_violated_responded_time)) {
                foreach ($sla_violated_responded as $key => $value) {
                    # code...
                    $sla_violated_responded_person1 = str_replace('_', " ", $value);
                    $sla_violated_responded_person = array_filter($sla_violated_responded_person1, 'strlen');
                    $definite_articles = array('assigner', 'department manager', 'team lead', 'admin');
                    $responded_person_user_ids = array_diff($sla_violated_responded_person, $definite_articles);
                    if ($responded_person_user_ids) {
                        foreach ($responded_person_user_ids as $responded_person_user_id) {
                            $sla_violated_responded_person_user_emails[] = user::where('id', '=', $responded_person_user_id)->pluck('email')->first();
                        }
                        $sla_violated_responded_fixed_person = array_map('ucfirst',array_diff($sla_violated_responded_person, $responded_person_user_ids));
                        $sla_violated_responded_personss[] = array_merge($sla_violated_responded_person_user_emails, $sla_violated_responded_fixed_person);
                    } else {
                        $sla_violated_responded_personss = [array_map('ucfirst',$sla_violated_responded_person)];
                    }
                }
                $violated_responded_persons = array_combine($sla_violated_responded_time, $sla_violated_responded_personss);
            } else {
                $violated_responded_persons = [];
            }
// violated Resolved  
            $slaViolatedResolvedListsTimes = SlaViolatedEscalate::where('sla_plan', $id)->where('escalate_type', 'resolution')->pluck('escalate_time')->toArray();
            $slaViolatedResolvedLists = SlaViolatedEscalate::where('sla_plan', $id)->where('escalate_type', 'resolution')->pluck('escalate_person', 'escalate_time')->toArray();
             if ($slaViolatedResolvedLists) {
                foreach ($slaViolatedResolvedLists as $key => $value) {
                    $slaViolatedResolvedPerson = array_filter(str_replace('_', " ", $value), 'strlen');
                    $defaultArray = array('assigner', 'department manager', 'team lead', 'admin');
                    $resolvedPersonUser = array_diff($slaViolatedResolvedPerson, $defaultArray);
                    $slaViolatedRespondedPersonUserEmails = user::whereIn('id', $resolvedPersonUser)->pluck('email')->toArray();
                    $slaViolatedRespondedFixedPerson = array_map('ucfirst',array_diff($slaViolatedResolvedPerson, $resolvedPersonUser));
                    $slaViolatedRespondedPersons[] = array_merge($slaViolatedRespondedFixedPerson, $slaViolatedRespondedPersonUserEmails);
                 }

                $violated_resolved_time_persons = array_combine($slaViolatedResolvedListsTimes, $slaViolatedRespondedPersons);
            } else {
                $violated_resolved_time_persons = null;
            }
            $sla_target = SlaTargets::where('sla_id', $id)->first();
            if ($sla_target) {
                $sla_target_priority_id = $sla_target->priority_id;
            }
            $customSLAEnforcements = $slas->customSLAEnforcements()->select('f_value', 'f_name', 'f_label', 'f_type')->get()->toArray();
            $customSLAEnforcements = addslashes(json_encode($customSLAEnforcements));
         return view('themes.default1.admin.helpdesk.manage.sla.edit', compact('slas', 'sla_target', 'sla_target_priority_id', 'apply_sla_helptopic', 'apply_sla_depertment', 'apply_sla_orgdepts', 'apply_sla_company', 'apply_sla_tickettype', 'apply_sla_ticketsource', 'sla_approaches_response_persons', 'sla_approaches_resolution_persons', 'sla_approaches_resolution_person_user_emails', 'sla_violated_responded_fixed_person', 'sla_violated_responded_person_user_emails', 'sla_violated_resolved_lists', 'violated_responded_persons', 'violated_resolved_time_persons', 'sla_violated_responded_persons', 'sla_approaches_response_time', 'sla_approaches_resolution_time', 'sla_violated_responded_time', 'apply_sla_tags', 'apply_sla_labels', 'customSLAEnforcements'));
        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param type int       $id
     * @param type Sla_plan  $sla
     * @param type SlaUpdate $request
     *
     * @return type Response
     */
    public function update($id, SlaUpdateRequest $request)
    {
        try {

            $checkOrganizationDeptStatus = \App\Model\helpdesk\Settings\CommonSettings::where('option_name', 'micro_organization_status')->select('status')->first();
            if ($checkOrganizationDeptStatus->status != 0) {
                $applySlaCompany = $request->apply_sla_companys;
                $applySlaOrgdept = $request->apply_sla_orgdept;
                if ($applySlaOrgdept) {
                    if (!$applySlaCompany) {
                        return redirect()->back()->with('fails', Lang::get('lang.please_select_company'));
                    }
                }
            }
            $sla = Sla_plan::whereId($id)->first();
            $defaultSla = Sla_plan::where('is_default', 1)->first();
            $sla = Sla_plan::where('id', $id)->first();
            $sla->name = $request->name;
            $sla->admin_note = $request->admin_note;
            $sla->status = $request->status;
            $sla->save();
            $this->slaPlan($sla->id, $request->apply_sla_helptopic, $request->apply_sla_orgdept, $request->apply_sla_depertment, $request->apply_sla_companys, $request->apply_sla_tickettypes, $request->apply_sla_ticketsources, $request->apply_sla_labels, $request->apply_sla_tags);
            $this->updateCustomSLAEnforcements($request, $sla);
            //sla approaches
            SlaApproachEscalate::where('sla_plan', $id)->delete();
            SlaViolatedEscalate::where('sla_plan', $id)->delete();
            if ($request->approaches_response_escalate_time != 'null' && $request->approaches_response_escalate_person != null) {
                $emails = array_map('strtolower',$request->approaches_response_escalate_person);
                $approachesEscalatePersonUserids = User::whereIn('email', $emails)->pluck('id')->toArray();
                $arrayName = array_intersect($emails, ['assigner', 'department manager', 'team lead', 'admin']);
                $responseEscalatePerson = implode(",", array_merge($approachesEscalatePersonUserids, $arrayName));


                if ($responseEscalatePerson) {
                    $this->slaApproachEscalate($sla->id, $request->approaches_response_escalate_time, 'response', $responseEscalatePerson);
                }
            }
            if ($request->approaches_resolution_escalate_time != 'null' && $request->approaches_resolution_escalate_person != null) {
                $resolutionEmails = array_map('strtolower',$request->approaches_resolution_escalate_person);
                $approachesEscalatePersonUserids = User::whereIn('email', $resolutionEmails)->pluck('id')->toArray();
                $arrayName = array_intersect($resolutionEmails, ['assigner', 'department manager', 'team lead', 'admin']);
                $resolutionEscalatePerson = implode(",", array_merge($approachesEscalatePersonUserids, $arrayName));
                if ($resolutionEscalatePerson) {
                    $this->slaApproachEscalate($sla->id, $request->approaches_resolution_escalate_time, 'resolution', $resolutionEscalatePerson);
                }
            }
            // violated
            if ($request->violated_response_escalate_time != 'null' && $request->violated_response_escalate_person != null) {
                $responseEmails = array_map('strtolower',$request->violated_response_escalate_person);
                $violatedEscalatePersonUserids = User::whereIn('email', $responseEmails)->pluck('id')->toArray();
                $arrayName = array_intersect($responseEmails, ['assigner', 'department manager', 'team lead', 'admin']);
                $violatedRespondedEscalatePerson = implode(",", array_merge($violatedEscalatePersonUserids, $arrayName));
                if ($violatedRespondedEscalatePerson) {
                    $this->slaViolatedEscalate($sla->id, $request->violated_response_escalate_time, 'response', $violatedRespondedEscalatePerson);
                }
            }
            SlaViolatedEscalate::where('sla_plan', $sla->id)->where('escalate_type', 'resolution')->delete();
            for ($j = 0; $j < 5; $j++) {
                $violatedescalateTime = $request->input('violated_resolution_escalate_time' . $j);
                if ( $violatedescalateTime && $request->input('violated_resolution_escalate_person' . $j) != null) {
                    $violatedResolvedEmails = array_map('strtolower',$request->input('violated_resolution_escalate_person' . $j));
                    $violatedEscalatePersonUserids = User::whereIn('email', $violatedResolvedEmails)->pluck('id')->toArray();
                    $arrayName = array_intersect($violatedResolvedEmails, ['assigner', 'department manager', 'team lead', 'admin']);
                    $slaViolatedResolvedUsers = implode(",", array_merge($violatedEscalatePersonUserids, $arrayName));
                    $violatedescalateTime = implode(",", $violatedescalateTime);
                    $this->slaViolatedEscalate($sla->id, $violatedescalateTime, 'resolution', $slaViolatedResolvedUsers);
                }
            }
            $targets = $sla->target; //SlaTargets::where('sla_id', '=', $slas->id)->first();
            if (!$targets) {
                $targets = new SlaTargets();
            }

            $targets->sla_id = $sla->id;
            $targets->priority_id = $request->sla_priority;
            $response_count = 0;
            $resolve_count = 0;
            if ($request->response_count != "") {
                $response_count = $request->response_count;
            }
            if ($request->resolve_count != "") {
                $resolve_count = $request->resolve_count;
            }
            $targets->respond_within = $response_count . '-' . $request->response_duration;
            $targets->resolve_within = $resolve_count . '-' . $request->resolve_duration;
            $targets->business_hour_id = $request->business_hour;
            $targets->send_email = $request->send_email;
            $targets->in_app = $request->in_app_notification;
            if ($request->filled('send_sms')) {
                $targets->send_sms = $request->send_sms;
            } else {
                $targets->send_sms = 0;
            }
            $targets->save();
            $sla_target_id = $targets->id;
            Sla_plan::where('id', $id)->update(array('sla_target' => $sla_target_id));
            if ($request->input('defaultSla') == 'on') {
                Sla_plan::where('is_default', '>', '0')
                        ->update(['is_default' => '0']);
                Sla_plan::where('id', '=', $id)
                        ->update(['is_default' => 1, 'status' => 1]);
            }
            return redirect('sla')->with('success', Lang::get('lang.sla_plan_updated_successfully'));
        } catch (Exception $e) {
            
            /* redirect to Index page with Fails Message */
            return redirect('sla')->with('fails', Lang::get('lang.sla_plan_can_not_update') . '<li>' . $e->getMessage() . '</li>');
        }
    }

    /**
     * 
     * @param type $sla_model
     */
    public function updateDuedate($sla_model)
    {
        $apply = new \App\Http\Controllers\SLA\ApplySla();
        $slaid = $sla_model->id;
        $sla = $apply->sla($slaid);
        $sla_model->tickets()->chunk(100, function($tickets) use($sla, $slaid, $apply) {
            foreach ($tickets as $ticket) {
                $created_at = $ticket->created_at;
                $answered = $ticket->isanswered;
                if ($answered == 1) {
                    $time = $sla->resolveTime();
                } else {
                    $time = $sla->respondTime();
                }
                $total = $ticket->halt()->sum('halted_time');
                $resolve = $time + $total;
                $due = $apply->slaResolveDue($slaid, $created_at, $resolve, $ticket)->tz('UTC');
                $ticket->duedate = $due;
                $ticket->save();
            }
        });
    }

    /**
     * 
     * @param type $slaid
     * @param type $ticket_created
     * @return type
     */
    public function responseOverdue($slaid, $ticket_created)
    {
        $sla = new \App\Http\Controllers\SLA\ApplySla();
        $responds_due = $sla->slaRespondsDue($slaid, faveotime($ticket_created->timezone(timezone()), true, true, true))->timezone('UTC');
        return $responds_due;
    }

    /**
     * 
     * @param type $slaid
     * @param type $ticket_created
     * @param type $sla_time
     * @param type $ticket
     * @return type
     */
    public function resolveOverdue($slaid, $ticket_created, $sla_time = "", $ticket)
    {
        $sla = new \App\Http\Controllers\SLA\ApplySla();
        $resolve_due = $sla->slaResolveDue($slaid, faveotime($ticket_created->timezone(timezone()), true, true, true), "", $ticket)->timezone('UTC');
        return $resolve_due;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param type int      $id
     * @param type Sla_plan $sla
     *
     * @return type Response
     */
    public function destroy($id)
    {

       SlaCustomEnforcements::where('sla_id',$id)->delete();
        $defaultSla = Sla_plan::where('is_default', '>', '0')->first();
        if ($defaultSla->id == $id) {
            return redirect('departments')->with('fails', Lang::get('lang.you_cannot_delete_default_department'));
        } else {
            // escalate delete
           SlaApproachEscalate::where('sla_plan', $id)->delete();
           SlaViolatedEscalate::where('sla_plan', $id)->delete();
            $tickets = DB::table('tickets')->where('sla', '=', $id)->update(['sla' => $defaultSla->id]);
            if ($tickets > 0) {
                if ($tickets > 1) {
                    $text_tickets = 'Tickets';
                } else {
                    $text_tickets = 'Ticket';
                }
                $ticket = '<li>' . $tickets . ' ' . $text_tickets . Lang::get('lang.have_been_moved_to_default_sla') . '</li>';
            } else {
                $ticket = '';
            }

            $message = $ticket;
            /* Delete a perticular field from the database by delete() using Id */
            $slas = Sla_plan::whereId($id)->first();
            /* Check whether function success or not */
            try {
                $slas->delete();
                SlaTargets::where('sla_id', $id)->delete();
                /* redirect to Index page with Success Message */
                return redirect('sla')->with('success', Lang::get('lang.sla_plan_deleted_successfully') . $message);
            } catch (Exception $e) {
                /* redirect to Index page with Fails Message */
                return redirect('sla')->with('fails', Lang::get('lang.sla_plan_can_not_delete') . '<li>' . $e->getMessage() . '</li>');
            }
        }
    }

    public function order(Request $request)
    {
        try {
            $list = $request->input('order');
            foreach ($list as $order => $sla) {
                if (is_numeric($order)) {
                    Sla_plan::whereId($sla['id'])->update(['order' => $order]);
                }
            }
            $message = ['message' => \Lang::get('lang.ordered_successfully')];
            $status = 200;
        } catch (\Exception $e) {
            $message = ['error' => $e->getMessage()];
            $status = 500;
        }
        return response()->json($message, $status);
    }

    public function conditionType(Request $request)
    {
        try {
            $type = $request->input('condtion_type');
            \App\Model\helpdesk\Settings\CommonSettings::updateOrCreate(['option_name' => 'sla_condition'], ['option_value' => $type]);
            $message = ['message' => \Lang::get('lang.condition_changed')];
            $status = 200;
        } catch (\Exception $e) {
            $message = ['error' => $e->getMessage()];
            $status = 500;
        }
        return response()->json($message, $status);
    }

    /**
     * function to save custom enforcement data while creating SLA
     * @param  Object   $request
     * @param  Integer  $applySla  id of a newly created SLA
     * @return Boolean
     */
    private function saveCustomSLAEnforcements($request, $applySla)
    {
        $custom = $this->filterCustomFieldsFromRequest($request);
        if (!empty($custom))
            $applySla->customSLAEnforcements()->createMany($custom);
        return true;
    }

    /**
     * function to save custom enforcement data while editing SLA
     * @param  Object  $request
     * @param  Integer $sla      id of SLA which is updating
     * @return Boolean
     */
    private function updateCustomSLAEnforcements($request, $sla)
    {
        $custom = $this->filterCustomFieldsFromRequest($request);
        $sla->customSLAEnforcements()->delete();
        if (empty($custom))
            return true;
        $sla->customSLAEnforcements()->createMany($custom);
        return true;
    }

    /**
     * Function formats requet and returns an Array of custom enforments
     * @param   Request Object  $request
     * @var     Array           $custom   array which will store mulitple array of custom enforment data 
     * @var     Integer         $count    counter which counts iteration of loops
     * @return  Array                     array containing array of custom enforcment data in required key value format
     */
    private function filterCustomFieldsFromRequest($request)
    {
        $custom = [];
        $cntr = 0; //counter
        foreach ($request->all() as $key => $value) {
            if (strpos($key, '+||+') && $value != '') {
                $field = explode('+||+', $key);
                $custom[$cntr]['f_label'] = $field[2];
                $custom[$cntr]['f_type'] = $field[1];
                $custom[$cntr]['f_value'] = $value;
                $custom[$cntr]['f_name'] = $field[0];
                $cntr++;
            }
        }
        return $custom;
    }

}
