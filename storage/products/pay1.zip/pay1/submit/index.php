
<?php
session_start();
ob_start();
error_reporting(-1);
ini_set("display_errors", 1);
@session_save_path("./");
include('../config.php');
//require('functions.php');
include('../crypto.php');
// $_COOKIE["test"] = "testvalue";
//error_reporting(0);
//error_reporting(E_ALL);
//ini_set('display_errors', 1);

function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

?>
<?php

if(isset($_POST['g-recaptcha-response']) && !empty($_POST['g-recaptcha-response'])){

    $secret = '6LfaLjQUAAAAAPXUQ8ERpcgt-q9GxnD1iRIpAUX6';
        //get verify response data
        $verifyResponse = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret='.$secret.'&response='.$_POST['g-recaptcha-response']);
        $responseData = json_decode($verifyResponse);
        if(!$responseData->success){
            echo "<script> 
                setTimeout(function() {
                    alert('Request failed please try again')
                  location.href='https://www.faveohelpdesk.com/pay/' 
                }, 1000);
             </script>";
        }
}
else{
    echo "<script> 
                setTimeout(function() {
                    alert('Request failed please try again')
                  location.href='https://www.faveohelpdesk.com/pay/' 
                }, 1000);
             </script>";
}

function redirect($url, $permanent = false) {
	if($permanent) {
		header('HTTPS/1.1 301 Moved Permanently');
	}
	header('Location: '.$url);
	exit();
}


?>
<!DOCTYPE html>
<html>
<head>

<!-- Basic -->
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>Faveo | Online Payment</title>
<meta name="keywords" content="HTML5 Template" />
<meta name="description" content="Porto - Responsive HTML5 Template">
<meta name="author" content="okler.net">

<!-- Favicon -->
<link rel="shortcut icon" href="../img/favicon.png" type="image/x-icon" />
<link rel="apple-touch-icon" href="../img/favivon.png">

<!-- Mobile Metas -->
<meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">

<!-- Web Fonts  -->
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800%7CShadows+Into+Light" rel="stylesheet" type="text/css">

<!-- Vendor CSS -->
<link rel="stylesheet" href="../vendor/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="../vendor/font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" href="../vendor/simple-line-icons/css/simple-line-icons.min.css">
<link rel="stylesheet" href="../vendor/owl.carousel/assets/owl.carousel.min.css">
<link rel="stylesheet" href="../vendor/owl.carousel/assets/owl.theme.default.min.css">
<link rel="stylesheet" href="../vendor/magnific-popup/magnific-popup.min.css">

<!-- Theme CSS -->
<link rel="stylesheet" href="../css/theme.css">
<link rel="stylesheet" href="../css/theme-elements.css">
<link rel="stylesheet" href="../css/theme-blog.css">
<link rel="stylesheet" href="../css/theme-shop.css">
<link rel="stylesheet" href="../css/theme-animate.css">

<!-- Skin CSS -->
<link rel="stylesheet" href="../css/skins/default.css">

<!-- Theme Custom CSS -->
<link rel="stylesheet" href="../css/custom.css">

<!-- Head Libs -->
<script src="../vendor/modernizr/modernizr.min.js"></script>
</head>
<body>
<div class="body">
  <header id="header" data-plugin-options='{"stickyEnabled": true, "stickyEnableOnBoxed": true, "stickyEnableOnMobile": true, "stickyStartAt": 57, "stickySetTop": "-57px", "stickyChangeLogo": true}'>
  <div class="header-body">
    <div class="header-container container">
      <div class="header-row">
        <div class="header-column">
          <div class="header-logo"> <a href="index.html"> <img alt="Porto" width="111" height="54" data-sticky-width="82" data-sticky-height="40" data-sticky-top="33" src="../img/faveo.png"> </a> </div>
        </div>
        <div class="header-column">
          <div class="header-row">
            <div class="header-search hidden-xs"> </div>
          </div>
          <div class="header-row">
            <div class="header-nav">
              <button class="btn header-btn-collapse-nav" data-toggle="collapse" data-target=".header-nav-main"> <i class="fa fa-bars"></i> </button>
              <div class="header-nav-main header-nav-main-effect-1 header-nav-main-sub-effect-1 collapse">
                <nav>
                <ul class="nav nav-pills" id="mainNav">
                  <li> <a href="http://faveohelpdesk.com/billing/home"> Pricing </a> </li>
                  <li> <a href="http://faveohelpdesk.com/billing/contact-us"> Contact Us </a> </li>
                  <li > <a  href="http://faveohelpdesk.com/billing/auth/login"> Login </a> </li>
                </ul>
              </div>
              </li>
              </ul>
              </li>
              </ul>
              </nav>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</header>
<div role="main" class="main shop">
  <section class="page-header">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <ul class="breadcrumb">
            <li><a href="#">Home</a> </li>
            <li class="active">Payment</li>
          </ul>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12">
          <h1>Online Payment</h1>
        </div>
      </div>
    </div>
  </section>
  <div class="container">
    <section class="page-not-found">
      <div class="row">
        <div style="text-align:center;">
          <div class="page-not-found-main">
            <p> <img  src="../img/ajax-loader.gif"/></p>
            <h3>Transaction is being processed </h3>
            <p>Please wait while your transaction is being processed ... </p>
            <p> (Please do not use "Refresh" or "Back" button)</p>
          </div>
        </div>
      </div>
    </section>
  </div>
</div>
<footer id="footer">
  <div class="container">
    <div class="row">
      <div class="footer-ribbon"> <span>Get in Touch</span> </div>
      <div class="col-md-3">
        <div class="newsletter">
          <h4>Newsletter</h4>
          <p>Keep up on our always evolving product features and technology. Enter your e-mail and subscribe to our newsletter.</p>
          <div class="alert alert-success hidden" id="newsletterSuccess"> <strong>Success!</strong> You've been added to our email list. </div>
          <div class="alert alert-danger hidden" id="newsletterError"></div>
          <form id="newsletterForm" action="php/newsletter-subscribe.php" method="POST">
            <div class="input-group">
              <input class="form-control" placeholder="Email Address" name="newsletterEmail" id="newsletterEmail" type="text">
              <span class="input-group-btn">
              <button class="btn btn-default" type="submit">Go!</button>
              </span> </div>
          </form>
        </div>
      </div>
      <div class="col-md-3">
        <h4>Latest Tweets</h4>
        <div id="tweet" class="twitter" data-plugin-tweets data-plugin-options='{"username": "", "count": 2}'>
          <p>Please wait...</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="contact-details">
          <h4>Contact Us</h4>
          <ul class="contact">
            <li>
              <p><i class="fa fa-map-marker"></i> <strong>Address:</strong> Century Paradise, D302, 115/3, Tejaswini Nagar, Dodda Kammanahalli, Bannerghatta Road, Bangalore 560 076, Karnataka, India</p>
            </li>
            <li>
              <p><i class="fa fa-phone"></i> <strong>Phone:</strong> +91 80 3075 2618</p>
            </li>
            <li>
              <p><i class="fa fa-envelope"></i> <strong>Email:</strong> <a href="mailto:support@ladybirdweb.com">support@ladybirdweb.com</a></p>
            </li>
          </ul>
        </div>
      </div>
      <div class="col-md-2">
        <h4>Follow Us</h4>
        <ul class="social-icons">
          <li class="social-icons-facebook"><a href="https://www.facebook.com/faveohelpdesk" target="_blank" title="Facebook"><i class="fa fa-facebook"></i></a></li>
          <li class="social-icons-twitter"><a href="https://twitter.com/faveohelpdesk" target="_blank" title="Twitter"><i class="fa fa-twitter"></i></a></li>
          <li class="social-icons-linkedin"><a href="https://www.linkedin.com/groups/8429668" target="_blank" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
        </ul>
      </div>
    </div>
  </div>
  <div class="footer-copyright">
    <div class="container">
      <div class="row">
        <div class="col-md-7">
          <p>Copyright © 2016. Ladybird Web Solution Pvt Ltd. All Rights Reserved. Powered by <a href="http://www.ladybirdweb.com" target="_blank"><img src="../img/Ladybird1.png" alt="Ladybird" /></a></p>
        </div>
      </div>
    </div>
  </div>
</footer>
</div>
<script src="../vendor/jquery/jquery.min.js"></script> 
<?php 
//echo "Mode". $_POST['payment-gateway'];
//Read Form data
	
	$order_id= generateRandomString();        
	$amount=$_POST['amount'];            
	$currency=$_POST['currency'];
	$billing_name=$_POST['billing_name'];
	$billing_address=$_POST['billing_address'];
	$billing_city=$_POST['billing_city'];
	$billing_state=$_POST['billing_state'];
	$billing_zip=$_POST['billing_zip'];
	$billing_country=$_POST['billing_country'];
	$billing_tel=$_POST['billing_tel'];
	$billing_email=$_POST['billing_email'];
	$delivery_name=$_POST['billing_name'];
	$delivery_address=$_POST['billing_address'];
	$delivery_city=$_POST['billing_city'];
	$delivery_state=$_POST['billing_state'];
	$delivery_zip=$_POST['billing_zip'];
	$delivery_country=$_POST['billing_country'];
	$delivery_tel=$_POST['billing_tel'];	
	$productinfo="Faveo Helpdesk";
	$message=$_POST['message-box'];
	$gateway=$_POST['payment-gateway'];
	$service_provider1 = "payu_paisa";
	
	// send email	

// $email_to = "support@ladybirdweb.com";
$email_to = "grgabhi28@gmail.com";
$email_from = "do_not_reply@faveohelpdesk.com";
$email_subject = "New order";
$email_message  = "<b>Order ID:</b> ".$order_id."<br/>";
$email_message .= "<b>Amount:</b> ".$amount."<br/>";
$email_message .= "<b>Currency:</b> ".$currency."<br/>";
$email_message .= "<b>Name:</b> ".$billing_name."<br/>";
$email_message .= "<b>Address:</b> ".$billing_address."<br/>";
$email_message .= "<b>City:</b> ".$billing_city."<br/>";
$email_message .= "<b>State:</b> ".$billing_state."<br/>";
$email_message .= "<b>Zip code:</b> ".$billing_zip."<br/>";
$email_message .= "<b>Country:</b> ".$billing_country."<br/>";
$email_message .= "<b>Email:</b> ".$billing_email."<br/>";
$email_message .= "<b>Telephone:</b> ".$billing_tel."<br/>";
$email_message .= "<b>Message:</b> ".$message."<br/>";
$email_message .= "<b>Gateway:</b> ".$gateway."<br/>";

$_SESSION['email_data'] = array(
        "email_to"              => $email_to,
        "email_from"            => $email_from,
        "email_subject"         => $email_subject,
        "message"               => $email_message
    );

// Always set content-type when sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// More headers
$headers .= "From: Faveo Helpdesk <".$email_from . ">\r\n";
 
// mail($email_to, $email_subject, $email_message, $headers);  
//Close email


	if($_POST['payment-gateway']=="PayPal")
		{

?> 
<form method="post" name="paypalform" action="<?php echo $base_url_paypal; ?>">
<!-- PayPal Configuration -->
<input type="hidden" name="business" value="<?php echo $paypal_email;?>">
<input type="hidden" name="cmd" value="_xclick">
<input type="hidden" name="image_url" value="http://www.faveohelpdesk.com/">
<input type="hidden" name="return" value="<?php echo $paypal_return_url;?>">
<input type="hidden" name="cancel_return" value="<?php echo $paypal_cancel_url;?>">
<input type="hidden" name="notify_url" value="<?php echo $paypal_notify_url;?>">
<input type="hidden" name="rm" value="2">
<input type="hidden" name="currency_code" value="<? echo strtoupper($currency); ?>">
<input type="hidden" name="lc" value="US">
<input type="hidden" name="bn" value="toolkit-php">
<input type="hidden" name="cbt" value="Continue >>">

<!-- Payment Page Information -->
<input type="hidden" name="no_shipping" value="">
<input type="hidden" name="no_note" value="1">
<input type="hidden" name="cn" value="Comments">
<input type="hidden" name="cs" value="">

<!-- Product Information -->
<input type="hidden" name="item_name" value="Faveo Helpdesk">
<input type="hidden" name="amount" value="<?php echo $amount; ?>">
<input type="hidden" name="quantity" value="">
<input type="hidden" name="item_number" value="<?php echo $order_id; ?>">



<!-- Shipping and Misc Information -->
<input type="hidden" name="shipping" value="">
<input type="hidden" name="shipping2" value="">
<input type="hidden" name="handling" value="">
<input type="hidden" name="tax" value="">
<input type="hidden" name="custom" value="">
<input type="hidden" name="invoice" value="">

<!-- Customer Information -->
<input type="hidden" name="first_name" value="Bhanu">
<input type="hidden" name="last_name" value="">
<input type="hidden" name="address1" value="<?php echo $billing_address ;?>">
<input type="hidden" name="address2" value="">
<input type="hidden" name="city" value="<?php echo $billing_city; ?>">
<input type="hidden" name="state" value="<?php echo $billing_state; ?>">
<input type="hidden" name="zip" value="<?php echo $billing_zip; ?>">
<input type="hidden" name="email" value="<?php echo $billing_email;?>">
<input type="hidden" name="night_phone_a" value="<?php echo $billing_tel; ?>">
<input type="hidden" name="night_phone_b" value="">
<input type="hidden" name="night_phone_c" value="">
</form>

<script language='javascript'>document.paypalform.submit();</script>




	
    
<?php }

if($_POST['payment-gateway']=="CCAvenue")
		{
			//echo"inside";
			$merchant_data=	'merchant_id='.$merchant_id.'&order_id='.$order_id.'&amount='.$amount.'&currency='.$currency.'&redirect_url='.$redirect_url.
					'&cancel_url='.$cancel_url.'&language='.$language.'&billing_name='.$billing_name.'&billing_address='.$billing_address.
					'&billing_city='.$billing_city.'&billing_state='.$billing_state.'&billing_zip='.$billing_zip.'&billing_country='.$billing_country.
					'&billing_tel='.$billing_tel.'&billing_email='.$billing_email.'&delivery_name='.$delivery_name.'&delivery_address='.$delivery_address.
					'&delivery_city='.$delivery_city.'&delivery_state='.$delivery_state.'&delivery_zip='.$delivery_zip.'&delivery_country='.$delivery_country.
					'&delivery_tel='.$delivery_tel;

	$encrypted_data=encrypt($merchant_data,$working_key); // Method for encrypting the data.
		?>
<form method="post" name="paymentpage" action="<?php echo $base_url_ccavenue; ?>">
 
            <input type="hidden" name="command" value="<?php echo $command;?>">
            <input type="hidden" name="encRequest" value="<?php echo $encrypted_data;?>">
            <input type="hidden" name="access_code" value="<?php echo $access_code;?>">
            
  <input type="hidden" value="submit">
</form>
<script language='javascript'>document.paymentpage.submit();</script>
<?php } 


if($_POST['payment-gateway']=="PayuMoney")
		{
			echo "Base url: ".  $base_url_payu_money;
			
			$hash = '';
//$productinfo1 = json_encode(json_decode('[{"name":"$name1","description":"$description","value":"$sellingCurrencyAmount","isRequired":"false"}]'));

$hash_string = '';
$hash_string .= $payu_money_key . '|' . $order_id . '|' . $amount . '|' . $productinfo . '|' . $billing_name . '|' . $billing_email . '|||||||||||';
$hash_string .= $payu_money_salt;
$hash = hash('sha512', $hash_string);

?>
 			<form action="<?php echo $base_url_payu_money; ?>" method="post" name="payumoney">
            <input type="hidden" name="key" value="<?php echo $payu_money_key ?>" />
            <input type="hidden" name="hash" value="<?php echo $hash ?>"/>
            <input type="hidden" name="txnid" value="<?php echo $order_id ?>" />
            <input type="hidden" name="amount" value="<?php echo $amount; ?>" />
            <input type="hidden" name="firstname" id="firstname" value="<?php echo $billing_name; ?>" />
            <input type="hidden" name="email" id="email" value="<?php echo $billing_email; ?>" />
            <input type="hidden"name="phone" value="<?php echo $billing_tel; ?>" />
            <input type="hidden" name="productinfo" value="<?php echo $productinfo; ?>" />
            <input type="hidden" name="surl" value="<?php echo $surl1; ?>" size="64" />
            <input type="hidden" name="furl" value="<?php echo $furl1; ?>" size="64" />
            <input type="hidden" name="service_provider" value="<?php echo $service_provider1; ?>" size="64" />
            <input type="hidden" name="curl" value="<?php echo $curl1; ?>" />
            <input type="hidden" name="address1" value="<?php echo $billing_address; ?>" />
            <input type="hidden" name="address2" value="<?php echo $address21; ?>" />
            <input type="hidden" name="city" value="<?php echo $billing_city; ?>" />
            <input type="hidden" name="state" value="<?php echo $billing_state; ?>" />
            <input type="hidden" name="country" value="<?php echo $billing_country; ?>" />
            <input type="hidden" name="zipcode" value="<?php echo $billing_zip; ?>" />
            <input type="hidden" value="Submit" />

        </form>
        <script language='javascript'>document.payumoney.submit();</script>
<?php
		}
		
?>
    

<!-- Vendor --> 

<script src="../vendor/jquery.appear/jquery.appear.min.js"></script> 
<script src="../vendor/jquery.easing/jquery.easing.min.js"></script> 
<script src="../vendor/jquery-cookie/jquery-cookie.min.js"></script> 
<script src="../vendor/bootstrap/js/bootstrap.min.js"></script> 
<script src="../vendor/common/common.min.js"></script> 
<script src="../vendor/jquery.validation/jquery.validation.min.js"></script> 
<script src="../vendor/jquery.stellar/jquery.stellar.min.js"></script> 
<script src="../vendor/jquery.easy-pie-chart/jquery.easy-pie-chart.min.js"></script> 
<script src="../vendor/jquery.gmap/jquery.gmap.min.js"></script> 
<script src="../vendor/jquery.lazyload/jquery.lazyload.min.js"></script> 
<script src="../vendor/isotope/jquery.isotope.min.js"></script> 
<script src="../vendor/owl.carousel/owl.carousel.min.js"></script> 
<script src="../vendor/magnific-popup/jquery.magnific-popup.min.js"></script> 
<script src="../vendor/vide/vide.min.js"></script> 

<!-- Theme Base, Components and Settings --> 
<script src="../js/theme.js"></script> 

<!-- Theme Custom --> 
<script src="../js/custom.js"></script> 

<!-- Theme Initialization Files --> 
<script src="../js/theme.init.js"></script> 

</body>
</html>
