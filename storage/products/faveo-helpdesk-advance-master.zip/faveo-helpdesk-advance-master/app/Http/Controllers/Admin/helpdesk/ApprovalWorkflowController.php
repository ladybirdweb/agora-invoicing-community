<?php

namespace App\Http\Controllers\Admin\helpdesk;

use App\Http\Controllers\Controller;
use App\Model\helpdesk\Manage\UserType;
use App\Model\helpdesk\Workflow\ApprovalLevel;
use App\Model\helpdesk\Workflow\ApprovalWorkflow;
use App\User;
use Auth;
use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Http\Request;
use Lang;
use Validator;

class ApprovalWorkflowController extends Controller
{
    public function __construct()
    {
        $this->middleware('role.admin');
    }

    /**
     * Show list page of approval workflow
     *
     * @return HTTP response
     */
    public function showIndex()
    {
        return view('themes.default1.admin.helpdesk.manage.approval_workflow.index');
    }

    /**
     * Show create page of approval workflow
     *
     * @return HTTP response
     */
    public function create()
    {
        return view('themes.default1.admin.helpdesk.manage.approval_workflow.create');
    }

    /**
     * Show edit page of approval workflow
     *
     * @return HTTP response
     */
    public function edit($id)
    {
        return view('themes.default1.admin.helpdesk.manage.approval_workflow.edit');
    }

    /**
     * Get list of approval workflow
     *
     * @return Json HTTP response
     */
    public function index(Request $request)
    {
        // Validate query params
        $this->validateQueryParams($request);

        try {
            $search = $request->search;

            // Get all approval workflow with pagination
            $approvalWorkflows = ApprovalWorkflow::when($search, function ($query) use ($search) {
                return $query->where('name', 'like', '%' . $search . '%');
            })->orderBy($request->input('sort_by', 'name'), $request->input('order', 'asc'))->paginate(10);

            return successResponse('', $approvalWorkflows);
        } catch (Exception $e) {
            return errorResponse($e->getMessage());
        }
    }

    /**
     * Get list of approval workflow
     *
     * @param $id Approval workflow id
     * @return Json HTTP response
     */
    public function show($id)
    {
        try {
            // Check approval workflow exists
            $approvalWorkflow = ApprovalWorkflow::find($id);

            if (is_null($approvalWorkflow)) {
                return errorResponse(Lang::get('lang.approval-workflow-not-found'));
            }

            $approvalLevels = $approvalWorkflow->approvalLevels()
                ->with(['approveUsers', 'approveUserTypes'])->orderBy('order', 'asc')->get();

            // Approval workflow data
            $data['id']   = $approvalWorkflow->id;
            $data['name'] = $approvalWorkflow->name;

            $data['action_on_approve'] = $approvalWorkflow->actionOnApprove()->first();
            $data['action_on_deny']    = $approvalWorkflow->actionOnDeny()->first();

            $data['name']    = $approvalWorkflow->name;
            $data['user_id'] = $approvalWorkflow->user_id;
            $data['levels']  = array();

            // Approval workflow levels
            foreach ($approvalLevels as $level) {
                $levelData['id']                      = $level->id;
                $levelData['name']                    = $level->name;
                $levelData['match']                   = $level->match;
                $levelData['order']                   = $level->order;
                $levelData['approvers']['users']      = array();
                $levelData['approvers']['user_types'] = array();

                // Approver users
                $levelData['approvers']['users'] = $this->getApprovers($level->approveUsers);

                // Approver user types
                $levelData['approvers']['user_types'] = $this->getApprovers($level->approveUserTypes);

                array_push($data['levels'], $levelData);
            }

            return successResponse('', $data);
        } catch (Exception $e) {
            return errorResponse($e->getMessage());
        }
    }

    /**
     * Store approval workflow
     *
     * @param $request Instance of Illuminate\Http\Request
     * @return Json HTTP response
     */
    public function store(Request $request)
    {
        try {
            // Validate request data
            $this->validateInputs($request);

            // If update action
            if ($request->has('id') && $request->id != 0) {
                // Check approval workflow exists
                $approvalWorkflow = ApprovalWorkflow::find($request->id);

                if (is_null($approvalWorkflow)) {
                    return errorResponse(Lang::get('lang.approval-workflow-not-found'));
                }

                $this->update($request, $approvalWorkflow);
            } else {
                // Get current user
                $currentUser = Auth::user();

                // Create approval workflow
                $approvalWorkflow = $currentUser->approvalWorkflows()->create([
                    'name'              => $request->name,
                    'action_on_approve' => $request->action_on_approve,
                    'action_on_deny'    => $request->action_on_deny,
                ]);

                // Save approval levels with approvers
                $this->saveApprovalLevels($approvalWorkflow, $request->levels);
            }

            return successResponse(Lang::get('lang.approval-workflow-save-successful'));
        } catch (Exception $e) {
            return errorResponse($e->getMessage());
        }
    }

    /**
     * Remove approval workflow
     *
     * @param $id Approval workflow id
     * @param $type Delete type workflow / level
     * @return Json HTTP response
     */
    public function destroy($id, $type)
    {
        try {
            if ($type == 'workflow') {
                // Check approval workflow exists
                $approvalWorkflow = ApprovalWorkflow::find($id);

                if (is_null($approvalWorkflow)) {
                    return errorResponse(Lang::get('lang.approval-workflow-not-found'));
                }

                $approvalLevels = $approvalWorkflow->approvalLevels()->get();

                foreach ($approvalLevels as $level) {
                    // Remove approver users
                    $level->approveUsers()->detach();

                    // Remove approver user types
                    $level->approveUserTypes()->detach();

                    // Remove approval level
                    $level->delete();
                }

                // Remove approval workflow
                $approvalWorkflow->delete();

                return successResponse(Lang::get('lang.approval-workflow-removed'));
            } else if ($type == 'level') {
                // Check approval level exists
                $approvalLevel = ApprovalLevel::find($id);

                if (!is_null($approvalLevel)) {
                    // Remove approver users
                    $approvalLevel->approveUsers()->detach();

                    // Remove approver user types
                    $approvalLevel->approveUserTypes()->detach();

                    // Remove approval level
                    $approvalLevel->delete();

                    return successResponse(Lang::get('lang.workflow-level-removed'));
                }

                return errorResponse(Lang::get('lang.approval-workflow-not-found'));
            } else {
                return errorResponse(Lang::get('lang.invalid-workflow-type'));
            }
        } catch (Exception $e) {
            return errorResponse($e->getMessage());
        }
    }

    /**
     * Update approval workflow
     *
     * @param $request Instance of Illuminate\Http\Request
     * @param $approvalWorkflow Instance of approval workflow
     * @return void
     */
    private function update(Request $request, ApprovalWorkflow $approvalWorkflow)
    {
        // Get current user
        $currentUser = Auth::user();

        // Create approval workflow
        $approvalWorkflow->name              = $request->name;
        $approvalWorkflow->user_id           = $currentUser->id;
        $approvalWorkflow->action_on_approve = $request->action_on_approve;
        $approvalWorkflow->action_on_deny    = $request->action_on_deny;

        $approvalWorkflow->save();

        // Save approval levels with approvers
        $this->saveApprovalLevels($approvalWorkflow, $request->levels);
    }

    /**
     * Sync approvers with approval leves
     *
     * @param $approvalWorkflow Instance Approval workflow
     * @param $levels array Approval workflow levels
     * @return void
     */
    private function saveApprovalLevels(ApprovalWorkflow $approvalWorkflow, array $levels)
    {
        // Save approval workflow levels
        foreach ($levels as $level) {
            if ($level['id'] == 0) {
                $approvalLevel = $approvalWorkflow->approvalLevels()->create([
                    'name'  => $level['name'],
                    'match' => $level['match'],
                    'order' => $level['order'],
                ]);
            } else {
                $approvalLevel = ApprovalLevel::find($level['id']);

                if (!is_null($approvalLevel)) {
                    $approvalLevel->name  = $level['name'];
                    $approvalLevel->match = $level['match'];
                    $approvalLevel->order = $level['order'];

                    $approvalLevel->save();
                }
            }

            // Sync approvers with approval levels
            $this->syncApproversWithLevel($approvalLevel, $level['approvers']);
        }
    }

    /**
     * Sync approvers with approval leves
     *
     * @param $approvalLevel Instance Approval workflow level
     * @param $level array Approvers of a level
     * @return void
     */
    private function syncApproversWithLevel(ApprovalLevel $approvalLevel, array $approvers)
    {
        $userIds     = array();
        $userTypeIds = array();

        if (!empty($approvers['users'])) {
            foreach ($approvers['users'] as $userId) {
                $user = User::find($userId);

                // Check if user exists
                if (!is_null($user)) {
                    $userIds[] = $user->id;
                }
            }
        }

        // Add approval workflow level approver users
        $approvalLevel->approveUsers()->sync($userIds);

        if (!empty($approvers['user_types'])) {
            foreach ($approvers['user_types'] as $userTypeId) {
                $userType = UserType::find($userTypeId);

                // Check if user type exists
                if (!is_null($userType)) {
                    $userTypeIds[] = $userType->id;
                }
            }
        }

        // Add approval workflow level approver user types
        $approvalLevel->approveUserTypes()->sync($userTypeIds);
    }

    /**
     * Validate query parameters
     *
     * @param \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response If validation failed return error response
     */
    private function validateQueryParams($request)
    {
        $validator = Validator::make($request->all(), [
            'per_page' => 'sometimes|integer',
            'page'     => 'sometimes|integer',
            'sort_by'  => 'sometimes|string|in:name,created_at,updated_at',
            'order'    => 'sometimes|string|in:asc,desc',
            'search'   => 'sometimes|string',
        ]);

        if ($validator->fails()) {
            $errors          = $validator->errors()->messages();
            $formattedErrors = array();

            foreach ($errors as $field => $message) {
                $formattedErrors[$field] = array_first($message);
            }

            throw new HttpResponseException(errorResponse($formattedErrors, 412));
        }
    }

    /**
     * Validate input parameters
     *
     * @param \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response If validation failed return error response
     */
    private function validateInputs($request)
    {
        $validator = Validator::make($request->all(), [
            'id'                            => 'sometimes|integer',
            'name'                          => 'required|string|max:255|unique:approval_workflows,name,' . $request->id,
            'levels'                        => 'required|array',
            'levels.*.id'                   => 'required_with:id|integer',
            'levels.*.name'                 => 'required|string|max:255',
            'levels.*.match'                => 'required|in:all,any',
            'levels.*.order'                => 'required|integer|min:1|max:255',
            'levels.*.approvers'            => 'required|array',
            'levels.*.approvers.users'      => 'required_without:levels.*.approvers.user_types|array',
            'levels.*.approvers.user_types' => 'required_without:levels.*.approvers.users|array',
        ]);

        if ($validator->fails()) {
            $errors          = $validator->errors()->messages();
            $formattedErrors = array();

            foreach ($errors as $field => $message) {
                $formattedErrors[$field] = array_first($message);
            }

            throw new HttpResponseException(errorResponse($formattedErrors, 412));
        }
    }

    /**
     * Get approvers
     *
     * @param $approvers Approver instance of User / UserType
     * @return array Approver details
     */
    private function getApprovers($approvers)
    {
        if (is_null($approvers)) {
            return array();
        }

        $approverData = array();

        foreach ($approvers as $approver) {
            $approverData[] = [
                'id'   => $approver->id,
                'name' => $approver instanceof User ? $approver->full_name : $approver->name,
            ];
        }

        return $approverData;
    }
}
