<?php

namespace App\Http\Controllers\Common;

use Socialite;

class Socialite extends Socialite
{
}
