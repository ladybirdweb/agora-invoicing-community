<?php

namespace App\Itil\Controllers;

use App\Itil\Controllers\BaseServiceDeskController;
use App\Itil\Requests\CreateLocationcatagoryRequest;
use App\Itil\Models\Changes\SdLocationcategories;
use Exception;
use Lang;

class LocationCategoryController extends BaseServiceDeskController {

    public function index() {
        try {

            return view('itil::locationcategory.index');
        } catch (Exception $ex) {
            return redirect()->back()->with('fails', $ex->getMessage());
        }
    }

    public function getLocation() {
        try {
            //dd('s');
            $locationcategorys = new SdLocationcategories();
            $locationcategory = $locationcategorys->select('id', 'name', 'parent_id', 'created_at', 'updated_at')->get();
            return \Datatable::Collection($locationcategory)
                            ->showColumns('name')
                             ->addColumn('created_at', function($model) {
                                $created_at=faveoDate($model->created_at);
                                return $created_at;
                            })
                                ->addColumn('updated_at', function($model) {
                                $updated_at=faveoDate($model->updated_at);
                                return $updated_at;
                            })
                            ->addColumn('action', function($model) {
                                 $url = url('service-desk/location-category-types/'.$model->id.'/delete');
                                $delete = \App\Itil\Controllers\UtilityController::deletePopUp($model->id, $url, "Delete $model->subject",'btn btn-primary btn-xs');
                                
                                return "<a href=" . url('service-desk/location-category-types/' . $model->id . '/edit') . " class='btn btn-primary btn-xs'><i class='fa fa-edit'>&nbsp;&nbsp;</i>Edit</a>&nbsp;&nbsp;"
                                        . $delete;
                            })
                            ->searchColumns('name')
                            ->orderColumns('name', 'created_at', 'updated_at')
                            ->make();
        } catch (Exception $ex) {
            return redirect()->back()->with('fails', $ex->getMessage());
        }
    }

    public function create() {
        try {
            return view('itil::locationcategory.create');
        } catch (Exception $ex) {
            return redirect()->back()->with('fails', $ex->getMessage());
        }
    }

    public function handleCreate(CreateLocationcatagoryRequest $request) {
        try {
            $sd_location_catagory = new SdLocationcategories;
            $sd_location_catagory->fill($request->input())->save();
            return \Redirect::route('service-desk.location-category.index')->with('message',Lang::get('lang.Location_category_successfully_create'));
        } catch (Exception $ex) {
            return redirect()->back()->with('fails', $ex->getMessage());
        }
    }

    public function edit($id) {
        try {
            $sd_location_catagory = SdLocationcategories::findOrFail($id);
            if ($sd_location_catagory) {
                return view('itil::locationcategory.edit', compact('sd_location_catagory'));
            }
            throw new Exception("We can not find your request");
        } catch (Exception $ex) {
            return redirect()->back()->with('fails', $ex->getMessage());
        }
    }

    public function handleEdit($id, CreateLocationcatagoryRequest $request) {
        try {
            $sd_location_catagory = SdLocationcategories::findOrFail($id);
            if ($sd_location_catagory) {
                $sd_location_catagory->fill($request->input())->save();
                return \Redirect::route('service-desk.location-category.index')->with('message', Lang::get('lang.Location_category_successfully_edit'));
            }
            throw new Exception("We can not find your request");
        } catch (Exception $ex) {
            return redirect()->back()->with('fails', $ex->getMessage());
        }
    }

    public function handledelete($id) {
        try {
            $sd_location_catagory = SdLocationcategories::findOrFail($id);
            if ($sd_location_catagory) {
                $sd_location_catagory->delete();
                return \Redirect::route('service-desk.location-category.index')->with('message',Lang::get('lang.Location_category_successfully_delete'));
            }
            throw new Exception("We can not find your request");
        } catch (Exception $ex) {
            return redirect()->back()->with('fails', $ex->getMessage());
        }
    }

}
