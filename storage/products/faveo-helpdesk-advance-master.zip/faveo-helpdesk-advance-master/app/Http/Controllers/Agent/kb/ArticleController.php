<?php

namespace App\Http\Controllers\Agent\kb;

// Controllers
use App\Http\Controllers\Controller;
// Requests
use App\Http\Requests\kb\ArticleRequest;
use App\Http\Requests\kb\ArticleUpdate;
use App\Http\Requests\kb\ArticletemplateRequest;
use App\Http\Requests\kb\ArticletemplateUpdateRequest;

// Models
use App\Model\kb\Article;
use App\Model\kb\Category;
use App\Model\kb\Comment;
use App\Model\kb\Relationship;
use App\Model\kb\Settings;
use App\Model\kb\ArticleTemplate;
// Classes
use Auth;
use Chumper\Datatable\Table;
use Datatable;
use DB;
use Exception;
use Illuminate\Http\Request;
use Lang;
use Redirect;
use App\Model\helpdesk\Settings\System;
use Carbon\Carbon;

/**
 * ArticleController
 * This controller is used to CRUD Articles.
 *
 * @author      Ladybird <info@ladybirdweb.com>
 */
class ArticleController extends Controller
{

    /**
     * Create a new controller instance.
     * constructor to check
     * 1. authentication
     * 2. user roles
     * 3. roles must be agent.
     *
     * @return void
     */
    protected $ticket_policy;

    public function __construct()
    {
        // checking authentication
        $this->middleware('auth');
        $this->ticket_policy = new \App\Policies\TicketPolicy();
        SettingsController::language();
    }

    public function test()
    {
        //$table = $this->setDatatable();
        return view('themes.default1.agent.kb.article.test');
    }

    /**
     * Fetching all the list of articles in a chumper datatable format.
     *
     * @return type void
     */
    public function getData(Request $request)
    {
          $pagination=($request->input('pagination'))?$request->input('pagination'):10;
          $sortBy=($request->input('sort-by'))?$request->input('sort-by'):'id';
          $search = $request->input('search-option');

          $baseQuery = Article::with('categories:kb_category.id,name')->with('author:users.id,first_name,last_name,user_name,email')->select('id', 'name', 'description', 'publish_time', 'slug','author')->orderBy($sortBy, 'desc');
          $searchQuery = $baseQuery->withCount('allComments')->withCount('pendingComments')->where(function($q) use ($search) {
                            $q->where('name', 'LIKE', '%' . $search . '%')
                            ->orWhere('slug', 'LIKE', '%' . $search . '%')
                            ->orWhere('description', 'LIKE', '%' . $search . '%');
                        })
                   ->paginate($pagination);
               return successResponse($searchQuery);
    }


    /**
     * List of Articles.
     *
     * @return type view
     */
    public function index()
    {
        /* show article list */
        try {
            if (!$this->ticket_policy->kb()) {
                return redirect('dashboard')->with('fails', Lang::get('lang.permission_denied'));
            }

              $article = new Article();
              $articles = $article
                ->select('id', 'name', 'description', 'publish_time', 'slug')
                ->orderBy('publish_time', 'desc')
                ->paginate(10);



            return view('themes.default1.agent.kb.article.index',compact('articles'));
        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }

    /**
     * Creating a Article.
     *
     * @param type Category $category
     *
     * @return type view
     */
    public function create(Category $category)
    {

        /* get the attributes of the category */
        $category = $category->where('status',1)->orderBy('id','desc')->pluck('id', 'name');
        $template = ArticleTemplate::where('status',1)->get();
        /* get the create page  */
        try {
            if (!$this->ticket_policy->kb()) {
                return redirect('dashboard')->with('fails', Lang::get('lang.permission_denied'));
            }
            return view('themes.default1.agent.kb.article.create', compact('category','template'));
        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }

    /**
     * Insert the values to the article.
     *
     * @param type Article        $article
     * @param type ArticleRequest $request
     *
     * @return type redirect
     */
    public function store(Article $article, ArticleRequest $request)
    {
        $content = trim(preg_replace("/<img[^>]+\>/i", "", $request->description), " \t.");
         if(strip_tags($content) == "\r\n"){
             return redirect()->back()->with('fails', Lang::get('lang.please_put_description_contain'));
         }
        if (!$this->ticket_policy->kb()) {
            return redirect('dashboard')->with('fails', Lang::get('lang.permission_denied'));
        }

          // requesting the values to store article data
        $time = $request->input('year') .'-'. $request->input('month').'-'.$request->input('day').' '.$request->input('hour').':' . sprintf("%02d", $request->input('minute')).':00';
        $changeTime= changeTimezoneForDatetime($time,System::first()->time_zone, 'UTC');
        $publishTime =$changeTime->toDateTimeString();

        $article->fill($request->except( 'slug','created_at','updated_at','publishTime'))->save();

        Article::where('id', $article->id)->update(['slug'=>str_slug($request->input('slug'), '-'),'publish_time'=>$publishTime,'created_at'=>$publishTime,'updated_at'=>$publishTime]);
        // creating article category relationship
        $categoryIds = $request->input('category_id');
         foreach ($categoryIds as $categoryId) {
           Relationship::create(['category_id'=>"$categoryId",'article_id'=>$article->id]);
           
        }
        /* insert the values to the article table  */
        try {
            $check=Article::where('id',$article->id)->first();
            $check->meta_description=(!$check->meta_description) ? substr(strip_tags($check['description']),0,160) . "..." : $request->meta_description;
            $check->seo_title=(!$check->seo_title) ? $check->name : $request->sco_title;
            $check->save();
            return redirect()->back()->with('success', Lang::get('lang.article_saved_successfully'));
        } catch (Exception $e) {
           
           return redirect()->back()->with('fails', Lang::get('lang.article_not_inserted') . '<li>' . $e->getMessage() . '</li>');
        }
    }

    /**
     * Edit an Article by id.
     *
     * @param type Integer      $id
     * @param type Article      $article
     * @param type Relationship $relation
     * @param type Category     $category
     *
     * @return view
     */
    public function edit($slug)
    {
        if (!$this->ticket_policy->kb()) {
            return redirect('dashboard')->with('fails', Lang::get('lang.permission_denied'));
        }
        /* define the selected fields */
        $assign = Relationship::where('article_id', $slug)->pluck('category_id');
        /* get the attributes of the category */
        $category = Category::pluck('id', 'name');
        /* get the selected article and display it at edit page  */
        /* Get the selected article with id */
        $article = Article::whereId($slug)->first();
      
        /* send to the edit page */
        $template = ArticleTemplate::where('status',1)->get();
        try {
            return view('themes.default1.agent.kb.article.edit', compact('assign', 'article', 'category','template'));
        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }

    /**
     * Update an Artile by id.
     *
     * @param type Integer        $articleId of article
     * @param type Article        $article
     * @param type Relationship   $relation
     * @param type ArticleRequest $request
     *
     * @return Response
     */
    public function update($articleId, ArticleUpdate $request)
    {

        $content = trim(preg_replace("/<img[^>]+\>/i", "", $request->description), " \t.");
         if(strip_tags($content) == "\r\n"){
             return redirect()->back()->with('fails', Lang::get('lang.please_put_description_contain'));
         }
       if (!$this->ticket_policy->kb()) {
            return redirect('dashboard')->with('fails', Lang::get('lang.permission_denied'));
        }
        $publishTime = $request->input('year') .'-'. $request->input('month').'-'.$request->input('day').' '.$request->input('hour').':' . sprintf("%02d", $request->input('minute')).':00';

        $publishTime= changeTimezoneForDatetime($publishTime,System::first()->time_zone, 'UTC')->toDateTimeString();
        $article=Article::where('id', $articleId)->first();
        $slug = str_slug($request->input('slug'), '-');
        /* get the attribute of relation table where id==$articleId */
        Relationship::where('article_id', $article->id)->delete();
       /* get the request of the current articles */
        $requests = $request->input('category_id');
         foreach ($requests as $req) {
            Relationship::create(['category_id'=>$req,'article_id'=>$article->id]);
         }
       try {
            $article->fill($request->all())->save();
             Article::where('id', $articleId)->update(['slug'=>$slug,'publish_time'=>$publishTime,'updated_at'=>$publishTime]);
             $check=Article::where('id',$article->id)->first();
             $check->meta_description=(!$check->meta_description)?substr(strip_tags($check['description']),0,160) . "..." : $request->meta_description;
             $check->seo_title=(!$check->seo_title)? $check->name : $request->seo_title;
             $check->save();
      return redirect()->back()->with('success', Lang::get('lang.article_updated_successfully'));
        } catch (Exception $e) {
            return redirect()->back()->with('fails', Lang::get('lang.article_not_updated') . '<li>' . $e->getMessage() . '</li>');
        }
    }

    /**
     * Delete an Agent by id.
     *
     * @param type         $id
     * @param type Article $article
     *
     * @return Response
     */
    public function destroy($slug, Article $article)
    {
        if (!$this->ticket_policy->kb()) {
            return redirect('dashboard')->with('fails', Lang::get('lang.permission_denied'));
        }
        /* delete the selected article from the table */
        $article = $article->where('slug', $slug)->first(); //get the selected article via id
        Comment::where('article_id', $article->id)->delete();
        Relationship::where('article_id', $article->id)->delete();
        
        if ($article) {
            if ($article->delete()) {//true:redirect to index page with success message
                return redirect('article')->with('success', Lang::get('lang.article_deleted_successfully'));
            } else { //redirect to index page with fails message
                return redirect('article')->with('fails', Lang::get('lang.article_not_deleted'));
            }
        } else {
            return redirect('article')->with('fails', Lang::get('lang.article_can_not_deleted'));
        }
    }

    /**
     * user time zone
     * fetching timezone.
     *
     * @param type $utc
     *
     * @return type
     */
    public static function usertimezone($utc)
    {
        $user = Auth::user();
        $tz = $user->timezone;
        $set = Settings::whereId('1')->first();
        $format = $set->dateformat;
        //$utc = date('M d Y h:i:s A');
        date_default_timezone_set($tz);
        $offset = date('Z', strtotime($utc));
        $date = date($format, strtotime($utc) + $offset);
        echo $date;
    }


    /**
     * Create a Article Template.
     *
     * @param type Category $category
     *
     * @return type view
     */
    public function articleAlltemplateList()
    {
       try {

            return view('themes.default1.agent.kb.article.template.index');
        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }
 /**
     * Create a Article Template.
     *
     * @param type Category $category
     *
     * @return type view
     */
    public function allArticleTemplate()
    {
       try {


         $article = new ArticleTemplate();
         $articles = $article
                ->select('id', 'name', 'status')
                ->orderBy('created_at', 'desc')
                ->get();
       // dd($articles);
        // returns chumper datatable
        return Datatable::Collection($articles)

                        /* add column name */
                        ->addColumn('name', function ($model) {
                            $name = str_limit($model->name, 20, '...');

                            return "<p title=$model->name>$name</p>";
                        })
                     ->addColumn('status', function ($model) {
                             if ($model->status == 1) {
                return '<p class="btn btn-xs btn-default" style="pointer-events:none;color:green">'.Lang::get('lang.active').'</p>';
            }else{


            return '<p class="btn btn-xs btn-default" style="pointer-events:none;color:red">'.Lang::get('lang.inactive').'</p>';
                        }
                        })
                     
                        /* add column action */
                        ->addColumn('Actions', function ($model) {
                            /* here are all the action buttons and modal popup to delete articles with confirmations */
                            return '<span  data-toggle="modal" data-target="#deletearticle' . $model->id . '"><a href="#" ><button class="btn btn-primary btn-xs"></a><i class="fa fa-trash">&nbsp;</i> ' . \Lang::get('lang.delete') . ' </button></span>&nbsp;&nbsp;<a href=' . url("articletemplate/$model->id/edit") . ' class="btn btn-primary btn-xs"><i class="fa fa-edit">&nbsp;&nbsp;</i>' . \Lang::get('lang.edit') . '</a>&nbsp;&nbsp;
                <div class="modal fade" id="deletearticle' . $model->id . '">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                <h4 class="modal-title">'.Lang::get('lang.delete').'</h4>
                            </div>
                            <div class="modal-body">
                             <p>Are you sure ?</p>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default pull-left" data-dismiss="modal" id="dismis2"><i class="fa fa-times" aria-hidden="true">&nbsp;&nbsp;</i>Close</button>
                                <a href="' . url("article/deletetemplate/$model->id") . '" class="btn btn-danger" onclick="clickAndDisable(this);"><i class="fa fa-trash">&nbsp;&nbsp;</i>'.Lang::get('lang.delete').'</a>
                            </div>
                        </div>
                    </div>
                </div>
                <script> 
   function clickAndDisable(link) {
     // disable subsequent clicks
     link.onclick = function(event) {
        event.preventDefault();
     }
   }   
</script> ';
                        })
                        ->searchColumns('name')
                        ->orderColumns('name')
                        ->make();
   
            
        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }




 /**
     * Create a Article Template.
     *
     * @param type Category $category
     *
     * @return type view
     */
    public function createTemplate()
    {
        /* Get the all attributes in the category model */
        // $category = $category->pluck('name','id')->toArray();
        /* get the view page to create new category with all attributes
          of category model */
        try {
             if (!$this->ticket_policy->kb()) {
                return redirect('dashboard')->with('fails', Lang::get('lang.permission_denied'));
            }
            return view('themes.default1.agent.kb.article.template.create');
        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }


/**
     * Create a Article Template.
     *
     * @param type Category $category
     *
     * @return type view
     */
    public function postTemplate(ArticletemplateRequest $request)
    {
      
        try {
             if (!$this->ticket_policy->kb()) {
                return redirect('dashboard')->with('fails', Lang::get('lang.permission_denied'));
            }

            $template=new ArticleTemplate();
            $template->name=$request->name;
            $template->status=$request->status;
            $template->description=$request->description;
            $template->save();


            return redirect('article/alltemplate/list')->with('success', Lang::get('lang.articletemplate_saved_successfully'));


        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }

     /**
     * Create a Article Template.
     *
     * @param type Category $category
     *
     * @return type view
     */
    public function editTemplate($id)
    {
         if (!$this->ticket_policy->kb()) {
                return redirect('dashboard')->with('fails', Lang::get('lang.permission_denied'));
            }
        
        $article_template = ArticleTemplate::where('id','=',$id)->first();
      
        try {
            // dd( $article_template);
            return view('themes.default1.agent.kb.article.template.edit',compact('article_template'));
        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }

    /**
     * Create a Article Template.
     *
     * @param type Category $category
     *
     * @return type view
     */
    public function editPostTemplate($id,ArticletemplateUpdateRequest $request)
    {
    try {
           if (!$this->ticket_policy->kb()) {
                return redirect('dashboard')->with('fails', Lang::get('lang.permission_denied'));
            }
            $article_template = ArticleTemplate::findOrFail($id);
            $article_template->name=$request->name;
            $article_template->status=$request->status;
            $article_template->description=$request->description;
            $article_template->save();

          return redirect('article/alltemplate/list')->with('success', Lang::get('lang.articletemplate_updated_successfully'));
        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }

    /**
     * Create a Article Template.
     *
     * @param type Category $category
     *
     * @return type view
     */
    public function PostTemplateDelete($id,Request $request)
    {
    try {
         if (!$this->ticket_policy->kb()) {
                return redirect('dashboard')->with('fails', Lang::get('lang.permission_denied'));
            }

         $check_template= Article::where('template','=',$id)->count();
         if($check_template>0){
               return redirect()->back()->with('fails',Lang::get('lang.this_template_already_applyed_in_article_you_can_not_delete_this_template'));
             }
          

             $template = ArticleTemplate::findOrFail($id);
             $template->delete();
            

          return redirect('article/alltemplate/list')->with('success', Lang::get('lang.articletemplate_deleted_successfully'));
        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }





       public function searchTemplate(Request $request)
        {
        
        $article_template = ArticleTemplate::findOrFail($request->temp_name);
        $description=$article_template->description;
        return  $description;

      
   
    }



}
