<?php

namespace App\Http\Controllers\Common;

// controllers
use App\Http\Controllers\Controller;
// requests
use App\Http\Requests;
use App\Http\Requests\helpdesk\SmtpRequest;
use App\Model\helpdesk\Email\Smtp;
// models
use App\Model\helpdesk\Settings\Plugin;
use App\Model\helpdesk\Theme\Widgets;
use App\Model\helpdesk\Utility\Version_Check;
use App\Model\helpdesk\Settings\CommonSettings;

use Config;
// classes
use Crypt;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Input;
use Lang;
use Validator;

use Illuminate\Database\Schema\Blueprint;
use Schema;
use Artisan;
use App\Model\Common\Template;
use App\Model\Common\TemplateType;

/**
 * ***************************
 * Settings Controllers
 * ***************************
 * Controller to keep smtp details and fetch where ever needed.
 */
class SettingsController extends Controller {

    /**
     * Create a new controller instance.
     *
     * @return type void
     */
    public function __construct() {
        $this->middleware('auth');
        $this->middleware('roles');
    }

    /**
     * get the page to create the footer.
     *
     * @return response
     */
    public function widgets() {
        return view('themes.default1.admin.helpdesk.theme.widgets');
    }

    /**
     * get the page to create the footer.
     *
     * @return response
     */
    public function list_widget() {
        return \Datatable::collection(Widgets::where('id', '<', '7')->get())
                        ->searchColumns('name','title')
                        ->orderColumns('name', 'title', 'value')
                        ->addColumn('name', function ($model) {
                            return $model->name;
                        })
                        ->addColumn('title', function ($model) {
                             $title=mb_substr($model->title, 0, 30, 'UTF-8');

                             return '<span title="'.$model->title.'">'.$title.'</span>';

                            // return $model->title;
                        })
                        // ->addColumn('body', function ($model) {
                        //     $body=mb_substr($model->value, 0, 30, 'UTF-8');

                        //      return '<span title="'.$model->value.'">'.$body.'</span>';;

                        //     // return $body;
                        // })
                        ->addColumn('Actions', function ($model) {
                            return 
                            '
                            <span data-toggle="modal">
                                <a class="btn btn-primary btn-xs" onclick="showEdit(\''.$model->id.'\',\''.$model->name.'\', \''.$model->title.'\', \'edit\')">
                                    <i class="fa fa-edit" style="color:white;">&nbsp;</i>' . \Lang::get('lang.edit') . '&nbsp;
                                </a>&nbsp;&nbsp;
                            </span>
                            <span data-toggle="modal">
                                <a class="btn btn-primary btn-xs" onclick="showEdit(\''.$model->id.'\',\''.$model->name.'\', \''.$model->title.'\', \'view\')">
                                    <i class="fa fa-eye" style="color:white;">&nbsp;&nbsp;</i>' . \Lang::get('lang.view') . 
                                '</a>
                            </span>
                            <script type="text/javascript">
                            var value'.$model->id.' = '.json_encode([$model->value]).'
                            </script>
                            ';
                        })
                        ->make();
    }

    /**
     * Post footer.
     *
     * @param type Footer  $footer
     * @param type Request $request
     *
     * @return type response
     */
    public function edit_widget($id, Widgets $widgets, Request $request) {
        $widget = $widgets->where('id',$id)->first();
        $widget->title = $request->title;
        $widget->value = $request->content;
        try {
            $widget->save();
            return redirect()->back()->with('success', $widget->name . Lang::get('lang.saved_successfully'));
        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }

    /**
     * get the page to create the footer.
     *
     * @return response
     */
    public function social_buttons() {
        return view('themes.default1.admin.helpdesk.theme.social');
    }

    /**
     * get the page to create the footer.
     *
     * @return response
     */
    public function list_social_buttons() {
        return \Datatable::collection(Widgets::where('id', '>', '6')->get())
                        ->searchColumns('name')
                        ->orderColumns('name', 'value')
                        ->addColumn('name', function ($model) {
                            return $model->name;
                        })
                        ->addColumn('link', function ($model) {
                            return $model->value;
                        })
                        ->addColumn('Actions', function ($model) {
                            return '<span data-toggle="modal" data-target="#edit_widget' . $model->id . '"><a class="btn btn-primary btn-xs"><i class="fa fa-edit" style="color:white;">&nbsp;&nbsp; </i>' . \Lang::get('lang.edit') . '</a></span>
                <div class="modal fade" id="edit_widget' . $model->id . '">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <form action="' . url('edit-widget/' . $model->id) . '" method="POST">
                            '.csrf_field().'
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    <h4 class="modal-title">' . strtoupper($model->name) . ' </h4>
                                </div>
                                <div class="modal-body">
                                    <br/>
                                    <input type="hidden" name="socail-button"  value="1">
                                    <div class="form-group" style="width:100%">
                                        <label>' . \Lang::get('lang.link') . '</label><br/>
                                        <input type="url" name="content" placeholder="https://www.example.com" class="form-control" style="width:100%" value="' . $model->value . '">
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-default pull-left"  data-dismiss="modal" id="dismis2">' . \Lang::get('lang.close') . '</button>
                                    <button type="submit" class="btn btn-primary"><i class="fa fa-refresh">&nbsp;</i>'.Lang::get('lang.update').'</button>  
                              </div>
                            </form>
                        </div>
                    </div>
                </div>';
                        })
                        ->make();
    }

    /**
     * Post footer.
     *
     * @param type Footer  $footer
     * @param type Request $request
     *
     * @return type response
     */
    public function editSocialButtons($id, Widgets $widgets, Request $request) {

        if($request->filled('socail-button')) {
            $v = \Validator::make($request->all(), [
                'content' => 'url'
            ]);
            if ($v->fails()) {
                $error = $v->errors()->toArray()['content'][0];
                return redirect()->back()->with('fails', $error);
            }
        }
        $widget = $widgets->where('id', '=', $id)->first();
        $widget->title = $request->title;
        $widget->value = $request->content;
        try {
            $widget->save();

            return redirect()->back()->with('success', $widget->name . ' Saved Successfully');
        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->errorInfo[2]);
        }
    }

    /**
     * get SMTP.
     *
     * @return type view
     */
    public function getsmtp() {
        $settings = Smtp::where('id', '=', '1')->first();
        return view('themes.default1.admin.helpdesk.emails.smtp', compact('settings'));
    }

    /**
     * POST SMTP.
     *
     * @return type view
     */
    public function postsmtp(SmtpRequest $request) {
        $data = Smtp::where('id', '=', 1)->first();
        $data->driver = $request->input('driver');
        $data->host = $request->input('host');
        $data->port = $request->input('port');
        $data->encryption = $request->input('encryption');
        $data->name = $request->input('name');
        $data->email = $request->input('email');
        $data->password = Crypt::encrypt($request->input('password'));
        try {
            $data->save();
            return \Redirect::route('getsmtp')->with('success', 'success');
        } catch (Exception $e) {
            return \Redirect::route('getsmtp')->with('fails', $e->errorInfo[2]);
        }
    }

    /**
     * Post settings.
     *
     * @param type Settings $set
     * @param type Request  $request
     *
     * @return type view
     */
    public function PostSettings(Settings $set, Request $request) {
        $settings = $set->where('id', '1')->first();
        $pass = $request->input('password');
        $password = Crypt::encrypt($pass);
        $settings->password = $password;
        try {
            $settings->save();
        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->errorInfo[2]);
        }
        if (Input::file('logo')) {
            $name = Input::file('logo')->getClientOriginalName();
            $destinationPath = 'dist/logo';
            $fileName = rand(0000, 9999) . '.' . $name;
            Input::file('logo')->move($destinationPath, $fileName);
            $settings->logo = $fileName;
            $settings->save();
        }
        try {
            $settings->fill($request->except('logo', 'password'))->save();

            return redirect()->back()->with('success', 'Settings updated Successfully');
        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->errorInfo[2]);
        }
    }

    public function Plugins(CommonSettings $Common) {
        $Common = $Common->select('status')->where('option_name', '=', 'dummy_data_installation')->first();
        if ($Common) {
            if($Common->status == 1 || $Common->status == '1') {
                $message = Lang::get('lang.plugin-with-dummy-data-error-message').' <a href="'.route('clean-database').'">'.Lang::get('lang.click').'</a> '.Lang::get('lang.clear-dummy-data');
                return redirect()->back()->with('fails', $message);
            }   
        }
        return view('themes.default1.admin.helpdesk.settings.plugins');
    }

    public function GetPlugin() {
        $plugins = $this->fetchConfig();

if(\Event::fire('helpdesk.apply.whitelabel')) {
    return \Datatable::collection(new Collection($plugins))
                        ->searchColumns('name')
                          ->addColumn('name', function ($model) {
                            if (array_has($model, 'path')) {
                                if ($model['status'] == 0) {
                                    $activate = '<a href=' . url('plugin/status/' . $model['path']) . '>Activate</a>';
                                    $settings = ' ';
                                } else {
                                    $settings = "";
                                    if (checkArray('settings', $model)) {
                                        $settings = '<a href=' . url($model['settings']) . '>Settings</a> | ';
                                    }
                                    $activate = '<a href=' . url('plugin/status/' . $model['path']) . '>Deactivate</a>';
                                }

                                $delete = '<a href="#"  id=delete' . $model['path'] . ' data-toggle=modal data-target=#del' . $model['path'] . "><span style='color:red'>Delete</span></a>"
                                        . "<div class='modal fade' id=del" . $model['path'] . ">
                                            <div class='modal-dialog'>
                                                <div class=modal-content>  
                                                    <div class=modal-header>
                                                        <h4 class=modal-title>Delete</h4>
                                                    </div>
                                                    <div class=modal-body>
                                                       <p>Are you Sure ?</p>
                                                        <div class=modal-footer>
                                                            <button type=button class='btn btn-default pull-left' data-dismiss=modal id=dismis>" . \Lang::get('lang.close') . '</button>
                                                            <a href=' . url('plugin/delete/' . $model['path']) . "><button class='btn btn-danger'>Delete</button></a>
                                                        </div>


                                                    </div>
                                                </div>
                                            </div>
                                        </div>";
                                $action = '<br><br>' . $delete . ' | ' . $settings . $activate;
                            } else {
                                $action = '';
                            }

                            return ucfirst($model['name']) . $action;
                        })
                        ->addColumn('description', function ($model) {
                            return 'A Helpdesk plugin';
                        })
                        ->addColumn('author', function ($model) {
                            return ucfirst('Helpdesk');
                        })
                        ->addColumn('website', function ($model) {

                            return '<a href="https://www.productdemourl.com">https://www.productdemourl.com</a>';
                        })
                        ->addColumn('version', function ($model) {
                            return $model['version'];
                        })
                        ->make();


        
 
                    }


                    else{

return \Datatable::collection(new Collection($plugins))
                        ->searchColumns('name')
                        ->addColumn('name', function ($model) {
                            if (array_has($model, 'path')) {
                                if ($model['status'] == 0) {
                                    $activate = '<a href=' . url('plugin/status/' . $model['path']) . '>Activate</a>';
                                    $settings = ' ';
                                } else {
                                    $settings = "";
                                    if (checkArray('settings', $model)) {
                                        $settings = '<a href=' . url($model['settings']) . '>Settings</a> | ';
                                    }
                                    $activate = '<a href=' . url('plugin/status/' . $model['path']) . '>Deactivate</a>';
                                }

                                $delete = '<a href="#"  id=delete' . $model['path'] . ' data-toggle=modal data-target=#del' . $model['path'] . "><span style='color:red'>Delete</span></a>"
                                        . "<div class='modal fade' id=del" . $model['path'] . ">
                                            <div class='modal-dialog'>
                                                <div class=modal-content>  
                                                    <div class=modal-header>
                                                        <h4 class=modal-title>Delete</h4>
                                                    </div>
                                                    <div class=modal-body>
                                                       <p>Are you Sure ?</p>
                                                        <div class=modal-footer>
                                                            <button type=button class='btn btn-default pull-left' data-dismiss=modal id=dismis><i class='fa fa-times' aria-hidden='true'>&nbsp;&nbsp;</i>" . \Lang::get('lang.close') . '</button>
                                                            <a href=' . url('plugin/delete/' . $model['path']) . "><button class='btn btn-danger'><i class='fa fa-trash' aria-hidden='true'>&nbsp;&nbsp;</i>Delete</button></a>
                                                        </div>


                                                    </div>
                                                </div>
                                            </div>
                                        </div>";
                                $action = '<br><br>' . $delete . ' | ' . $settings . $activate;
                            } else {
                                $action = '';
                            }

                            return ucfirst($model['name']) . $action;
                        })
                        ->addColumn('description', function ($model) {
                            return ucfirst($model['description']);
                        })
                        ->addColumn('author', function ($model) {
                            return ucfirst($model['author']);
                        })
                        ->addColumn('website', function ($model) {
                            return '<a href=' . $model['website'] . ' target=_blank>' . $model['website'] . '</a>';
                        })
                        ->addColumn('version', function ($model) {
                            return $model['version'];
                        })
                        ->make();



                    }
    }

    /**
     * Reading the Filedirectory.
     *
     * @return type
     */
    public function ReadPlugins() {
        $dir = app_path() . DIRECTORY_SEPARATOR . 'Plugins';
        $plugins = array_diff(scandir($dir), ['.', '..']);

        return $plugins;
    }

    /**
     * After plugin post.
     *
     * @param Request $request
     *
     * @return type
     */
    public function PostPlugins(Request $request) {
        $this->validate($request, ['plugin' => 'required|mimes:application/zip,zip,Zip']);
        try {
            if (!extension_loaded('zip')) {
                throw new Exception('Please enable zip extension in your php');
            }
            $plug = new Plugin();
            $file = $request->file('plugin');
            $destination = app_path() . DIRECTORY_SEPARATOR . 'Plugins';
            $zipfile = $file->getRealPath();
            /*
             * get the file name and remove .zip
             */
            $filename2 = $file->getClientOriginalName();
            $filename2 = str_replace('.zip', '', $filename2);
            $filename1 = ucfirst($file->getClientOriginalName());
            $filename = str_replace('.zip', '', $filename1);
            $dir_check = scandir($destination);
            if (in_array($filename, $dir_check)) {
                return redirect()->back()->with('fails', Lang::get('lang.plugin-exists'));
            }
            mkdir($destination . DIRECTORY_SEPARATOR . $filename);
            /*
             * extract the zip file using zipper
             */
            \Zipper::make($zipfile)->folder($filename2)->extractTo($destination . DIRECTORY_SEPARATOR . $filename);

            $file = app_path() . DIRECTORY_SEPARATOR . 'Plugins' . DIRECTORY_SEPARATOR . $filename; // Plugin file path

            if (file_exists($file)) {
                $seviceporvider = $file . DIRECTORY_SEPARATOR . 'ServiceProvider.php';
                $config = $file . DIRECTORY_SEPARATOR . 'config.php';
                if (file_exists($seviceporvider) && file_exists($config)) {
                    /*
                     * move to faveo config
                     */
                    $faveoconfig = config_path() . DIRECTORY_SEPARATOR . 'plugins' . DIRECTORY_SEPARATOR . $filename . '.php';
                    if ($faveoconfig) {

                        //copy($config, $faveoconfig);
                        /*
                         * write provider list in app.php line 128
                         */
                        //$app = base_path() . DIRECTORY_SEPARATOR . 'config' . DIRECTORY_SEPARATOR . 'app.php';
                        //chmod($app, 0644);
                        //$str = "\n\n\t\t\t'App\\Plugins\\$filename" . "\\ServiceProvider',";
                        //$line_i_am_looking_for = 196;
                        //$lines = file($app, FILE_IGNORE_NEW_LINES);
                        //$lines[$line_i_am_looking_for] = $str;
                        //file_put_contents($app, implode("\n", $lines));
                        $plug->create(['name' => $filename, 'path' => $filename, 'status' => 1]);

                        return redirect()->back()->with('success', Lang::get('lang.plugin-installed'));
                    } else {
                        /*
                         * delete if the plugin hasn't config.php and ServiceProvider.php
                         */
                        $this->deleteDirectory($file);

                        return redirect()->back()->with('fails', Lang::get('no-plugin-file') . $file);
                    }
                } else {
                    /*
                     * delete if the plugin hasn't config.php and ServiceProvider.php
                     */
                    $this->deleteDirectory($file);

                    return redirect()->back()->with('fails', Lang::get('plugin-config-missing') . $file);
                }
            } else {
                /*
                 * delete if the plugin Name is not equal to the folder name
                 */
                $this->deleteDirectory($file);

                return redirect()->back()->with('fails', '<b>' . Lang::get('lang.plugin-path-missing') . '</b>  ' . $file);
            }
        } catch (Exception $ex) {
            return redirect()->back()->with('fails', $ex->getMessage());
        }
    }

    /**
     * Delete the directory.
     *
     * @param type $dir
     *
     * @return bool
     */
    public function deleteDirectory($dir) {
        if (!file_exists($dir)) {
            return true;
        }
        if (!is_dir($dir)) {
            return unlink($dir);
        }
        foreach (scandir($dir) as $item) {
            if ($item == '.' || $item == '..') {
                continue;
            }
            chmod($dir . DIRECTORY_SEPARATOR . $item, 0777);
            if (!$this->deleteDirectory($dir . DIRECTORY_SEPARATOR . $item)) {
                return false;
            }
        }
        chmod($dir, 0777);

        return rmdir($dir);
    }

    public function ReadConfigs() {
        $dir = app_path() . DIRECTORY_SEPARATOR . 'Plugins' . DIRECTORY_SEPARATOR;
        $directories = scandir($dir);
        $files = [];
        foreach ($directories as $key => $file) {
            if ($file === '.' or $file === '..') {
                continue;
            }

            if (is_dir($dir . DIRECTORY_SEPARATOR . $file)) {
                $files[$key] = $file;
            }
        }
        //dd($files);
        $config = [];
        $plugins = [];
        if (count($files) > 0) {
            foreach ($files as $key => $file) {
                $plugin = $dir . $file;
                $plugins[$key] = array_diff(scandir($plugin), ['.', '..', 'ServiceProvider.php']);
                $plugins[$key]['file'] = $plugin;
            }
            foreach ($plugins as $plugin) {
                $dir = $plugin['file'];
                //opendir($dir);
                if ($dh = opendir($dir)) {
                    while (($file = readdir($dh)) !== false) {
                        if ($file == 'config.php') {
                            $config[] = $dir . DIRECTORY_SEPARATOR . $file;
                        }
                    }
                    closedir($dh);
                }
            }

            return $config;
        } else {
            return 'null';
        }
    }

    public function fetchConfig() {
        $configs = $this->ReadConfigs();
        //dd($configs);
        $plugs = new Plugin();
        $fields = [];
        $attributes = [];
        if ($configs != 'null') {
            foreach ($configs as $key => $config) {
                $fields[$key] = include $config;
            }
        }
        //dd($fields);
        if (count($fields) > 0) {
            foreach ($fields as $key => $field) {
                $plug = $plugs->where('name', $field['name'])->select('path', 'status')->orderBy('name')->get()->toArray();
                if ($plug) {
                    foreach ($plug as $i => $value) {
                        $attributes[$key]['path'] = $plug[$i]['path'];
                        $attributes[$key]['status'] = $plug[$i]['status'];
                    }
                } else {
                    $attributes[$key]['path'] = $field['name'];
                    $attributes[$key]['status'] = 0;
                }
                $attributes[$key]['name'] = $field['name'];
                $attributes[$key]['settings'] = $field['settings'];
                $attributes[$key]['description'] = $field['description'];
                $attributes[$key]['website'] = $field['website'];
                $attributes[$key]['version'] = $field['version'];
                $attributes[$key]['author'] = $field['author'];
            }
        }
        //dd($attributes);
        return $attributes;
    }

    public function DeletePlugin($slug) {
        $dir = app_path() . DIRECTORY_SEPARATOR . 'Plugins' . DIRECTORY_SEPARATOR . $slug;
        $this->deleteDirectory($dir);
        /*
         * remove service provider from app.php
         */
        //$str = "'App\\Plugins\\$slug" . "\\ServiceProvider',";
        //$path_to_file = base_path() . DIRECTORY_SEPARATOR . 'config' . DIRECTORY_SEPARATOR . 'app.php';
        //$file_contents = file_get_contents($path_to_file);
        //$file_contents = str_replace($str, '//', $file_contents);
        //file_put_contents($path_to_file, $file_contents);
        $plugin = new Plugin();
        $plugin = $plugin->where('path', $slug)->first();
        if ($plugin) {
            $plugin->delete();
        }

        return redirect()->back()->with('success', 'Deleted Successfully');
    }

    public function StatusPlugin($slug) {
        \Event::fire('lime-survey.plugin.activated');

        $plugs = new Plugin();

        $plug = $plugs->where('name', $slug)->first();

        $status = 0;
        if (!$plug) {
            $status = 1;
        }elseif($plug->status==0){
            $status = 1;
        }

        $plugs->updateOrCreate(['name' => $slug, 'path' => $slug],
                [ 'status' => $status]);

        if($slug == "Calendar" && $status == 0){
            $templates = new Template;
            $templates->whereIn( 'name', ['task-update','task-reminder','task-created','task-status','task-assigned', 'task-deleted', 'task-assigned-owner'])->delete();
        }
        if($slug == "Calendar" && $status == 1){
            TemplateType::updateOrCreate([
                'name' => 'task-reminder',  
                'name' => 'task-created', 
                'name' => 'task-update',
                'name' => 'task-status',
                'name' => 'task-assigned',
                'name' => 'task-deleted',
                'name' => 'task-assigned-owner',
            ]);
            

            Template::updateOrCreate([
                    'variable' => '1',
                    'template_category' => 'common-tmeplates',
                    'subject' => 'Task Update',
                    'name' => 'task-update',
                    'type' => TemplateType::where('name', 'task-update')->first()->id,
                    'set_id' => '1',
                    'message' => '<p>Hello {!! $receiver_name !!},<br /><br />'
                    .'Your task {!! $task_name !!} has been updated by {!! $updated_by !!}.</p>'
                    .'Kind Regards,<br />'
                    .'{!! $system_from !!}'
            ]);
            Template::updateOrCreate([
                    'variable' => '1',
                                'template_category' => 'common-tmeplates',
                                'subject' => 'Task Alert',
                                'name' => 'task-reminder',
                                'type' => TemplateType::where('name', 'task-reminder')->first()->id,
                                'set_id' => '1',
                                'message' => '<p>Hello {!! $receiver_name !!},<br /><br />'
                                        .'Your task {!! $task_name !!} is due on {!! $task_end_date !!}. </p>'
                                        .''
                                        .'Kind Regards,<br />'
                                        .'{!! $system_from !!}'
            ]);
            Template::updateOrCreate([
                    'variable' => '1',
                    'template_category' => 'common-tmeplates',
                    'subject' => 'Task created',
                    'name' => 'task-created',
                    'type' => TemplateType::where('name', 'task-created')->first()->id,
                    'set_id' => '1',
                    'message' => '<p>Hello {!! $receiver_name !!},<br /><br />'
                            .'Your task {!! $task_name !!} has been created,  is due on {!! $task_end_date !!}. </p>'
                            .''
                            .'Kind Regards,<br />'
                            .'{!! $system_from !!}'
            ]);
            Template::updateOrCreate([
                    'variable' => '1',
                    'template_category' => 'common-tmeplates',
                    'subject' => 'Task status update',
                    'name' => 'task-status',
                    'type' => TemplateType::where('name', 'task-status')->first()->id,
                    'set_id' => '1',
                    'message' => '<p>Hello {!! $receiver_name !!},<br /><br />'
                    .'Your task {!! $task_name !!} status has been {!! $status !!}.</p>'
                    .''
                    .'Kind Regards,<br />'
                    .'{!! $system_from !!}'
            ]);
            Template::updateOrCreate([
                    'variable' => '1',
                    'template_category' => 'common-tmeplates',
                    'subject' => 'Task Assigned',
                    'name' => 'task-assigned',
                    'type' => TemplateType::where('name', 'task-assigned')->first()->id,
                    'set_id' => '1',
                    'message' => '<p>Hello {!! $receiver_name !!},<br /><br />'
                        .'You have been assigned to task {!! $task_name !!} by {!! $created_by !!}'
                        .'  is due on {!! $task_end_date !!}.</p>'
                        .''
                        .'Kind Regards,<br />'
                        .'{!! $system_from !!}'
            ]);

            Template::updateOrCreate([
                    'variable' => '1',
                    'template_category' => 'common-tmeplates',
                    'subject' => 'Task Deleted',
                    'name' => 'task-deleted',
                    'type' => TemplateType::where('name', 'task-deleted')->first()->id,
                    'set_id' => '1',
                    'message' => '<p>Hello {!! $receiver_name !!},<br /><br />'
                        .'Your task {!! $task_name !!} was deleted or removed by {!! $updated_by !!}.</p>'
                        .''
                        .'Kind Regards,<br />'
                        .'{!! $system_from !!}'
            ]);

            Template::updateOrCreate([
            'variable' => '1',
            'template_category' => 'common-tmeplates',
            'subject' => 'Task Assigned',
            'name' => 'task-assigned-owner',
            'type' => TemplateType::where('name', 'task-assigned-owner')->first()->id,
            'set_id' => '1',
            'message' => '<p>Hello {!! $receiver_name !!},<br /><br />'
                        .'Your task {!! $task_name !!} has been assigned to {!! $agent_name !!} and'
                        .'  is due on {!! $task_end_date !!}.</p>'

                        .''
                        .'Kind Regards,<br />'
                        .'{!! $system_from !!}'
            ]);

        }

        if($slug == "LimeSurvey" && $status == 1){
            // \Event::fire('lime-survey.plugin.activated');
        }

        \Event::fire('plugin.status.change',[['name'=>$slug,'status'=>$status]]);

        return redirect()->back()->with('success',Lang::get('lang.plugin_updated_successfully'));
    }

    /**
     * 
     * @param CommonSettings $Common
     * @return type
     */
    public function modules(CommonSettings $Common) {

        return view('themes.default1.admin.helpdesk.modules.all-module');
    }

    /**
     * 
     * @return type
     */
    public function Getmodules() {
        try {
          $moduleQuery = CommonSettings::select('option_name', 'status')->where('option_name', 'helptopic_link_with_type')->orwhere('option_name','micro_organization_status')->orwhere('option_name','batch_tickets')->orwhere('option_name','redirect_to_timeline')->orwhere('option_name', 'time_track');

            $satellite_path = base_path('app/SatelliteHelpdesk');
            $checkValue = CommonSettings::where('option_name', 'satellite_helpdesk')->first();
            if (is_dir($satellite_path) && !$checkValue) {
                \Event::fire('helpdesk.prasent.satellitehelpdesk');
                $moduleQuery = $moduleQuery->orwhere('option_name', 'satellite_helpdesk');
            } elseif (!is_dir($satellite_path) && $checkValue) {

                CommonSettings::where('option_name', 'satellite_helpdesk')->delete();
            } else {
                $moduleQuery = $moduleQuery->orwhere('option_name', 'satellite_helpdesk');
            }
          return \DataTables::of($moduleQuery->get())
                        ->editColumn('name', function ($moduleQuery) {
                            if ($moduleQuery->option_name == 'helptopic_link_with_type') {
                                $name = 'Helptopic link with type';
                                $name_with_tooltip = ' <a class="right" title="" data-placement="right" data-toggle="tooltip" href="#" data-original-title="' . Lang::get('HelptopicType::lang.if_enabled_on_the_ticket_create_edit_page_only_those_type_will_show_which_are_linked_to_selected_helptopic_if_none_linked_all_ticket_type_will_show') . '">' . $name . ' </a>';
                            } elseif ($moduleQuery->option_name == 'micro_organization_status') {
                                $name = 'Organization Department';
                                $name_with_tooltip = ' <a class="right" title="" data-placement="right" data-toggle="tooltip" href="#" data-original-title="' . Lang::get('lang.organization_department_add_ability_to_setup_department_for_user_organization_and_this_can_be_used_for_assigning_SLA') . '">' . $name . ' </a>';

                            } elseif ($moduleQuery->option_name == 'satellite_helpdesk') {
                                $name = 'Satellite Helpdesk';
                                $name_with_tooltip = ' <a class="right" title="" data-placement="right" data-toggle="tooltip" href="#" data-original-title="' . Lang::get('lang.satellite_helpdesk') . '">' . $name . ' </a>';
                            }
                            elseif ($moduleQuery->option_name == 'batch_tickets') {
                                $name = ucwords(__('lang.batch-ticket'));
                                $name_with_tooltip = ' <a class="right" title="" data-placement="right" data-toggle="tooltip" href="#" data-original-title="' . __('lang.batch-ticket-description') . '">' . $name . ' </a>';

                            }elseif ($moduleQuery->option_name == 'redirect_to_timeline') {
                                $name = ucwords(__('lang.redirect-to-timeline'));
                                $name_with_tooltip = ' <a class="right" title="" data-placement="right" data-toggle="tooltip" href="#" data-original-title="' . __('lang.redirect-to-timeline-description') . '">' . $name . ' </a>';
                            } elseif ($moduleQuery->option_name == 'time_track') {
                                $name = ucwords(__('lang.time-track'));
                                $name_with_tooltip = ' <a class="right" title="" data-placement="right" data-toggle="tooltip" href="#" data-original-title="' . __('lang.time-track-description') . '">' . $name . ' </a>';
                            } else {

                                $name = 'Helpdesk Module';
                                $name_with_tooltip = $name;
                            }

                            return $name_with_tooltip;
                        })
                        ->editColumn('version', function ($moduleQuery) {

                            return '1.0.0';
                        })
                        ->addColumn('action', function ($moduleQuery) {

                            if ($moduleQuery->status == 1) {
                                return'<label class="switch toggle_event_editing">
                            <input type="hidden" name="module_name" class="module_name" value="' . $moduleQuery->option_name . '" >
                         <input type="checkbox" name="modules_settings" checked value="'.$moduleQuery->status.'"  class="modules_settings_value">
                          <span class="slider round"></span>
                        </label>';
                            } else {
                                return'<label class="switch toggle_event_editing">
                             <input type="hidden" name="module_name" class="module_name" value="' . $moduleQuery->option_name . '" >
                         <input type="checkbox" name="modules_settings" value="'.$moduleQuery->status.'" class="modules_settings_value">
                          <span class="slider round"></span>
                        </label>';
                            }
                        })
                        ->rawColumns(['name', 'version', 'action'])
                        ->make();

        } catch (Exception $ex) {
            return redirect()->back()->with('fails', $ex->getMessage());
        }
                        
    }

    /**
     * 
     * @param Request $request
     * @return mixed Errors or Success message
     */
    public function ChangemoduleStatus(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'current_module_name'   => 'required',
            'current_module_status' => 'required',
        ]);

        if ($validator->fails()) {

            $errors = $validator->errors();

            $all_errors['current_module_name']   = $errors->first('current_module_name');
            $all_errors['current_module_status'] = $errors->first('current_module_status');

            return errorResponse($all_errors, 422);
        }

        try {
            $update = CommonSettings::where('option_name', $request->current_module_name)->first();
            $status=($request->current_module_status==1)?0:1;
            $update->status = $status;
            $update->save();

            if($request->current_module_name == 'satellite_helpdesk'){
               if (env('DB_INSTALL') == 1 && !Schema::hasTable('satellite_helpdesk')) {
                    $path = "app" . DIRECTORY_SEPARATOR . "SatelliteHelpdesk" . DIRECTORY_SEPARATOR . "database" . DIRECTORY_SEPARATOR . "migrations";
                    Artisan::call('migrate', [
                        '--path' => $path,
                        '--force' => true,
                     ]);
                }
            }

            // disable time track additional feature
            if ($update->option_name == 'time_track' && $request->current_module_status == 1) {
                $timeTrack = CommonSettings::where('option_name', 'time_track_option')->first();

                if ($timeTrack) {
                     $timeTrack->status = 0;
                    $timeTrack->save();
                }               
            }
            
           return Lang::get('lang.your_status_updated_successfully');
        } catch (Exception $e) {
            return Redirect()->back()->with('fails', $e->getMessage());
        }
    }

}
