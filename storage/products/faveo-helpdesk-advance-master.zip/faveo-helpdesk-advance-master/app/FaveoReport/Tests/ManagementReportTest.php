<?php

namespace App\FaveoReport\Tests;

use App\FaveoReport\Jobs\ManagementReportExportJob;
use App\Model\MailJob\QueueService;
use App\User;
use Illuminate\Foundation\Testing\DatabaseTransactions;
use Illuminate\Support\Facades\Queue;
use Illuminate\Support\Str;
use Tests\DBTestCase;

class ManagementReportTest extends DBTestCase
{
    use DatabaseTransactions;

    /**
     * @return Array $params New ticket params
     */
    private function get_management_create_ticket_params()
    {
        $user_id = factory(User::class)->create(['role' => 'admin'])->id;
        $params  = [
            "requester"   => $user_id,
            "subject"     => "Unit Test For management report",
            "type"        => 1,
            "status"      => 1,
            "priority"    => 2,
            "location"    => "Bangalore",
            "help_topic"  => 1,
            "department"  => 1,
            "assigned"    => 1,
            "description" => "<p><span class='scayt-misspell-word' data-scayt-word='TEst' data-scayt-lang='en_US'>This is unit Test for management report</span><br></p>",
            "company"     => "",
            "api"         => "true",
        ];
        return $params;
    }

    /**
     * Test create ticket with admin previlage
     * @uses get_management_create_ticket_params
     * @group reports
     */
    public function test_postNewticket_createTicketAsAdmin()
    {
        $this->getLoggedInUserForWeb('admin');
        $params   = $this->get_management_create_ticket_params();
        $response = $this->call("POST", route('post.newticket'), $params);
        $response->assertStatus(200);
    }

    /** @group reports */
    public function test_getView_asAdmin()
    {
        $this->getLoggedInUserForWeb('admin');
        $response = $this->call('GET', url('management/performance'));
        $response->assertStatus(200);
    }

    /** @group reports */
    public function test_getView_asAgent()
    {
        $this->getLoggedInUserForWeb('agent');
        $this->createPermissionForLoggedInUser(["report" => "1"]);
        $response = $this->call('GET', url('management/performance'));
        $response->assertStatus(200);
    }

    /** @group reports */
    public function test_ManagementQuery_asAdmin()
    {
        $this->getLoggedInUserForWeb('admin');
        $response = $this->call('post', url('report/management/report'));
        $response->assertStatus(200);
    }

    /** @group reports */
    public function test_result_allCustomFieldsAsAdmin()
    {
        $this->getLoggedInUserForWeb('admin');
        $response = $this->call('GET', url('custom-filter-fields?get-all=true'));
        $response->assertStatus(200);
    }

    /** @group reports */
    public function test_agentApi_asAdminWithoutInactiveAgents()
    {
        $this->getLoggedInUserForWeb('admin');
        $response = $this->call('GET', url('report/api/get/agents'));
        $response->assertStatus(200);
    }

    /** @group reports */
    public function test_agentApi_asAdminWithInactiveAgents()
    {
        $this->getLoggedInUserForWeb('admin');
        $response = $this->call('GET', url('report/api/get/agents'), ['inactive' => 'Yes']);
        $response->assertStatus(200);
    }

    /** @group reports */
    public function test_departmentApi_asAdmin()
    {
        $this->getLoggedInUserForWeb('admin');
        $response = $this->call('GET', url('report/api/get/departments'));
        $response->assertStatus(200);
    }

    /** @group reports */
    public function test_sourceApi_asAdmin()
    {
        $this->getLoggedInUserForWeb('admin');
        $response = $this->call('GET', url('report/api/get/sources'));
        $response->assertStatus(200);
    }

    /** @group reports */
    public function test_priorityApi_asAdminWithoutInactivePriorities()
    {
        $this->getLoggedInUserForWeb('admin');
        $response = $this->call('GET', url('report/api/get/priorities'));
        $response->assertStatus(200);
    }

    /** @group reports */
    public function test_priorityApi_asAdminWithInactivePriorities()
    {
        $this->getLoggedInUserForWeb('admin');
        $response = $this->call('GET', url('report/api/get/priorities'), ['inactive' => 'Yes']);
        $response->assertStatus(200);
    }

    /** @group reports */
    public function test_clientApi_asAdminWithoutInactiveClients()
    {
        $this->getLoggedInUserForWeb('admin');
        $response = $this->call('GET', url('report/api/get/clients'));
        $response->assertStatus(200);
    }

    /** @group reports */
    public function test_clientApi_asAdminWithInactiveClients()
    {
        $this->getLoggedInUserForWeb('admin');
        $response = $this->call('GET', url('report/api/get/clients'), ['inactive' => 'Yes']);
        $response->assertStatus(200);
    }

    /** @group reports */
    public function test_typeApi_asAdminWithoutInctiveTypes()
    {
        $this->getLoggedInUserForWeb('admin');
        $response = $this->call('GET', url('report/api/get/types'));
        $response->assertStatus(200);
    }

    /** @group reports */
    public function test_typeApi_asAdminWithInctiveTypes()
    {
        $this->getLoggedInUserForWeb('admin');
        $response = $this->call('GET', url('report/api/get/types'), ['inactive' => 'Yes']);
        $response->assertStatus(200);
    }

    /** @group reports */
    public function test_statusApi_asAdmin()
    {
        $this->getLoggedInUserForWeb('admin');
        $response = $this->call('GET', url('report/api/get/status'));
        $response->assertStatus(200);
    }

    /** @group reports */
    public function test_helptopicApi_asAdminWithoutInactiveHelptopics()
    {
        $this->getLoggedInUserForWeb('admin');
        $response = $this->call('GET', url('report/api/get/helptopic'));
        $response->assertStatus(200);
    }

    /** @group reports */
    public function test_helptopicApi_asAdminWithInactiveHelptopics()
    {
        $this->getLoggedInUserForWeb('admin');
        $response = $this->call('GET', url('report/api/get/helptopic'), ['inactive' => 'Yes']);
        $response->assertStatus(200);
    }

    /** @group reports */
    public function test_teamApi_asAdminWithoutInactiveTeams()
    {
        $this->getLoggedInUserForWeb('admin');
        $response = $this->call('GET', url('report/api/get/team'));
        $response->assertStatus(200);
    }

    /** @group reports */
    public function test_teamApi_asAdminWithInactiveTeams()
    {
        $this->getLoggedInUserForWeb('admin');
        $response = $this->call('GET', url('report/api/get/team'), ['inactive' => 'Yes']);
        $response->assertStatus(200);
    }

    /** @group reports */
    public function test_triggerManagementReportExport_asAdminWithQueueDriverSync()
    {
        QueueService::where('status', 1)->update(['status' => 0]);
        QueueService::where('short_name', 'sync')->update(['status' => 1]);

        Queue::fake();

        $this->getLoggedInUserForWeb('admin');

        $response = $this->json('POST', route('report.management.performance.export'));
        $response->assertJson(['status' => 'failed']);

        Queue::assertNotPushed(ManagementReportExportJob::class);
    }

    /** @group reports */
    public function test_triggerManagementReportExport_asAdminWithQueueDriverDatabase()
    {
        QueueService::where('status', 1)->update(['status' => 0]);
        QueueService::where('short_name', 'database')->update(['status' => 1]);

        Queue::fake();

        $this->getLoggedInUserForWeb('admin');

        $response = $this->json('POST', route('report.management.performance.export'));
        $response->assertJson(['status' => 'success']);

        Queue::assertPushed(ManagementReportExportJob::class);
        Queue::assertPushedOn('reports', ManagementReportExportJob::class);
    }

    /** @group reports */
    public function test_downloadManagementReportExport_asAdmin()
    {
        $this->getLoggedInUserForWeb('admin');

        $hash = Str::random(60);

        $report = \App\FaveoReport\Models\Report::create([
            'file'         => 'test.xls',
            'type'         => 'Test Report',
            'hash'         => $hash,
            'expired_at'   => \Carbon\Carbon::now()->addHours(6),
            'is_completed' => 1,
            'user_id'      => factory(User::class)->create(['role' => 'admin'])->id,
        ]);

        $response = $this->call('GET', route('report.management.performance.export.download', $hash));

        $response->assertStatus(410);
    }

    /** @group reports */
    public function test_escapeContent_asAdmin()
    {
        $this->getLoggedInUserForWeb('admin');

        $mngt_report = new \App\FaveoReport\Controllers\ManagementReport();

        $result = $this->getPrivateMethod($mngt_report, 'escapeContent', ['<style></style>']);

        $this->assertEquals($result, '');
    }

    /** @group reports */
    public function test_stripTagsContent_asAdmin()
    {
        $this->getLoggedInUserForWeb('admin');

        $mngt_report = new \App\FaveoReport\Controllers\ManagementReport();

        $result = $this->getPrivateMethod($mngt_report, 'stripTagsContent', ['<style><h1>hi</h1></style>hello']);

        $this->assertEquals($result, 'hello');
    }
}
