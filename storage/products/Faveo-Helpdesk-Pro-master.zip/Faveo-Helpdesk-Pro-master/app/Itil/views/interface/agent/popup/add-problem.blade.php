
<style>
    .table .table-bordered {
        width: 100%     !important;
    }
</style>
<div class="btn-group">
    <button type="button" class="btn btn-sm btn-primary">Problems</button>
    <button type="button" class="btn btn-sm btn-primary dropdown-toggle" data-toggle="dropdown" style="height: 30px">
        <span class="caret"></span>
        <span class="sr-only">Toggle Dropdown</span>
    </button>
    <ul class="dropdown-menu" role="menu">
        <li><a href="#problem" data-toggle="modal" data-target="#problemnew{{$id->id}}">Attach New Problem</a></li>
        <li><a href="#problem"  data-toggle="modal" data-target="#problemexisting{{$id->id}}">Attach Existing Problem</a></li>
    </ul>
</div>
<div class="modal fade" id="problemnew{{$id->id}}">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">New Problems</h4>
                {!! Form::open(['url'=>'service-desk/attach-problem/ticket/new']) !!}
            </div>
            <div class="modal-body">
                <?php
                $subject = \App\Itil\Controllers\UtilityController::getSubjectByThreadId($id);
                $content = \App\Itil\Controllers\UtilityController::getBodyByThreadMaxId($id);
                $requester = \App\User::pluck('email', 'email')->toArray();
                $status = \App\Model\helpdesk\Ticket\Ticket_Status::pluck('name', 'id')->toArray();
                $priority = \App\Model\helpdesk\Ticket\Ticket_Priority::pluck('priority', 'priority_id')->toArray();
                $impact = App\Itil\Models\Problem\Impact::pluck('name', 'id')->toArray();
                //$group = \App\Model\helpdesk\Agent\Groups::pluck('name', 'id')->toArray();
                $agent = \App\User::where('role', '!=', 'user')->pluck('email', 'id')->toArray();
                if(isAsset()==true){
                    $assets = \App\Itil\Models\Assets\SdAssets::pluck('name', 'id')->toArray();
                }
                 $location = App\Location\Models\Location::pluck('title', 'id')->toArray();
                // $location = App\Itil\Models\Common\Location::pluck('title', 'id')->toArray();
                $ticket = App\Itil\Controllers\UtilityController::getTicketByThreadId($id);
                ?>
                <!-- Form  -->
                
                {!! Form::hidden('ticketid',$ticket->id) !!}
                <div class="row">


                    <div class="form-group col-md-6 {{ $errors->has('from') ? 'has-error' : '' }}">
                        {!! Form::label('from',Lang::get('itil::lang.from')) !!} 
                        {!! Form::select('from',$requester,null,['class' => 'form-control']) !!}
                    </div>
                    <div class="form-group col-md-6 {{ $errors->has('subject') ? 'has-error' : '' }}">
                        {!! Form::label('subject',Lang::get('itil::lang.subject')) !!} 
                        {!! Form::text('subject',$subject,['class' => 'form-control']) !!}
                    </div>
                    <div class="form-group col-md-12 {{ $errors->has('description') ? 'has-error' : '' }}">
                        {!! Form::label('description',Lang::get('itil::lang.description')) !!}
                       {!! Form::text('description',$content,['class' => 'form-control','id'=>'ckeditor1']) !!}
                    </div>
                    <div class="form-group col-md-4 {{ $errors->has('status_type_id') ? 'has-error' : '' }}">
                        {!! Form::label('status_type_id',Lang::get('itil::lang.status')) !!}
                        {!! Form::select('status_type_id',$status,null,['class' => 'form-control']) !!}
                    </div>
                    <div class="form-group col-md-4 {{ $errors->has('priority_id') ? 'has-error' : '' }}">
                        {!! Form::label('priority_id',Lang::get('itil::lang.priority')) !!}
                        {!! Form::select('priority_id',$priority,null,['class' => 'form-control']) !!}
                    </div>
                    <div class="form-group col-md-4 {{ $errors->has('impact_id') ? 'has-error' : '' }}">
                        {!! Form::label('impact_id',Lang::get('itil::lang.impact')) !!}
                        {!! Form::select('impact_id',$impact,null,['class' => 'form-control']) !!}
                    </div>
                    <div class="form-group col-md-6 {{ $errors->has('location_type_id') ? 'has-error' : '' }}">
                        {!! Form::label('location_type_id',Lang::get('itil::lang.location')) !!}
                        {!! Form::select('location_type_id',$location,null,['class' => 'form-control']) !!}
                    </div>
                    {{--<div class="form-group col-md-6 {{ $errors->has('group_id') ? 'has-error' : '' }}">
                        {!! Form::label('group_id',Lang::get('itil::lang.group')) !!}
                        {!! Form::select('group_id',$group,null,['class' => 'form-control']) !!}
                    </div>--}}
                    <div class="form-group col-md-6 {{ $errors->has('agent_id') ? 'has-error' : '' }}">
                        {!! Form::label('agent_id',Lang::get('itil::lang.agent')) !!}
                        {!! Form::select('agent_id',$agent,null,['class' => 'form-control']) !!}
                    </div>
                    <div class="form-group col-md-6 {{ $errors->has('assigned_id') ? 'has-error' : '' }}">
                        {!! Form::label('assigned_id',Lang::get('itil::lang.assigned')) !!}
                        {!! Form::select('assigned_id',$agent,null,['class' => 'form-control']) !!}
                    </div>
                    @if(isAsset()==true)
                    <div class="form-group col-md-6 {{ $errors->has('asset') ? 'has-error' : '' }}">
                        {!! Form::label('asset',Lang::get('itil::lang.asset')) !!}
                        {!! Form::select('asset',$assets,null,['class' => 'form-control']) !!}
                    </div>
                    @endif

                    <div class="form-group col-md-6 {{ $errors->has('attachment') ? 'has-error' : '' }}">
                        {!! Form::label('attachment',Lang::get('itil::lang.attachment')) !!}
                        {!! Form::file('attachment',null,['class' => 'form-control']) !!}
                    </div>



                </div>



            </div>
            <div class="modal-footer">
                <button type="button" id="close" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <input type="submit" class="btn btn-primary" value="{{Lang::get('lang.save')}}">
                {!! Form::close() !!}
            </div>

            
            <!-- /Form -->
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->  


<!-- Existing Problem-->
<div class="modal fade" id="problemexisting{{$id->id}}">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="post" action="{{url('service-desk/attach-problem/ticket/existing')}}">
                <input type="hidden" name="_token" value="{{csrf_token()}}">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Existing Problems</h4>
                
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-12">
                        <!-- Form  -->
                        
                        {!! Form::hidden('ticketid',$ticket->id) !!}

                        {!! Datatable::table()
                        ->addColumn('#', 'Subject')
                        ->setUrl(url('service-desk/problems/attach/existing'))
                        ->render() !!}
                    </div>
                </div>


            </div>
            <div class="modal-footer">
                <button type="button" id="close" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <input type="submit" class="btn btn-primary" value="{{Lang::get('lang.save')}}">
                
            </div>

            </form>
            <!-- /Form -->
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->  
