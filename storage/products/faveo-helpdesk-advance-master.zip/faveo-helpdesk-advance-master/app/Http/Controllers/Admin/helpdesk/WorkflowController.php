<?php

namespace App\Http\Controllers\Admin\helpdesk;

// controller
use App\Http\Controllers\Agent\helpdesk\TicketController;
use App\Http\Controllers\Controller;
// request
use App\Http\Requests\helpdesk\WorkflowCreateRequest;
use App\Http\Requests\helpdesk\WorkflowUpdateRequest;
use App\Model\helpdesk\Agent\Department;
// model
use App\Model\helpdesk\Agent\Teams;
use App\Model\helpdesk\Email\Emails;
use App\Model\helpdesk\Manage\Help_topic;
use App\Model\helpdesk\Manage\Sla\Sla_plan;
use App\Model\helpdesk\Ticket\Ticket_Priority;
use App\Model\helpdesk\Ticket\Ticket_Status;
use App\Model\helpdesk\Workflow\WorkflowAction;
use App\Model\helpdesk\Workflow\WorkflowName;
use App\Model\helpdesk\Workflow\WorkflowRules;
use App\User;
use Datatable;
//classes
use Exception;
use Illuminate\Http\Request;
use Lang;

/**
 * WorkflowController
 * In this controller in the CRUD function for all the workflow applied in faveo.
 *
 * @author      Ladybird <info@ladybirdweb.com>
 */
class WorkflowController extends Controller
{
    /**
     * Create a new controller instance.
     * constructor to check
     * 1. authentication
     * 2. user roles
     * 3. roles must be agent.
     *
     * @return void
     */
    public function __construct()
    {
        // checking authentication
        $this->middleware('auth');
        // checking admin roles
        $this->middleware('roles');
    }
    /**
     * Display a listing of all the workflow.
     *
     * @return type
     */
    public function index()
    {
        try {
            $workflow = WorkflowName::select('id', 'name')->orderBy('order')->get()->toJson();
            return view('themes.default1.admin.helpdesk.manage.workflow.index', compact('workflow'));
        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }
    /**
     * List of all the workflow in the system.
     *
     * @return type
     */
    public function workFlowList()
    {
        // returns chumper datatable
        return Datatable::collection(WorkflowName::All())
                        /* searcable column name */
                        ->searchColumns('name')
                        /* order column name and description */
                        ->orderColumns('name', 'order', 'rules', 'Updated', 'Created')
                        /* add column name */
                        ->addColumn('name', function ($model) {
                            return $model->name;
                        })
                        /* add column status */
                        ->addColumn('status', function ($model) {
                            if ($model->status == 1) {
                                return '<p class="btn btn-xs btn-default" style="pointer-events:none;color:green">' . Lang::get('lang.active') . '</p>';
                            }
                            elseif ($model->status == 0) {
                                return '<p class="btn btn-xs btn-default" style="pointer-events:none;color:red">' . Lang::get('lang.inactive') . '</p>';
                            }
                        })
                        /* add column order */
                        ->addColumn('order', function ($model) {
                            return $model->order;
                        })
                        /* add column rules */
                        ->addColumn('rules', function ($model) {
                            $rules = WorkflowRules::where('workflow_id', '=', $model->id)->count();

                            return $rules;
                        })
                        /* add column target */
                        ->addColumn('target', function ($model) {
                            $target = "";
                            if ($model->target == 'any') {
                                $target = "Any";
                            }
                            else {
                                $targets = $model->targets()->first();
                                if ($targets) {
                                    $target = $targets->value;
                                }
                            }
                            return $target;
                        })
                        /* add column created */
                        ->addColumn('Created', function ($model) {
                            return faveoDate($model->created_at);
                        })
                        /* add column updated */
                        ->addColumn('Updated', function ($model) {
                            return faveoDate($model->updated_at);
                        })
                        /* add column action */
                        ->addColumn('Actions', function ($model) {
                            $url          = url('/workflow/delete/' . $model->id);
                            $confirmation = $delete       = \App\Itil\Controllers\UtilityController::deletePopUp($model->id, $url, "Delete $model->subject");

                            return "<a class='btn btn-primary btn-xs ' href='" . route('workflow.edit', $model->id) . "'><i class='fa fa-edit text-white'></i>&nbsp; Edit</a> &nbsp;$confirmation";
                        })
                        ->make();
    }
    /**
     * Show the form for creating a new workflow.
     *
     * @return type Response
     */
    public function create(Emails $emails)
    {
        $email_data = [];
        foreach ($emails->pluck('email_address', 'id') as $key => $email) {
            $email_data["E-$key"] = $email;
        }
        $emails = $email_data;

        try {
            return view('themes.default1.admin.helpdesk.manage.workflow.create', compact('emails'));
        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }
    /**
     * Store a new workflow in to the system.
     *
     * @param \App\Http\Requests\helpdesk\WorkflowCreateRequest $request
     *
     * @return type view
     */
    public function store(WorkflowCreateRequest $request)
    {
        $workflow = $request->input('workflow');
        $rules    = $this->removeEmptyRuleOrActionArray($request->input('rules'));
        $actions  = $this->removeEmptyRuleOrActionArray($request->input('actions'), 'actions');
        try {
            // store a new workflow credentials in to the system
            $workflow_name = new WorkflowName();
            $max_order = $workflow_name->max('order');
            if ($max_order == null) {
                $max_order = 0;
            }
            $workflow['order'] = $max_order+1;
            $workflow_name->fill($workflow)->save();
            $workflow_name->rule()->createMany($rules);
            $workflow_name->action()->createMany($actions);
            return response()->json(['message' => Lang::get('lang.workflow_saved_successfully')]);
            //return redirect('workflow')->with('success', Lang::get('lang.workflow_saved_successfully'));
        } catch (Exception $e) {
            //return redirect()->back()->with('fails', $e->getMessage());
            return response()->json(['error' => $e->getMessage()]);
        }
    }
    /**
     * Editing the details of the banned users.
     *
     * @param type $id
     * @param User $ban
     *
     * @return type Response
     */
    public function edit($id, WorkflowName $work_flow_name, Emails $emails, WorkflowRules $workflow_rule, WorkflowAction $workflow_action)
    {
        try {
            $emails           = $emails->get();
            $workflow         = $work_flow_name->whereId($id)->first();
            if (!$workflow) {
                return redirect()->to('workflow')->with('fails', Lang::get('lang.not_found'));
            }
            $workflow_rules   = $workflow->rule()->select('matching_scenario', 'matching_relation', 'matching_value', 'custom_rule')->get()->toJson();
            $workflow_actions = $workflow->action()->select('condition', 'action', 'custom_action')->get()->toJson();

            return view('themes.default1.admin.helpdesk.manage.workflow.edit', compact('id', 'workflow', 'emails', 'workflow_rules', 'workflow_actions'));
        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }
    /**
     * Update ticket workflow.
     *
     * @param type                                              $id
     * @param \App\Http\Requests\helpdesk\WorkflowUpdateRequest $request
     *
     * @return type view
     */
    public function update($id, WorkflowCreateRequest $request)
    {
        try {
            $workflow      = $request->input('workflow');
            $rules         = $this->removeEmptyRuleOrActionArray($request->input('rules'));
            $actions       = $this->removeEmptyRuleOrActionArray($request->input('actions'), 'actions');
            // store a new workflow credentials in to the system
            $workflow_name = WorkflowName::whereId($id)->first();
            if (!$workflow_name) {
                return errorResponse(\Lang::get('lang.not_found'), 404);
            }
            $workflow_name->fill($workflow)->save();
            $workflow_name->rule()->delete();
            $workflow_name->rule()->createMany($rules);
            $workflow_name->action()->delete();
            $workflow_name->action()->createMany($actions);
            return response()->json(['message' => Lang::get('lang.workflow_updated_successfully')]);
            //return redirect('workflow')->with('success', Lang::get('lang.workflow_updated_successfully'));
        } catch (Exception $e) {
            return response()->json(['error' => $e->getMessage()]);
            //return redirect()->back()->with('fails', $e->getMessage());
        }
    }
    /**
     * function to delete workflow.
     *
     * @param type $id
     */
    public function destroy($id)
    {
        try {
            // remove all the contents of workflow
            $workflow_action = WorkflowAction::where('workflow_id', '=', $id)->delete();
            $workflow_rules  = WorkflowRules::where('workflow_id', '=', $id)->delete();
            $workflow        = WorkflowName::whereId($id)->delete();

            return redirect('workflow')->with('success', Lang::get('lang.workflow_deleted_successfully'));
        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }
    /**
     * function to select action.
     *
     * @param type                     $id
     * @param \Illuminate\Http\Request $request
     *
     * @return type void
     */
    public function selectAction($id, Request $request)
    {
        if ($request->option == 'reject') {
            return $this->rejectTicket($id);
        }
        elseif ($request->option == 'department') {
            return $this->department($id);
        }
        elseif ($request->option == 'priority') {
            return $this->priority($id);
        }
        elseif ($request->option == 'sla') {
            return $this->slaPlan($id);
        }
        elseif ($request->option == 'team') {
            return $this->assignTeam($id);
        }
        elseif ($request->option == 'agent') {
            return $this->assignAgent($id);
        }
        elseif ($request->option == 'helptopic') {
            return $this->helptopic($id);
        }
        elseif ($request->option == 'status') {
            return $this->ticketStatus($id);
        }
    }
    /**
     * function to reject ticket.
     *
     * @return string
     */
    public function rejectTicket($id)
    {
        $var = '<input type="hidden" name="action[' . $id . '][b]" class="form-control" value="reject"><span text-red>Reject</span> ';

        return $var;
    }
    /**
     * function to return deprtment select option.
     *
     * @return type string
     */
    public function department($id)
    {
        $departments = Department::all();
        $var         = "<select name='action[" . $id . "][b]' class='form-control required'>";
        foreach ($departments as $department) {
            $var .= "<option value='" . $department->id . "'>" . $department->name . '</option>';
        }
        $var .= '</select>';

        return $var;
    }
    /**
     * function to return the priority select option.
     *
     * @return type string
     */
    public function priority($id)
    {
        $priorities = Ticket_Priority::where('status', '=', 1)->get();
        $var        = "<div ><select name='action[" . $id . "][b]' class='form-control required'>";
        foreach ($priorities as $priority) {
            $var .= "<option value='" . $priority->priority_id . "'>" . $priority->priority_desc . '</option>';
        }
        $var .= '</select></div>';

        return $var;
    }
    /**
     * function to return the slaplan select option.
     *
     * @return type string
     */
    public function slaPlan($id)
    {
        $sla_plans = Sla_plan::where('status', '=', 1)->get();
        $var       = "<div ><select name='action[" . $id . "][b]' class='form-control required'>";
        foreach ($sla_plans as $sla_plan) {
            $var .= "<option value='" . $sla_plan->id . "'>" . $sla_plan->name . '</option>';
        }
        $var .= '</select></div>';

        return $var;
    }
    /**
     * function to get system team select option.
     *
     * @return type string
     */
    public function assignTeam($id)
    {
        $teams = Teams::where('status', '=', 1)->get();
        $var   = "<div ><select name='action[" . $id . "][b]' class='form-control required'>";
        foreach ($teams as $team) {
            $var .= "<option value='" . $team->id . "'>" . $team->name . '</option>';
        }
        $var .= '</select></div>';

        return $var;
    }
    /**
     * function to get system agents select option.
     *
     * @return type string
     */
    public function assignAgent($id)
    {
        $users = User::where('role', '!=', 'user')->where('active', '=', 1)->where('is_delete', '!=', 1)->where('ban', '!=', 1)->get();
        $var   = "<div ><select name='action[" . $id . "][b]' class='form-control required'>";
        foreach ($users as $user) {
            $var .= "<option value='" . $user->id . "'>" . $user->first_name . ' ' . $user->last_name . '</option>';
        }
        $var .= '</select></div>';

        return $var;
    }
    /**
     * function to get the helptopic select option.
     *
     * @return type string
     */
    public function helptopic($id)
    {
        $help_topics = Help_topic::where('status', '=', 1)->get();
        $var         = "<div><select name='action[" . $id . "][b]' class='form-control required'>";
        foreach ($help_topics as $help_topic) {
            $var .= "<option value='" . $help_topic->id . "'>" . $help_topic->topic . '</option>';
        }
        $var .= '</select></div>';

        return $var;
    }
    /**
     * function to get the select option to choose the ticket status.
     *
     * @return type string
     */
    public function ticketStatus($id)
    {
        $ticket_status = Ticket_Status::all();
        $var           = "<div><select name='action[" . $id . "][b]' class='form-control required'>";
        foreach ($ticket_status as $status) {
            $var .= "<option value='" . $status->id . "'>" . $status->name . '</option>';
        }
        $var .= '</select></div>';

        return $var;
    }
    /**
     * Reordering the list position
     * 
     * @param Request $request
     * @return json
     */
    public function reorder(Request $request)
    {
       
        try {
            $lists = $request->input('order');
            if (count($lists) > 0) {
                foreach ($lists as $pos => $array) {
                    if (is_numeric($pos)) {
                        $id = $array['id'];
                        WorkflowName::whereId($id)->update(['order' => $pos + 1]);
                    }
                }
            }
            $message = ['message' => 'Ordered successfully'];
            $status  = 200;
        } catch (\Exception $ex) {
            $message = ['error' => $ex->getMessage()];
            $status  = 500;
        }
        return response()->json($message, $status);
    }

    /**
     * @category function to remove Rule or Action array if they only ontain hashKey
     * @param Array $rules, String $type
     * @return Array $rules
     * @var Strin $key //index key to check exists or not in each array
     */
    public function removeEmptyRuleOrActionArray($rules, $type = 'rules') {
        $key = ($type == 'rules') ? 'custom_rule' : 'custom_action';
        for ($i = 0; $i <= count($rules); $i++) {
            if (empty($rules[$i])) {
                unset($rules[$i]);
            } elseif (array_key_exists($key, $rules[$i])) {
                if (empty($rules[$i][$key])) {
                    unset($rules[$i][$key]);
                }
            }                
        }
        return $rules;
    }
}
