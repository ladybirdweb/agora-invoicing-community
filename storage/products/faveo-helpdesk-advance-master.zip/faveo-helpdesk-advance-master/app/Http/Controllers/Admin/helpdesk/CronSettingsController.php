<?php


namespace App\Http\Controllers\Admin\helpdesk;

// controllers
use App\Http\Controllers\Controller;
use App\Model\helpdesk\Settings\CommonSettings;
use Illuminate\Http\Request;
use Lang;

class CronSettingsController extends Controller
{
    /**
     * get the form for cron job setting page.
     *
     * @param type Email    $email
     * @param type Template $template
     * @param type Emails   $email1
     *
     * @return type Response
     */
    public function getSchedular() {
        $cronPath = base_path('artisan');
        $condition = new \App\Model\MailJob\Condition();
        $execEnabled = $this->execEnabled();
        $paths = $this->getPHPBinPath();
        $jobs = array_merge(
                $condition->whereNull('plugin_name', null)->get()->toArray(),
                $condition->whereNotNull('plugin_name', null)->get()->toArray());
        $commands = [
            ''                   => trans("lang.select"),
            'everyMinute'        => trans("lang.everyMinute"),
            'everyFiveMinutes'   => trans("lang.everyFiveMinutes"),
            'everyTenMinutes'    => trans("lang.everyTenMinutes"),
            'everyThirtyMinutes' => trans("lang.everyThirtyMinutes"),
            'hourly'             => trans("lang.hourly"),
            'daily'              => trans("lang.daily"),
            'dailyAt'            => trans("lang.dailyAt"),
            'weekly'             => trans("lang.weekly"),
            'monthly'            => trans("lang.monthly"),
            'yearly'             => trans("lang.yearly"),
        ];

        return view('themes.default1.admin.helpdesk.settings.cron.cron', compact('commands', 'condition', 'jobs', 'execEnabled', 'cronPath', 'paths'));
    }

    /**
     * Update the specified schedular in storage for cron job.
     * @param  Request  $request
     *
     */
    public function postSchedular(Request $request)
    {
        try {
            $command = new \App\Model\MailJob\Condition();
            $formData = $request->except(['_token', '_method']);
            $command->whereNotIn('active', array_keys($formData))->update(['active' => 0]);
            foreach ($formData as $key => $value) {
                $command->updateOrCreate(
                    ['job' => $key],
                    [
                        'active' => (array_key_exists('active', $value))? (int) $value['active']: 0,
                        'value'  => implode(",", $value['value'])
                    ]);
            }
            /* redirect to Index page with Success Message */
            success: return redirect('job-scheduler')->with(
                'success',
                Lang::get('lang.job_scheduler_saved_successfully'));
        } catch (Exception $e) {
            /* redirect to Index page with Fails Message */
            return redirect('job-scheduler')->with('fails', Lang::get('lang.job-scheduler-error') . '<li>' . $e->getMessage() . '</li>');
        }
    }

    public function activateCronUrl(Request $request) {
        $value = 0;
        $status = $request->input('status');
        if ($status == 'true') {
            $value = 1;
        }
        CommonSettings::updateOrCreate(
                ['option_name' => 'cron_url',], ['status' => $value,]
        );
    }

    /**
     * Check if exec() function is available
     *
     * @return boolean
     */
    private function execEnabled() {
        try {
            // make a small test
            return function_exists('exec') && !in_array('exec', array_map('trim', explode(', ', ini_get('disable_functions'))));
        } catch (\Exception $ex) {
            return false;
        }
    }

    private function getPHPBinPath()
    {
        $paths = [
            '/usr/bin/php',
            '/usr/local/bin/php',
            '/bin/php',
            '/usr/bin/php7',
            '/usr/bin/php7.1',
            '/usr/bin/php71',
            '/opt/plesk/php/7.1/bin/php',
        ];
        // try to detect system's PHP CLI
        if($this->execEnabled()) {
            try {
                $paths = array_unique(array_merge($paths, explode(" ", exec("whereis php"))));
            } catch (\Exception $e) {
                // @todo: system logging here
                echo $e->getMessage();
            }
        }

        // validate detected / default PHP CLI
        // Because array_filter() preserves keys, you should consider the resulting array to be an associative array even if the original array had integer keys for there may be holes in your sequence of keys. This means that, for example, json_encode() will convert your result array into an object instead of an array. Call array_values() on the result array to guarantee json_encode() gives you an array.
        $paths = array_values(array_filter($paths, function($path) {
            return is_executable($path) && preg_match("/php[0-9\.a-z]{0,3}$/i", $path);
        }));

        return $paths;
    }

    protected function checkPHPExecutablePath(Request $request)
    {
        $path = $request->get('path');
        $version = "5.6";
        if (!file_exists($path) || !is_executable($path)) {
            return errorResponse(trans('lang.invalid-php-path'));
        }

        if($this->execEnabled()) {
            $exec_script = $path . " ".public_path('cron-test.php');
            $version = exec($exec_script, $output);
            return (version_compare($version, '7.1.3', '>=') == 1) ? successResponse(trans('lang.valid-php-path')): errorResponse(trans('lang.invalid-php-version-or-path'));
        } else {
            
            return successResponse(trans('lang.please_enable_php_exec_for_cronjob_check'));
        }
    }
}