<?php

namespace App\Http\Controllers\Agent\helpdesk\Approval;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class ApprovalController extends Controller
{

    public $types;
    public $priorities;
    public $departments;
    public $approvers;
    public $approval_id = 1;
    public $approved;
    public $cab;

    public function getOption($option)
    {
        return \App\Model\helpdesk\Settings\ApprovalMeta::where('approval_id', $this->approval_id)
                        ->where('option', $option)
                        ->pluck('value')
                        ->toArray();
    }
    public function setTypes()
    {
        $this->types = $this->getOption('type');
    }
    public function setPriority()
    {
        $this->priorities = $this->getOption('priority');
    }
    public function setDepartment()
    {
        $this->departments = $this->getOption('department');
    }
    public function setApprover($ticket_id)
    {
        $approved        = \App\Model\helpdesk\Settings\ApprovalMeta::where('approval_id', $this->approval_id)
                ->where('option', 'approver')
                ->where('ticket_id', $ticket_id)
                ->pluck('value')
                ->toArray();
        $this->approvers = $approved;
    }
    public function setCab()
    {
        $this->cab = $this->getOption('cab');
    }
    public function setApproved($ticket_id)
    {
        $approved       = \App\Model\helpdesk\Settings\ApprovalMeta::where('approval_id', $this->approval_id)
                ->where('option', 'approved')
                ->where('ticket_id', $ticket_id)
                ->pluck('value')
                ->toArray();
        $this->approved = $approved;
    }
    /**
     * 2. check if approval module activated
     * @return boolean
     */
    public function isActive()
    {
        $check     = false;
        $approvals = new \App\Model\helpdesk\Settings\Approval();
        $approval  = $approvals->find($this->approval_id);
        if ($approval && $approval->status) {
            $check = true;
        }
        return $check;
    }
    /**
     * check a ticket has approved
     * @param type $ticket_id
     * @return boolean
     */
    public function isApproved($ticket_id)
    {
        $check = true;
        if ($this->isActive()) {
            $this->setApprover($ticket_id);
            $this->setApproved($ticket_id);
            $approvers = $this->approvers;
            $approved  = $this->approved;
            $diff      = array_diff($approvers, $approved);
            if ($diff) {
                $check = false;
            }
        }
        return $check;
    }
    public function update($model, $request)
    {
        $model->update([
            'status' => $request->status
        ]);
        $meta = $request->input('meta');
        $model->meta()->whereNull('ticket_id')->delete();
        if (count($meta) > 0) {
            foreach ($meta as $key => $values) {
                $this->addMeta($model, $key, $values);
            }
        }
    }
    public function deleteOptions($model, $option, $ticket_id = "")
    {
        $model->where('option', $option)
                ->when($ticket_id, function($q)use($ticket_id) {
                    return $q->where('ticket_id', $ticket_id);
                })
                ->delete();
    }
    public function addMeta($model, $key, $values, $ticket_id = null,$delete=true)
    {
        if($delete){
         $this->deleteOptions($model->meta(), $key, $ticket_id);
        }
        if (is_array($values)) {
            foreach ($values as $value) {
                $model->meta()->create(['approval_id' => $model->id, 'option'      => $key,
                    'value'       => $value, 'ticket_id'   => $ticket_id
                ]);
            }
        }
        else {
            $model->meta()->updateOrCreate(['approval_id' => $model->id, 'option'      => $key,
                'value'       => $values, 'ticket_id'   => $ticket_id
            ]);
        }
    }
    /**
     * 4. get the id of the approvers (might it has department_manager and team_lead)
     * @param type $approver
     * @param type $ticket_id
     */
    public function getIdOfApprover($approver, $ticket_id)
    {
        if (!is_numeric($approver)) {
            $ticket   = \App\Model\helpdesk\Ticket\Tickets::findOrFail($ticket_id);
            $value    = $this->notificationController()->getAgentIdByDependency($approver, $ticket);
            $approver = "";
            if (checkArray(0, $value)) {
                $approver = $this->notificationController()->getAgentIdByDependency($approver, $ticket)[0];
            }
        }
        return $approver;
    }
    public function notificationController()
    {
        return new \App\Http\Controllers\Agent\helpdesk\Notifications\NotificationController();
    }
    /**
     * mark as approved when approver approve/deny
     * @param Request $request
     * @return type
     */
    public function addApproved(Request $request)
    {
        try {
            $approve_id        = $request->input('approval_id');
            $approver_id       = $request->input('approver_id');
            $is_approved       = $request->input('is_approved');
            $ticket_id         = $request->input('ticket_id');
            $this->approval_id = $approve_id;
            $approver          = \App\User::findOrFail($approver_id);
            $model             = \App\Model\helpdesk\Settings\Approval::find($approve_id);
            $thread_body       = $this->threadBody($approver, $is_approved);
            $ticket            = $this->ticket($ticket_id, $thread_body, $approver_id);
            if ($is_approved == 'yes') {
                $this->addMeta($model, 'approved', $approver_id, $ticket_id,false);
                $message = trans('lang.ticket-approved-successfully', ['ticket_number' => $ticket->ticket_number]);
            }
            else {
                $message = trans('lang.ticket-approval-denied-successfully', ['ticket_number' => $ticket->ticket_number]);
            }
            $this->close($ticket, $approver_id);
            return redirect('/')->with('success', $message);
        } catch (\Exception $ex) {
            return redirect('/')->with('fails', $ex->getMessage());
        }
    }
    /**
     * get the thread body to display in ticket detail page
     * @param type $approver
     * @param type $is_approved
     * @return type
     */
    public function threadBody($approver, $is_approved)
    {
        $approved_user = $approver->first_name . ' ' . $approver->last_name;
        $thread_body   = "";
        if ($is_approved == 'yes') {
            $thread_body = trans("lang.approver-is-approved-your-clouser-request", ['approver' => $approved_user]);
        }
        elseif ($is_approved == 'no') {
            $thread_body = trans("lang.approver-is-not-approved-your-clouser-request", ['approver' => $approved_user]);
        }
        return $thread_body;
    }
    public function ticket($ticket_id, $thread_body, $user_id)
    {
        $ticket = \App\Model\helpdesk\Ticket\Tickets::find($ticket_id);
        if ($ticket && $thread_body) {
            $ticket->thread()->create([
                'user_id'     => $user_id,
                'poster'      => 'support',
                'is_internal' => 1,
                'body'        => $thread_body,
                'thread_type' => 'approval',
            ]);
            return $ticket;
        }
        throw new \Exception(trans('lang.ticket-not-found'));
    }
    /**
     * change the status to close when all approvers approved
     * @param type $ticket
     */
    public function close($ticket, $approver_id)
    {
        if ($this->isApproved($ticket->id)) {
            $status = \App\Model\helpdesk\Ticket\Ticket_Status::whereHas('type', function($q) {
                        $q->where('name', 'closed');
                    })
                    ->where('default', 1)
                    ->first();
            $ticket_ctrl = new \App\Http\Controllers\Agent\helpdesk\TicketController();
            $ticket_ctrl->changeStatus($ticket->id, $status->id, $approver_id);
        }
    }
    /**
     * 3. add approver to approval_meta table according to cab details
     * @param type $ticket_id
     */
    public function addApprover($ticket_id)
    {
        $this->setCab();
        $cab   = $this->cab;
        $model = \App\Model\helpdesk\Settings\Approval::find($this->approval_id);
        foreach ($cab as $value) {
            $id = $this->getIdOfApprover($value, $ticket_id);
            if ($id) {
                $this->addMeta($model, 'approver', $id, $ticket_id,false);
            }
        }
    }
    /**
     * 1. came to execution
     * @param type $event
     * @return type
     */
    public function eventExecute($event)
    {
        $status_id = $event['status_id'];
        $ticket_id = $event['ticket_id'];
        try {
            if ($this->isActive() && $this->isNeedApproval($ticket_id)) {
                $this->addApprover($ticket_id);
                $approve_status_id = \App\Model\helpdesk\Ticket\Ticket_Status::whereHas('type', function($q) {
                            $q->where('name', 'approval');
                        })
                        ->value('id');

                if (!$this->isApproved($ticket_id) && $approve_status_id) {
                    $this->sendApprovalMail($ticket_id);
                    $status_id = $approve_status_id;
                }
            }
        } catch (\Exception $e) {
            loging('ticket-approval', $e->getMessage());
        }
        return $status_id;
    }
    public function isNeedApproval($ticket_id)
    {
        $this->setDepartment();
        $this->setPriority();
        $this->setTypes();
        $check  = false;
        $ticket = \App\Model\helpdesk\Ticket\Tickets::find($ticket_id);
        if ($ticket) {
            $department = $ticket->dept_id;
            $priority   = $ticket->priority_id;
            $type       = $ticket->type;
            if (in_array($department, $this->departments) || in_array($priority, $this->priorities)
                    || in_array($type, $this->types)) {
                $check = true;
            }
        }
        return $check;
    }
    /**
     * get the approvers id to send approval mail
     * @param type $ticket_id
     */
    public function sendApprovalMail($ticket_id)
    {
        $approver  = $this->approvers;
        $approvers = \App\User::where('is_delete', '!=', 1)
                ->where('ban', '!=', 1)
                ->where('active', 1)
                ->whereIn('id', $approver)
                ->get();
        foreach ($approvers as $user) {
            $this->sendMail($user, $ticket_id);
        }
    }
    /**
     * sending mail to approvers
     * @param type $user
     * @param type $ticket_id
     */
    public function sendMail($user, $ticket_id)
    {
        $ticketdata    = \App\Model\helpdesk\Ticket\Tickets::find($ticket_id);
        $approver_name = $user->first_name . " " . $user->last_name;
        $email         = $user->email;
        $id            = $user->id;
        $approval_id   = $this->approval_id;
        $approve_url   = faveoUrl("ticket/approve?approver_id=$id&approval_id=$approval_id&is_approved=yes&ticket_id=$ticket_id");
        $deny_url      = faveoUrl("ticket/approve?approver_id=$id&approval_id=$approval_id&is_approved=no&ticket_id=$ticket_id");
        $from          = $this->mailControl()->mailfrom('1', $ticketdata->dept_id);
        $message       = ['subject'  => 'Approve ticket ' . '[#' . $ticketdata->ticket_number . ']',
            'scenario' => 'approve-ticket'];
        $variable      = [
            'ticket_subject' => title($ticketdata->id),
            'ticket_number'  => $ticketdata->ticket_number,
            'ticket_link'    => faveoUrl('/thread/' . $ticketdata->id),
            'approve_url'    => $approve_url,
            'deny_url'       => $deny_url,
            'agent_name'     => $approver_name,
        ];
        $to            = ['email' => $email, 'name' => $approver_name, 'role' => $user->role, 'preferred_language' => ''];
        $this->mailControl()->sendmail($from, $to, $message, $variable, "", true);
    }
    public function mailControl()
    {
        return new \App\Http\Controllers\Common\PhpMailController();
    }
}
