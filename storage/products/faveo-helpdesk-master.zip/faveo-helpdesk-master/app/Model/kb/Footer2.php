<?php

namespace App\Model\kb;

use App\BaseModel;

class Footer2 extends BaseModel
{
    protected $table = 'footer2';
    protected $fillable = ['title', 'footer'];
}
