<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\BaseModel;
class Organization extends BaseModel
{
    protected $table = 'organization';
}
