<?php

namespace App\Http\Requests\helpdesk\Listener;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class ListenerRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
//        print_r($this->method());
//        print_r($this->all());
//        die();
        return [
            'listeners.name'   => 'required|unique:listeners,id,'.$this->segment(2),
            'listeners.status' => [
                Rule::in(['0', '1']),
            ],
            'listeners.rule_match' => [
                Rule::in(['any', 'all']),
            ],
            'events.*.event' =>'required',
            'events.*.condition' =>'required_unless:events.*.event,duedate,reply,note',
            'events.*.old' =>[
                'required_unless:events.*.event,duedate,reply,note',
                //'required_if:events.*.condition,changed',
            ],//'required_if:events.*.condition,changed',
            'events.*.new' =>[
                'required_unless:events.*.event,duedate,reply,note',
                //'required_if:events.*.condition,changed`',
            ],//'required_if:events.*.condition,changed',
            'rules.*.condition'=>'required_with:rules.*.key',
            'rules.*.value'=>'required_with:rules.*.key',
            'actions'=>'required',
            'actions.*.key'=>'required',
            'actions.*.value'=>'required',
            'actions.meta.receiver'=>'required_if:actions.*.key,mail',
            'actions.*.meta.subject'=>'required_if:actions.*.key,mail',
            'actions.*.meta.content'=>'required_if:actions.*.key,mail'
        ];
    }
    
    public function messages()
    {
        return [
            'events.*.old.required_unless'=>'Please choose an old value',
            'events.*.new.required_unless'=>'Please choose a new value',
            'listeners.name.required'=>'Please enter a name',
            'listeners.name.unique'=>'Name is already exist',
            'events.*.event.required'=>'Please choose an event',
            'events.*.condition.required'=>'Please choose condition for the event',
            'events.*.condition.required_unless'=>'Please choose condition for the event',
            'events.*.old.required_if'=>'Please choose an old value',
            'events.*.new.required_if'=>'Please choose a new value',
            'rules.*.condition.required_with'=>'Please choose a condition for the rule',
            'rules.*.value.required_with'=>'Please choose a value for the rule',
            'actions.*.key.required'=>'Please choose an action',
            'actions.*.value.required'=>'Please choose a value for the action',
            'actions.*.meta.receiver.required_if'=>'Please choose a receiver for the email',
            'actions.*.meta.subject.required_if'=>'Please enter a subject for the email',
            'actions.*.meta.content.required_if'=>'Please enter a content for the email',
        ];
    }
}
