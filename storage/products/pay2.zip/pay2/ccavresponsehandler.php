<?
session_start();
@session_save_path("./");  
?>
<?php 
include('config.php');
require("functions.php");
include('crypto.php');
?>
<html>
<head>
<title> CCAvenue Payment Gateway for Reseller Club</title>
<script language="JavaScript">
        function successClicked()
        {
            document.paymentpage.submit();
        }
        function failClicked()
        {
            document.paymentpage.status.value = "N";
            document.paymentpage.submit();
        }
        function pendingClicked()
        {
            document.paymentpage.status.value = "P";
            document.paymentpage.submit();
        }
</script>
</head>
<body onLoad="document.paymentpage.submit()" >

<?php

	error_reporting(0);
	$encResponse=$_POST["encResp"];			//This is the response sent by the CCAvenue Server
	$rcvdString=decrypt($encResponse,$working_key);		//Crypto Decryption used as per the specified working key.
	$order_status="";
	$decryptValues=explode('&', $rcvdString);
	$dataSize=sizeof($decryptValues);
	for($i = 0; $i < $dataSize; $i++) 
	{
		$information=explode('=',$decryptValues[$i]);
		if($i==3)	$order_status=$information[1];
	}
	
	/*Reseller Club Code Starts*/
		$redirectUrl = $_SESSION['redirecturl'];  // redirectUrl received from foundation
		//$Redirect_Urlb=$_SESSION['Redirect_Urlb'];
		$transId = $_SESSION['transid'];		 //Pass the same transid which was passsed to your Gateway URL at the beginning of the transaction.
		$sellingCurrencyAmount = $_SESSION['sellingcurrencyamount'];
		$accountingCurrencyAmount = $_SESSION['accountingcurencyamount'];
		$status = $order_status;//$_REQUEST["status"];	 // Transaction status received from your Payment Gateway
        //This can be either 'Y' or 'N'. A 'Y' signifies that the Transaction went through SUCCESSFULLY and that the amount has been collected.
        //An 'N' on the other hand, signifies that the Transaction FAILED.

		/**HERE YOU HAVE TO VERIFY THAT THE STATUS PASSED FROM YOUR PAYMENT GATEWAY IS VALID.
	    * And it has not been tampered with. The data has not been changed since it can * easily be done with HTTP request. 
		*
		**/
		
		srand((double)microtime()*1000000);
		$rkey = rand();

		
		/*Reseller Club Code Ends*/
		
	echo "<center>";

	//echo $checksuma;

	if($order_status==="Success")
	{
		$status ="Y";
		echo "<br>Thank you for shopping with us. Your credit card has been charged and your transaction is successful. We will be shipping your order to you soon.";
		
	}
	else if($order_status==="Aborted")
	{
		$status ="N";
		echo "<br>Thank you for shopping with us.We will keep you posted regarding the status of your order through e-mail";
	
	}
	else if($order_status==="Failure")
	{
		$status ="N";
		echo "<br>Thank you for shopping with us.However,the transaction has been declined.";
	}
	else
	{
		$status ="N";
		echo "<br>Security Error. Illegal access detected";
	
	}

	echo "<br><br>";
$checksuma =generateChecksum($transId,$sellingCurrencyAmount,$accountingCurrencyAmount,$status, $rkey,$key);

echo "</center>";
?>
<form name="paymentpage" action="<?php echo $redirectUrl;?>">
			<input type="hidden" name="url" value="<?php echo $redirectUrl;?>">
			<input type="hidden" name="transid" value="<?php echo $transId;?>">
		    <input type="hidden" name="status" value="<?php echo $status;?>">
			<input type="hidden" name="rkey" value="<?php echo $rkey;?>">
		    <input type="hidden" name="checksum" value="<?php echo $checksuma;?>">
		    <input type="hidden" name="sellingamount" value="<?php echo $sellingCurrencyAmount;?>">
			<input type="hidden" name="accountingamount" value="<?php echo $accountingCurrencyAmount;?>">
			<input type="hidden" value="submit">
			Please wait...............
		</form>
       
        
        </body>
</html>