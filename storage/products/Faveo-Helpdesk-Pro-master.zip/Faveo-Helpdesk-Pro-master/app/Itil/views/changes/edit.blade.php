@extends('themes.default1.agent.layout.agent')
@section('content')

<section class="content-heading-anchor">
    <h2>
        {{Lang::get('itil::lang.edit_change')}}  


    </h2>

</section>

<!-- Main content -->
{!! Form::model($change,['url'=>'service-desk/changes/'.$change->id,'method'=>'patch','files'=>true,'id'=>'Form']) !!}

<div class="box box-primary">
    <div class="box-header with-border">
        <h4> {{str_limit($change->subject,20)}}  
            <a href="{{url('service-desk/changes/'.$change->id.'/show')}}" class="btn btn-default">{{Lang::get('itil::lang.show')}}</a> </h4>
        @if (count($errors) > 0)
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
        @endif
        <div class="alert alert-success alert-dismissable" style="display: none;">
    <i class="fa  fa-check-circle"></i>
    <span class="success-msg"></span>
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    
   </div>

        @if(Session::has('success'))
        <div class="alert alert-success alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            {{Session::get('success')}}
        </div>
        @endif
        <!-- fail message -->
        @if(Session::has('fails'))
        <div class="alert alert-danger alert-dismissable">
            <i class="fa fa-ban"></i>
            <b>{{Lang::get('message.alert')}}!</b> {{Lang::get('message.failed')}}.
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            {{Session::get('fails')}}
        </div>
        @endif
        {!! Form::model($change,['url'=>'service-desk/changes/'.$change->id,'method'=>'patch','files'=>true]) !!}
    </div><!-- /.box-header -->
    <!-- form start -->

    <!--<form action="{!!URL::route('service-desk.post.changes')!!}" method="post" role="form">-->
    <div class="box-body">
        <div class="row">
            <div class="form-group col-md-6 required {{ $errors->has('subject') ? 'has-error' : '' }}">
                <label for="inputPassword3" class="control-label">{{Lang::get('itil::lang.subject')}} </label>
                {!! Form::text('subject',null,['class'=>'form-control']) !!}
                <!--<input type="text" class="form-control" name="subject" id="inputPassword3" placeholder="Subject">-->
            </div>
            <div class="form-group col-md-6 {{ $errors->has('requester') ? 'has-error' : '' }}">
                <label for="inputPassword3" class="control-label">{{Lang::get('itil::lang.requester')}} </label>
                {!! Form::select('requester',$requester,null,['class'=>'form-control']) !!}
                <!--<input type="text" class="form-control" name="subject" id="inputPassword3" placeholder="Subject">-->
            </div>

            <div class="form-group col-md-6 {{ $errors->has('approval_id') ? 'has-error' : '' }}">
                <label class="control-label">{{Lang::get('itil::lang.approval')}}</label>
                {!! Form::select('approval_id',$users,null,['class'=>'form-control']) !!}

            </div>
            <div class="form-group col-md-12 required {{ $errors->has('description') ? 'has-error' : '' }}">
                <label for="internal_notes" class="control-label" >Description</label>
                {!! Form::textarea('description',null,['class'=>'form-control','id'=>'ckeditor']) !!}
                <!--<textarea class="form-control textarea" name="description" rows="7" id="internal_notes"></textarea>-->
            </div>
            <div class="form-group col-md-6 {{ $errors->has('status_id') ? 'has-error' : '' }}">
                <label class=" control-label">{{Lang::get('itil::lang.status')}}</label>
                {!! Form::select('status_id',$statuses,null,['class'=>'form-control'])!!}
            </div>
            <div class="form-group col-md-6 {{ $errors->has('priority_id') ? 'has-error' : '' }}">
                <label class="control-label">{{Lang::get('itil::lang.priority')}}</label>
                {!! Form::select('priority_id',$sd_changes_priorities,null,['class'=>'form-control']) !!}

            </div> 
            <div class="form-group col-md-6 {{ $errors->has('change_type_id') ? 'has-error' : '' }}">
                <label class=" control-label">{{Lang::get('itil::lang.change_type')}}</label>
                {!! Form::select('change_type_id',$sd_changes_types,null,['class'=>'form-control']) !!}

            </div>
            <!--  <div class="form-group col-md-6 {{ $errors->has('location_id') ? 'has-error' : '' }}">
                 <label class="control-label">{{Lang::get('itil::lang.location')}}</label>
                 {!! Form::select('location_id',$sd_locations,null,['class'=>'form-control']) !!}
 
             </div> -->
            <div class="form-group col-md-6 {{ $errors->has('location') ? 'has-error' : '' }}">
                <label class="control-label">{{Lang::get('lang.location')}}</label>
                <?php
                $location = App\Location\Models\Location::all(); //for dropdown showing all location
                ?>


                {!! Form::select('location_id', [Lang::get('lang.location')=>$location->pluck('title','id')->toArray()],$change->location_id,['class' => 'form-control select']) !!}
            </div>

            <div class="form-group col-md-6 {{ $errors->has('impact_id') ? 'has-error' : '' }}">
                <label class=" control-label" >Impact Type</label>
                {!! Form::select('impact_id',$sd_impact_types,null,['class'=>'form-control']) !!}

            </div>
            @if(isAsset()==true)
            <div class="form-group col-md-6 {{ $errors->has('asset') ? 'has-error' : '' }}">
                <label class=" control-label" >Asset</label>
                {!! Form::select('asset[]',$assets,null,['class'=>'form-control','multiple'=>true]) !!}

            </div>
            @endif

            <?php
            $attachment = DB::table('sd_attachments')->where('owner', '=', 'sd_changes:' . $change->id)->first();
            if(isset($attachment))
                $value = $attachment->value;
            if ($attachment) {
                $value = $attachment->value;
            } else {
                $value = "";
            }
            ?>

            <div class="form-group col-md-6 {{ $errors->has('attachments') ? 'has-error' : '' }}">
                <label class=" control-label" >Attachments{{Lang::get('lang.maximum_upload_file_size_is_2MB')}}</label>
                {!! Form::file('attachments[]',['class'=>'file-data']) !!}
                   @if (isset( $attachment))
                <div class="alert alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true" style="color:red;"> <i class="fa fa-trash"></i></button>
                 
                      <li>
                                <a href="{{url('service-desk/download/'.$attachment->id.'/'.$attachment->owner.'/attachment')}}">
                                    <span class="mailbox-attachment-icon" style="background-color:#fff;">{!!strtoupper($attachment->type)!!}</span>
                                    <div class="mailbox-attachment-info">
                                        <span style="color: green;"">
                                            <b style="word-wrap: break-word;">{!!$attachment->value!!}</b>
                                            <br/>
                                            <p>{{\App\Plugins\ServiceDesk\Controllers\Library\UtilityController::getAttachmentSize($attachment->size)}}</p>
                                        </span>

                                    </div>
                                </a>
                            </li>
                    <input type="hidden" name="uploadfile" id="uploadfile" value="{!! $value!!}">
                    @endif
                </div>
            </div>
        </div>
        <div class="box-footer">
            <div class="from-group">
<!--                <input type="submit" value="{{Lang::get('itil::lang.add_change')}}" class="btn btn-success">-->
                {!!Form::button('<i class="fa fa-refresh" aria-hidden="true">&nbsp;&nbsp;</i>'.Lang::get('itil::lang.update'),['type' => 'submit', 'class' =>'btn btn-primary','id'=>'submit'])!!}
                {!! Form::close() !!}
            </div>
        </div>

    </div>
</div>

<!--submit button-->
<script>
    $('#Form').submit(function () {
        var btn = $('#submit');
        btn[0].innerHTML = "<i class='fa fa-refresh fa-spin fa-1x fa-fw'></i>Updating...";
        $('#submit').attr('disabled', 'disabled');
    });
    $('#submit').attr('disabled', 'disabled');
    $('#Form').on('input', function () {
        $('#submit').removeAttr('disabled');
    });
    $('#Form').on('change', ':input', function () {
        $('#submit').removeAttr('disabled');
    });
</script>

<script type="text/javascript">
    $(document).ready(function() {
        $('.fa-trash').click(function(){                  
            var currentValue = $('#uploadfile').val();
            $.ajax({
            type: 'post',
            url: '{{route("uploadfile.changes.delete",$change->id)}}',
            data: {
                "_token": "{{ csrf_token() }}",
                filename: currentValue
            
            },
         
            success: function (result) {
              
                $('.success-msg').html(result);
                $('.alert-success').css('display', 'block');
                setInterval(function(){
                    $('.alert-success').slideUp( 3000, function() {});
                }, 500);
            }
        });
        });         
    });
</script>


@stop

