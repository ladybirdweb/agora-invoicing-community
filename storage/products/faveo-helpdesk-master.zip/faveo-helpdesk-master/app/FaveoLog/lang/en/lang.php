<?php

return [
    'logs'=> 'Logs',
];
