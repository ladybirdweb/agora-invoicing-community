<?php

namespace App\Http\Controllers\Agent\kb;

// Controllers
use App\Http\Controllers\Agent\helpdesk\TicketController;
use App\Http\Controllers\Controller;
// Requests
use App\Http\Requests\kb\CategoryRequest;
use App\Http\Requests\kb\CategoryUpdateRequest;
// Model
use App\Model\kb\Category;
use App\Model\kb\Relationship;
// Classes
use Datatable;
use Exception;
use Lang;
use Redirect;
use Illuminate\Http\Request;
use Validator;
/**
 * CategoryController
 * This controller is used to CRUD category.
 *
 * @author      Ladybird <info@ladybirdweb.com>
 */
class CategoryController extends Controller
{
    /**
     * Create a new controller instance.
     * constructor to check
     * 1. authentication
     * 2. user roles
     * 3. roles must be agent.
     *
     * @return void
     */
    protected $ticket_policy;
    
    public function __construct()
    {
        // checking authentication
        $this->middleware('auth');
        // checking roles
        $this->ticket_policy = new \App\Policies\TicketPolicy();
        if (!$this->ticket_policy->kb()) {
            return redirect('dashboard')->with('fails', Lang::get('lang.permission_denied'));
        }
        SettingsController::language();
    }

    /**
     * Indexing all Category.
     *
     * @param type Category $category
     *
     * @return Response
     */
    public function index()
    {
        /*  get the view of index of the catogorys with all attributes
          of category model */
        try {
            return view('themes.default1.agent.kb.category.index');
        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }

    /**
     * fetching category list in chumper datatables.
     *
     * @return type chumper datatable
     */
    public function getData()
    {
        /* fetching chumper datatables */
        return Datatable::collection(Category::All())
                        /* search column name */
                        ->searchColumns('name')
                        /* order column name and description */
                        ->orderColumns('name')
                        /* add column name */
                        ->addColumn('name', function ($model) {
                            $string = strip_tags($model->name);
                            return str_limit($string, 20);
                        })
                        ->addColumn('status', function($model) {

                                 if ($model->status == 1) {
                                       return '<p class="btn btn-xs btn-default" style="pointer-events:none;color:green;">'.Lang::get('lang.active').'</p>';
                                   }
                                        return '<p class="btn btn-xs btn-default" style="pointer-events:none;color:red;">'.Lang::get('lang.inactive').'</p>';
                              
                            })


                        
                        ->addColumn('visible_to', function ($model) {
                            $t = $model->visible_to;
                            
                            if($t=='all_users'){
                                $visible='All users';
                            }
                            elseif($t=='logged_in_users'){
                                $visible ='Logged in users';
                            }
                            else{
                                $visible ='Agents';
                            }

                            return($visible);
                        })
                        ->addColumn('description', function ($model) {
                             $comment =str_limit($model->description,100);
                            $title = strip_tags($model->description);

                            $view="<ul class='nav nav-stacked'><span style='word-wrap: break-word;' title='$title'>$comment</span></ul>";
                           return $view;
                    })
                        /* add column Actions */
                        /* there are action buttons and modal popup to delete a data column */
                        ->addColumn('Actions', function ($model) {
                            return '<span  data-toggle="modal" data-target="#deletecategory'.$model->slug.'"><a href="#" ><button class="btn btn-primary btn-xs"><i class="fa fa-trash">&nbsp;&nbsp;</i>'.\Lang::get('lang.delete').'</button></span>&nbsp;&nbsp;<a href=category/'.$model->id.'/edit class="btn btn-primary btn-xs"><i class="fa fa-edit">&nbsp;&nbsp;</i>'.\Lang::get('lang.edit').'</a>&nbsp;&nbsp;<a href=article-list class="btn btn-primary btn-xs"><i class="fa fa-eye">&nbsp;&nbsp;</i>'.\Lang::get('lang.view').'</a>
				<div class="modal fade" id="deletecategory'.$model->slug.'">
        			<div class="modal-dialog">
            			<div class="modal-content">
                			<div class="modal-header">
                    			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    			<h4 class="modal-title">'.Lang::get('lang.delete').'</h4>
                			</div>
                			<div class="modal-body">
                				<p>Are you sure ?</p>
                			</div>
                			<div class="modal-footer">
                    			<button type="button" class="btn btn-default pull-left" data-dismiss="modal" id="dismis2"><i class="fa fa-times" aria-hidden="true">&nbsp;&nbsp;</i>'.Lang::get('lang.close').'</button>
                    			<a href="category/delete/'.$model->id.'"><button class="btn btn-danger"><i class="fa fa-trash" aria-hidden="true">&nbsp;&nbsp;</i>'.Lang::get('lang.delete').'</button></a>
                			</div>
            			</div>
        			</div>
    			</div>';
                        })
                        ->make();
    }

    /**
     * Create a Category.
     *
     * @param type Category $category
     *
     * @return type view
     */
    public function create(Category $category)
    {
        /* Get the all attributes in the category model */
        $category = $category->pluck('name', 'id')->toArray();
        /* get the view page to create new category with all attributes
          of category model */
        try {
            return view('themes.default1.agent.kb.category.create', compact('category'));
        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }

    /**
     * To store the selected category.
     *
     * @param type Category        $category
     * @param type CategoryRequest $request
     *
     * @return type Redirect
     */
    public function store(Category $category, Request $request)

    {
        /* Get the whole request from the form and insert into table via model */
        // $create_from_articale=$request->new_catagory;
     
        if ($request->new_category==1) {
            $validator = Validator::make($request->all(), [
            'new_category_name' => 'required|max:250|unique:kb_category,name',
            'new_category_display_order' => 'required',
            'new_category_description' =>  'required|unique:kb_category,display_order',
        ]);

        if (!$validator->passes()) {

            return response()->json(['error'=>$validator->errors()->all()]);
        }

            $category=new Category();
            $category->name=$request->new_category_name;
            $category->slug=$request->new_category_name;
            $category->status=$request->new_category_status;
            $category->visible_to=$request->new_category_visible_to;
            $category->display_order=$request->new_category_display_order;
            $category->description=$request->new_category_description;
            $category->save();
       return response()->json(['success'=>Lang::get('lang.category_saved_successfully')]);
            
        } else {
                $this->validate(
            $request, [
            'name'        => 'required|max:250|unique:kb_category,name',
            'description' => 'required',
            'display_order'      => 'required|unique:kb_category',
            ]
        );
            $sl = $request->input('name');
            $slug = str_slug($sl, '-');
            $category->slug = $slug;
        // send success message to index page
            try {
                $category->fill($request->input())->save();
                return Redirect('category')->with('success', Lang::get('lang.category_saved_successfully'));
            } catch (Exception $e) {
                return Redirect::back()->with('fails', Lang::get('lang.category_not_inserted').'<li>'.$e->getMessage().'</li>');
            }
        }
    }

    /**
     * Show the form for editing the specified category.
     *
     * @param type          $slug
     * @param type Category $category
     *
     * @return type view
     */
    public function edit($id)
    {
        /* get the atributes of the category model whose id == $id */
        $category = Category::whereId($id)->first();
        $categories = Category::pluck('name', 'id')->toArray();
        /* get the Edit page the selected category via id */
        return view('themes.default1.agent.kb.category.edit', compact('category', 'categories'));
    }

    /**
     * Update the specified Category in storage.
     *
     * @param type                $slug
     * @param type Category       $category
     * @param type CategoryUpdate $request
     *
     * @return type redirect
     */
    public function update($id, CategoryUpdateRequest $request)
    {

        /* Edit the selected category via id */
        $category = Category::where('id', $id)->first();
        $sl = $request->input('name');
        $slug = str_slug($sl, '-');
        /* update the values at the table via model according with the request */
        //redirct to index page with success message
        try {
            $category->slug = $slug;
            $category->fill($request->input())->save();
            return redirect('category')->with('success', Lang::get('lang.category_updated_successfully'));
        } catch (Exception $e) {
            //redirect to index with fails message
            return redirect('category')->with('fails', Lang::get('lang.category_not_updated').'<li>'.$e->getMessage().'</li>');
        }
    }

    /**
     * Remove the specified category from storage.
     *
     * @param type              $id
     * @param type Category     $category
     * @param type Relationship $relation
     *
     * @return type Redirect
     */
    public function destroy($id, Category $category, Relationship $relation)
    {
        $relation = $relation->where('category_id', $id)->first();

        if ($relation != null) {

            return Redirect::back()->with('fails', Lang::get('lang.category_not_deleted'));
        } else {
            /*  delete the category selected, id == $id */
            $category = $category->whereId($id)->first();
            // redirect to index with success message
            try {
                $category->delete();

                return Redirect::back()->with('success', Lang::get('lang.category_deleted_successfully'));
            } catch (Exception $e) {
                return Redirect::back()->with('fails', Lang::get('lang.category_not_deleted').'<li>'.$e->getMessage().'</li>');
            }
        }
    }
}
