<?php

namespace App\Api\v2;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Validation\Rule;
use App\User;

class ClientApiController extends Controller
{

    public $request;
    public $auth_user;

    public function __construct(Request $request)
    {
        $this->request = $request;
        $this->middleware('jwt.auth');
        try {
            $user            = \JWTAuth::parseToken()->authenticate();
            $this->auth_user = $user;
        } catch (\Tymon\JWTAuth\Exceptions\TokenExpiredException $e) {
            
        } catch (\Tymon\JWTAuth\Exceptions\JWTException $e) {
            
        }
    }
    public function ticketCreate()
    {

        $this->validate($this->request, [
            'subject'   => 'required',
            'body'      => 'required',
            'helptopic' => 'required',
        ]);
        try {
            $code     = new \App\Model\helpdesk\Utility\CountryCode();
            $user_id  = $this->auth_user->id;
            $user     = User::whereId($user_id)->select('email', 'first_name', 'last_name', 'mobile', 'country_code')->first()->toArray();
            $all      = $this->request->except('token', 'api_key', 'ip') + ['Requester' => $user_id];
            $merged   = array_merge($user, $all);
            $request                = new \App\Http\Requests\helpdesk\TicketRequest();
            $request->replace($merged);
            \Route::dispatch($request);
            $response = (new \App\Http\Controllers\Agent\helpdesk\TicketController())->post_newticket($request, $code, true);
            return response()->json(compact('response'));
        } catch (\Exception $e) {
            $error = $e->getMessage();
            $line  = $e->getLine();
            $file  = $e->getFile();
            return response()->json(compact('error', 'file', 'line'));
        }
    }
    /**
     * Reply for the ticket.
     *
     * @param TicketRequest $request
     *
     * @return json
     */
    public function ticketReply()
    {
        $this->validate($this->request, [
            'ticket_id'     => ['required', Rule::exists('tickets', 'id')->where('user_id', $this->auth_user->id)], //'required|exists:tickets,id',
            'reply_content' => 'required',
        ]);
        try {

            $attach = $this->request->input('attachments');
            $this->request->merge(['reply_content' => preg_replace('/[ ](?=[^>]*(?:<|$))/', '&nbsp;', nl2br($this->request->get('reply_content')))]);
            $result = $this->ticket->reply($this->thread, $this->request, $this->attach, $attach);
            $result = $result->join('users', 'ticket_thread.user_id', '=', 'users.id')
                    ->select('ticket_thread.*', 'users.first_name as first_name')
                    ->orderBy('ticket_thread.id', 'desc')
                    ->first();
            return response()->json(compact('result'));
        } catch (\Exception $e) {
            $error = $e->getMessage();
            $line  = $e->getLine();
            $file  = $e->getFile();

            return response()->json(compact('error', 'file', 'line'));
        }
    }
    public function getDetails()
    {
        try {
            return $this->auth_user->with(['userExtraField', 'org'])->first();
        } catch (\Exception $e) {
            $error = $e->getMessage();
            $line  = $e->getLine();
            $file  = $e->getFile();

            return response()->json(compact('error', 'file', 'line'));
        }
    }
    public function updateDetails()
    {
        $this->validate($this->request, [
            'first_name' => 'required',
            'last_name'  => 'required',
            'user_name'  => [
                'required',
                Rule::unique('users')->ignore($this->auth_user->id),
            ],
            'email'      => [
                'required',
                Rule::unique('users')->ignore($this->auth_user->id),
            ],
        ]);
        try {
            $this->auth_user->fill($this->request->all())->save();
            $result = ['success' => 'updated successfully','user'=>$this->auth_user];
            return response()->json(compact('result'));
        } catch (\Exception $e) {
            $error = $e->getMessage();
            $line  = $e->getLine();
            $file  = $e->getFile();

            return response()->json(compact('error', 'file', 'line'));
        }
    }
    public function changePassword()
    {
        $this->validate($this->request, [
            'old_password' => 'required',
            'new_password' => 'required|min:8',
        ]);
        try {
            $old = $this->request->input('old_password');
            $new = $this->request->input('new_password');
            $result = ['fails' => 'not able to process'];
            if (\Hash::check($old, $this->auth_user->getAuthPassword())) {
                $this->auth_user->password = \Hash::make($new);
                $this->auth_user->save();
                $result = ['success' => 'updated successfully'];
            }
            return response()->json(compact('result'));
        } catch (\Exception $e) {
            $error = $e->getMessage();
            $line  = $e->getLine();
            $file  = $e->getFile();
            return response()->json(compact('error', 'file', 'line'));
        }
    }
    
    public function allTickets(){
        try{
           return $this->auth_user->with(['ticketsRequester']); 
        } catch (\Exception $e) {
            $error = $e->getMessage();
            $line  = $e->getLine();
            $file  = $e->getFile();
            return response()->json(compact('error', 'file', 'line'));
        }
    }
    
    public function getTicket(){
        $this->validate($this->request, [
            'ticket_id'     => ['required', Rule::exists('tickets', 'id')->where('user_id', $this->auth_user->id)],
        ]);
        try{
            $id = $this->request->input('ticket_id');
            return $this->auth_user->ticketsRequester()->where('id',$id)->with(['thread','collaborator','formdata'])->first();
        } catch (\Exception $e) {
            $error = $e->getMessage();
            $line  = $e->getLine();
            $file  = $e->getFile();
            return response()->json(compact('error', 'file', 'line'));
        }
    }
}
