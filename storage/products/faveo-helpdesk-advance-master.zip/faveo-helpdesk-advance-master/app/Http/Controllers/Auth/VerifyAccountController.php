<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Common\PhpMailController;
use App\Http\Controllers\Controller;
use \App\Http\Controllers\Agent\helpdesk\Notifications\NotificationController;
use App\User;
use Illuminate\Http\Request;
use Lang;
use Validator;


/**
 * ---------------------------------------------------
 * VerifyAccountController
 * ---------------------------------------------------
 * This controller handles the verification of email for new users.
 *
 * @author      Ladybird <info@ladybirdweb.com>
*/
class VerifyAccountController extends Controller
{
    protected $PhpMailController;
    
    public function __construct()
    {
        $this->PhpMailController = new PhpMailController();
    }


    /**
     *post updateEmail by the passed token
     *@param $request Request (oldEmail, newEmail)
     *@return Response
    */
    public function postUpdateEmailVerification(Request $request)
    {
        $user = User::where('email',  $request->oldEmail)->first();
        $newEmail = $request->newEmail;
        $validation = $this->validateEmail($request);
        
        if (!$user) {
            return errorResponse(Lang::get('lang.user_not_found_with_this_email'));
        }
        
        if ($validation) {
            $validation = array('email_address' => 'The email has already been taken.');
            return errorResponse($validation, 412);
        }
        
        if ($newEmail) {
            $user->email = $newEmail;
            $user->user_name = ($user->user_name == $request->oldEmail) ? $newEmail : $user->user_name;
        }
        
        $code = str_random(60);
        $user->email_verify = $code;
        $user->save();
        $this->sendEmail($user);
        return successResponse(Lang::get('lang.verify-email-message', ['email' => substr_replace($user->email, '***', strpos($user->email, '@')-3, 3)]));
    }

    /**
     * Function to validate email
     *
     * @param \Illuminate\Http\Request  $request
     * @return $errors
    */
    public function validateEmail($request)
    {   
        if (($request->oldEmail == $request->newEmail) || empty($request->newEmail)) {
            return null;
        }
        $validator = Validator::make($request->all(), [
            'newEmail'  =>  'email|unique:users,email|unique:emails,email_address',
            ]);

        if ($validator->fails()) {
            $errors  =  $validator->errors()->messages();
            return $errors;
        }
    }

    /**
     *Function to sendEmail by the passed user
     *@param $user
    */
    public function sendEmail($user)
    {
        $notifications[]=[
                'registration_alert'=>[
                    'userid'=> $user->id,
                    'from'=>$this->PhpMailController->mailfrom('1', '0'),
                    'message'=>['subject' => 'regestration', 'scenario' => 'registration'],
                    'variable'=>['new_user_name' => $user->name(), 'new_user_email' => $user->email, 'account_activation_link' => faveoUrl('account/activation/' . $user->email_verify)],
                ]
            ];

        $alert = new NotificationController();
        $alert->setDetails($notifications);
    }

    /**
     *post verifyEmail by passed token
     *@param string $token
     *@return Response
    */
    public function postAccountActivate($token)
    {
    
        $user = User::where('email_verify', $token)->first();

        if (!$user) {
            return errorResponse(Lang::get('lang.not_found'));
        }

        // Change the active and email_verify fields to 1
       $user->update(['active'=>1, 'email_verify'=>1]);

        return successResponse('Your email: '.$user->email. ' is verified and account activated.');

    }

     

}
