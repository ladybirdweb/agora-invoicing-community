<?php

namespace App\Http\Controllers\Common\Twitter;

/**
 * @author Abraham Williams <abraham@abrah.am>
 */
class TwitterOAuthException extends \Exception
{
}
