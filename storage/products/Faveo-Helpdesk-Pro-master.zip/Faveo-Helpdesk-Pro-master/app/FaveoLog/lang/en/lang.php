<?php

return [
    'logs'=>'Logs',
];
