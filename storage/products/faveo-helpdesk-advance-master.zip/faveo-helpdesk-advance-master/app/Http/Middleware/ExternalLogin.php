<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Contracts\Auth\Guard;
use App\Http\Controllers\Client\helpdesk\UnAuthController;
// use App\User;
// use Auth;
class ExternalLogin
{
    /**
     * The Guard implementation.
     *
     * @var Guard
     */
    protected $auth;

    /**
     * Create a new filter instance.
     *
     * @param Guard $auth
     *
     * @return void
     */
    public function __construct(Guard $auth)
    {
        $this->auth = $auth;
    }

    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if(isInstall()){
            if ($this->auth->guest()) {
                $external_login_controller = new UnAuthController(new \App\Http\Controllers\Common\PhpMailController);
                $redirect = $external_login_controller->handleExternalLogin($request);
                if ($redirect === true) {
                    //do nothing
                } else {
                    return redirect($redirect);
                }
            }
        }
        return $next($request);
    }

}
