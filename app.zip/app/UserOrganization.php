<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\BaseModel;
class UserOrganization extends BaseModel
{
    protected $table = 'user_org_relationship';
}
