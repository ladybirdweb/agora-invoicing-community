<?php

namespace App\FaveoStorage\Controllers;

use Storage;
use App\Model\helpdesk\Settings\CommonSettings;
use App\Http\Controllers\Controller;
use Config;
use App\Model\helpdesk\Ticket\Ticket_attachments;
use App\Model\helpdesk\Ticket\Ticket_Thread;

class StorageController extends Controller
{

    protected $default;
    protected $driver;
    protected $root;
    protected $public_root;
    protected $private_root;
    protected $s3_key;
    protected $s3_region;
    protected $s3_secret;
    protected $s3_bucket;
    protected $rackspace_key;
    protected $rackspace_region;
    protected $rackspace_username;
    protected $rackspace_container;
    protected $rackspace_endpoint;
    protected $rackspace_url_type;

    public function __construct()
    {
        $this->default             = $this->defaults();
        $this->driver              = $this->driver();
        $this->root                = $this->root();
        $this->public_root         = $this->root('public-root');
        $this->private_root        = $this->root('private-root');
        $this->s3_key              = $this->s3Key();
        $this->s3_region           = $this->s3Region();
        $this->s3_bucket           = $this->s3Bucket();
        $this->rackspace_container = $this->rackspaceContainer();
        $this->rackspace_endpoint  = $this->rackspaceEndpoint();
        $this->rackspace_key       = $this->rackspaceKey();
        $this->rackspace_region    = $this->rackspaceRegion();
        $this->rackspace_url_type  = $this->rackspaceUrlType();
        $this->rackspace_username  = $this->rackspaceUsername();
    }
    /**
     * storage configuration
     * @param string $option
     * @return string
     */
    protected function settings($option)
    {
        $settings = new CommonSettings();
        $setting  = $settings->getOptionValue('storage', $option);
        $value    = "";
        if ($setting) {
            $value = $setting->option_value;
        }
        return $value;
    }
    /**
     * get the default values
     * @return string 
     */
    public function defaults()
    {
        $default = "local";
        if ($this->settings('default')) {
            $default = $this->settings('default');
        }
        return $default;
    }
    /**
     * get default drive
     * @return string
     */
    public function driver()
    {
        return $this->settings('default');
    }
    /**
     * get the default root
     * @param string $type
     * @return string
     */
    public function root($type = 'private-root')
    {
        $root = $this->settings($type);
        if (!$root && $type == 'private-root') {
            $root = storage_path('app/private');
        }
        if (!$root && $type == 'public-root') {
            $root = public_path();
        }
        $carbon = \Carbon\Carbon::now();
        return $root . DIRECTORY_SEPARATOR . $carbon->year . DIRECTORY_SEPARATOR . $carbon->month . DIRECTORY_SEPARATOR . $carbon->day;
    }
    /**
     * get s3 key
     * @return string
     */
    public function s3Key()
    {
        return $this->settings('s3_key');
    }
    /**
     * get s3 region
     * @return string
     */
    public function s3Region()
    {
        return $this->settings('s3_region');
    }
    /**
     * get s3 secret
     * @return string
     */
    public function s3Secret()
    {
        return $this->settings('s3_secret');
    }
    /**
     * get s3 bucket
     * @return string
     */
    public function s3Bucket()
    {
        return $this->settings('s3_bucket');
    }
    /**
     * get rackspace key
     * @return string
     */
    public function rackspaceKey()
    {
        return $this->settings('root');
    }
    /**
     * get rackspace region
     * @return string
     */
    public function rackspaceRegion()
    {
        return $this->settings('rackspace_region');
    }
    public function rackspaceUsername()
    {
        return $this->settings('rackspace_username');
    }
    /**
     * get rackspace user name
     * @return string
     */
    public function rackspaceContainer()
    {
        return $this->settings('rackspace_container');
    }
    /**
     * get rackspace end point
     * @return string
     */
    public function rackspaceEndpoint()
    {
        return $this->settings('rackspace_endpoint');
    }
    /**
     * get rackspace url type
     * @return string
     */
    public function rackspaceUrlType()
    {
        return $this->settings('rackspace_url_type');
    }
    /**
     * set file system
     * @return string
     */
    protected function setFileSystem()
    {
        $config = $this->config();
        //dd($config);
        foreach ($config as $key => $con) {
            if (is_array($con)) {
                foreach ($con as $k => $v) {
                    Config::set("filesystem.$key.$k", $v);
                }
            }
            Config::set("filesystem.$key", $con);
        }
        return Config::get('filesystem');
    }
    /**
     * get congiguration for file system
     * @return array
     */
    protected function config()
    {
        return [
            'default' => $this->default,
            'cloud'   => 's3',
            'disks'   => $this->disks(),
        ];
    }
    /**
     * return the disk configuration for laravel filesystem
     * @return array
     */
    protected function disks()
    {

        return [
            "local"     => [
                'driver' => "local",
                'root'   => $this->root . '/attachments',
            ],
            "s3"        => [
                'driver' => "s3",
                'key'    => $this->s3_key,
                'secret' => $this->s3_secret,
                'region' => $this->s3_region,
                'bucket' => $this->s3_bucket,
            ],
            "rackspace" => [
                'driver'    => "rackspace",
                'username'  => $this->rackspace_username,
                'key'       => $this->rackspace_key,
                'container' => $this->rackspace_container,
                'endpoint'  => $this->rackspace_endpoint,
                'region'    => $this->rackspace_region,
                'url_type'  => $this->rackspace_url_type,
            ],
        ];
    }
    /**
     * upload attachment file to system
     * 
     * NOTE: $filepath is added as a workaround for php-imap package to work and should be removed while rewriting this module
     * 
     * @param mixed $data
     * @param string $filename
     * @param string $type
     * @param integer $size
     * @param string $disposition
     * @param integer $thread_id
     * @param mixed $attachment
     * @return string
     * 
     */
    public function upload($data, $filename, $type, $size, $disposition, $thread_id, $attachment, $recur
    = false, $realPath = '')
    {
        $upload = new Ticket_attachments();
        $name   = $upload->whereName($filename)->select('name')->first();


        if ($name) {
            $filename = $this->formatNameOfFile($filename, $disposition);
        }
        
        $upload->thread_id = $thread_id;
        $upload->name      = $filename;
        $upload->type      = $type;
        $upload->size      = $size;
        $upload->poster    = $disposition;
        $upload->driver    = $this->default;
        if ($this->default !== "database") {
            $upload_path  = $this->root();
            $upload->path = $upload_path;
            $s            = [
                'pathname'  => $upload_path . DIRECTORY_SEPARATOR . $filename,
                'extension' => $type,
                'filename'  => $filename,
                'size'      => $size,
                'type'      => $type,
                'path'      => $upload_path
            ];
            $this->uploadInLocal($attachment, $upload_path, $filename, $realPath);
            if ($recur) {
                return $s;
            }
        }
        else {
            $upload->file = $data;
        }
        if ($data && $size && $disposition) {
            $upload->save();
        }
        return $filename;
    }


    /* formats the name of the file */
    protected function formatNameOfFile($filename, $disposition){
        switch($disposition){
            case 'ATTACHMENT':
                //there can be multiple attachments of same name, so adding random string to it
                return  $filename = str_random(5) . "_" . $filename;

            case 'INLINE':
                return $filename;
            
            default:
                return  $filename = str_random(5) . "_" . $filename;
        }
    }

    /**
     * upload to system
     * @param mixed $attachment
     * @param string $upload_path
     * @param string $filename
     * @param string $realPath
     */
    public function uploadInLocal($attachment, $upload_path, $filename, $realPath)
    {
            if (!\File::exists($upload_path)) {
                \File::makeDirectory($upload_path, 0777, true);
            }
            $path = $upload_path . DIRECTORY_SEPARATOR . $filename;
            if (method_exists($attachment, 'getStructure')) {
                $attachment->saveAs($path);
            }
            else {
                \File::move($realPath, $upload_path.'/'.$filename);
            }
    }
    /**
     * save attachemnt details to database
     * @param integer $thread_id
     * @param array $attachments
     * @param array $inline
     * @return object
     * @throws \Exception
     */
    public function saveAttachments($thread_id, $attachments = [], $inline = [])
    {
        if (is_array($attachments) || is_array($inline)) {
            $ticket_thread = Ticket_Thread::find($thread_id);
            if (!$ticket_thread) {
                throw new \Exception('Thread not found');
            }
            $PhpMailController      = new \App\Http\Controllers\Common\PhpMailController();
            $NotificationController = new \App\Http\Controllers\Common\NotificationController();
            $ticket_controller      = new \App\Http\Controllers\Agent\helpdesk\TicketController($PhpMailController, $NotificationController);
            $thread                 = $ticket_controller->saveReplyAttachment($ticket_thread, $attachments, $inline);
        }
        return $thread;
    }
    
    /**
     * save attachment/inline document if it is an object
     * @param integer $thread_id
     * @param mixed $attachment
     * @return object
     */
    public function saveObjectAttachments($thread_id, $attachment, $recur = false, $disposition = 'ATTACHMENT')
    {

        if (is_object($attachment)) {
            if (method_exists($attachment, 'getStructure')) {

                $structure = $attachment->getStructure();
                if (isset($structure->disposition)) {
                    $disposition = $structure->disposition;
                }
                $filename = $attachment->getFileName();
                $type     = $attachment->getMimeType();
                $size     = $attachment->getSize();
                $data     = $attachment->getData();
            }
            else {
                
                

                try{
                    
                    //getClientOriginalName doesn't exists on php-imap package, so
                    //to do a workaround for both packages to work, try and catch has been implemented
                    //NOTE: it has to be removed once older package is removed
                    $filename = $attachment->getClientOriginalName();
                    $type     = $attachment->getMimeType();
                    $size     = $attachment->getSize();
                    $data     = file_get_contents($attachment->getRealPath());
                    $filePath = $attachment->getRealPath();
                
                }catch (\Error $e){
                    //getting all its information using its path
                    $filePath = $attachment->filePath;
                    $filename = basename($filePath);
                    $type = mime_content_type($filePath);
                    $size = filesize($filePath);
                    $data = file_get_contents($filePath);    
                }
                
            }
            $filename = $this->upload($data, $filename, $type, $size, $disposition, $thread_id, $attachment, $recur, $filePath);
            if ($recur) {
                return $filename;
            }
            $thread = $this->updateBody($attachment, $thread_id, $filename);
        }
        return $thread;
    }

    /**
     * update the body if thread has inline image
     * @param mixed $attachment
     * @param integer $thread_id
     * @param string $filename
     * @return object
     */
    public function updateBody($attachment, $thread_id, $filename)
    {
        $disposition = 'ATTACHMENT';
        $structurId = null;
        if (method_exists($attachment, 'getStructure')) {
            $structure   = $attachment->getStructure();
            $structurId  = str_replace(">", "", str_replace("<", "", $structure->id));
            if (isset($structure->disposition)) {
                $disposition = $structure->disposition;
            }
        } elseif (property_exists($attachment, 'disposition')) {
            $disposition = $attachment->disposition;
            $structurId  = $attachment->contentId;
        }

        //in case of outlook inline images comes with disposition as null
        if ($disposition == 'INLINE' || $disposition == 'inline' || !$disposition) {            
            $threads = new Ticket_Thread();
            $thread  = $threads->find($thread_id);
            $body    = $thread->body;
            $body    = str_replace('cid:' . $structurId, $filename, $body);
            $thread->body = $body;
            $thread->save();
            return $thread;
        }
    }
    /**
     * get the attachemnt/inline to render
     * @param string $drive
     * @param string $name
     * @param string $root
     * @return type
     */
    public function getFile($drive, $name, $root)
    {
        if ($drive != "database") {
            $root = $root . "/" . $name;
            if (\File::exists($root)) {
                //chmod($root, 0755);
                return \File::get($root);
            }
        }
    }
}
