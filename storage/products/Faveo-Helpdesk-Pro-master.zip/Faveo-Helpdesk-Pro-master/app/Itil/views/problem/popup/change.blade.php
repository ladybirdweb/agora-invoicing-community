<!--<a href="#impact" class="btn btn-sm btn-primary" data-toggle="modal" data-target="#impact{{$problem->id}}">Impact</a>-->
<?php
$statuses = \App\Itil\Models\Changes\SdChangestatus::pluck('name', 'id')->toArray();
$sd_changes_priorities = \App\Itil\Models\Changes\SdChangepriorities::pluck('name', 'id')->toArray();
$sd_changes_types = App\Itil\Models\Changes\SdChangetypes::pluck('name', 'id')->toArray();
$sd_impact_types = \App\Itil\Models\Changes\SdImpacttypes::pluck('name', 'id')->toArray();
$sd_locations = \App\Itil\Models\Releases\SdLocations::pluck('title', 'id')->toArray();
$users = \App\Itil\Models\Common\Cab::pluck('name', 'id')->toArray();
if (isAsset() == true) {
    $assets = \App\Itil\Models\Assets\SdAssets::pluck('name', 'id')->toArray();
}
$requester = App\User::where('role', 'agent')->orWhere('role', 'admin')->pluck('email', 'id')->toArray();
?>
<div class="modal fade" id="changenew{{$problem->id}}">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Change</h4>
                {!! Form::open(['url'=>'service-desk/problem/change/'.$problem->id,'method'=>'post','files'=>true]) !!}
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="form-group col-md-6 {{ $errors->has('subject') ? 'has-error' : '' }}">
                        <label for="inputPassword3" class="control-label">{{Lang::get('itil::lang.subject')}} </label><span class="text-red"> *</span>
                        {!! Form::text('subject',null,['class'=>'form-control','required'=>'required']) !!}
                        <!--<input type="text" class="form-control" name="subject" id="inputPassword3" placeholder="Subject">-->
                    </div>
                    <div class="form-group col-md-6 {{ $errors->has('requester') ? 'has-error' : '' }}">
                        <label for="inputPassword3" class="control-label">{{Lang::get('itil::lang.requester')}} </label>
                        {!! Form::select('requester',$requester,null,['class'=>'form-control']) !!}
                        <!--<input type="text" class="form-control" name="subject" id="inputPassword3" placeholder="Subject">-->
                    </div>


                    <div class="form-group col-md-6 {{ $errors->has('approval_id') ? 'has-error' : '' }}">
                        <label class="control-label">{{Lang::get('itil::lang.approval')}}</label>
                        {!! Form::select('approval_id',$users,null,['class'=>'form-control']) !!}

                    </div>

                    <div class="form-group col-md-12 {{ $errors->has('description') ? 'has-error' : '' }}">
                        <label for="internal_notes" class="control-label" >Description</label><span class="text-red"> *</span>
                        {!! Form::textarea('description',null,['class'=>'form-control','required'=>'required']) !!}
                        <!--<textarea class="form-control textarea" name="description" rows="7" id="internal_notes"></textarea>-->
                    </div>
                    <div class="form-group col-md-6 {{ $errors->has('status_id') ? 'has-error' : '' }}">
                        <label class=" control-label">{{Lang::get('itil::lang.status')}}</label>
                        {!! Form::select('status_id',$statuses,null,['class'=>'form-control'])!!}
                    </div>
                    <div class="form-group col-md-6 {{ $errors->has('priority_id') ? 'has-error' : '' }}">
                        <label class="control-label">{{Lang::get('itil::lang.priority')}}</label>
                        {!! Form::select('priority_id',$sd_changes_priorities,null,['class'=>'form-control']) !!}

                    </div> 
                    <div class="form-group col-md-6 {{ $errors->has('change_type_id') ? 'has-error' : '' }}">
                        <label class=" control-label">{{Lang::get('itil::lang.change_type')}}</label>
                        {!! Form::select('change_type_id',$sd_changes_types,null,['class'=>'form-control']) !!}

                    </div>
                 <!--    <div class="form-group col-md-6 {{ $errors->has('location_id') ? 'has-error' : '' }}">
                        <label class="control-label">{{Lang::get('itil::lang.location')}}</label>
                        {!! Form::select('location_id',$sd_locations,null,['class'=>'form-control']) !!}

                    </div> -->
                       <div class="form-group col-md-6 {{ $errors->has('location_id') ? 'has-error' : '' }}">
             
                  <?php
                   $location=App\Location\Models\Location::all();//for dropdown showing all location
                   ?>

                {!! Form::label('location',Lang::get('lang.location')) !!} <span class="text-red"> *</span>
                {!! Form::select('location_id', [Lang::get('lang.location')=>$location->pluck('title','id')->toArray()],null,['class' => 'form-control select']) !!}

               

            </div>
                    <div class="form-group col-md-6 {{ $errors->has('impact_id') ? 'has-error' : '' }}">
                        <label class=" control-label" >Impact Type</label>
                        {!! Form::select('impact_id',$sd_impact_types,null,['class'=>'form-control']) !!}

                    </div>
                    @if(isAsset()==true)
                    <div class="form-group col-md-6 {{ $errors->has('asset') ? 'has-error' : '' }}">
                        <label class=" control-label" >Asset</label>
                        {!! Form::select('asset[]',$assets,null,['class'=>'form-control','multiple'=>true]) !!}

                    </div>
                    @endif
                    <div class="form-group col-md-6 {{ $errors->has('attachments') ? 'has-error' : '' }}">
                        <label class=" control-label" >Attachments</label>
                        {!! Form::file('attachments[]',['class'=>'file-data']) !!}

                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" id="close" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <input type="submit" class="btn btn-primary" value="{{Lang::get('lang.save')}}">
                {!! Form::close() !!}
            </div>
            <!-- /Form -->
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<script type="text/javascript">
 $(".box-primary").on('change',".file-data", function(){
  
            if(this.files[0].size > 2048*1024){
                $(this).parent().find(".file-error").empty()
                $(this).parent().append("<p class='file-error' style='color:red'>cannot upload files more than 2 MB</p>")
                $(this).val('');
            }
        else{
            $(this).parent().find(".file-error").empty()
        }
   });
 </script>