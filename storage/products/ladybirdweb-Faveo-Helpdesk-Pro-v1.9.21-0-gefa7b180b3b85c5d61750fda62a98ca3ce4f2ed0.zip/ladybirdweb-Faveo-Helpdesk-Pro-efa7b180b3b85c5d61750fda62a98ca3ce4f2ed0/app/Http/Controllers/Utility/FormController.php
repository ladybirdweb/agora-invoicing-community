<?php

namespace App\Http\Controllers\Utility;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Custom\Form;
use DB;
use Auth;
use Input;
use App\User;

class FormController extends Controller
{
    /**
     * get the form in json format
     * @param boolean $array
     * @return array|json
     */
    public function getTicketFormJson($form_type = "ticket", $array = false)
    {
        $form   = new Form();
        $custom = $form->where('form', $form_type)->select('json')->first();
        $json   = "";
        if ($custom) {
            $json = str_replace("'", '"', $custom->json);
        }
        $json_event = checkArray('0', event(new \App\Events\ClientTicketForm($json)));
        if ($json_event) {
            $json = json_encode($json_event);
        }
        if ($array) {
            return $json;
        }
        return '[' . $json . ']';
    }
    /**
     * get all dependencies
     * @param Request $request
     * @return mixed
     */
    public function dependancy(Request $request)
    {
        try{
            $linked_topic = ($request->has('linkedtopic')) ? $request->get('linkedtopic')
                        : '';
            $dependency   = $request->input('dependency', 'priority');

            return $this->getDependancy($dependency, $linked_topic, $request);
        }  catch (\Exception $e){
            return response()->json(['error'=>$e->getMessage()]);
        }
    }
    /**
     * get the model for every dependency
     * @param string $dependency
     * @return mixed
     */
    public function getDependancyApproval($dependency, $term)
    {

        switch ($dependency) {
            case "priority":
                $auth_user = \Auth::user();
                if ($auth_user && $auth_user->role != 'user') {
                    return DB::table('ticket_priority')->where('priority', 'LIKE', '%' . $term . '%')->where('status', '=', 1)->select('priority_id as id', 'priority as optionvalue')->get()->toJson();
                }
                else {
                    return DB::table('ticket_priority')->where('priority', 'LIKE', '%' . $term . '%')->where('status', '=', 1)->where('ispublic', 1)->select('priority_id as id', 'priority as optionvalue')->get()->toJson();
                }
            case "faveo_department":
                return DB::table('department')->where('name', 'LIKE', '%' . $term . '%')->select('id', 'name as optionvalue')->get()->toJson();
            case "type":
                $auth_user = \Auth::user();
                if ($auth_user && $auth_user->role != 'user') {

                    return DB::table('ticket_type')->where('name', 'LIKE', '%' . $term . '%')->where('status', '=', 1)->select('id', 'name as optionvalue')->get()->toJson();
                }
                else {
                    return DB::table('ticket_type')->where('name', 'LIKE', '%' . $term . '%')->where('status', '=', 1)->where('ispublic', '=', 1)->select('id', 'name as optionvalue')->get()->toJson();
                }
            case "assigned_to":
                return DB::table('users')->where('role', '!=', 'user')->where('is_delete', '!=', 1)->where('ban', '!=', 1)->select('id', 'user_name as optionvalue')->get()->toJson();
        }
    }
    /**
     * get the model for every dependency
     * @param string $dependency
     * @return mixed
     */
    public function getDependancy($dependency, $linked_topic = '', $request = '')
    {
        // dd($dependency);
        switch ($dependency) {
            case "priority":
                $auth_user = \Auth::user();
                if ($auth_user && $auth_user->role != 'user') {
                    return DB::table('ticket_priority')->where('status', '=', 1)->select('priority_id as id', 'priority as optionvalue')->get()->toJson();
                }
                else {
                    return DB::table('ticket_priority')->where('status', '=', 1)->where('ispublic', 1)->select('priority_id as id', 'priority as optionvalue')->get()->toJson();
                }
            case "department":
                $departments = DB::table('department')->select('id', 'name as optionvalue', 'nodes');
                if ($linked_topic != '') {
                    $help_topic = DB::table('help_topic')->select('linked_departments', 'department')->where('topic', '=', $linked_topic)->first();
                    if ($help_topic->linked_departments == null || $help_topic->linked_departments
                            == '') {
                        $departments = $departments->where('id', '=', $help_topic->department)->get();
                    }
                    else {
                        $dept_ids    = explode(",", $help_topic->linked_departments);
                        $departments = $departments->whereIn('id', $dept_ids)->get();
                    }
                    // ->get();
                }
                else {
                    $departments = $departments->get();
                }
                foreach ($departments as $value) {
                    $value->optionvalue = [['language' => 'en', 'option' => $value->optionvalue, 'flag' => asset("lb-faveo/flags/en.png")]];
                    if ($value->nodes != null) {
                        $value->nodes = json_decode(str_replace("'", '"', $value->nodes));
                    }
                    else {
                        $value->nodes = [];
                    }
                }
                return response()->json($departments);
            case "faveo_department":
                return DB::table('department')->select('id', 'name as optionvalue')->get()->toJson();
            case "type":
                $auth_user = \Auth::user();
                if ($auth_user && $auth_user->role != 'user') {

                    return DB::table('ticket_type')->where('status', '=', 1)->select('id', 'name as optionvalue')->get()->toJson();
                }
                else {
                    return DB::table('ticket_type')->where('status', '=', 1)->where('ispublic', '=', 1)->select('id', 'name as optionvalue')->get()->toJson();
                }
            case "assigned_to":
                return DB::table('users')->where('role', '!=', 'user')
                                ->where([
                                    ['active', '=', 1],
                                    ['is_delete', '!=', 1],
                                    ['ban', '!=', 1]
                                ])->select('id', 'user_name as optionvalue')->orderBy('optionvalue')->get()->toJson();
                return DB::table('users')->where('role', '!=', 'user')->where('active', '=', 1)->where('is_delete', '!=', 1)->where('ban', '!=', 1)->select('id', 'user_name as optionvalue')->get()->toJson();
            case "company":
                return DB::table('organization')->select('id', 'name as optionvalue')->get()->toJson();
            case "status":
                if (Auth::user() && Auth::user()->role != 'user') {
                    return DB::table('ticket_status')->select('id', 'name as optionvalue')->get()->toJson();
                }
                return DB::table('ticket_status')->where('visibility_for_client', 1)->where('allow_client', 1)->select('id', 'name as optionvalue')->where('purpose_of_status', 1)->get()->toJson();
            case "help_topic":
                $auth_user = \Auth::user();
                if ($auth_user && $auth_user->role != 'user') {
                    $help_topics = DB::table('help_topic')->where('status', '=', 1)->select('id', 'topic as optionvalue', 'nodes')->get()->toJson();
                }
                else {
                    $help_topics = DB::table('help_topic')->where('status', '=', 1)->where('type', '=', 1)->select('id', 'topic as optionvalue', 'nodes')->get()->toJson();
                }
                return $help_topics;
            // case "status":
            //     return DB::table('ticket_status')->select('id', 'name as optionvalue')->get()->toJson();
            case "helptopic":
                $help_topics = DB::table('help_topic');
                if ($linked_topic != '') {
                    $dept        = DB::table('department')->where('name', '=', $linked_topic)->pluck('id')->toArray()[0];
                    $help_topics = $help_topics->whereRaw("find_in_set('" . $dept . "', linked_departments)")->orWhere('department', '=', $dept);
                }
                $auth_user = \Auth::user();
                if ($auth_user && $auth_user->role != 'user') {
                    $help_topics = $help_topics->where('status', '=', 1)->select('id', 'topic as optionvalue', 'nodes')->orderBy('optionvalue')->get();
                }
                else {
                    $help_topics = $help_topics->where('status', '=', 1)->where('type', '=', 1)->select('id', 'topic as optionvalue', 'nodes')->orderBy('optionvalue')->get();
                }
                foreach ($help_topics as $value) {
                    $value->optionvalue = [['language' => 'en', 'option' => $value->optionvalue, 'flag' => asset("lb-faveo/flags/en.png")]];
                    if ($value->nodes != null) {
                        $value->nodes = json_decode(str_replace("'", '"', $value->nodes));
                    }
                    else {
                        $value->nodes = [];
                    }
                }
                return response()->json($help_topics);
            case "source":
                return DB::table('ticket_source')->select('id', 'value as optionvalue')->get()->toJson();
            case "approval":
                return $this->getDependancyApproval($request->get('req'), $request->get('term'));
            case "location":
                // return DB::table('location')->select('title', 'title as optionvalue')->get()->toJson();
                $auth_user = \Auth::user();
                if ($auth_user && $auth_user->role != 'user') {
                    if (\Auth::user()->role === 'admin') {
                        return DB::table('location')->orderBy('title', 'asc')->select('title as id', 'title as optionvalue')->get()->toJson();
                    }
                    else {
                        $agent_location = User::where('id', '=', \Auth::user()->id)->select('location')->first();

                        if ($agent_location->location) {
                            return DB::table('location')->orderBy('title', 'asc')->where('title', '=', $agent_location->location)->select('title as id', 'title as optionvalue')->get()->toJson();
                        }
                        else {
                            return DB::table('location')->orderBy('title', 'asc')->select('title as id', 'title as optionvalue')->get()->toJson();
                        }
                    }
                }
                else {
                    return DB::table('location')->orderBy('title', 'asc')->select('title as id', 'title as optionvalue')->get()->toJson();
                }

            case "org_dept":
                $company = $request->input('company');
                return \App\Model\helpdesk\Agent_panel\OrganizationDepartment::whereIn('org_id', $company)->select('id', 'org_deptname as optionvalue')->get()->toJson();
        }
    }
    /**
     * get requester in form
     * @param Request $request
     * @return json
     */
    public function requester(Request $request)
    {
        $method   = $request->input('type', 'agent');
        $user_ids = explode(',', $request->input('user_id', ''));
        if (count($user_ids) == 1 && $user_ids[0] == '') {
            $user_ids = '';
        }
        $user  = new \App\User();
        $term  = $request->input('term');
        $query = $user
                ->when($user_ids, function($q)use($user_ids) {
                    $q->whereIn('id', $user_ids);
                })
                ->where('is_delete', '!=', 1)
                ->where('active', '=', 1)
                ->where('ban', '!=', 1)
                ->when($term, function($q) use($term) {
                    $q->where(function($query) use($term) {
                        $query->where('first_name', 'LIKE', '%' . $term . '%')
                        ->orWhere('last_name', 'LIKE', '%' . $term . '%')
                        ->orWhere('user_name', 'LIKE', '%' . $term . '%')
                        ->orWhere('email', 'LIKE', '%' . $term . '%');
                    });
                })
                ->with(['org' => function($org) {
                $org->select('id', 'org_id', 'user_id', 'role', 'org_department');
            }, 'org.organisation' => function($company) {
                $company->select('id', 'name as company');
            }, 'org.orgDepartment' => function($q) {
                    $q->select('id', 'org_deptname', 'business_hours_id');
                }
                    ]);
        if ($method == 'agent') {
            $users = $query
                    ->where('role', '!=', 'user')
                    ->select('id', 'user_name as name', 'first_name', 'last_name')
                    ->get();
            return $users;
        }
        if ($method == 'requester') {
            $users = $query
                    ->select('id', 'user_name as name', 'first_name', 'last_name')
                    ->get();
            return $users;
        }
        else {
            $users = $user->where('user_name', $term)
                    ->where('is_delete', '!=', 1)
                    ->select('id', 'user_name as name', 'first_name', 'last_name')
                    ->first();
            return $users;
        }
    }
    /**
     * get the authentcated user deatails in client page
     * @return json
     */
    public function authRequesterClient()
    {
        $user = NULL;
        if (\Auth::user()) {
            $user               = \Auth::user()->load(['org' => function($q) {
                    $q->select('id', 'org_id', 'user_id', 'role', 'org_department');
                }, 'org.orgDepartment' => function($q) {
                    $q->select('id', 'org_deptname', 'business_hours_id');
                }, 'org.organisation' => function($company) {
                $company->select('id', 'name as company');
            }]);
        }
        return $user;
    }
    /**
     * parse the form from json to array
     * @return array
     */
    public function ticketFormBuilder($form)
    {
        $json            = $this->getTicketFormJson($form, true);
        $array           = json_decode($json, true);
        $array_title_key = collect($array)->keyBy('unique')->toArray();
        $result          = $this->parseTicketFormArray($array_title_key);
        return $result;
    }
    /**
     * get values in array after
     * @param array $array
     * @return array
     */
    public function parseTicketFormArray($array)
    {
        $result = [];
        foreach ($array as $key => $value) {
            $result[$key] = $this->parseParent($value, $key);
        }
        return $result;
    }
    /**
     * parse the parent field is it is a nested field
     * @param array $value
     * @param string $key
     * @param string $parent
     * @param string $child
     * @param string $option_value
     * @return array
     */
    public function parseParent($value, $key = "", $parent = "", $child = "", $option_value
    = "")
    {
        //dd($value);
        $agent       = checkArray('agentRequiredFormSubmit', $value);
        $client      = checkArray('customerRequiredFormSubmit', $value);
        $label       = checkArray('agentlabel', $value);
        $agent_label = "";
        if ($label && is_array($label)) {
            $agent_label = head($label)['label'];
        }
        if (is_string($label)) {
            $agent_label = $label;
        }
        $result['agent_label'] = $agent_label;
        $result['agent']       = $agent;
        $result['client']      = $client;
        $result['parent']      = $parent;
        $result['label']       = $child;
        $result['option']      = $option_value;
        $options               = checkArray('options', $value);
        if ($options && count($options) > 0) {
            $array = $this->parseOptions($options, $key);
            if (is_array($array)) {
                $result = array_merge($result, $array);
            }
        }
        return $result;
    }
    /**
     * 
     * @param array $options
     * @param string $parent
     * @return type
     */
    public function parseOptions($options, $parent = "")
    {
        $result = [];
        foreach ($options as $option) {
            $nodes        = checkArray('nodes', $option);
            $option_value = checkArray('optionvalue', $option);
            if ($nodes && checkArray('0', $nodes)) {
                foreach ($nodes as $node) {
                    $result['child'][$node['unique']] = $this->parseParent($node, $node['agentlabel'], $parent, $node['agentlabel'], $option_value);
                }
            }
        }
        return $result;
    }
    public function saveRequired($form = 'ticket')
    {
        \App\Model\Custom\Required::
                where('form', $form)
                ->delete();
        $array = $this->ticketFormBuilder($form);
        foreach ($array as $parent => $values) {
            $this->saveOptions($parent, $values, $form);
        }
    }
    public function saveOptions($key, $values, $form, $option = 'required', $parent_id
    = "")
    {
        $required     = [];
        $child        = checkArray('child', $values);
        $option_value = checkArray('option', $values);
        if (!is_string($option_value)) {
            $option_value = head($option_value)['option'];
        }
        $required['option'] = $option_value;
        if (checkArray('agent', $values)) {
            $required['agent'] = $option;
        }
        if (checkArray('client', $values)) {
            $required['client'] = $option;
        }
        if ($parent_id) {
            $required['parent'] = $parent_id;
        }
        if ($required) {

            if (!is_string($key)) {
                $key = head($key)['label'];
            }
            $required['field'] = $key;
            $required['form']  = $form;
            $required['label'] = checkArray('agent_label', $values);
            $required_model    = \App\Model\Custom\Required::updateOrCreate($required);
            if ($child) {
                $parent_field_name = $key;
                $this->saveChild($child, $parent_field_name, $required_model, $form);
            }
        }
    }
    public function saveChild($child, $parent_field_name, $model, $form, $option_value
    = "")
    {
        foreach ($child as $key => $values) {
            $option = "required_if:$parent_field_name";
            $this->saveOptions($key, $values, $form, $option, $model->id);
        }
    }
    public function captchaValidation($captcha = "")
    {

        $google_secret_key = \App\Model\helpdesk\Settings\commonSettings::where('option_name', '=', 'google secret key')->select('option_value')->first();

        if ($captcha && $google_secret_key) {
            $post_data = http_build_query(
                    array(
                        'secret'   => $google_secret_key->option_value,
                        'response' => $captcha,
                        'remoteip' => $_SERVER['REMOTE_ADDR']
                    )
            );
            $opts      = array('http' =>
                array(
                    'method'  => 'POST',
                    'header'  => 'Content-type: application/x-www-form-urlencoded',
                    'content' => $post_data
                )
            );

            $context  = stream_context_create($opts);
            $response = file_get_contents('https://www.google.com/recaptcha/api/siteverify', false, $context);
            $result   = json_decode($response);
            if (!$result->success) {
                return false;
            }
            else {
                return true;
            }
        }
        else {

            return false;
        }
    }
}
