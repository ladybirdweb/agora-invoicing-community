<?php

namespace App\Http\Controllers\Client\helpdesk;

use App\Http\Controllers\Agent\helpdesk\TicketWorkflowController;
use App\Http\Controllers\Controller;
use App\Model\helpdesk\Ticket\Ticket_Thread;
use App\Model\helpdesk\Ticket\Tickets;
use App\User;
use Auth;
use Illuminate\Http\Request;
use Lang;
use App\Model\helpdesk\Agent\Department;
use App\Model\helpdesk\Ticket\Ticket_Status;
use App\Model\helpdesk\Settings\CommonSettings;
use App\Model\helpdesk\Agent_panel\User_org;
use Input;
use Illuminate\Support\Facades\Crypt;

class ClientTicketController extends Controller {

    /**
     * Create a new controller instance.
     *
     * @return type response
     */
    public function __construct() {
        $this->TicketWorkflowController = new TicketWorkflowController;
        $this->middleware('auth');
        $this->middleware('board');
    }

    /**
     * Get Checked ticket.
     *
     * @param type Tickets $ticket
     * @param type User    $user
     *
     * @return type response
     */
    public function getCheckTicket(Tickets $ticket, User $user) {
        return view('themes.default1.client.helpdesk.guest-user.newticket', compact('ticket'));
    }

    /**
     * handles a client reply
     * @param integer $id ticketId  id of the ticket to which client is replying
     * @param object $request       Request
     * @return type json            Success message if success else failure
     */
    public function reply($id, Request $request) {
        $this->validate($request, ['reply' => 'required']);
        try {
            $ticket = Tickets::find($id);
            $thread = Ticket_Thread::where('ticket_id', $ticket->id)->first();

            $subject = $thread->title . '[#' . $ticket->ticket_number . ']';
            $body = $request->input('reply');
            $fromaddress = Auth::user()->email;
            $fromname = Auth::user()->user_name;
            $phone = '';
            $phonecode = '';
            $mobile_number = '';

            $helptopic = $ticket->help_topic_id;
            $sla = $ticket->sla;
            $priority = $ticket->priority_id;
            $source = $ticket->source;
            $collaborator = '';
            $dept = $ticket->dept_id;
            $assign = $ticket->assigned_to;
            $form_data = [];
            $team_assign = null;

            //purpose of status 7 corresponds to unapproved status, which should not change is client is replying
            $ticket_status = ($ticket->statuses->purpose_of_status == 7) ? $ticket->status : null;
            $auto_response = 0;
            $type = "";
            $attachment = Input::hasFile('attachment') ? Input::file('attachment'): "";
            $this->TicketWorkflowController->workflow($fromaddress, $fromname, $subject, $body, $phone, $phonecode, $mobile_number, $helptopic, $sla, $priority, $source, $collaborator, $dept, $assign, $team_assign, $ticket_status, $form_data, $auto_response, $type,$attachment);
            $result = ["success" => Lang::get('lang.successfully_replied')];
        } catch (\Exception $e) {
            $result = $e->getMessage();
            return response()->json(compact('result'), 500);
        }
        return response()->json(compact('result'));
    }
     /**
     * Gets tickets raised by a user or (if enabled) gets all the tickets raised by any member of the organization, irrespective of user type
     * @param string $orgId of Of organization
     * @return json
     */
    public function myTickets($orgId=null) {
        try {
          $tickets=new Tickets();
          $allowedTickets = $this->allowedTicketsForAUser(Auth::user()->id,$orgId);
          $allowOrganizationmanager = CommonSettings::where('option_name', 'allow_organization_mngr_approve_tickets')->value('status');
          $orgmanager=User_org::where('user_id',Auth::user()->id)->select('role')->first();

          if($orgmanager && $orgmanager->role == "manager" && $allowOrganizationmanager == 1){

                 //NOTE: queries for open and closed tickets are different so that is required, pagination can be implemented easily
            $openTicketQuery = $tickets->orderBy('updated_at', 'desc')->whereIN('id', $allowedTickets)->where(function ($query) {
                $query->whereIN('tickets.status', getStatusArray('open'))
                        ->orWhereIN('tickets.status', getStatusArray('approval'))->get();
            });
            $openTickets = $this->queryBuilderForMyTickets($openTicketQuery);


            //close ticket
            $closeTicketQuery = $tickets->orderBy('updated_at', 'desc')->whereIN('id', $allowedTickets)->whereIN('tickets.status', getStatusArray('closed'));
            $closeTickets = $this->queryBuilderForMyTickets($closeTicketQuery);
            //deleted ticket
            $deleteTicketQuery = $tickets->orderBy('updated_at', 'desc')->whereIN('id', $allowedTickets)->whereIN('tickets.status', getStatusArray('deleted'));
            $deleteTickets = $this->queryBuilderForMyTickets($deleteTicketQuery);
            //unapprove ticket
            $unapprovedTicketQuery = $tickets->orderBy('updated_at', 'desc')->whereIN('id', $allowedTickets)->whereIN('tickets.status', getStatusArray('unapproved'));
            $unapprovedTickets = $this->queryBuilderForMyTickets($unapprovedTicketQuery);
            return successResponse('', ["open" => $openTickets, "closed" => $closeTickets,'deleted'=>$deleteTickets,'unapproved'=> $unapprovedTickets]);
           }

        elseif($orgmanager && $orgmanager->role == "manager" && $allowOrganizationmanager != 1){

                 $openTicketQuery = $tickets->orderBy('updated_at', 'desc')->whereIN('id', $allowedTickets)->where(function ($query) {
                $query->whereIN('tickets.status', getStatusArray('open'))
                        ->orWhereIN('tickets.status', getStatusArray('approval'))->orWhereIN('tickets.status', getStatusArray('unapproved'))->get();
            });
            $openTickets = $this->queryBuilderForMyTickets($openTicketQuery);
            $closeTicketQuery = $tickets->orderBy('updated_at', 'desc')->whereIN('id', $allowedTickets)->whereIN('tickets.status', getStatusArray('closed'));
            $closeTickets = $this->queryBuilderForMyTickets($closeTicketQuery);
             //deleted ticket
            $deleteTicketQuery = $tickets->orderBy('updated_at', 'desc')->whereIN('id', $allowedTickets)->whereIN('tickets.status', getStatusArray('deleted'));
            $deleteTickets = $this->queryBuilderForMyTickets($deleteTicketQuery);

              return successResponse('', ["open" => $openTickets, "closed" => $closeTickets,'deleted'=>$deleteTickets]);

            }
            else{

             //NOTE: queries for open and closed tickets are different so that is required, pagination can be implemented easily
            $openTicketQuery = $tickets->orderBy('updated_at', 'desc')->whereIN('id', $allowedTickets)->where(function ($query) {
                $query->whereIN('tickets.status', getStatusArray('open'))
                        ->orWhereIN('tickets.status', getStatusArray('approval'))->orWhereIN('tickets.status', getStatusArray('unapproved'))->get();
            });
            $openTickets = $this->queryBuilderForMyTickets($openTicketQuery);
            $closeTicketQuery = $tickets->orderBy('updated_at', 'desc')->whereIN('id', $allowedTickets)->whereIN('tickets.status', getStatusArray('closed'));
            $closeTickets = $this->queryBuilderForMyTickets($closeTicketQuery);

            return successResponse('', ["open" => $openTickets, "closed" => $closeTickets]);

            }


        } catch (\Exception $e) {
            $error = $e->getMessage();
            $line = $e->getLine();
            $file = $e->getFile();

            return response()->json(compact('error', 'file', 'line'));
        }
    }

    /**
     * helper function for myTickets method
     * build and return query results
     *
     * @return array
     */
    private function queryBuilderForMyTickets($q) {
        $tickets = $q->with([
                    'firstThread' => function($q) {//for getting title of the thread/ticket
                        $q->select('id', 'ticket_id', 'user_id', 'title', 'updated_at');
                    },
                    'lastThread' => function($q) {//for getting last replier's name
                        $q->select('id', 'ticket_id', 'user_id', 'title', 'updated_at')->with(['user' => function($q1) {
                                $q1->select('id', 'first_name', 'last_name');
                            }]);
                    }])
                ->with('priority:priority_id,priority')
                ->select('tickets.id', 'tickets.ticket_number', 'tickets.updated_at', 'tickets.priority_id')
                ->orderBy('id', 'DESC')
                ->get();
        return $this->formatMyTickets($tickets);
    }

    /**
     * helper function for myTickets method
     * unset unnecessary elements and returns the formatted array
     *
     * @return array
     */
    private function formatMyTickets($tickets) {
        foreach ($tickets as $element) {
             $element['encrypt_id'] = Crypt::encryptString($element['id']);
            $element['last_replier'] = $element['lastThread']['user'];
            $element['title'] = $element['firstThread']['title'];
            $priority = $element['priority']['priority'];
            unset($element->priority);
            $element['priority'] = $priority;
            unset($element->firstThread, $element->lastThread, $element->priority_id);
        }
        return $tickets;
    }

    /**
     * gets list of statuses from the Db
     * @return json
     */
    public function getStatusList(Ticket_Status $status, CommonSettings $commonSettings) {

        try {
            $isAllowedToSetStatus = $commonSettings->where('option_name', 'user_set_ticket_status')->first();

            if ($isAllowedToSetStatus->status) {

                $statuses = $status->where('visibility_for_client', 1)->where('allow_client', 1)->where('purpose_of_status', '!=', 5)->get();
            } else {
                $statuses = [];
            }
            return successResponse('', ['statuses' => $statuses]);
        } catch (\Exception $e) {
            $error = $e->getMessage();
            $line = $e->getLine();
            $file = $e->getFile();
            return errorResponse($e->getMessage());
        }
    }

   /**
    * This method return ticket id as a array based on user type (may be user as a organization manager or organization members or normal user)
    * @param int $userId of user
    * @param string $orgId of Of organization
    * @return type array  (ticket id)
    */
    private function allowedTicketsForAUser(int $userId, $orgId=null) {


        $orgmanager=User_org::where('user_id',Auth::user()->id)->select('role')->first();
        $orgId =($orgId) ? User_org::where('user_id', $userId)->where('org_id', $orgId)->pluck('org_id')->toArray() :User_org::where('user_id', $userId)->pluck('org_id')->toArray();
        $orgMembersArray = User_org::whereIN('org_id', $orgId)->pluck('user_id')->toArray();

        $orgMembers = array_unique($orgMembersArray);

        //check whether user is allowed to view all the organisation tickets
        $showOrgTicketsToUser = CommonSettings::where('option_name', '=', 'user_show_org_ticket')->first();

        //if (belongs to an organisation and is allowed to view organisation's tickets) else (tickets that user owns)
        $idsOfAllowedTicket = ($orgId && $showOrgTicketsToUser->status == 0 || ($orgId && $orgmanager && $orgmanager->role == "manager")) ?
                Tickets::whereIN('user_id', $orgMembers)->pluck('id') :
                Tickets::where('user_id', $userId)->pluck('id');

        return $idsOfAllowedTicket->toArray();
    }

    /**
     * ticket details including all the threads
     * @param $id ticketId in encryted form
     * @param $tickets an instance of Ticket
     * @return json
     */
    public function checkTicket($id, Request $request) {
        try {

            $currentPage = $request->input('page') ? $request->input('page') : 1;

            $uploadFileSize = parse_size(ini_get('post_max_size'));
            $uploadSingleFileSize = parse_size(ini_get('upload_max_filesize'));
            $uploadFilecount = parse_size(ini_get('max_file_uploads'));
            $id = Crypt::decryptString($id);

            $ticket = $this->queryBuilderForCheckTicket($id, $currentPage);
            $allowedTickets = $this->allowedTicketsForAUser(Auth::user()->id);

            $orgTicketReply = CommonSettings::where('option_name', 'user_reply_org_ticket')->value('status');
            $reply=($orgTicketReply != "1")?'yes':'no';
            if (in_array($ticket['id'], $allowedTickets)) {

            return successResponse('', ['ticket' => $ticket,'reply'=>$reply,'uploadfilesize'=>$uploadFileSize,'uploadSingleFileSize'=>$uploadSingleFileSize,'uploadFilecount'=>$uploadFilecount]);

            }

            return errorResponse(['invalid' =>[Lang::get('lang.unauthorized_access'), 401]]);
        } catch (\Exception $e) {
            return errorResponse($e->getMessage());
        }
    }

    /**
     * Can be used by outside classes to get the same structure of the ticket without a logged in user
     * @param int $ticketId   id of the ticket
     * @param int $currentPage  page number (each page contains 10 tickets)
     * @return Tickets
     */
    public function getTicketById($ticketId, $currentPage)
    {
        return $this->queryBuilderForCheckTicket($ticketId, $currentPage);
    }

    /**
     * Gets data for tickets by applying all the required relationships(specific to checkTicket functionality. Should not be used by other methods)
     * @param $id ticketId
     * @return array
     */
    private function queryBuilderForCheckTicket($id, $currentPage)
    {
        $recordsPerPage = 10;
        $offset = ($currentPage - 1) * $recordsPerPage;
        $ticket = Tickets::where('tickets.id', $id)
                    ->select('id', 'duedate', 'dept_id','ticket_number', 'help_topic_id','status', 'user_id', 'priority_id', 'created_at')
                        ->with(['ratings' => function($q){
                            $q->select('id','rating_id','rating_value','ticket_id')
                            ->where('thread_id',null)->orWhere('thread_id',0)->orWhere('thread_id',"");
                        }])
                        ->with(['thread' => function($q) use($recordsPerPage, $offset) {
                            $q->with('ratings:id,rating_id,rating_value,thread_id')
                            ->orderBy('id','desc')
                            ->where('is_internal','!=',1)
                            ->select('id', 'user_id', 'title', 'body', 'created_at', 'updated_at', 'ticket_id')
                            ->with('user:id,first_name,last_name,profile_pic,email,role')
                            ->with('attach')->skip($offset)->take($recordsPerPage);
                        }])->with('user:id,first_name,last_name,profile_pic,email')
                                //if user role is non-user, ratings should not show
                        ->with('helptopic:id,topic,department')
                        ->with('statuses:id,name')
                        ->with('priority:priority_id,priority as name')
                        ->first()
                        ->toArray();


              return $this->formatCheckTicket($ticket);
    }

    /** formats ticket in a way that front-end expects (specific to checkTicket functionality. Should not be used by other methods)
     * @param $ticket Ticket in
     * @return array
     */
    private function formatCheckTicket($ticket)
    {
        $ticket['help_topic'] = $ticket['helptopic']['topic'];
        $threads = [];

        foreach ($ticket['thread'] as $thread){

            //extracting title out of thread
            if($thread['title']){
                $ticket['title'] = $thread['title'];
            }

            if($thread['user']['role'] == 'user'){
                unset($thread['ratings']);
            }

            array_push($threads,$thread);
        }

        $ticket['threads'] = $threads;
        unset($ticket['thread']);
        $departmentId = $ticket['dept_id'];
        $ticket['department'] = Department::where('id', $departmentId)->select('name')->first()->name;
        $ticket['status'] = $ticket['statuses']['name'];
        $priority = $ticket['priority']['name'];
        unset($ticket['priority'], $ticket['priority_id']);
        $ticket['priority'] = $priority;
        unset($ticket['helptopic'], $ticket['statuses'], $ticket['help_topic_id'], $ticket['user_id']);
        return $ticket;
    }

}
