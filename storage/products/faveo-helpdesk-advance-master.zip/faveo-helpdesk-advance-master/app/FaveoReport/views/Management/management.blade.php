@extends('themes.default1.agent.layout.agent')
@section('Staffs')
active
@stop

@section('staffs-bar')
active
@stop

@section('Report')
class="active"
@stop

@section('HeadInclude')
<link href="{{assetLink('css','dataTables-bootstrap')}}" rel="stylesheet"  type="text/css" media="none" onload="this.media='all';"/>
<style type="text/css">
    button.dt-button{
      color: #f9f9f9;
    display: inline-block;
    padding: 6px 12px;
    margin-bottom: 0;
    font-size: 14px;
    font-weight: 400;
    line-height: 1.42857143;
    text-align: center;
    white-space: nowrap;
    vertical-align: middle;
    -ms-touch-action: manipulation;
    touch-action: manipulation;
    cursor: pointer;
    background: #3c8dbc;
    border-color: #367fa9;
    }
    button.dt-button:hover{
      background-color: #3c8dbc!important;
    border-color: #367fa9!important;
    background-image: none !important;
    }
    .dt-buttons{
      float:right !important;
    }
</style>
@stop

@section('PageHeader')
<h1>{!! Lang::get('report::lang.management-performance') !!}</h1>
@stop

@section('content')
<div class="alert alert-success alert-dismissable" style="display: none;">
    <i class="fa  fa-check-circle"></i>
    <span class="success-msg"></span>
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
</div>
<div id="alert-danger" class="alert alert-danger alert-dismissable" style="display: none;">
    <i class="fa fa-check-circle"> </i>
    <b><span id="get-danger"></span></b>
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
</div>
<div class="box box-primary">
    <div class="box-header">
        <button class="btn btn-primary pull-right" id="exportBtn">{!! Lang::get('lang.export') !!}</button>
        <button class="btn btn-primary" onclick="showhidefilter();"><i class="fa fa-filter">&nbsp;</i>{!! Lang::get('report::lang.filter') !!}</button>
          @include('report::indepth.filter')
    </div>

    <div class="box-body">
        <div class="wrapper1" >
           <div class="div1" style="overflow-x: auto;overflow-y: hidden;"></div>
        </div>
        <div class="wrapper2" style="overflow-x: auto;overflow-y: hidden">
            <div class="div2">
                <table class="table table-bordered" cellspacing="0"  id="users-table" style="width: 100%">
                    <thead>
                        <tr>
                            <th>{!! Lang::get('report::lang.ticket_number') !!}</th>
                            <th>{!! Lang::get('report::lang.subject') !!}</th>
                            <th>{!! Lang::get('report::lang.status') !!}</th>
                            <th>{!! Lang::get('report::lang.created_date') !!}</th>
                            <th>{!! Lang::get('report::lang.type') !!}</th>
                            <th>{!! Lang::get('report::lang.priority') !!}</th>
                            <th>{!! Lang::get('report::lang.org_name') !!}</th>
                            <th>{!! Lang::get('report::lang.email') !!}</th>
                            <th>{!! Lang::get('report::lang.location') !!}</th>
                            <th>{!! Lang::get('report::lang.department') !!}</th>
                            <th>{!! Lang::get('report::lang.helptopic') !!}</th>
                            <th>{!! Lang::get('report::lang.ticket_source') !!}</th>
                            <th>{!! Lang::get('report::lang.description') !!}</th>
                            <th>{!! Lang::get('report::lang.reply_content') !!}</th>
                            <th>{!! Lang::get('report::lang.agent_responded_time') !!}</th>
                            <th>{!! Lang::get('report::lang.last_response_date') !!}</th>
                            <th>{!! Lang::get('report::lang.close_date') !!}</th>
                            <th>{!! Lang::get('report::lang.assigned_to_agent') !!}</th>
                            <th>{!! Lang::get('report::lang.assigned_to_team') !!}</th>
                            <th>{!! Lang::get('report::lang.response_sla_met') !!}</th>
                            <th>{!! Lang::get('report::lang.resolution_sla_met') !!}</th>
                            <th>{!! Lang::get('report::lang.resolution_due_date') !!}</th>
                            <th>{!! Lang::get('report::lang.over_due') !!}</th>
                            <th>{!! Lang::get('report::lang.first_resp_tme_bh') !!}</th>
                            {{-- <th>{!! Lang::get('report::lang.reso_tme_bh') !!}</th> --}}
                        </tr>
                    </thead>
                </table>
            </div>
        </div>
    </div>
</div>
@stop
@section('FooterInclude')
<script src="{{assetLink('js','jquery-dataTables')}}" type="text/javascript" ></script>
<script src="{{assetLink('js','dataTables-bootstrap')}}" type="text/javascript"></script>
<script type="text/javascript">
    var customLabel=[];
    var allColumnDef=[
       {"orderable": false, "targets": [2,4]},
       {"searchable": false, "targets": [3] },
       {render: function(data) {return data}, "targets": "_all"}
    ];
    var allColumns=[
        {data: 'ticket_number', name: 'ticket_number'},
        {data: 'subject', name: 'subject'},
        {data: 'statuses', name: 'statuses'},
        {data: 'created_at', name: 'created_at'},
        {data: 'types', name: 'types'},
        {data: 'priority', name: 'priority'},
        {data: 'org_name', name: 'org_name'},
        {data: 'email', name: 'email'},
        {data: 'location', name: 'location'},
        {data: 'departments', name: 'departments'},
        {data: 'helptopic', name: 'helptopic'},
        {data: 'sources', name: 'sources'},
        {data: 'description', name: 'description'},
        {data: 'reply_content', name: 'reply_content'},
        {data: 'agent_responded_time', name: 'agent_responded_time'},
        {data: 'last_response', name: 'last_response'},
        {data: 'closed_at', name: 'closed_at'},
        {data: 'assigned', name: 'assigned'},
        {data: 'assigned_team', name: 'assigned_team'},
        {data: 'is_response_sla', name: 'is_response_sla'},
        {data: 'is_resolution_sla', name: 'is_resolution_sla'},
        {data: 'duedate', name: 'duedate'},
        {data: 'overdue', name: 'overdue'},
        {data: 'first_resp_time_bh', name: 'first_resp_time_bh'},
        // {data: 'reso_time_bh', name: 'reso_time_bh'},
    ];

    function hideEmptyCols(table) {
      var numCols = $("th", table).length;
      for ( var i=1; i<=numCols; i++ ) {
          var empty = false;
          //grab all the <td>'s of the column at i
          $("td:nth-child(" + i + ")", table).each(function(index, el) {  
               $("th:nth-child(" + i + ")", table).show(); //hide header <th>
              //check if the <span> of this <td> is empty
              if ( $(el).text() == "" ) {

                  empty=true; //break out of each() early
                  return true;
              }
              else{
                  empty=false;
                  return false;
              }

          });
          if ( empty ) {
              $("td:nth-child(" + i + ")", table).hide(); //hide <td>'s
              $("th:nth-child(" + i + ")", table).hide(); //hide header <th>
          }
      }
    }

    function getAllColumn(){
        return allColumns;
    }

    function getColumnDef(){
        return allColumnDef;
    }

    $.ajax({
        url: "{{url('custom-filter-fields?get-all=true')}}",
        method: "GET",
        success: function(json){
            var count = 0;
            for(var k in json){
                for(var r in json){
                    if((json[r].label==json[k].label) && (json[r].field!=json[k].field)) {
                        count++;
                        json[r].label=json[r].label+'-'+count;
                    }
                }
            }
            customLabel=json;
            for(var j in json){
                $('#users-table').find('thead tr').append('<th>'+json[j].label+'</th>');
                allColumns.push({data: json[j].label, name: json[j].label, searchable: false });
                allColumnDef[0].targets.push(allColumns.length-1);
            }
            var oTable = $('#users-table').DataTable({
                dom: 'Blrtip',
                initComplete: function(settings, json) {
                    hideEmptyCols($('#users-table'));
                },
                processing: true,
                serverSide: true,
                ajax: {
                    url:"{{ url('report/management/report') }}",
                    method:"POST",
                    data: function (d) {
                        d.start_date = $('input[name=start_date]').val();
                        d.end_date = $('input[name=end_date]').val();
                        d.update_start = $('#updateStart').val(),
                        d.update_end = $('#updateEnd').val(),
                        d.agents = $('#agents').val();
                        d.departments = $('#departments').val();
                        d.sources = $('#sources').val();
                        d.priorities = $('#priorities').val();
                        d.clients = $('#clients').val();
                        d.types = $('#types').val();
                        d.status = $('#status').val();
                        d.helptopic = $('#helptopic').val();
                        d.team = $('#team').val();
                    },
                    dataSrc: function ( json ) {
                        for(var h in customLabel){
                            for(var a in json.data){
                                if(json.data[a].formdata.length > 0){
                                    for(var k in json.data[a].formdata){
                                        if(json.data[a].formdata[k].key == customLabel[h].field){
                                            json.data[a][customLabel[h].label] = json.data[a].formdata[k].content;
                                            break;
                                        } else {
                                            json.data[a][customLabel[h].label] = '';
                                        }
                                    }
                                } else {
                                    json.data[a][customLabel[h].label] = '';
                                }
                            }
                        }
                        return json.data;
                    }
                },
                oLanguage: {
                    "sLengthMenu": "_MENU_ Show  entries",
                    "sSearch"    : "Search: ",
                    "sProcessing": '<img id="blur-bg" class="backgroundfadein" style="top:40%;left:50%; width: 50px; height:50 px; display: block; position:    fixed;" src="{!! assetLink("image","gifloader3") !!}">'
                },
                columns: getAllColumn(),
                fnDrawCallback: function( oSettings ) { 
                    hideEmptyCols($('#users-table'))
                    $("#tag-table").css({"opacity": "1"});
                    $('.loader').css('display', 'none');
                },
                fnPreDrawCallback: function(oSettings, json) {
                    $('.loader').css('display', 'block');
                    $("#tag-table").css({"opacity":"0.3"});
                    $('#blur-bg').css({"opacity": "0.7", "z-index": "99999"});
                },
                columnDefs: getColumnDef()
            });
            $('#submit-filter').on('click', function (e) {
                oTable.draw();
                e.preventDefault();
            });
        }
    });

    $(function(){
        $('.div1').css('width',$('.table').width());
        $(".wrapper1").scroll(function(){
            $(".wrapper2").scrollLeft($(".wrapper1").scrollLeft());
        });
        $(".wrapper2").scroll(function(){
          $(".wrapper1").scrollLeft($(".wrapper2").scrollLeft());
        });
        $('#exportBtn').click(function() {
            $.ajax({
                url: '{{ route('report.management.performance.export') }}',
                type: 'POST',
                data: $('#filter').serialize(),
            }).success(function(resp) {
                if (resp.status == 'success') {
                  $('.alert-success .success-msg').html(resp.message);
                  $('.alert-success').show();
                } else {
                  $('.alert-danger #get-danger').html(resp.message);
                  $('.alert-danger').show();
                }
                setInterval(function() {
                  $('.alert').slideUp(3000);
                }, 4000);
            });
        });
    }); 
</script>
@stop
