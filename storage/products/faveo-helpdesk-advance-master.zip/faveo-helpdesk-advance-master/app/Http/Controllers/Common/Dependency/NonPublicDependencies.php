<?php
namespace App\Http\Controllers\Common\Dependency;

use App\Http\Controllers\Controller;
use App\User;
use App\Model\helpdesk\Filters\Filter;
use App\Model\helpdesk\Manage\Sla\Sla_plan as SlaPlan;
use App\Model\helpdesk\Agent\Teams;
use App\Model\helpdesk\Agent\Department;
use App\Model\helpdesk\Filters\Label;
use App\Model\helpdesk\Filters\Tag;
use App\Traits\EnhancedDependency;
use App\Model\helpdesk\Workflow\ApprovalWorkflow;
use App\Model\helpdesk\Email\Emails as SystemEmail;

/**
 * Contains dependencies which are only accessed by admin or agent.
 * @author avinash kumar <avinash.kumar@ladybirdweb.com>
 */
class NonPublicDependencies extends Controller
{
    use EnhancedDependency;
    /**
     * @var string      Search String that is required to be searched
     */
    protected $searchQuery;

    /**
     * @var integer     Maximum number of rows that are required
     */
    protected $limit;

    /**
     * @var string      Role of the user (admin, agent, user)
     *                  It should be initialized in a way that if user is not logged in, its value should be 'user'
     */
    protected $userRole;

    /**
     * @var boolean     In most of the cases only few columns like 'id' and 'name' is required in the response,
     *                  but when more information is required other than 'id' and 'name', meta must be initialized as true
     *                  for eg. in case of ticket status, sometimes 'id' and 'name' of the status is enough but sometimes we need 'icon' and 'icon_color' also.
     *                  In that case $meta must be initialized as true, else false
     */
    protected $meta;

    /**
     * @var boolean     There are certain differences in data that is required in agent panel (for display purpose)  and in admin panel (for config purpose).
     *                  For eg. In ticket status, status like 'unapproved' is not required in agent panel but required in admin panel irrespective of
     *                  user being an admin. In that case $config must initialized as true, else false.
     *                  Also, when meta is passed as true, all the fields in the DB will be returned irrespective of value of $meta
     *                  because it is required in admin panel for configuration purpose
     */
    protected $config;

    /**
     *@var Array        When we need to call the methods avaible in EnhancedDependency trait to update or modify list data based on specail conditions
     *
     */
    protected $supplements;

    /**
     * Gets non-public dependency data according to the value of $type
     * @param string $type      Dependency type (like help-topics, priorities etc)
     * @return array|boolean    Array of dependency data on success, false on failure
     */
    protected function handleNonPublicDependencies($type)
    {
        switch ($type) {

            //non-public dependencies
            case 'sla-plans':
                return $this->slaPlans();

            case 'agents':
                return $this->agents();

            case 'teams':
                return $this->teams();

            case 'agents-teams':
                return $this->agentsAndTeams();

            case 'labels':
                return $this->labels();

            case 'tags':
                return $this->tags();

            case 'departments':
                return $this->departments();

            case 'approval-workflows':
                return $this->approvalWorkflows();

            case 'users-including-system-email':
                return $this->getUsersIncludingSystemEmail();

            default:
                return false;
        }
    }

    /**
     * Gets list of available sla-plans
     * @return array    List of available sla plans
     */
    protected function slaPlans()
    {
        //only an agent or admin should be able to access this
        if ($this->userRole == 'user') {
            return false;
        }

        $baseQuery = SlaPlan::where('name', 'LIKE', "%$this->searchQuery%");

        if (!$this->config) {
            $baseQuery = $baseQuery->where('status', 1)->select('id', 'name');
        }

        $slaPlans = $baseQuery->orderBy('updated_at','DESC')->take($this->limit)->get();
        return ['sla_plans' => $slaPlans];
    }

    /**
     * Gets list of agents with necessary fields.
     * @return array    list of agents/admin
     */
    protected function agents()
    {
        if ($this->userRole == 'user') {
            return false;
        }

        $roles = ['agent', 'admin'];
        $agents = $this->getUsersByRoles($roles);
        return ['agents' => $agents];
    }

    /**
     * Gets list of teams with necessary fields.
     * @return array  list of teams
     */
    protected function teams()
    {
        if ($this->userRole == 'user') {
            return false;
        }
        $baseQuery = Teams::has('agents')->where('name', 'LIKE', "%$this->searchQuery%");

        if (!$this->config) {
            $baseQuery = $baseQuery->where('status', 1)->select('id', 'name');
        }
        $teams = $baseQuery->orderBy('updated_at','DESC')->take($this->limit)->get();
        return ['teams' => $teams];
    }

    /**
     * Gets list of people and teams to whom a ticket can be assigned with necessary fields.
     * @return array list of agents/admin and teams
     */
    protected function agentsAndTeams()
    {
        if ($this->userRole == 'user') {
            return false;
        }
        $agents = $this->agents();
        $teams = $this->teams();

        return array_merge($agents, $teams);
    }

    /**
     * NOTE: test cases are pending
     * Gets list of labels
     * @return array  list of labels
     */
    protected function labels()
    {
        if ($this->userRole == 'user') {
            return false;
        }
        $labelQuery = Label::where('status',1)->select('id','title','color');
        if($this->meta){
            $labelQuery->addSelect('color');
        }
        $labels = $labelQuery->orderBy('updated_at','DESC')->get();
        foreach($labels as $label){
            $label['name'] = $label['title'];
            unset($label['title']);
        }
        return ['labels' => $labels];
    }

    /**
     * Gets list of tags
     * @return array list of tags
     */
    protected function tags()
    {
        if ($this->userRole == 'user') {
            return false;
        }
        $tags = Tag::select('id','name')->orderBy('updated_at','DESC')->get();
        return ['tags' => $tags];
    }

    /**
     * Gets list of departments
     * @return array list of departments
     */
    protected function departments()
    {
        if ($this->userRole == 'user') {
            return false;
        }

        $baseQuery = Department::where('name', 'LIKE', "%$this->searchQuery%");
        if (!$this->config) {
            $baseQuery = $baseQuery->orderBy('name')->select('id', 'name');
        }
        $departments = $baseQuery->orderBy('updated_at','DESC')->take($this->limit)->get();
        return ['departments' => $departments];
    }

    /**
     * Gets list of users
     * @param array $roles      Array of roles according to which users has to be fetched.
     *                          for eg. for fetching all users $roles will be ['user','agent','admin']
     * @return array            List of users
     */
    protected function getUsersByRoles($roles)
    {
        $searchQuery = $this->searchQuery;
        $baseQuery = User::where('ban', '!=', 1)->where('active', 1)
            ->where('is_delete', '!=', 1)->whereIn('role', $roles)
            ->where(function($q) use ($searchQuery) {
            $q->where('first_name', 'LIKE', "%$searchQuery%")
            ->orWhere('last_name', 'LIKE', "%$searchQuery%")
            ->orWhere('user_name', 'LIKE', "%$searchQuery%");
        });


        if (!$this->config) {
            $baseQuery = $baseQuery->select('id', 'first_name', 'last_name', 'user_name');
        }

        if ($this->meta) {
            //columns required must be added here
            $baseQuery->addSelect('email')->addSelect('profile_pic');
        }

        //if first name is null then sort by user name
        $users = $baseQuery->orderBy('updated_at','DESC')->take($this->limit)->get();

        foreach ($users as $user) {
            $user['name'] = $user['first_name'] ? $user['first_name'] . ' ' . $user['last_name'] : $user['user_name'];
            unset($user['first_name'], $user['last_name'], $user['user_name']);
        }

        if($this->supplements){
          $this->appendSystemEmailToResult($users);
        }

        return $users;
    }

    /**
     * Appends system email to normal result
     * @param  Collection &$users array of users to which results has to be appended
     * @return null
     */
    private function appendSystemEmailToResult(&$users)
    {
        $systemMails = SystemEmail::where('email_address','LIKE',"%$this->searchQuery%")
          ->select('id','email_address as email','email_name as name')
          ->orderBy('updated_at','DESC')
          ->take($this->limit)
          ->get();

        foreach ($systemMails as $systemMail) {
          $systemMail->profile_pic = assetLink('image','system');
          $users[] = $systemMail;
        }
    }

    protected function approvalWorkflows(){

      //only an agent or admin should be able to access this
      if ($this->userRole == 'user') {
          return false;
      }

      $baseQuery = ApprovalWorkflow::where('name', 'LIKE', "%$this->searchQuery%");

      if (!$this->config) {
          $baseQuery = $baseQuery->select('id','name');
      }

      $approvalWorkflows = $baseQuery->orderBy('updated_at','DESC')->take($this->limit)->get();
      return ['approval_workflows' => $approvalWorkflows];
    }
}
