<?php

namespace App\Http\ViewComposers;

use Illuminate\View\View;
use App\Model\helpdesk\Settings\Company;
use Auth;
use App\User;
use App\Model\helpdesk\Ticket\Tickets;
use App\Model\helpdesk\Agent\Department;
use App\Model\helpdesk\Settings\Approval;
use App\Model\helpdesk\Email\Emails;
use App\Model\helpdesk\Agent\DepartmentAssignAgents;
use App\Model\helpdesk\Settings\CommonSettings;
use App\Http\Controllers\Agent\helpdesk\TicketsView\TicketsCategoryController;

class AgentLayout extends TicketsCategoryController{

    /**
     * The user repository implementation.
     *
     * @var UserRepository
     */
    protected $company;
    protected $users;
    protected $tickets;
    protected $department;
    protected $emails;

    /**
     * Create a new profile composer.
     *
     * @param
     * @return void
     */
    public function __construct(Company $company, User $users, Tickets $tickets, Department $department, Approval $approval, Emails $emails, CommonSettings $common_settings) {
        $this->company = $company;
        $this->auth = Auth::user();
        $this->users = $users;
        $this->tickets = $tickets;
        $this->department = $department;
        $this->approval = $approval;
        $this->emails = $emails;
        $this->common_settings = $common_settings;
    }

    /**
     * Bind data to the view.
     *
     * @param  View  $view
     * @return void
     */
    public function compose(View $view) {
        $view->with([
            'company' => $this->company,
            //'notifications' => $notifications,
            'myticket' => $this->myTicketsQuery(),
            'unassigned' => $this->unassignedQuery(),
            'followup_ticket' => $this->followupTicketQuery(),
            'closingapproval' => $this->closingApprovalQuery(),
            'closed' => $this->closedQuery(),
            'deleted' => $this->deletedQuery(),
            'tickets' => $this->inboxQuery(),
            'overdues' => $this->overdueTicketsQuery(),
            'unapproved' => $this->unapprovedQuery(),
            'waiting_for_approval' => $this->waitingForApprovalQuery(),
            'approval_enable' => $this->getApprovalEnableOrNot(),
            'due_today' => $this->dueTodayTicketsQuery(),
            'is_mail_conigured' => $this->getEmailConfig(),
            'dummy_installation' => $this->getDummyDataInstallation(),
            'ticket_policy' => new \App\Policies\TicketPolicy(),
            'spam'=>$this->spamQuery()
        ]);
    }

    public function users() {
        return $this->users->select('id', 'profile_pic');
    }

    public function tickets() {
        return $this->tickets->select('id', 'ticket_number');
    }

    public function getApprovalEnableOrNot() {
        return $this->approval->where('id', '=', 1)
                        ->select('status');
    }

    public function getDueToday() {
        $ticket = $this->tickets()
                ->Join('ticket_status', 'ticket_status.id', '=', 'tickets.status')
                ->Join('ticket_status_type', function ($join) {
            $join->on('ticket_status.purpose_of_status', '=', 'ticket_status_type.id')
            ->whereIn('ticket_status_type.name', ['open']);
        });
        if ($this->auth->role == 'admin') {
            return $ticket
                            ->where('isanswered', '=', 0)
                            ->whereNotNull('duedate')
                            ->whereRaw('date(duedate) = ?', [date('Y-m-d')]);
        } elseif ($this->auth->role == 'agent') {

            $ticket_policy = new \App\Policies\TicketPolicy();

            if ($ticket_policy->globalAccess()) {
                return $ticket
                                ->where('isanswered', '=', 0)
                                ->whereNotNull('duedate')
                                ->whereRaw('date(duedate) = ?', [date('Y-m-d')]);
            } else if ($ticket_policy->restrictedAccess()) {
                $ticket = $ticket
                        ->where('isanswered', '=', 0)
                        ->whereNotNull('duedate')
                        ->whereRaw('date(duedate) = ?', [date('Y-m-d')]);

                return $ticket->where('assigned_to', $this->auth->id);
            } else {
                $id = Auth::user()->id;
                $dept = DepartmentAssignAgents::where('agent_id', '=', $id)->pluck('department_id')->toArray();
                $ticket = $ticket->whereIn('tickets.dept_id', $dept);

                return $ticket->where('isanswered', '=', 0)
                                ->whereNotNull('tickets.duedate')
                                ->whereDate('tickets.duedate', '=', \Carbon\Carbon::now()->format('Y-m-d'));
            }
        }
    }

    /**
     * @category function to check configured mails
     * @param null
     * @var $emails
     * @return boolean true/false
     */
    public function getEmailConfig() {
        $emailForIncoming = $this->emails->select('id')->where('sending_status', '=', 1)->count();
        $emailForOutGoing = $this->emails->select('id')->where('fetching_status', '=', 1)->count();
        if ($emailForIncoming >= 1 && $emailForOutGoing >= 1) {
            return true;
        }
        return false;
    }

    /**
     * @category function to check if dummy data is installed in the system or not
     * @param null
     * @return builder
     */
    public function getDummyDataInstallation() {
        $return_collection = $this->common_settings->select('status')->where('option_name', '=', 'dummy_data_installation')->first();
        if (!$return_collection) {
            $return_collection = collect(['status' => 0]);
            return $return_collection['status'];
        }

        return $return_collection->status;
    }

}
