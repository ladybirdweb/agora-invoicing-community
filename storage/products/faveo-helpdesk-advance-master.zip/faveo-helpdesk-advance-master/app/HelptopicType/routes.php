<?php

    \Event::listen('settings.helptopic.link.types', function() {

        $set = new App\HelptopicType\Controllers\SettingsController();
        echo $set->settingsLink();
    });
   
  Route::group(['middleware' => ['web', 'auth']], function() {
  Route::get('helpdesk/helptopic-type/settings/status', ['as' => 'helpdesk.helptopic-type.settings', 'uses' => 'App\HelptopicType\Controllers\HelptopicType\HelptopicTypeController@index']);
  Route::post('helpdesk/helptopic-type', ['as' => 'helpdesk.helptopic-type', 'uses' => 'App\HelptopicType\Controllers\HelptopicType\HelptopicTypeController@settings']);
  Breadcrumbs::register('helpdesk.helptopic-type.settings', function ($breadcrumbs) {
                $breadcrumbs->parent('setting');
                $breadcrumbs->push(Lang::get('HelptopicType::lang.helptopic_type'), route('helpdesk.micro.organizarion'));
            });
 // Breadcrumbs::register('helpdesk.location.edit', function ($breadcrumbs) {
 //              $breadcrumbs->parent('setting');
 //              $breadcrumbs->push(Lang::get('lang.location'), route('helpdesk.location.index'));
 //              $breadcrumbs->push(Lang::get('lang.edit'), url('helpdesk/location-types/{id}/edit'));
 //              });

    });

     

