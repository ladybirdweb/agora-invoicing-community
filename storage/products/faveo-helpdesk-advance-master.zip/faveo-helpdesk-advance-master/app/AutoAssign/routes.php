<?php

\Event::listen('ticket.assign', function($event) {
    $dept_id = $event['department'];
    $type_id = $event['type'];
    $extra_field = $event['extra'];
    $assign = new \App\AutoAssign\Controllers\AssignController();
    return $assign->createTicket($dept_id,$type_id,$extra_field);
});
\Event::listen('user.logout', function() {
    $assign = new \App\AutoAssign\Controllers\Authenticate();
    $assign->logout();
});

\Event::listen('user.login', function() {
    $assign = new \App\AutoAssign\Controllers\Authenticate();
    $assign->login();
});

\Event::listen('settings.ticket.view', function() {
    $set = new App\AutoAssign\Controllers\SettingsController();
    echo $set->settingsView();
});

Route::group(['middleware' => ['web','auth','roles']], function() {
    Route::get('auto-assign', [
        'as' => 'auto.assign',
        'uses' => 'App\AutoAssign\Controllers\SettingsController@getSettings'
    ]);

    Route::post('auto-assign', [
        'as' => 'post.auto.assign',
        'uses' => 'App\AutoAssign\Controllers\SettingsController@postSettings'
    ]);
});

//Route::get('round', [
//    'as' => 'round',
//    'uses' => 'App\AutoAssign\Controllers\RoundRobin@tickets'
//]);
