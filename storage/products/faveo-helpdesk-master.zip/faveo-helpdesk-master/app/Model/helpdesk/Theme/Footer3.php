<?php

namespace App\Model\helpdesk\Theme;

use Illuminate\Database\Eloquent\Model;

class Footer3 extends Model
{
    protected $table = 'footer3';
    protected $fillable = ['title', 'footer'];
}
