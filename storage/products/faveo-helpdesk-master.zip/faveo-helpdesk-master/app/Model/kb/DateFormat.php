<?php

namespace App\Model\kb;

use App\BaseModel;

class DateFormat extends BaseModel
{
    protected $table = 'date_time_format';

    //protected $fillable = ['id', 'name', 'description', 'status', 'parent', 'created_at', 'updated_at'];
}
