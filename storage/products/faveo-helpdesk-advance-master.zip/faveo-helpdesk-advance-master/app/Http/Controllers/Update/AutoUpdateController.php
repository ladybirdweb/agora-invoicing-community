<?php

namespace App\Http\Controllers\Update;

use File;
use Artisan;
use Updater; //self Updater facede
use Exception;
use GuzzleHttp\Client;
use Illuminate\Http\Request;
use Illuminate\Database\Connection;
use Symfony\Component\Finder\Finder;
use App\Http\Controllers\Controller;
use App\Model\Update\BarNotification;
use App\Model\helpdesk\Settings\System;
use Codedge\Updater\Events\UpdateFailed;
use App\Http\Controllers\Utility\LibraryController;
use App\Http\Controllers\Update\SyncFaveoToLatestVersion;

/**
 * ---------------------------------------------------
 * AutoUpdateController
 * ---------------------------------------------------
 * This controller handles all the auto update functions
 *
 * @author      Ladybird <info@ladybirdweb.com>,  Abhishek Gurung <abhishek.gurung@ladybirdweb.com>
 * @author      Ladybird <info@ladybirdweb.com>,  Ashutosh Pathak <ashutosh.pathak@ladybirdweb.com>
 */

class AutoUpdateController extends Controller
{
    const GITHUB_API_URL = 'https://api.github.com';
    const NEW_VERSION_FILE = 'self-updater-new-version';

    protected $updater;
    protected $system;
    protected $client;

    public function __construct(Updater $updater, Client $client)
    {
        require_once("script/update_core_configuration.php");
        require_once("script/update_core_functions.php");
        $this->client = $client; //initialize guzzle client
        $this->updater = $updater; // initialize updater
        $this->system = System::first();
    }


    /**
     * check for updates.
     *
     * This function checks for update based on
     * product_order_number, serial_key and domain_name
     *
     */
    protected function checkForUpdates()
    {
        if (\Auth::user()->role != 'admin') {
            return view('themes.default1.admin.helpdesk.auto-updates.index');
        }
        if ($this->system->version == \Storage::get('self-updater-new-version')) {
            return view('themes.default1.admin.helpdesk.auto-updates.index')->with(['no_update' => "Sorry no update avaiable "]);
        }
        if (!$this->system->order_number || $this->system->serial_key != \DB::table('faveo_license')->pluck('LICENSE_CODE')->first()) {
            return redirect('update-order-details');
        }
        $data = [
            'order_number' => $this->system->order_number,
        ];
        $response = $this->checkUpdatesExpiry($data);
        $result =json_decode($response->getBody()->getContents());
        if ($result->status == "success") {
            $update_avaiable = true;
            return view('themes.default1.admin.helpdesk.auto-updates.index', compact('response', 'update_avaiable'));
        } else {
            return view('themes.default1.admin.helpdesk.auto-updates.index');
        }
    }

    private function checkUpdatesExpiry($data)
    {
        try {//Check from Billing if the Auto Updates have  expired
            $expiryCheck = $this->client->request(
                'POST',
                'https://billing.faveohelpdesk.com/v1/checkUpdatesExpiry',
                [
                'form_params' => $data
                ]
            );
            return $expiryCheck;
        } catch (\Exception $e) {
            return view('themes.default1.admin.helpdesk.auto-updates.index')->with(['error' => $e->getMessage()]);
        }
    }


    protected function downloadUpdate(Request $request)
    {
        if (\Event::fire('helpdesk.apply.whitelabel')) {
            return ['success' => false, "message" => "Update cannot be proceed due to whitelable enabled"];
        }
        set_time_limit(-1);
        \Cache::forget('progress-report');
        try {
            return ['success' => true, "message" => "Success"];
        } catch (Exception $e) {
            return ['success' => false, "message" => "Oops something went wrong. ".$e->getMessage()];
        }
    }

    protected function update(Request $request)
    {
        set_time_limit(0);
        \Config::set('app.debug', true);
         
        try {
           // Artisan::call('down');
            $response=ausDownloadFile();
            
            if ($response['notification_case']=="notification_operation_ok") { //'notification_operation_ok' case returned - operation succeeded
                $notify = BarNotification::where('key', 'new-version')->first();
                if ($notify) {
                    $notify->delete();
                }
                
             //   System::first()->update(['version'=> $request->input('update_version')]);
            //    Artisan::call('up');
                return ["success" => true, "message" => $response['notification_text']];
            } else {
              //  Artisan::call('up');
                return ["success" => false, "message" => "Oops something went wrong during update. ".$response['notification_text']];
            }
        } catch (\Exception $e) {
            //Artisan::call('up');
            return ["success" => false, "message" => "Oops something went wrong during update. ".$e->getMessage()];
        }
    }

    private function updatefaveodatabase($version)
    {
        System::first()->update([
            "version" => $version
        ]);
    }

    public function getOrderDetails()
    {
        return view('themes.default1.admin.helpdesk.auto-updates.order-details');
    }


    public function updateOrderDetails(Request $request)
    {
        $data = $request->except('_token');
        if ($this->system->update($data)) {
            return redirect('check-updates');
        }
    }



    public static function getLatestRelease()
    {
        if (empty(\Config::get('self-update.app_name'))) {
            throw new \Exception('No repository specified. Please enter a valid Github repository owner and name in your config.');
        } else {
            $client = new Client([]);
            $source = 'https://billing.faveohelpdesk.com/version/latest?title='.\Config::get('self-update.app_name');
            $response = $client->request(
                'GET',
                $source
            );
            
            $releaseCollection = collect(\GuzzleHttp\json_decode($response->getBody()));
            if ($releaseCollection->isEmpty()) {
                throw new \Exception('Cannot find a release to update. Please check the repository you\'re pulling from');
            }
            $release = 'v'.$releaseCollection['version'];
            \Storage::put(static::NEW_VERSION_FILE, $release);
        }
    }

    /*
    * Get the Domain/subdomain of the host
    * @params Get the system url
    * @returns string
    * @author Ashutosh Pathak <ashutosh.pathak@ladybirdweb.com>
    */
    private function get_domain($url)
    {
        $pieces = parse_url($url);
        $domain = isset($pieces['host']) ? $pieces['host'] : $pieces['path'];
        return $domain;
    }

    public function createBackUp()
    {
        set_time_limit(0);
        try {
            // dump(glob(base_path().DIRECTORY_SEPARATOR.'vendor'.DIRECTORY_SEPARATOR.'bin/*'));
            $path = glob(base_path().DIRECTORY_SEPARATOR.'vendor'.DIRECTORY_SEPARATOR.'bin/*');
           
            foreach ($path as $key => $value) {
                $info = new \SplFileInfo($value);
                if (!$info->getExtension()) {
                    unlink($value);
                }
            }
            

            if (File::isDirectory(base_path().'/back-up')) {
                File::deleteDirectory((base_path().'/back-up'));
                sleep(10);
            }

            $dirs = collect(File::directories(base_path(), true)); //getting all the directories for backup
            foreach ($dirs as $key => $value) {
                if (($value == base_path().DIRECTORY_SEPARATOR.'back-up') || ($value == base_path().DIRECTORY_SEPARATOR.'new-release')) {
                    $dirs->forget($key);
                } //Excluding back-up folder
            }
            
            File::makeDirectory(base_path().'/back-up', 493, true, true);
            foreach ($dirs as $key => $value) {
                if (($value != base_path().DIRECTORY_SEPARATOR.'backup') || ($value != base_path().DIRECTORY_SEPARATOR.'new-release')) {
                    File::copyDirectory($value, base_path().DIRECTORY_SEPARATOR.'back-up'.DIRECTORY_SEPARATOR.basename($value));
                } // copying all directories in back-up folder
            }

            $files = collect(File::files(base_path())); //get all files from base_path
            foreach ($files as $key => $value) {
                File::copy($value->getRealPath(), base_path().DIRECTORY_SEPARATOR.'back-up'.DIRECTORY_SEPARATOR.$value->getfilename());
            }

            return ["success" => true, "message" => "back-up created successfully" ];
        } catch (\Exception $e) {
            return ["success" => false, "message" => $e->getMessage()];
        }
    }

    public function checkBackUp()
    {
        try {
            if (File::isDirectory(base_path().DIRECTORY_SEPARATOR.'back-up')) {
                $back_up = stat(base_path().DIRECTORY_SEPARATOR.'back-up');
                $back_up['created_at'] = \Carbon\Carbon::createFromTimestamp($back_up["mtime"]);
                $date = $back_up['created_at'];
                $date->setTimezone($this->system->time_zone);
                return ["success" => true, "message" => "back-up exists", "created_at" => $date->format('D d-M-Y h:i:a') ];
            }
            return ["success" => false, "message" => "back-up does not exists"];
        } catch (\Exception $e) {
            return ["success" => false, "message" => "something went wrong. Please try again"];
        }
    }

    // Functon to restore from backup
    public function restoreBackUp()
    {
        \Session::forget('restore-progress');
        $back_up_size = $this->getDirSize(base_path('/back-up'));

        try {
            $dirs = collect(File::directories(base_path('/back-up'), true)); //getting all the directories from backup
            foreach ($dirs as $key => $value) {
                if ($value == base_path().'/back-up') {
                    $dirs->forget($key);
                } //Excluding back-up folder
            }
            
            File::makeDirectory(base_path().'/', 493, true, true);
            File::makeDirectory(base_path().'/test-progress', 493, true, true);
            foreach ($dirs as $key => $value) {
                File::copyDirectory($value, base_path().'/'.basename($value)); // copying all directories from back-up folder
                File::copyDirectory($value, base_path().'/test-progress/'.basename($value));
                // setting progress report
                $progress_size = $this->getDirSize(base_path().'/test-progress');
                $restored = ($progress_size / $back_up_size) * 100;
                \Session::put('restore-progress', $restored);
                \Session::save();
            }
            
            $files = collect(File::files(base_path().'/back-up/')); //get all files from base_path
            foreach ($files as $key => $value) {
                File::copy($value->getRealPath(), base_path().'/test/'.$value->getfilename());
                File::copy($value->getRealPath(), base_path().'/test-progress/'.$value->getfilename());
                $progress_size = $this->getDirSize(base_path().'/test-progress');
                $restored = ($progress_size / $back_up_size) * 100;
                \Session::put('restore-progress', $restored);
                \Session::save();
            }
            \Artisan::call('up');
            File::deleteDirectory(base_path('test-progress'));
            return ["success" => true, "message" => "Successfully Restored form backup" ];
        } catch (\Exception $e) {
            return ["success" => false, "message" => $e->getMessage()];
        }
    }

    // function to check directory size
    private function getDirSize($path)
    {
        $file_size = 0;
        foreach (File::allFiles($path) as $file) {
            $file_size += $file->getSize();
        }
        $file_size = number_format($file_size /(1024*1024), 2);
        return $file_size;
    }


    public function deleteBackUp()
    {
        if (File::isDirectory(base_path().DIRECTORY_SEPARATOR.'back-up')) {
            File::deleteDirectory((base_path().DIRECTORY_SEPARATOR.'back-up'));
            sleep(10);
            return ['success' => true, 'message' => 'backup removed successfully'];
        }
    }

    protected function updateDatabase(Connection $conn)
    {
        try {
            dump($latestConfigVersion,$latestVersion);
            $latestConfigVersion = \Config::get('app.tags');
            $latestVersion = \Storage::get('self-updater-new-version');
            if ($latestConfigVersion == $latestVersion) {
                (new SyncFaveoToLatestVersion)->sync();
                 return ["success" => true, "message" => "Application updated successfully"];
            }
            return ["success" => false, "message" => 'Faveo cannot be updated.Increase increase your memory limit and try.'];
           
        } catch (\Exception $ex) {
            return ["success" => false, "message" => 'Database cannot be updated'];
        }
        
        $query_directory = [];
        $installed_version = System::first()->version;
        switch ($conn->getDriverName()) {
            case "mysql":
                $directory_path = base_path().DIRECTORY_SEPARATOR."DB".DIRECTORY_SEPARATOR."mysql";
                $directories = collect(File::directories($directory_path));
                foreach ($directories as $key => $value) {
                    $getDir = str_replace($directory_path.DIRECTORY_SEPARATOR, '', $value);
                    if (version_compare($getDir, $installed_version, '>=')) {
                        array_push($query_directory, $getDir);
                    }
                }
                $query_executed = $this->executeQuery($query_directory, $directory_path);
                if ($query_executed == true) {
                    sleep(10);
                    \Log::info("query success");
                    return ["success" => true, "message" => "database updated successfully"];
                } else {
                    \Log::info("query failed");
                    \Log::info($query_executed);
                    return ["success" => false, "message" => $query_executed];
                }
                break;
        }
        // $directories = File::directories()
    }

    private function executeQuery($directories, $directory_path)
    {
        try {
            \Log::info("query executing now");
            \Log::info(count($directories)." directories are there");
            // dump($directories);
            foreach ($directories as $key => $value) {
                \Log::info("directories name:   ".$value);
                $files = collect(File::allFiles($directory_path.DIRECTORY_SEPARATOR.$value));
                \Log::info("query executing now with files");
                \Log::info(count($files)." files are there");
                foreach ($files as $key1 => $file) {
                    \Log::info("query executing now with inside");
                    \Log::info($file->getPath());
                    \Log::info($file->getFilename());
                    $file_content = file_get_contents($file->getPath().DIRECTORY_SEPARATOR.$file->getFilename());
                    $result = \DB::unprepared($file_content);
                    \Log::info($result);
                }
            }

            return true;
        } catch (\Exception $e) {
            \Log::info("Exception while updating database:   ".$e->getMessage());
            return false;
        }
    }
}
