<template>
	
	<div>
		
		<div class="box-container">
						
			<div class="box-header with-border with-switch">
						
				<h3 for="exception logs" id="exception_logs_title" class="box-title">{{lang('exception_logs')}}</h3>
						
			</div>

			<div class="box-body">
					
				<div class="row">
					
					<logs-table v-if="!options.length"
						:category_ids="category_ids" 
						:created_at_end="created_at_end"
						:created_at_start="created_at_start" 
						:columns="columns" :options="options" :apiUrl="apiUrl" id="exception_logs_title">
					</logs-table>
				</div>
			</div>
		</div>
	</div>
</template>

<script>

	import axios from 'axios';

	import { mapGetters } from 'vuex'
	
	export default {

		props : {

			category_ids : { type : Array, default : ()=>[] },

			created_at_start : { type : String, default : '' },

			created_at_end : { type : String, default : '' },
		},

		data() {

			return {

				columns : [],

				options : {},

				apiUrl : '/api/logs/exception' ,

				columns: ['category', 'file', 'line', 'message', 'trace', 'created_at'],

				options : {},
			}
		},

		beforeMount(){
			const self = this;
			this.options = {

				headings: { 

					category: 'Category', 

					file: 'File', 

					line:'Line',

					message: 'Message',
					
					trace: 'Trace',

					created_at: 'Created At'
				},

				columnsClasses : {

					category: 'log-category', 

					file: 'log-file', 

					line:'log-line',

					trace: 'log-trace',

					message: 'log-message',

					created_at: 'log-created'
				},

				texts: { filter: '', limit: '' },

				templates: {

					category(h,row){

						return row.category.name
					},

					created_at(h, row) {
						
						return self.formattedTime(row.created_at)
					},

					trace: 'logs-trace',
				},

				sortable:  ['category', 'file', 'line', 'trace', 'message', 'created_at'],

				filterable:  ['category', 'file', 'line', 'trace', 'message', 'created_at'],
				
				pagination:{chunk:5,nav: 'fixed',edge:true},

				requestAdapter(data) {

					return {
					
						sort_field: data.orderBy,
					
						sort_order: data.ascending ? 'desc' : 'asc',
					
						search_query:data.query,
					
						page:data.page,
					
						limit:data.limit,

					}
				},
				responseAdapter({data}) {
					return {
						
						data: data.data.data,

						count: data.data.total
					
					}
				},
			}
		},

		computed:{
			...mapGetters(['formattedTime','formattedDate'])
		},

		components : {

			'logs-table': require('./ReusableComponent/LogsTable.vue')
		}
	};
</script>

<style>
	
	.log-category{
		width:10% !important;
		word-break: break-word;
	}
	.log-file{
		width:30% !important;
		word-break: break-all;
	}
	.log-trace{
		width: 20% !important;
    	word-break: break-all;
	}
	.log-line{
		width: 8% !important;
    	word-break: break-all;
	}
	.log-created{
		width: 12% !important;
    	word-break: break-all;
	}
	.log-message{
		width:20% !important;
		word-break: break-all;
	}

</style>