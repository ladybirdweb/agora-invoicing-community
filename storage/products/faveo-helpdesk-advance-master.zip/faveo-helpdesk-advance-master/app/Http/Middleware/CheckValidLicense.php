<?php

namespace App\Http\Middleware;

use Closure;
use Schema;

class CheckValidLicense
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if (\App::environment() != 'production') {
        return $next($request);
       }
       $host = \Config::get('database.connections.mysql.host');
       $username = \Config::get('database.connections.mysql.username');
       $password = \Config::get('database.connections.mysql.password');
       $database = \Config::get('database.connections.mysql.database');

          // dump(env('DB_HOST'),env('DB_USERNAME'), env('DB_PASSWORD'),env('DB_DATABASE'));
        //verify license (Auto PHP Licenser will determine when connection to your server is needed)
        $GLOBALS["mysqli"] = mysqli_connect($host,$username, $password,$database); 
        //establish connection to MySQL database
          if (!Schema::hasTable('faveo_license')) {
            Schema::create('faveo_license', function ($table) {
                    $table->increments('SETTING_ID');
          });
             \DB::table('faveo_license')->insert(['SETTING_ID'=>'1']);
        }
         $license_notifications_array=  aplVerifyLicense($GLOBALS["mysqli"]);
        if ($license_notifications_array['notification_case']=="notification_license_ok") //'notification_license_ok' case returned - operation succeeded
      {
          return $next($request);
      } else {
          return redirect('licenseError');
       }
       
    }
}
