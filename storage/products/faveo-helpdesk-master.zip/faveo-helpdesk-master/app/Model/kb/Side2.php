<?php

namespace App\Model\kb;

use App\BaseModel;

class Side2 extends BaseModel
{
    protected $table = 'side2';
    protected $fillable = ['title', 'content'];
}
