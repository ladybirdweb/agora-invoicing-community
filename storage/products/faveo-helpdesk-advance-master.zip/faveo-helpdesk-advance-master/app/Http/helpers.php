<?php

/**
 * log the actions in log files
 * @param string $context
 * @param string $message
 * @param string $level
 * @param array $array
 */
function loging($context, $message, $level = 'error', $array = [])
{

    \Log::$level($message . ":-:-:-" . $context, $array);
}
/**
 * find a key exists in an array
 * @param string $key
 * @param array $array
 * @return string
 */
function checkArray($key, $array)
{
    $value = "";
    if (is_array($array) && array_key_exists($key, $array)) {
        $value = $array[$key];
    }
    return $value;
}
/**
 * get the image type
 * @param string $type
 * @return string
 */
function mime($type)
{
    if ($type == 'jpg' ||
            $type == 'png' ||
            $type == 'PNG' ||
            $type == 'JPG' ||
            $type == 'jpeg' ||
            $type == 'JPEG' ||
            $type == 'gif' ||
            $type == 'GIF' ||
            $type == 'image/jpeg' ||
            $type == 'image/jpg' ||
            $type == 'image/gif' ||
            $type == "application/octet-stream" ||
            $type == "image/png" ||
            starts_with($type, 'image')) {
        return "image";
    }
}
/**
 * remove underscore of the string
 * @param string $string
 * @return string
 */
function removeUnderscore($string)
{
    if (str_contains($string, '_') === true) {
        $string = str_replace('_', ' ', $string);
    }
    return ucfirst($string);
}
/**
 * check itil module on/off
 * @return boolean
 */
function isItil()
{
    $check = false;
    if (\Schema::hasTable('sd_releases') && \Schema::hasTable('sd_changes') && \Schema::hasTable('sd_problem')) {
        $check = true;
    }
    return $check;
}
/**
 * check asset module on/off
 * @return boolean
 */
function isAsset()
{
    $check = false;
    if (view()->exists('service::assets.index')) {
        $check = true;
    }
    return $check;
}
/**
 * check the itil enable
 * @return boolean
 */
function itilEnabled()
{
    $check = false;
    if (\Schema::hasTable('common_settings')) {
        $settings = \DB::table('common_settings')->where('option_name', 'itil')->first();
        if ($settings && $settings->status == 1) {
            $check = true;
        }
    }
    return $check;
}
/**
 * check bill module enables
 * @return boolean
 */
function isBill()
{
    $check = false;
    if (\Schema::hasTable('common_settings')) {
        $settings = \DB::table('common_settings')->where('option_name', 'bill')->first();
        if ($settings && $settings->status == 1) {
            $check = true;
        }
    }
    return $check;
}

/**
 * check time track module enables
 * @return boolean
 */
function isTimeTrack()
{
    $check = false;
    if (\Schema::hasTable('common_settings')) {
        $settings = \DB::table('common_settings')->where('option_name', 'time_track')->first();
        if ($settings && $settings->status == 1) {
            $check = true;
        }
    }
    return $check;
}

/**
 * check cron url on/off
 * @return boolean
 */
function isCronUrl()
{
    $check    = false;
    $settings = \DB::table('common_settings')->where('option_name', 'cron_url')->first();
    if ($settings && $settings->status == 1) {
        $check = true;
    }

    return $check;
}
/**
 * render the html for delete popup
 * @param mixed $id
 * @param string $url
 * @param string $title
 * @param string $class
 * @param string $btn_name
 * @param string $button_check
 * @return string
 */
function deletePopUp($id, $url, $title = "Delete", $class = "btn btn-primary btn-xs", $btn_name
= "Delete", $button_check = true)
{
    $button = "";
    if ($button_check == true) {
        $button = '<a href="#delete" class="' . $class . '" data-toggle="modal" data-target="#delete' . $id . '"><i class="fa fa-trash" style="color:white;">&nbsp;&nbsp;</i>' . $btn_name . '</a>&nbsp;&nbsp;';
    }
    return $button . '<div class="modal fade" id="delete' . $id . '">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                <h4 class="modal-title">' . $title . '</h4>
                            </div>
                            <div class="modal-body">
                                <div class="row">
                                <div class="col-md-12">
                                <p>Are you sure ?</p>
                                </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" id="close" class="btn btn-default pull-left" data-dismiss="modal"><i class="fa fa-times" aria-hidden="true">&nbsp;&nbsp;</i>'.Lang::get('lang.close').'</button>
                                <a href="' . $url . '" class="btn btn-danger" onclick="clickAndDisable(this);"><i class="fa fa-trash">&nbsp;&nbsp;</i>'.Lang::get('lang.delete').'</a>
                            </div>
                        </div>
                    </div>
                </div><script>
   function clickAndDisable(link) {
     // disable subsequent clicks
     link.onclick = function(event) {
        event.preventDefault();
     }
   }
</script>';
}
/**
 * check installed
 * @return boolean
 */
function isInstall()
{
    $check = false;
    $env   = base_path('.env');
    if (\File::exists($env) && \Config::get('database.install') == 1) {
        $check = true;
    }
    return $check;
}
/**
 *
 * @param string $date
 * @param integer $hour
 * @param integer $min
 * @param integer $sec
 * @param string $tz
 * @return \Carbon\Carbon
 */
function faveotime($date, $hour = 0, $min = 0, $sec = 0, $tz = "")
{
    if (is_bool($hour) && $hour == true) {
        $hour = $date->hour;
    }
    if (is_bool($min) && $min == true) {
        $min = $date->minute;
    }
    if (is_bool($sec) && $sec == true) {
        $sec = $date->second;
    }
    if (!$tz) {
        $tz = timezone();
    }
    $date1 = \Carbon\Carbon::create($date->year, $date->month, $date->day, $hour, $min, $sec, $tz);
    return $date1->hour($hour)->minute($min)->second($sec);
}
/**
 *
 * @param array $array
 * @return int
 */
function sla($array = [], $actions = 'create', $ticketId=0)
{
    $userid         = checkArray('user_id', $array);
    $type           = checkArray('type', $array);
    $department     = checkArray('department', $array);
    $source         = checkArray('source', $array);
    $priority       = checkArray('priority', $array);
    $helptopic      = checkArray('helptopic', $array);
    $label          = checkArray('label', $array);
    $tag            = checkArray('tag', $array);
    $org_department = NULL;
    $company        = NULL;
    $custom         = ($actions == 'create') ? \Config::get('app.custom-fields') : getCustomFieldsOfTickets($ticketId, ['key', 'content'], true);
    if ($userid) {
        $companyArray = App\Model\helpdesk\Agent_panel\User_org::where('user_id', $userid)->select('org_id', 'org_department')->get()->toArray();
        if (!empty($companyArray)) {
            $filteredCompanyArray = [];
            foreach ($companyArray as $value) {
                foreach ($value as $key2 => $value2) {
                    if ((!(strlen($value2) > 0 && strlen(trim($value2)) == 0) && $value2 != null)) $filteredCompanyArray[$key2][] = $value2;
                }
            }
            if (isMicroOrg() && array_key_exists('org_department', $filteredCompanyArray)) {
                $org_department = $filteredCompanyArray['org_department'];
            }
            $company = $filteredCompanyArray['org_id'];
        }
    }
    $slaid = "";
    $slaConditionCheck = slaCondition();
    if ($slaConditionCheck == 'any') {
        $slaid = slaAny($type, $department, $source, $company, $helptopic, $org_department, $label, $tag, $priority, $custom);
    } else {
        $slaid = slaAll($type, $department, $source, $company, $helptopic, $org_department, $label, $tag, $priority, $custom);
    }
    if ($slaid) {
        return $slaid;
    }
    else {
        $sla_value = \App\Model\helpdesk\Manage\Sla\Sla_plan::
                where('status', 1)
                ->orderBy('order')
                ->join('sla_targets', function ($join) use ($priority) {
                    return $join->on('sla_plan.id', '=', 'sla_targets.sla_id')
                            ->where('sla_targets.priority_id', '=', $priority);
                })
                ->first();
        if ($sla_value) {
            return $sla_value->id;
        }
    }
    $default = \App\Model\helpdesk\Manage\Sla\Sla_plan::where('status', 1)
            ->where('is_default', 1)
            ->first();
    if ($default) {
        return $default->id;
    }
}
function slaAll($type, $department, $source, $company, $helptopic, $org_department, $label, $tag, $priority, $custom)
{
    $array     = [
        'apply_sla_depertment'   => $department,
        'apply_sla_company'      => $company,
        'apply_sla_tickettype'   => $type,
        'apply_sla_ticketsource' => $source,
        'apply_sla_helptopic'    => $helptopic,
        'apply_sla_orgdepts'     => $org_department,
        'apply_sla_labels'       => $label,
        'apply_sla_tags'         => $tag,
    ];
    $sla_array = \App\Model\helpdesk\Manage\Sla\Sla_plan::
            where('status', 1)
            ->orderBy('order')
            ->join('sla_targets', function ($join) use ($priority) {
                return $join->on('sla_plan.id', '=', 'sla_targets.sla_id')
                        ->where('sla_targets.priority_id', '=', $priority);
            })
            ->select('sla_plan.id', 'apply_sla_depertment', 'apply_sla_company', 'apply_sla_tickettype', 'apply_sla_ticketsource', 'apply_sla_helptopic', 'apply_sla_orgdepts', 'apply_sla_labels', 'apply_sla_tags')
            ->get()
            ->toArray()
    ;
    $va   = [];
    $slas = collect($sla_array)->keyBy('id');
    if ($slas) {
        foreach ($slas as $key => $sla) {
            array_forget($sla, 'id');
            $va[$key] = array_filter($sla);
        }
    }
    if ($va) {
        $values = array_filter($va);
        if(empty($values)) return checkSLAForCustomValues($va, $custom);
        foreach ($values as $slaId => $value) {
            if (is_array($value)) {
                $check = [];
                foreach ($value as $k => $v) {
                    $check[] = checkEnforcement($k, $v, $array);
                }
                customFieldsSLAEnforcementsAll($slaId, $value, $check, $custom);
                $counts = array_count_values($check);
                if (checkArray(1, $counts)) {
                    if (count($value) == $counts[1]) {
                        return $slaId;
                    }
                }
            }
        }
    }
}
function checkSLAForCustomValues($slaArray, $custom)
{
    foreach ($slaArray as $slaId => $value) {
        $check = [];
        $value = [];
        customFieldsSLAEnforcementsAll($slaId, $value, $check, $custom);
        if(!empty($check) && $check[0] == 1) return $slaId;
    }
}

function checkEnforcement($enforce, $enforce_value, $array)
{
    $check = 0;
    if ((($enforce == 'apply_sla_labels') || ($enforce == 'apply_sla_tags')) && (checkArray($enforce, $array) != '' || checkArray($enforce, $array) != null)) {
        if(count(checkArray($enforce, $array)) >= count($enforce_value)) {
            if(count(array_intersect(checkArray($enforce, $array), $enforce_value)) == count($enforce_value)) {
                $check = 1;
            }
        }
    } elseif (($enforce == 'apply_sla_company' || $enforce == 'apply_sla_orgdepts')  && (checkArray($enforce, $array) != '' || checkArray($enforce, $array) != null)) {
        if (count(array_intersect(checkArray($enforce, $array), $enforce_value)) >= 1) {
            $check = 1;
        }
    } elseif (in_array(checkArray($enforce, $array), $enforce_value)) {
        $check = 1;
    }
    return $check;
}
function slaAny($type, $department, $source, $company, $helptopic, $org_department, $label, $tag, $priority, $custom)
{
    $sla = \App\Model\helpdesk\Manage\Sla\Sla_plan::
            where('status', 1)
            ->orderBy('order')
            ->join('sla_targets', function ($join) use ($priority) {
                return $join->on('sla_plan.id', '=', 'sla_targets.sla_id')
                        ->where('sla_targets.priority_id', '=', $priority);
            })
            ->where(function($query)use($type, $department, $source, $company, $helptopic, $org_department, $label, $tag, $custom) {
        $query
        ->where(function($query)use($type, $department, $source, $company, $helptopic, $org_department, $label, $tag, $custom) {
            $query
            ->when($type, function($query)use($type) {
                $query->orWhereRaw("find_in_set($type, apply_sla_tickettype)");
            })
            ->when($department, function($query)use($department) {
                $query->orWhereRaw("find_in_set($department, apply_sla_depertment)");
            })
            ->when($source, function($query)use($source) {
                $query->orWhereRaw("find_in_set($source, apply_sla_ticketsource)");
            })
            ->when($company, function($query)use($company) {
                if ($company != '' || $company != null) {
                    foreach ($company as $company_string) {
                        $query->orWhereRaw("find_in_set($company_string, apply_sla_company)");
                    }
                }
            })
            ->when($helptopic, function($query)use($helptopic) {
                $query->orWhereRaw("find_in_set($helptopic, apply_sla_helptopic)");
            })
            ->when($org_department, function($query)use($org_department) {
                if ($org_department != '' || $org_department != null) {
                    foreach ($org_department as $org_department_string) {
                        $query->orWhereRaw("find_in_set($org_department_string, apply_sla_orgdepts)");
                    }
                }
            })
            ->when($label, function($query)use($label) {
                if($label != '' || $label != null) {
                    foreach ($label as $label_string) {
                        $query->orWhereRaw("find_in_set('$label_string', apply_sla_labels)");
                    }
                }
            })
            ->when($tag, function($query)use($tag) {
                if($tag != '' || $tag != null) {
                    foreach ($tag as $tag_string) {
                        $query->orWhereRaw("find_in_set('$tag_string', apply_sla_tags)");
                    }
                }
            })
            ->when($custom, function($query) use($custom){
                if(!empty($custom)) {
                    $customId = App\Model\helpdesk\Manage\Sla\SlaCustomEnforcements::whereIn('f_name', array_keys($custom))->distinct('sla_id')->pluck('sla_id')->toArray();
                    $query->orWhere(function($query)use($customId){
                        $query->whereIn('sla_plan.id', $customId);
                    });
                }
            });
        });
    });
    $all = $sla->get();
    if ($all->count() > 0) {
        $collection = $all->mapWithKeys(function($value)use($type, $department, $source, $company, $helptopic, $org_department, $label, $tag, $custom) {
            $array = [$value->sla_id => 0];
            if (is_array($value->apply_sla_tickettype) && in_array($type, $value->apply_sla_tickettype)) {
                $array[$value->sla_id] ++;
            }
            if (is_array($value->apply_sla_depertment) && in_array($department, $value->apply_sla_depertment)) {
                $array[$value->sla_id] ++;
            }
            if (is_array($value->apply_sla_ticketsource) && in_array($source, $value->apply_sla_ticketsource)) {
                $array[$value->sla_id] ++;
            }
            if (is_array($value->apply_sla_company) && ($company != null || $company != '')) {
                $array[$value->sla_id] += count(array_intersect($company, $value->apply_sla_company));
            }
            if (is_array($value->apply_sla_helptopic) && in_array($helptopic, $value->apply_sla_helptopic)) {
                $array[$value->sla_id] ++;
            }
            if (is_array($value->apply_sla_orgdepts) && ($org_department != null || $org_department != '')) {
                $array[$value->sla_id] += count(array_intersect($org_department, $value->apply_sla_orgdepts));
            }
            if (is_array($value->apply_sla_labels) && ($label != null || $label != '')) {
                $array[$value->sla_id] += count(array_intersect($label, $value->apply_sla_labels));
            }
            if (is_array($value->apply_sla_tags) && ($tag != null || $tag != '')) {
                $array[$value->sla_id] += count(array_intersect($tag, $value->apply_sla_tags));
            }
            $array[$value->sla_id] += customFieldsSLAEnforcementsAny($value->sla_id, $custom);
            return $array;
        })
        ;
        $array = $collection->toArray();
        if ($array) {
            $maxs = array_keys($array, max($array));
            return $maxs[0];
        }
    }
}
/**
 * get carbon instance
 * @param string $date
 * @param string $glue
 * @param string $format
 * @param boolean $flag
 * @return \Carbon\Carbon
 */
function getCarbon($date, $glue = '-', $format = "Y-m-d", $flag = true)
{
    //dd($date,$glue);
    $parse = explode($glue, $date);
    if ($format == "Y-m-d") {
        $day   = $parse[2];
        $month = $parse[1];
        $year  = $parse[0];
    }

    if ($format == "m-d-Y") {
        $month = $parse[0];
        $day   = $parse[1];
        $year  = $parse[2];
    }

    $hour   = 0;
    $minute = 0;
    $second = 0;
    if ($format == "Y-m-d H:m:i") {
        $day   = $parse[2];
        $month = $parse[1];
        $year  = $parse[0];
    }
    if (!$flag) {
        $hour   = 23;
        $minute = 59;
        $second = 59;
    }
    $carbon = \Carbon\Carbon::create($year, $month, $day, $hour, $minute, $second);
    return $carbon;
}
/**
 * create carbon instance
 * @param string $date
 * @param string $tz
 * @param string $format
 * @return \Carbon\Carbon
 */
function createCarbon($date, $tz = "", $format = "")
{
    if (!$tz) {
        $tz = timezone();
    }
    if (!$format) {
        $format = dateformat();
    }
    return \Carbon\Carbon::parse($date)->tz($tz)->format($format);
}
/**
 * parse the carbon
 * @param string $date
 * @return \Carbon\Carbon
 */
function carbon($date)
{
    return \Carbon\Carbon::parse($date);
}
/**
 * get the priority from sla
 * @param integer $slaid
 * @return integer
 */
function priority($slaid)
{
    if ($slaid) {
        $sla         = new App\Http\Controllers\SLA\Sla($slaid);
        $priority_id = $sla->priority;
        return $priority_id;
    }
    else {
        $priority = App\Model\helpdesk\Ticket\Ticket_Priority::select('priority_id')->first();
        return $priority->priority_id;
    }
}
/**
 * get system timezone
 * @return string
 */
function timezone()
{
    if (\Auth::check()) {
        $auth_timezone = \Auth::user()->agent_tzone;
        if ($auth_timezone && !is_numeric($auth_timezone)) {
            return \Auth::user()->agent_tzone;
        }
    }
    $system = App\Model\helpdesk\Settings\System::select('time_zone')->first();
    $tz     = "UTC";
    if ($system) {
        $tz = $system->time_zone;
    }
    return $tz;
}
/**
 * get system date format
 * @return string
 */
function dateformat()
{
    $system = App\Model\helpdesk\Settings\System::select('date_time_format')->first();
    $format = "F j, Y, g:i a";
    if ($system) {
        $format = $system->date_time_format;
    }
    return $format;
}
/**
 * generate url with application url
 * @param string $route
 * @return string
 */
function faveoUrl($route)
{
    $url    = \Config::get('app.url');
    $system = App\Model\helpdesk\Settings\System::select('url')->first();
    if ($system && $system->url) {
        $url = $system->url;
    }
    if (!str_finish($url, '/')) {
        $url = $url . "/";
    }
    //dd($url."/".$route);
    return $url . "/" . $route;
}
/**
 * @category function to UTF encoding
 * @param string name
 * @return string name
 */
function utfEncoding($name)
{
    $title = "";
    $array = imap_mime_header_decode($name);
    if (is_array($array) && count($array) > 0) {
        if ($array[0]->charset != 'UTF-8') {
            $name = imap_utf8($name);
        }
        else {
            foreach ($array as $text) {
                $title .= $text->text;
            }
            $name = $title;
        }
    }
    if ((ord($name) >= 97 && ord($name) <= 122) || (ord($name) >= 65 && ord($name)
            <= 90)) {
        $name = ucfirst($name);
    }
    return $name;
}
/**
 * get the role of the user
 * @param integer $id
 * @return string
 */
function role($id)
{
    $user = \App\User::where('id', $id)->select('role')->first();
    if ($user) {
        return $user->role;
    }
}
/**
 * get the ticket title
 * @param integer $ticketid
 * @return string
 */
function title($ticketid)
{
    $thread = firstThread($ticketid);
    if ($thread) {
        return utfEncoding($thread->title);
    }
}
/**
 * get the requester of the ticket
 * @param integer $ticketid
 * @return integer
 */
function requester($ticketid)
{
    $ticket = ticket($ticketid);
    if ($ticket) {
        return $ticket->user_id;
    }
}
/**
 * get the thread
 * @param integer $threadid
 * @return \App\Model\helpdesk\Utility\Ticket_thread
 */
function thread($threadid)
{
    return App\Model\helpdesk\Utility\Ticket_thread::where('id', $threadid)
                    ->select('title', 'user_id', 'id', 'poster', 'is_internal')
                    ->first();
}
/**
 * get the poster
 * @param integer $threadid
 * @return string
 */
function poster($threadid)
{
    $thread = thread($threadid);
    if ($thread) {
        return $thread->poster;
    }
}
/**
 * get the type of the thread
 * @param integer $threadid
 * @return string
 */
function threadType($threadid)
{
    $thread = thread($threadid);
    if ($thread) {
        return $thread->thread_type;
    }
}
/**
 * get the last responder
 * @param integer $ticketid
 * @return mixed
 */
function lastResponder($ticketid)
{
    $thread = App\Model\helpdesk\Utility\Ticket_thread::where('ticket_id', $ticketid)
            ->whereNotNull('user_id')
            ->where('user_id', '')
            ->where('is_internal', 0)
            ->orderBy('id', 'desc')
            ->first();
    if ($thread) {
        return $thread->user_id;
    }
}
/**
 * get the ticket
 * @param integer $ticketid
 * @return \App\Model\helpdesk\Ticket\Tickets
 */
function ticket($ticketid)
{
    return App\Model\helpdesk\Ticket\Tickets::where('id', $ticketid)
                    ->select('user_id', 'assigned_to', 'sla', 'priority_id', 'dept_id', 'source', 'duedate')
                    ->first();
}
/**
 * get the first thread of the ticket
 * @param integer $ticketid
 * @return \App\Model\helpdesk\Utility\Ticket_thread
 */
function firstThread($ticketid)
{
    return App\Model\helpdesk\Utility\Ticket_thread::where('ticket_id', $ticketid)
                    ->whereNotNull('title')
                    ->where('title', '!=', '')
                    ->select('title', 'user_id', 'id', 'poster', 'is_internal')
                    ->orderBy('id')->first();
}
/**
 * get the last thread of the ticket
 * @param integer $ticketid
 * @return \App\Model\helpdesk\Utility\Ticket_thread
 */
function lastThread($ticketid)
{
    return App\Model\helpdesk\Utility\Ticket_thread::where('ticket_id', $ticketid)
                    ->orderBy('id', 'desc')
                    ->first();
}
/**
 * get the default source
 * @param integer $ticketid
 * @return string
 */
function source($ticketid)
{
    $ticket = ticket($ticketid);
    if ($ticket) {
        return $ticket->source;
    }
}
/**
 * get the duedate in utc
 * @param integer $ticketid
 * @return \Carbon\Carbon
 */
function dueDateUTC($ticketid)
{
    $ticket = ticket($ticketid);
    if ($ticket) {
        return $ticket->duedate;
    }
}
/**
 * get the duedate
 * @param integer $ticketid
 * @return \Carbon\Carbon
 */
function dueDate($ticketid)
{
    $ticket = ticket($ticketid);
    if ($ticket) {
        return $ticket->duedate->tz(timezone());
    }
}
/**
 * get the date from a string
 * @param string $str
 * @return string
 */
function getDateFromString($str)
{
    $reg   = '/\d{2}\/\d{2}\/\d{4}.\d{2}:\d{2}:\d{2}/';
    $match = preg_match($reg, $str, $matches);
    if (!$matches) {
        $reg   = '/\d{2}\-\d{2}\-\d{4}.\d{2}:\d{2}:\d{2}/';
        $match = preg_match($reg, $str, $matches);
    }
    if (!$matches) {
        $reg   = '/\d{2}\.\d{2}\.\d{4}.\d{2}:\d{2}:\d{2}/';
        $match = preg_match($reg, $str, $matches);
    }
    if (!$matches) {
        $reg   = '/\d{4}\.\d{2}\.\d{2}.\d{2}:\d{2}:\d{2}/';
        $match = preg_match($reg, $str, $matches);
    }
    if (!$matches) {
        $reg   = '/\d{4}\/\d{2}\/\d{2}.\d{2}:\d{2}:\d{2}/';
        $match = preg_match($reg, $str, $matches);
    }
    if (!$matches) {
        $reg   = '/\d{4}\-\d{2}\-\d{2}.\d{2}:\d{2}:\d{2}/';
        $match = preg_match($reg, $str, $matches);
    }
    if ($match) {
        $date   = checkArray(0, $matches);
        $carbon = carbon($date);
        return $carbon;
    }
}
/**
 * convert the string to hours
 * @param string $time
 * @param string $format
 * @return string
 */
function convertToHours($time, $format = '%02d:%02d')
{
    if ($time < 1) {
        return;
    }
    $hours   = floor($time / 60);
    $minutes = ($time % 60);
    return sprintf($format, $hours, $minutes);
}
/**
 * collapse the array
 * @param array $array
 * @return array
 */
function collapse($array)
{
    $arrays = [];
    if (count($array) > 0) {
        foreach ($array as $key => $value) {
            if (is_array($value)) {
                foreach ($value as $k => $v) {
                    if (!is_array($v)) {
                        $arrays[$k] = $v;
                    }
                }
            }
        }
    }
    return $arrays;
}
/**
 * delete the files
 * @param string $dir
 * @return mixed
 */
function delTree($dir)
{
    $files = array_diff(scandir($dir), array('.', '..'));
    foreach ($files as $file) {
        (is_dir("$dir/$file")) ? delTree("$dir/$file") : unlink("$dir/$file");
    }
    return rmdir($dir);
}
/**
 * get date into human readable formate
 * @param \Carbon\Carbon $carbon
 * @return string
 */
function humanReadingDate($carbon)
{
    //$now = \Carbon\Carbon::now()->tz(timezone());
    return $carbon->diffForHumans();
}
/**
 * return date into string format according to default timezone and format
 * @param mixed $date
 * @param string $format
 * @param string $tz
 * @return string
 */
function faveoDate($date = "", $format = "", $tz = "", $change_tz=true)
{
    if (!$date) {
        $date = \Carbon\Carbon::now();
    }
    if (!is_object($date)) {
        $date = carbon($date);
    }
    if (!$format || !$tz) {
        $system = App\Model\helpdesk\Settings\System::select('time_zone', 'date_time_format')->first();
    }
    if (!$format) {
        $format = $system->date_time_format;
    }
    if (!$tz) {
        $tz = timezone();
    }
    try {
        if($change_tz) {
            if ($format == "human-read") {
                return $date->tz($tz)->diffForHumans();
            }
            return $date->tz($tz)->format($format);
        } else {
            if ($format == "human-read") {
                return $date->diffForHumans();
            }
            return $date->format($format);
        }
    } catch (\Exception $ex) {
        return "invalid";
    }
}
/**
 * get the domain
 * @return string
 */
function domainUrl()
{
    return sprintf(
            "%s://%s", isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off' ? 'https'
                        : 'http', $_SERVER['SERVER_NAME']
    );
}
/**
 * get the ticket number of a ticket
 * @param integer $ticketid
 * @return integer
 */
function ticketNumber($ticketid)
{
    return App\Model\helpdesk\Ticket\Tickets::where('id', $ticketid)
                    ->select('ticket_number')
                    ->value('ticket_number');
}
/**
 * check a plugin is on/off
 * @param string $plugin
 * @return boolean
 */
function isPlugin($plugin = 'ServiceDesk')
{
    $plugin = \DB::table('plugins')->where('name', $plugin)->where('status', 1)->count();
    $check  = false;
    if ($plugin > 0) {
        $check = true;
    }
    return $check;
}
/**
 * get the default storage
 * @return string
 */
function storageDrive()
{
    $drive    = 'local';
    $settings = \DB::table('common_settings')->where('option_name', 'storage')
                    ->where('optional_field', 'default')->first();
    if ($settings && $settings->option_value) {
        $drive = $settings->option_value;
    }
    return $drive;
}
/**
 * get maximum file upload size
 * @staticvar integer $max_size
 * @return integer
 */
function file_upload_max_size()
{
    static $max_size = -1;

    if ($max_size < 0) {
        // Start with post_max_size.
        $max_size = parse_size(ini_get('post_max_size'));

        // If upload_max_size is less, then reduce. Except if upload_max_size is
        // zero, which indicates no limit.
        $upload_max = parse_size(ini_get('upload_max_filesize'));
        if ($upload_max > 0 && $upload_max < $max_size) {
            $max_size = $upload_max;
        }
    }
    return ($max_size / 1024) / 1024;
}
function parse_size($size)
{
    $unit = preg_replace('/[^bkmgtpezy]/i', '', $size); // Remove the non-unit characters from the size.
    $size = preg_replace('/[^0-9\.]/', '', $size); // Remove the non-numeric characters from the size.
    if ($unit) {
        // Find the position of the unit in the ordered string which is the power of magnitude to multiply a kilobyte by.
        return round($size * pow(1024, stripos('bkmgtpezy', $unit[0])));
    }
    else {
        return round($size);
    }
}
/**
 * @category funcion to get the value of account activation method
 * @param object of model CommonSettings : $settings
 * @var string $value
 * @return string $value: value of activation option fetched from DB
 */
function getAccountActivationOptionValue()
{
    $value = App\Model\helpdesk\Settings\CommonSettings::select('option_value')->where('option_name', '=', 'account_actvation_option')->first();
    return $value->option_value;
}
/**
 * @category Funcion to set validation rule for email
 * @param null
 * @return string : validation rule
 */
function getEmailValidation()
{
    $value           = getAccountActivationOptionValue();
    $email_mandatory = App\Model\helpdesk\Settings\CommonSettings::select('status')->where('option_name', '=', 'email_mandatory')->first();
    if ($value == 'email' || $value == 'email,mobile' || $email_mandatory->status
            == 1) {
        return 'required|max:50|email|unique:users,email';
    }
    else {
        return 'max:50|email|unique:users,email';
    }
}
/**
 * @category Funcion to set validation rule for mobile and code
 * @param string $field : name of field
 * @return string : validation rule
 */
function getMobileValidation($field)
{
    $value = getAccountActivationOptionValue();
    if (strpos($value, 'mobile') !== false) {
        return 'required|numeric|max:999999999999999|unique:users,mobile';
    }
    else {
        return 'numeric|max:999999999999999|unique:users,mobile';
    }
}
/**
 * get default department id
 * @return integer
 */
function defaultDepartmentId()
{
    $id     = "";
    $system = \App\Model\helpdesk\Settings\System::select('department')->first();
    if ($system) {
        $id = $system->department;
    }
    else {
        $department = App\Model\helpdesk\Agent\Department::select('id')->first();
        $id         = $department->id;
    }
    return $id;
}
function isMicroOrg()
{
    $check = false;
    if (\Schema::hasTable('common_settings')) {
        $settings = \DB::table('common_settings')->where('option_name', 'micro_organization_status')->first();
        if ($settings && $settings->status == 1) {
            $check = true;
        }
    }
    return $check;
}
/**
 * @category function to return array values if status id
 * @param string purpose of status
 * @return array ids of status with purpose passed as string
 */
function getStatusArray($status)
{
    $type   = new App\Model\helpdesk\Ticket\TicketStatusType();
    $values = $type->select('name', 'id')
            ->whereIn('name', [$status])
            ->with(['status' => function ($query) {
                    $query->select('id as status_id', 'name', 'purpose_of_status');
                }])
            ->get()
            ->pluck('status')
            ->flatten()
            ->pluck('status_id')
            ->toArray()
    ;
    return $values;
}
function isCustomMail()
{
    $check   = false;
    $drive   = config('mail.driver');
    $default = [
        'smtp'     => true,
        'mail'     => true,
        'sendmail' => true,
        'mailgun'  => true,
        'mandrill' => true,
        'log'      => true,
        'sparkpost'=>true,
        'ses'=>true,
        'stripe'=>true
    ];
    // dd($drive, $default);
    if (!checkArray($drive, $default)) {
        $check = true;
    }
    return $check;
}
function departmentByHelptopic($helptopic_id)
{
    $help_topic = \App\Model\helpdesk\Manage\Help_topic::where('id', '=', $helptopic_id)->select('department')->first();
    if ($help_topic) {
        $department_id = $help_topic->department;
    }
    else {
        $department_id = defaultDepartmentId();
    }
    return $department_id;
}
function commonSettings($option, $optionField, $returnColum = 'option_value')
{
    return \App\Model\helpdesk\Settings\CommonSettings::where('option_name', $option)
                    ->where('optional_field', $optionField)
                    ->value($returnColum);
}
/**
 * @category function to get GMT for system timezone
 * @param null
 * @var $system, $tz
 * @return string GMT value of timezone
 */
function getGMT($fetchId = false)
{
    $system = \App\Model\helpdesk\Settings\System::select('time_zone')->first();
    $tz     = \DB::table('timezone')->select('location', 'id')->where('name', '=', $system->time_zone)->first();
    if ($fetchId) {
        return $tz->id;
    }
    $tz = explode(")", substr($tz->location, stripos($tz->location, 'T') + 1));
    return $tz[0];
}
/**
 * get the default type id
 * @return int
 */
function defaultType()
{
    return App\Model\helpdesk\Manage\Tickettype::where('status', 1)
                    ->where('is_default', 1)
                    ->value('id');
}
function canRegister()
{
    $check  = true;
    $common = \App\Model\helpdesk\Settings\CommonSettings::where('option_name', 'user_registration')
            ->select('status')
            ->value('status');
    if ($common == 1) {
        $check = false;
    }
    return $check;
}
function array_keys_exists(array $keys, array $arr)
{
    foreach ($keys as $key) {
        if (array_key_exists($key, $arr)) {
            return true;
        }
    }
    return false;
}
function slaCondition()
{
    $codition = "all";
    $value    = commonSettings('sla_condition', '');
    if ($value) {
        $codition = $value;
    }
    return $codition;
}
function apiSettings($key)
{
    return \App\Model\Api\ApiSetting::where('key', $key)->value('value');
}

// For API response
/**
 * Format the error message into json error response
 *
 * @param string|array $message Error message
 * @param int $statusCode
 * @return HTTP json response
 */
function errorResponse($message, $statusCode = FAVEO_ERROR_CODE) {
    return response()->json(['success' => false, 'message' => $message], $statusCode);
}

/**
 * Format success message/data into json success response
 *
 * @param string $message Success message
 * @param array|string $data Data of the response
 * @param int $statusCode
 * @return HTTP json response
 */
function successResponse($message = '', $data = '', $statusCode = FAVEO_SUCCESS_CODE) {
    $response = ['success' => true];

    // if message given
    if (!empty($message)) {
        $response['message'] = $message;
    }

    // If data given
    if (!empty($data)) {
        $response['data'] = $data;
    }

    return response()->json($response, $statusCode);
}

/**
 * Format exception response with exception details
 *
 * @param instance $exception Exception instance
 * @return HTTP json response
 */
function exceptionResponse(\Exception $exception){
    return errorResponse([
        'file' => $exception->getFile(),
        'line_number' => $exception->getLine(),
        'exception' => $exception->getMessage(),
    ], FAVEO_EXCEPTION_CODE);
}


/**
 * converts UTC timestamp into datetime according to the system's timezone
 * @param string $timestamp     timestamp in UTC (for eg. 1521519438)
 * @return string               datetime (for eg. 20-03-2018 09:47:18 )
 */
function convertTimestampToDate($timestamp)
{
    return \Carbon\Carbon::createFromTimestamp($timestamp, timezone())->toDateTimeString();

}

/**
 * gets logged in agent's timezone. If a guest accesses this, system's timezone will be returned
 */
function agentTimeZone()
{
    try{
        $timezone = (\Auth::check() && \Auth::user()->role != 'user') ?
                    \App\Model\kb\Timezone::where('id', \Auth::user()->agent_tzone)->first()->name :
                    \App\Model\helpdesk\Settings\System::select('time_zone')->first()->time_zone ;
        return $timezone;
    }
    catch(\Exception $e){
        return \App\Model\helpdesk\Settings\System::select('time_zone')->first()->time_zone;
    }
}

/**
 * converts datetime from one timezone to another
 * @param $dateTime         dateTime in given timzone
 * @param $fromTimezone     timezone from which date has to e changed
 * @param $toTimezone       timezone to which date has to be changed
 * @return string           dateTime in changed timezone
 */
function changeTimezoneForDatetime($dateTime,$fromTimezone, $toTimezone)
{
    $date = \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $dateTime, $fromTimezone);
    return $date->setTimezone($toTimezone);
}


/**
 * sets mail config and reloads the config into the container
 * NOTE: this is getting used outside the class to set service config
 * @return void
 */
function setServiceConfig($emailConfig)
{
    $sendingProtocol = $emailConfig->sending_protocol;

    if( $sendingProtocol != 'smtp' && $sendingProtocol != 'mail'){

        $services = \Config::get("services.$sendingProtocol");
        $dynamicServiceConfig = [];

        //loop over it and assign according to the keys given by user
        foreach($services as $key => $value){
            $dynamicServiceConfig[$key] = isset($emailConfig[$key]) ? $emailConfig[$key] : $value;
        }

        //setting that service configuration
        \Config::set("services.$sendingProtocol", $dynamicServiceConfig);
    }
    else {
        \Config::set('mail.host',$emailConfig['sending_host']);
        \Config::set('mail.port', $emailConfig['sending_port']);
        \Config::set('mail.password', $emailConfig['password']);
        \Config::set('mail.security', $emailConfig['sending_encryption']);
    }

    //setting mail driver as $sending protocol
    \Config::set('mail.driver', $sendingProtocol);
    \Config::set('mail.from.address', $emailConfig['email_address']);
    \Config::set('mail.from.name',  $emailConfig['email_name']);
    \Config::set('mail.username', $emailConfig['user_name']);

    //setting the config again in the service container
    (new \Illuminate\Mail\MailServiceProvider(app()))->register();
}

/**
 *========================================================================
 *                   Temporary functions block
 *------------------------------------------------------------------------
 * This block contains some functions which are being used for temporary
 * purpose to fulfil custom requirement with SLA enforecements. This block
 * can be removed and reused while rewriting SLA module functionality.
 *========================================================================
 */

/**
 * Function to get custom form data of ticket from ticket_form_data model.
 * @param  Integer $ticketID   id of a ticket
 * @param  Array   $colunms    array of name of columns to return in result
 * @return Array               Array containng requested column values
 */
function getCustomFieldsOfTickets($ticketId, $columns = [], $format=false)
{
    $ticket = App\Model\helpdesk\Ticket\Tickets::where('id', $ticketId)->first();
    if (!$ticket) {
        return [];
    }
    $ticket = (empty($columns))? $ticket->formdata()->get()->toArray(): $ticket->formdata()->get($columns)->toArray();
    if (!$format) return $ticket;
    $formattedArray = [];
    foreach ($ticket as $value) {
        $formattedArray[$value['key']] = $value['content'];
    }
    return $formattedArray;
}


/**
 *  helper function for SLA to check SLA enforement for custom fields in 'ANY' scenario
 *  @param  Integer  $slaId               id of an SLA to check custom fields enforcments
 *  @param  Array    $ticketCustomFields  Array containing custom fields data of ticket
 *  @param  Integer  $matched             total number of feilds matched in sla custom enforcments and ticket csutom field data
 */
function customFieldsSLAEnforcementsAny($slaId, $ticketCustomFields)
{
    if (empty($ticketCustomFields)) return 0;
    $customSLAQueryBuidler = \App\Model\helpdesk\Manage\Sla\SlaCustomEnforcements::where('sla_id', $slaId)->get(['f_name', 'f_type', 'f_value']);
    if($customSLAQueryBuidler->count() == 0) return 0;
    $wrkflw = new App\Http\Controllers\Agent\helpdesk\TicketWorkflowController();
    $matched = 0;
    foreach ($customSLAQueryBuidler as $value) {
        $key = $value['f_name'];
        $ruleValue = ($value['f_type'] == 'checkbox') ? [$value['f_value'], 'equal', 'checked']: [$value['f_value'], 'equal'];
        $matched += ($wrkflw->relation($key, $ruleValue, $ticketCustomFields)) ? 1 : 0;
    }
    return $matched;
}

/**
 * helper function for SLA to check SLA enforement for custom fields in 'ALL' scenario it pushes new elements in 2nd and 3rd parameter array
 * @param Integer  $slaId               id of an SLA to check custom fields enforcements
 * @param Array    $value               Array which keeps record of field
 * @param Array    $check               Array which keeps record of match
 * @param Array    $ticketCustomFields  Array of custom fields data of ticket
 */
function customFieldsSLAEnforcementsAll($slaId, &$value, &$check, $ticketCustomFields)
{
    $customSLAQueryBuidler = \App\Model\helpdesk\Manage\Sla\SlaCustomEnforcements::where('sla_id', $slaId)->get(['f_name', 'f_type', 'f_value']);
    if($customSLAQueryBuidler->count() == 0) return true;
    $allMatched = false;
    array_push($value, 'custom-fields');
    array_push($check, 0);
    if (empty($ticketCustomFields)) return 0;
    $wrkflw = new App\Http\Controllers\Agent\helpdesk\TicketWorkflowController();
    foreach ($customSLAQueryBuidler as $customValue) {
        $key = $customValue['f_name'];
        $ruleValue = ($customValue['f_type'] == 'checkbox') ? [$customValue['f_value'], 'equal', 'checked']: [$customValue['f_value'], 'equal'];
        $allMatched = $wrkflw->relation($key, $ruleValue, $ticketCustomFields);
        if (!$allMatched) return false;
    }
    $check[count($check)-1]=1;
    return true;
}

/**
     * upload to system
     * @param mixed $attachment
     * @param string $upload_path
     * @param string $filename
     */

function uploadInLocal($attachment, $upload_path, $filename)
    {
            if (!\File::exists($upload_path)) {
                \File::makeDirectory($upload_path, 0777, true);
            }
            $path = $upload_path . DIRECTORY_SEPARATOR . $filename;
            if (method_exists($attachment, 'getStructure')) {
                $attachment->saveAs($path);
            }
            else {
                $attachment->move($upload_path, $filename);
            }
}
/**
* This function return time zone name with GMT format  ex:-(GMT-11:00)Pacific/Midway
* @return type array
*/

function timezoneFormat(){

        $timezonesList = \App\Model\helpdesk\Utility\Timezones::orderBy('id','ASC')->get();

                         //
            foreach ($timezonesList as $timezone) {
            $location = $timezone->location;
            $start  = strpos($location, '(');
            $end    = strpos($location, ')', $start + 1);
            $length = $end - $start;
            $result = substr($location, $start + 1, $length - 1);
            $display[]=(['id'=>$timezone->id ,'name'=> '('.$result.')'.' '.$timezone->name]);
            }
             //for display
            return array_column($display,'name','id');

    }


    /**
     * Sets up DB config for testing
     * @param  string $dbUsername  mysql username
     * @param  string $dbPassword  mysql password
     * @return null
     */
    function setupConfig($dbUsername, $dbPassword,$port='',$dbengine='')
    {
        Config::set('app.env', 'development');
        Config::set('database.connections.mysql.port', '');
        Config::set('database.connections.mysql.database', null);
        Config::set('database.connections.mysql.username', $dbUsername);
        Config::set('database.connections.mysql.password', $dbPassword);
        Config::set('database.connections.mysql.engine', $dbengine);
        Config::set('database.install', 0);
    }


/**
* This function return agent list with Alphabeticorder
* @return type array
*/
function agentListAlphabeticorder(array $userId=[]) : array{
     $agentLists = \App\User::where('is_delete','!=',1)->where('ban','!=',1)->where('active',1)
                             ->where(function($query) use ($userId){
                                  $query->whereIn('id',$userId)->orwhere('role', 'admin');
                              })->select('id', 'first_name','last_name','user_name')->orderBy('first_name')->get();
            foreach ($agentLists as $agent) {

                 $name=(($agent ->first_name) != "") ? ($agent ->first_name." ".$agent ->last_name) :($agent ->user_name);
                 $assigntoAgent[]=(['id'=>$agent->id,'name'=>$name]);
                # code...
            }

            $assigntoAgent=array_column($assigntoAgent,'name','id');
            return $assigntoAgent;
}

/**
* This function return agent list with based on permission
* @return type array
*/


function getAgentbasedonPermission(string $permision) : array{

    $data= \App\Model\helpdesk\Agent\Groups::where('permision','!=',null)->pluck('permision','user_id')->toArray();
    $agentId = [];
    if(count($data)){
        foreach ($data as $key => $value) {

            if($value && array_key_exists($permision, $value)){
                $agentId[] = $key;
            }
        }
    }
    return $agentId;
}
/**
 *========================================================================
 *                   Temporary functions block ends here
 *========================================================================
 */

/**
 * Creates an empty DB with given name
 * @param string $dbName    name of the DB
 * @return null
 */
function createDB(string $dbName)
{
    try{
         \DB::purge('mysql');
    // removing old db
    \DB::connection('mysql')->getPdo()->exec("DROP DATABASE IF EXISTS `{$dbName}`");

    // Creating testing_db
    \DB::connection('mysql')->getPdo()->exec("CREATE DATABASE `{$dbName}`");
    //disconnecting it will remove database config from the memory so that new database name can be
    // populated
    \DB::disconnect('mysql');
    }
    catch (\Exception $e) {
        return redirect()->back()->with('fails',$e->getMessage());
    }

}


/**
 * Checks if organization department modules is enabled
 * @return boolean
 */
function isOrgDeptModuleEnabled()
{
  return (bool)\App\Model\helpdesk\Settings\CommonSettings::where('option_name','micro_organization_status')
        ->where('status', 1)->count();
}
/**
 * This function return asset link based on link.php settings
 * @param string $type
 * @param string $key
 * @return type
 */
function assetLink(string $type, string $key)
{
   return asset(\Config::get('link.' . $type . '.' . $key));
}

/**
 * Gives bundle URL after appending version number to it
 * @param  string $url
 * @return string
 */
function bundleLink(string $url) : string
{
    return asset($url)."?version=".\Config::get('app.tags');
}

/**
 * checks if a user is a team lead
 * @param  int  $teamId
 * @param  int  $userId
 * @return boolean
 */
function isTeamLead($teamId, $userId)
{
    if(\App\Model\helpdesk\Agent\Teams::where('id',$teamId)->where('team_lead', $userId)->count()){
      return true;
    }

    return false;
}

/**
 * Checks if a user is a department manager
 * @param  int  $departmentId
 * @param  int  $userId
 * @return boolean
 */
function isDepartmentManager($departmentId, $userId)
{
    if(\App\Model\helpdesk\Agent\DepartmentAssignManager::where('department_id', $departmentId)
        ->where('manager_id',$userId)->count()){
      return true;
    }

    return false;
}

/**
 * Checks Internet connection is present or not
 * @return boolean
 */

function isInternetConnection()
{
     $connected = @fsockopen("www.google.com", 80);
                                        //website, port  (try 80 or 443)
    if ($connected){
        $isConn = true; //action when connected
        // fclose($connected);
    }else{
        $isConn = false; //action in connection failure
    }
    return $isConn;
}
