<?php

namespace App\Http\Controllers\Auth;

// controllers
use App\Http\Controllers\Common\PhpMailController;
use App\Http\Controllers\Common\SettingsController;
use App\Http\Controllers\Controller;
use Response;
// requests
use App\Http\Requests\helpdesk\LoginRequest;
use App\Http\Requests\helpdesk\RegisterRequest;
use App\Http\Requests\helpdesk\OtpVerifyRequest;
use App\Model\helpdesk\Settings\Security;
use App\Model\helpdesk\Settings\CommonSettings;
use App\Model\helpdesk\Utility\CountryCode;
use App\Model\helpdesk\Ticket\Ticket_Thread;
use App\Model\helpdesk\Ticket\Tickets;
use App\Model\kb\Timezone;
use App\Model\helpdesk\Settings\Plugin;
use App\Model\helpdesk\Settings\SocialMedia;

// classes
use App\User;
use App\Model\helpdesk\Utility\Otp;
use Schema;
use Auth;
use DB;
use Hash;
use Illuminate\Foundation\Auth\AuthenticatesAndRegistersUsers;
use Lang;
use DateTime;
use Input;
use Socialite;
use App\Http\Controllers\Admin\helpdesk\SocialMedia\SocialMediaController;
use Illuminate\Http\Request;
use App\Model\helpdesk\Agent_panel\Organization;
use App\Model\helpdesk\Agent_panel\User_org;
use App\Model\helpdesk\Settings\System;

/**
 * ---------------------------------------------------
 * AuthController
 * ---------------------------------------------------
 * This controller handles the registration of new users, as well as the
 * authentication of existing users. By default, this controller uses
 * a simple trait to add these behaviors. Why don't you explore it?
 *
 * @author      Ladybird <info@ladybirdweb.com>
 */
class AuthController extends Controller
{

    //use AuthenticatesAndRegistersUsers;
    /* to redirect after login */

    // if auth is agent
    protected $redirectTo = '/dashboard';
    // if auth is user
    protected $redirectToUser = '/profile';
    /* Direct After Logout */
    protected $redirectAfterLogout = '/';
    protected $loginPath = '/auth/login';
    protected $social;

    /**
     * Create a new authentication controller instance.
     *
     * @param \Illuminate\Contracts\Auth\Guard     $auth
     * @param \Illuminate\Contracts\Auth\Registrar $registrar
     *
     * @return void
     */
    public function __construct()
    {
        $this->PhpMailController = new PhpMailController();
        $social = new SocialMediaController();
        $social->configService();
        $this->middleware('guest', ['except' => ['getLogout', 'verifyOTP', 'resendOTP', 'redirectToProvider', 'resendActivationLink','postRegister','getLoggedInUserInfo','licenseVerification']]);
        $this->middleware('board', ['only' => ['getRegister']]);
        $this->middleware('limit.reached', ['only' => ['postRegister']]);
     
    }


    public function licenseVerification(Request $request)
    {
        $code = $request->input('first') . $request->input('second') . $request->input('third') . $request->input('forth');
        //verify license (Auto PHP Licenser will determine when connection to your server is needed)
        $GLOBALS["mysqli"]=mysqli_connect(env('DB_HOST'),env('DB_USERNAME'), env('DB_PASSWORD'),env('DB_DATABASE')); //establish connection to MySQL database
        if (Schema::hasTable('faveo_license')) {
            $license_notifications_array=  aplVerifyLicense($GLOBALS["mysqli"]);
        } else {
                Schema::create('faveo_license', function ($table) {
                    $table->increments('SETTING_ID');
                });
            \DB::table('faveo_license')->insert(['SETTING_ID'=>'1']);//create table and insert a row to pass table as array in next step for verification
            $license_notifications_array=  aplVerifyLicense($GLOBALS["mysqli"]);
         }
        if ($license_notifications_array['notification_case']=="notification_license_ok")//'notification_license_ok' case returned-operation succeeded
        {
         return redirect()->to('/');// do nothing (so user can continue using his script)
        } else {
        $url = url('/');
        \Schema::dropIfExists('faveo_license');
        $license_notifications_array=aplInstallLicense($url,"",$code, $GLOBALS["mysqli"]); //install personal (code-based) license using MySQL database 
         return redirect()->to('/');
        }
    }

    public function redirectToProvider($provider, $redirect = '')
    {

        if ($redirect !== '') {
            $this->setSession($provider, $redirect);
        }
        //dd(\Config::get('services'));
        $s = Socialite::driver($provider)->redirect();
        //dd('dscd');
        return $s;
    }

    public function handleProviderCallback($provider)
    {
        try {
            //notice we are not doing any validation, you should do it
            $this->changeRedirect();

            $user = Socialite::driver($provider)->user();
            if ($user) {
                // stroing data to our use table and logging them in
                $username = $user->getEmail();
                $first_name = $user->getName();
                if ($user->nickname) {
                    $username = $user->nickname;
                }

                if (!$first_name) {
                    $first_name = $username;
                }

                $data = [
                    'first_name' => $first_name,
                    'email' => $user->getEmail(),
                    'user_name' => $username,
                    'role' => 'user',
                    'active' => 1,
                ];
                $user = User::where('email', $data['email'])->first();
                if (!$user) {
                    $user = User::where('user_name', $data['user_name'])->first();
                }
                if (!$user) {
                    $user =  User::firstOrCreate($data);
                }
                Auth::login($user);
            }
            //after login redirecting to home page
            return redirect('/');
        } catch (\Exception $ex) {
            return redirect()->back()->with('fails', $ex->getMessage());
        }
    }

    /**
     * Get the form for registration.
     *
     * @return type Response
     */
    public function getRegister(CommonSettings $settings)
    {
        if ($settings->where('option_name', '=', 'user_registration')->pluck('status')->first() == '1') {
            return redirect()->to('/')->with('fails', Lang::get('lang.access-denied'));
        }
        $email_mandatory = $settings->select('status')->where('option_name', '=', 'email_mandatory')->first();
        $aoption = $settings->select('option_value')->where('option_name', '=', 'account_actvation_option')->first();
        \Event::fire(new \App\Events\FormRegisterEvent());
        if (Auth::user()) {
            if (Auth::user()->role == 'admin' || Auth::user()->role == 'agent') {
                return \Redirect::route('dashboard');
            } elseif (Auth::user()->role == 'user') {
                // return view('auth.register');
            }
        } else {
            return view('auth.register', compact('email_mandatory', 'aoption'));
        }
    }

    /**
     * Post registration form.
     *
     * @param type User            $user
     * @param type RegisterRequest $request
     *
     * @return type Response
     */
    public function postRegister(User $user, Request $request, $api = false, $send_mail = true,$role='user')
    {
        try {
            $checkUserInFaveo = User::where('id',$user->id)->value('id');
            $request_array = $request->input();
            $password_str = str_random(8);
            if($request->filled('password')){
                $password_str = $request->input('password');
            }
            $password = Hash::make($password_str);
            $user->password = $password;
            if ($request->input('full_name')) {
                $name = $request->input('full_name');
                $name2 = explode(" ", $name);
                $user->first_name = $name2[0];
                if (count($name2) > 1) {
                    $user->last_name = $name2[1];
                }
            } else {
                $name = $request->input('first_name')." ".$request->input('last_name');
                $user->first_name = $request->input('first_name');
                $user->last_name = $request->input('last_name');
            }
            if ($request_array['email'] == '') {
                $user->email = null;
            } else {
                $user->email = $request->input('email');
            }
            if ($request->input('mobile')) {
                $user->country_code = 0;
                if (array_key_exists('code', $request_array)) {
                    if ($request->get('code') == '' || $request->get('code') == null) {
                        return redirect()->back()->with(['code_error' => Lang::get('lang.incorrect-country-code-error'), 'country_code' => 1])->withInput();
                    }
                    $code = CountryCode::select('phonecode')->where('phonecode', '=', $request->get('code'))->count();
                    if ($code == 0) {
                        return redirect()->back()->with(['code_error' => Lang::get('lang.incorrect-country-code-error'), 'country_code' => 1])->withInput();
                    }
                    $user->country_code = $request->input('code');
                }
                $user->mobile = $request->input('mobile');
            } else {
                $user->mobile = null;
            }
            if ($request->filled('user_name')) {
                $user->user_name = $request->input('user_name');
            } else {
                if ($request_array['email'] != '') {
                    $user->user_name = $request->input('email');
                } else {
                    $user->user_name = $request->input('mobile');
                }
            }
            $user->role = $role;
            $code = str_random(60);
            $user->email_verify = $code;
            $user->mobile_otp_verify = $code;
            $default = [
                        "user_name",
                        'full_name',
                        'password',
                        'password_confirmation',
                        'code',
                        "first_name",
                        "last_name",
                        "user_name",
                        "phone_number",
                        "organisation",
                        "phone",
                        "company",
                        "email",
                        "mobile",
                        "_token"
                    ];
            $extra = $request->except($default);

            $user->agent_tzone = getGmt(true); //adding default timezone for user account
            $user->save();
            $this->saveExtraField($user,$extra);
            $userid = $user->id;
            $message12 = '';
            $settings = CommonSettings::select('status')->where('option_name', '=', 'send_otp')->first();
            $sms = Plugin::select('status')->where('name', '=', 'SMS')->first();
            // Event for login
            \Event::fire(new \App\Events\LoginEvent($request));


            $registerNotifications['registration_notification_alert'] = [
                'userid'=>$userid,
                'from' => $this->PhpMailController->mailfrom('1', '0'),
                'message' => ['subject' => null, 'scenario' => 'registration-and-verify'],
                'variable' => ['new_user_name' => $name, 'new_user_email' => $request->input('email'), 'user_password' => $password_str, 'account_activation_link' => faveoUrl('account/activation/' . $code)]
            ];
            if(commonSettings('registration_mail_templates', '') == "multiple") {
                $registerNotifications['registration_alert'] = [
                    'userid'=>$userid,
                    'from'=>$this->PhpMailController->mailfrom('1', '0'),
                    'message'=>['subject' => null, 'scenario' => 'registration'],
                    'variable'=>['new_user_name' => $name, 'new_user_email' => $request->input('email'), 'account_activation_link' => faveoUrl('account/activation/' . $code)],
                ];
                $registerNotifications['registration_notification_alert']['message']['scenario'] = 'registration-notification';
                unset($registerNotifications['registration_notification_alert']['variable']['account_activation_link']);
            }
            $registerNotifications['new_user_alert'] = [
                'model'=>$user,
                'userid'=>$userid,
                'from' => $this->PhpMailController->mailfrom('1', '0'),
                'message' => ['subject' => null, 'scenario' => 'new-user'],
                'variable' => ['new_user_name' => $name, 'new_user_email' => $user->user_name, 'user_profile_link' =>faveoUrl('user/' . $userid)]
            ];
            $notifications[]=$registerNotifications;
            $alert = new \App\Http\Controllers\Agent\helpdesk\Notifications\NotificationController();
            if (!$request->input('email') || !$send_mail) {
                $alert->setParameter('send_mail', false);
            }
            if(!$checkUserInFaveo){

                $alert->setDetails($notifications);
            }
            if ($settings->status == 1 || $settings->status == '1') {
                if (count($sms) > 0) {
                    if ($sms->status == 1 || $sms->status == '1') {
                        $message12 = Lang::get('lang.activate_your_account_click_on_Link_that_send_to_your_mail_and_moble');
                    } else {
                        $message12 = Lang::get('lang.activate_your_account_click_on_Link_that_send_to_your_mail_sms_plugin_inactive_or_not_setup');
                    }
                } else {
                    if ($request->input('email') !== '') {
                        $message12 = Lang::get('lang.activate_your_account_click_on_Link_that_send_to_your_mail');
                    } else {
                        $message12 = Lang::get('lang.account-created-contact-admin-as-we-were-not-able-to-send-opt');
                    }
                }
            } else {
                $message12 = Lang::get('lang.activate_your_account_click_on_Link_that_send_to_your_mail');
            }
            if ($api==true) {
                return ['message'=>$message12,'user'=>$user];
            }

            return redirect('home')->with('success', $message12);
        } catch (\Exception $e) {
            if ($api==true) {
                return ['error'=>$e->getMessage()];
            }
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }

    public function saveExtraField($user,$extra=[]){
        if(count($extra)>0){
            foreach($extra as $key=>$value){
                $user->userExtraField()->updateOrCreate(['owner'=>$user->id,'key'=>$key],[
                    'value'=>$value,
                ]);
            }
        }
    }

    /**
     * Function to activate account.
     *
     * @param type $token
     *
     * @return type redirect
     */
    public function accountActivate($token)
    {
        $user = User::where('email_verify', '=', $token)->first();
        $account_actvation_option = explode(',', getAccountActivationOptionValue());
        $active = 1;
        if (in_array('mobile', $account_actvation_option)) {
            $active = 0;
        }

        if ($user) {
            $user->active = $active;
            $user->email_verify = 1;
            $user->save();
            // $this->openTicketAfterVerification($user->id);
            return redirect('/auth/login')->with('status', 'Account activated. Login to start');
        } else {
            return redirect('/auth/login')->with('fails', 'Invalid Token');
        }
    }



    /**
     * Get mail function.
     *
     * @param type      $token
     * @param type User $user
     *
     * @return type Response
     */
    public function getMail($token, User $user)
    {
        $user = $user->where('remember_token', $token)->where('active', 0)->first();
        if ($user) {
            $user->active = 1;
            $user->save();

            return redirect('auth/login');
        } else {
            return redirect('auth/login');
        }
    }

    /**
     * Get login page.
     *
     * @return type Response
     */
    public function getLogin()
    {
        $directory = base_path();
        if (file_exists($directory . DIRECTORY_SEPARATOR . '.env')) {
            if (Auth::user()) {
                if (Auth::user()->role == 'admin' || Auth::user()->role == 'agent') {
                    return \Redirect::route('dashboard');
                } elseif (Auth::user()->role == 'user') {
                    return \Redirect::route('home');
                }
            } else {
                return view('auth.login');
            }
        } else {
            return Redirect::route('licence');
        }
    }

    /**
     * Post of login page.
     *
     * @param type LoginRequest $request
     *
     * @return type Response
     */
    public function postLogin(LoginRequest $request)
    {
        try {

             $system=System::where('id',1)->value('status');

            \Event::fire('login-data-submitting', [$request->all()]); //added 5/5/2016

            // Set login attempts and login time
            if(\Auth::check()){
              return successResponse('',['redirect_url'=>$this->redirectPath()]);
            }
            $value = $_SERVER['REMOTE_ADDR'];
            $usernameinput = $request->input('email');
            $password = $request->input('password');
            if ($request->input('referer')) {
                $referer = 'form';
            } else {
                $referer = '/';
            }

            $field = filter_var($usernameinput, FILTER_VALIDATE_EMAIL) ? 'email' : 'user_name';
            $result = $this->confirmIPAddress($value, $usernameinput);

            // If attempts > 3 and time < 30 minutes
            $security = Security::whereId('1')->first();
            if ($result == 1) {
                // return redirect()->back()->withErrors('email', 'Incorrect details')->with(['error' => $security->lockout_message, 'referer' => $referer]);
                return errorResponse($security->lockout_message);

            }
            $check_active = User::where('email', '=', $request->input('email'))->orwhere('user_name', '=', $request->input('email'))->first();

            if (!$check_active) { //check if user exists or not

                //if check active is not admin and system = 0
                //return errorResponse
                //if user deos not exist then return back with error that user is not registered
                // return redirect()->back()
                //                 ->withInput($request->all('email', 'remember'))
                //                 ->withErrors([
                //                     'email'       => $this->getFailedLoginMessage(),
                //                     'password'    => $this->getFailedLoginMessage(),
                //                 ])->with(['error' => Lang::get('lang.not-registered'),
                //                           'referer'             => $referer, ]);

               return errorResponse(Lang::get('lang.not-registered'));
            }
             if($system == 0 && $check_active->role != "admin"){
                         return errorResponse(Lang::get('lang.system_currently_offline'));
                    }

            if (!Hash::check($password, $check_active->password)) {
                goto attempt_login;
            }

            if ($check_active->ban || $check_active->is_delete) { // check is user account is ban or deactivated( deleted)
                // return redirect()->back()
                //     ->withInput($request->all('email', 'remember'))
                //     ->withErrors([
                //         'email'       => $this->getFailedLoginMessage(),
                //         'password'    => $this->getFailedLoginMessage(),
                //     ])->with([
                //         'error' => Lang::get('lang.account-is-banned-or-deactivated'),
                //         'referer'             => $referer
                //     ]);
            return errorResponse(Lang::get('lang.account-is-banned-or-deactivated'));
            }

            if (!$check_active->active) {
                $account_actvation_option = explode(',', getAccountActivationOptionValue());
                if (in_array('email', $account_actvation_option)) {
                    if ($check_active->email_verify != 1 || $check_active->email_verify != '1') {

                     \session(['values' => $request->input(),'referer'=>$referer,'user_id'=>$check_active->id,'email'=>$check_active->email,'error'=>Lang::get('lang.this_account_is_currently_inactive')]);

                     return successResponse('Account is currently inactive',['redirect_url'=>"verify-email",
                        'email'=> $check_active->email]);
                    }
                }

                $controller = $alert = new \App\Http\Controllers\Agent\helpdesk\Notifications\NotificationController();
                if (in_array('mobile', $account_actvation_option)) {
                    if ($controller->checkPluginSetup()) {
                        // return mobile verification screen
                        if ($check_active->mobile_otp_verify != 1 || $check_active->mobile_otp_verify != '1') {
                            $country_code = "auto";
                            $code = CountryCode::select('iso')->where('phonecode', '=', $check_active->country_code)->first();
                            if ($code && $check_active->country_code != 0) {
                                $country_code = $code->iso;
                            }

                            return \Redirect::route('otp-verification')
                                ->withInput($request->input())
                                ->with(['values' => $request->input(),
                                    'referer'    => $referer,
                                    'user_id'    => $check_active->id,
                                    'name'       => $check_active->first_name,
                                    'number'     => $check_active->mobile,
                                    'code'       => $country_code, ]);
                        }
                    } else {
                        return redirect()->back()
                            ->withInput($request->all('email', 'remember'))
                            ->withErrors([
                                'error' => Lang::get('lang.this_account_is_currently_inactive')." ".Lang::get('lang.error-sms-service-not-active')
                            ]);
                    }
                }

                // return redirect()->back()
                //             ->withInput($request->all('email', 'remember'))
                //             ->withErrors([
                //                 'error' => Lang::get('lang.this_account_is_currently_inactive')
                //             ]);

              return errorResponse(Lang::get('lang.this_account_is_currently_inactive'));
            }
            // try login
            attempt_login: $loginAttempts = 1;
            // If session has login attempts, retrieve attempts counter and attempts time
            if (\Session::has('loginAttempts')) {
                $loginAttempts = \Session::get('loginAttempts');
                $loginAttemptTime = \Session::get('loginAttemptTime');
                $this->addLoginAttempt($value, $usernameinput);
                // $credentials = $request->all('email', 'password');
                $usernameinput = $request->input('email');
                $password = $request->input('password');
                $field = filter_var($usernameinput, FILTER_VALIDATE_EMAIL) ? 'email' : 'user_name';
                // If attempts > 3 and time < 10 minutes
                if ($security && $loginAttempts > $security->backlist_threshold && (time() - $loginAttemptTime <= ($security->lockout_period * 60))) {
                    // return redirect()->back()->withErrors('email', 'incorrect email')->with('error', $security->lockout_message);
                     return errorResponse($security->lockout_message);

                }
                // If time > 10 minutes, reset attempts counter and time in session
                if ($security && (time() - $loginAttemptTime) > ($security->lockout_period * 60)) {
                    \Session::put('loginAttempts', 1);
                    \Session::put('loginAttemptTime', time());
                }
            } else { // If no login attempts stored, init login attempts and time
                \Session::put('loginAttempts', $loginAttempts);
                \Session::put('loginAttemptTime', time());
                $this->clearLoginAttempts($value, $usernameinput);
            }


            // If auth ok, redirect to restricted area
            \Session::put('loginAttempts', $loginAttempts + 1);
            if (Auth::Attempt([$field => $usernameinput, 'password' => $password], $request->filled('remember'))) {
                \Event::fire('user.login', []);
                if (Auth::user()->role == 'user') {

                    if($system == 0){
                         return errorResponse(Lang::get('lang.system_currently_offline'));
                    }
                    if ($request->input('referer')) {
                        return \Redirect::route($request->input('referer'));
                    }
                    return successResponse('',['redirect_url'=>$this->redirectPath()]);
                    // return \Redirect::route('/');
                } else {

                    if(Auth::user()->role == 'agent' && $system == 0){
                         return errorResponse(Lang::get('lang.system_currently_offline'));
                    }

                    //register and submit ticket page is in blade so requires a redirect instead of json
                    //So it should be removed as soon as both are converted into vueJs
                    if($request->input('redirect')){
                      return redirect()->intended($this->redirectPath());
                    }
                    return successResponse('',['redirect_url'=>$this->redirectPath()]);
                }
            }

            // return redirect()->back()
            //                 ->withInput($request->all('email', 'remember'))
            //                 ->withErrors([
            //                     'email'       => $this->getFailedLoginMessage(),
            //                     'password'    => $this->getFailedLoginMessage(),
            //                 ])->with(['error' => Lang::get('lang.invalid'),
            //             'referer'             => $referer, ]);
           return errorResponse(Lang::get('lang.invalid'));
        } catch (\Exception $e) {
            return errorResponse($e->getMessage());
            //catch the exception here
        }
    }

    /**
     * Add login attempt.
     *
     * @param type IPaddress $value
     *
     * @return type Response
     */
    public function addLoginAttempt($value, $field)
    {
        $result = DB::table('login_attempts')->where('IP', '=', $value)->first();
        $data = $result;
        $security = Security::whereId('1')->first();
        if($security){
        $apt = $security->backlist_threshold;
        if ($data) {
            $attempts = $data->Attempts + 1;
            if ($attempts == $apt) {
//                $result = DB::select('UPDATE login_attempts SET Attempts='.$attempts.", LastLogin=NOW() WHERE IP = '$value' OR User = '$field'");
                $result = DB::table('login_attempts')->where('IP', '=', $value)->orWhere('User', '=', $field)->update(['Attempts' => $attempts, 'LastLogin' => Date('Y-m-d H:i:s')]);
            } else {
                $result = DB::table('login_attempts')->where('IP', '=', $value)->orWhere('User', '=', $field)->update(['Attempts' => $attempts]);
                // $result = DB::select("UPDATE login_attempts SET Attempts=".$attempts." WHERE IP = '$value' OR User = '$field'");
            }
        } else {
//            $result = DB::select("INSERT INTO login_attempts (Attempts,User,IP,LastLogin) values (1,'$field','$value', NOW())");
            $result = DB::table('login_attempts')->update(['Attempts' => 1, 'User' => $field, 'IP' => $value, 'LastLogin' => Date('Y-m-d H:i:s')]);
        }
        }
    }

    /**
     * Clear login attempt.
     *
     * @param type IPaddress $value
     *
     * @return type Response
     */
    public function clearLoginAttempts($value, $field)
    {
        $data = DB::table('login_attempts')->where('IP', '=', $value)->orWhere('User', '=', $field)->update(['attempts' => '0']);

        return $data;
    }

    /**
     * Confiem IP.
     *
     * @param type IPaddress $value
     *
     * @return type Response
     */
    public function confirmIPAddress($value, $field)
    {
        $security = Security::whereId('1')->first();
        $time = $security->lockout_period;
        $max_attempts = $security->backlist_threshold;
        $table = 'login_attempts';
        $result = DB::select('SELECT Attempts, (CASE when LastLogin is not NULL and DATE_ADD(LastLogin, INTERVAL ' . $time . ' MINUTE)>NOW() then 1 else 0 end) as Denied ' .
                        ' FROM ' . $table . " WHERE IP = '$value' OR User = '$field'");
        $data = $result;
        //Verify that at least one login attempt is in database
        if (!$data) {
            return 0;
        }
        if ($data[0]->Attempts >= $max_attempts) {
            if ($data[0]->Denied == 1) {
                return 1;
            } else {
                $this->clearLoginAttempts($value, $field);
                return 0;
            }
        }

        return 0;
    }

    /**
     * Get Failed login message.
     *
     * @return type string
     */
    protected function getFailedLoginMessage()
    {
        return Lang::get('lang.this_field_do_not_match_our_records');
    }

    /**
     *@category function to show verify OTP page
     *@param null
     *@return response|view
     */
    public function getVerifyOTP()
    {
        if (\Session::has('values')) {
            return view('auth.otp-verify');
        } else {
            return redirect('auth/login');
        }
    }

    /**
     *@category function to verify OTP
     *@param $request
     *@return int|string
     */
    public function verifyOTP(LoginRequest $request)
    {
        $user = User::select('id', 'mobile', 'country_code', 'user_name', 'mobile_otp_verify', 'updated_at')->where('email', '=', $request->input('email'))
            ->orWhere('user_name', '=', $request->input('email'))->first();
        $otp_length = strlen($request->input('otp'));
        if (($otp_length == 6 && !preg_match("/[a-z]/i", $request->input('otp')))) {
            $otp2 = Hash::make($request->input('otp'));
            $date1 = date_format($user->updated_at, "Y-m-d h:i:sa");
            $date2 = date("Y-m-d h:i:sa");
            $time1 = new DateTime($date2);
            $time2 = new DateTime($date1);
            $interval = $time1->diff($time2);
            if ($interval->i > 30 || $interval->h > 0) {
                $message = Lang::get('lang.otp-expired');
            } else {
                if (Hash::check($request->input('otp'), $user->mobile_otp_verify)) {
                    User::where('id', '=', $user->id)
                            ->update([
                                'mobile_otp_verify' => '1',
                                'mobile' => $request->input('mobile'),
                                'active' => 1,
                                'country_code' => str_replace('+', '', $request->input('country_code'))
                            ]);
                    $this->openTicketAfterVerification($user->id);
                    return $this->postLogin($request);
                } else {
                    $message = Lang::get('lang.otp-not-matched');
                }
            }
        } else {
            $message = Lang::get('lang.otp-invalid');
        }
        $country_code = "auto";
        $code = CountryCode::select('iso')->where('phonecode', '=', str_replace('+', '', $request->input('country_code')))->first();
        if ($code) {
            $country_code = $code->iso;
        }
        return \Redirect::route('otp-verification')
                        ->withInput($request->input())
                        ->with(['values' => $request->input(),
                            'number' => $request->input('number'),
                            'name' => $user->user_name,
                            'user_id' => $user->id,
                            'code'  => $country_code,
                            'fails' => $message]);
    }

    public function resendOTP(OtpVerifyRequest $request)
    {
        try {
            $controller = $alert = new \App\Http\Controllers\Agent\helpdesk\Notifications\NotificationController();
            if ($controller->checkPluginSetup()) {
                $user_number_exists = User::select('id')->where('mobile', '=', $request->get('mobile'))->where('id', '!=', $request->get('user_id'))->count();
                if ($user_number_exists == 0) {
                    $user_details = User::select('email', 'first_name', 'last_name', 'user_name', 'role', 'user_language')->where('id', '=', $request->get('user_id'))->first()->toArray();
                    $otp = mt_rand(100000, 999999);
                    $otp_hash =  Hash::make($otp);
                    $user_details['mobile'] = $request->get('mobile');
                    $user_details['country_code'] = $request->get('code');
                    $message = [
                        'scenario' => 'otp-verification',
                    ];
                    User::where('id', '=', $request->get('user_id'))
                        ->update([
                            'mobile_otp_verify' => $otp_hash
                        ]);
                    $variables = [
                       'otp_code' => $otp
                    ];
                    try {
                        $sms_controller = new \App\Plugins\SMS\Controllers\MsgNotificationController;
                        $sms_controller->notifyBySMS($user_details, $variables, $message, []);
                        return 1;
                    } catch (\Exception $e) {
                        $message = Lang::get('lang.otp-can-not-be-verified');
                        return response()->json(['error'=> $message]);
                    }
                } else {
                    $message = Lang::get('lang.mobile_number_already_verified');
                    return response()->json(['error' => $message]);
                }
            } else {
                $message = Lang::get('lang.error-sms-service-not-active');
                return response()->json(['error' => $message]);
            }
        } catch (\Exception $e) {
            $message = Lang::get('lang.otp-can-not-be-verified');
            return response()->json(['error' => $message]);
        }
    }

    /**
     * @category function to change ticket status when user verifies his account
     * @param int $id => user_id
     * @return null
     * @author manish.verma@ladybirdweb.com
     */
    public function openTicketAfterVerification($id)
    {
        // dd($id);
        $ticket = Tickets::select('id')
                ->where(['user_id' => $id, 'status' => 6])
                ->get();
        Tickets::where(['user_id' => $id, 'status' => 6])
                ->update(['status' => 1]);
        if ($ticket != null) {
            foreach ($ticket as $value) {
                $ticket_id = $value->id;
                Ticket_Thread::where('ticket_id', '=', $ticket_id)
                    ->update(["updated_at" => date('Y-m-d H:i:s')]);
            }
        }
    }


    public function changeRedirect()
    {
        $provider = \Session::get('provider');
        $url = \Session::get($provider . 'redirect');
        \Config::set("services.$provider.redirect", $url);
    }

    public function setSession($provider, $redirect)
    {
        $url = url($redirect);
        \Session::put('provider', $provider);
        \Session::put($provider . 'redirect', $url);
        $this->changeRedirect();
    }
      /**
     * Log the user out of the application.
     *
     * @return \Illuminate\Http\Response
     */
    public function getLogout(Request $request)
    {
        \Event::fire('user.logout', []);
        $login = new LoginController();
        return $login->logout($request);
    }

    public function redirectPath()
    {
        $auth = Auth::user();
        if ($auth && $auth->role!='user') {
            return "dashboard";
        } else {
            return "/";
        }
    }

    /**
     *
     *
     *
     */
    public function getEmailVerification()
    {
        if (\Session::get('values')) {
           return view('auth.email-verify');
        } else {
           return redirect('auth/login');
        }

    }

    /**
     *
     *
     *
     */
    public function resendActivationLink(Request $request)
    {
        try {

            $validator = \Validator::make($request->all(), [
             'email'         =>  'required|unique:users,email|unique:emails,email_address',
            ]);
          if (!$validator->passes()) {
             $message = $validator->errors()->all();
             return ['response' => 'error','message' => $message[0]];
            }
           $user = User::where('id', '=', \Input::get('user_id'))->first();
            $code = str_random(60);
            $user->email_verify = $code;
            if (\Input::get('change') == "yes") {
                $user->email = \Input::get('email');
            }

            $user->save();
            $notifications[]=[
                'registration_alert'=>[
                    'userid'=> $user->id,
                    'from'=>$this->PhpMailController->mailfrom('1', '0'),
                    'message'=>['subject' => null, 'scenario' => 'registration'],
                    'variable'=>['new_user_name' => $user->name(), 'new_user_email' => $user->email, 'account_activation_link' => faveoUrl('account/activate/' . $code)],
                ]
            ];
            $alert = new \App\Http\Controllers\Agent\helpdesk\Notifications\NotificationController();
            $alert->setDetails($notifications);
            return ['response' => 'success', 'message' => Lang::get('lang.verify-email-message', ['email' => substr_replace($user->email, '***', strpos($user->email, '@')-3, 3)])];
        } catch (\Exception $e) {
            return ['response' => 'error', 'message' => $e->getMessage()];
        }
    }


        /**
     * made for vue frontend to work with user-data
     * NOTE: must be deleted once login functionality is implemented in vue
     * @return Response     Success with user data if logged in else failure
     */
    public function getLoggedInUserInfo(){
            $user = [];
            $system = System::select('time_zone')->first();
            $user['date_format'] = dateformat();
           //for guest user
            if(!\Auth::check()){
                $user['timezone']  = $system->time_zone;//system timezone
                $user['user_data'] = [];
            }
            //for logged in user
            if(\Auth::check() && \Auth::user()->role == 'user'){
                $user['timezone']  = $system->time_zone;//system timezone
                $user['user_data'] = Auth::user();
            }
            //for admin or agent
            if(\Auth::check() && \Auth::user()->role != 'user'){
               $user['timezone'] = Timezone::where('id', \Auth::user()->agent_tzone)->first()->name;
               $user['date_format'] = dateformat();
               $user['user_data'] = Auth::user();
            }

             $status = CommonSettings::where('option_name', 'cdn_settings')->value('option_value');
             $user['base_url']= ($status == "0") ? url('/') : "https://www.faveohelpdesk.com/cdn" ;
             $user['system_url']=  url('/') ;
            return successResponse('',$user);
    }

            /**
     * made for vue frontend to work with user-data
     * NOTE: must be deleted once login functionality is implemented in vue
     * @return Response     Success with user data if logged in else failure
     */

        public function getActiveSocialLoginsList()
    {
        $ldap=(isPlugin('Ldap'))? 1 : 0 ;

        $socialLoginActiveProviders = SocialMedia::where('key','status')->where('value','1')->pluck('provider');

        return successResponse('',['providers'=>$socialLoginActiveProviders,'ldapauthenticate'=>$ldap]);
    }

}
