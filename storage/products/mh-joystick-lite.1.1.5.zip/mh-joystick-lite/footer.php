</div><!-- /wrapper -->
</div><!-- /container -->
<footer class="mh-footer mh-row">
    <div class="mh-container footer-info">
    	<div class="mh-col-2-3 copyright">
			<?php printf(__('Copyright &copy; %1$s %2$s', 'mh-joystick-lite'), date("Y"), get_bloginfo('name')); ?>
		</div>
		<div class="mh-col-1-3 credits-text">
			<?php printf(__('MH Joystick lite by %s', 'mh-joystick-lite'), '<a href="' . esc_url('https://www.mhthemes.com/') . '" title="' . __('Premium Magazine WordPress Themes', 'mh-joystick-lite') . '" rel="nofollow">' . __('MH Themes', 'mh-joystick-lite') . '</a>'); ?>
		</div>
    </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>