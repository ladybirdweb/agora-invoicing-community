<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;

class RecurTicket implements ShouldQueue
{

    use Dispatchable,
        InteractsWithQueue,
        Queueable,
        SerializesModels;
    public $tries = 5;
    public $values;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($tickets)
    {
        $this->values = $tickets;
    }
    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $user_id       = $this->values['requester'];
        $subject       = $this->values['subject'];
        $body          = $this->values['body'];
        $helptopic     = $this->values['help_topic'];
        $sla           = $this->values['sla'];
        $priority      = $this->values['priority'];
        $source        = $this->values['source'];
        $headers       = $this->values['cc'];
        $dept          = $this->values['dept'];
        $assignto      = $this->values['assigned'];
        $from_data     = $this->values['extra_form'];
        $status        = $this->values['status'];
        $type          = $this->values['type'];
        $attachment    = $this->values['attachments'];
        $inline        = $this->values['inline'];
        $email_content = $this->values['email_content'];
        $company       = $this->values['company'];
        $user = $this->getUser($user_id);
        $this->ticketController()->create_user($user->email, $user->user_name, $subject, $body, "", "", "", $helptopic, $sla, $priority, $source, $headers, $dept, $assignto, $from_data, "", $status, $type, $attachment, $inline, $email_content, $company);
    }
    
    public function getUser($id){
        return \App\User::whereId($id)->select('id','user_name','email','phone_number','ext','mobile')->first();
    }
    
    /**
     * The job failed to process.
     *
     * @param  Exception  $exception
     * @return void
     */
    public function failed(\Exception $exception)
    {
        loging('recurring-ticket', $exception->getMessage().' Line=>'.$exception->getLine()." File=>".$exception->getFile());
    }
    
    public function ticketController()
    {
        return new \App\Http\Controllers\Agent\helpdesk\TicketController();
    }
}
