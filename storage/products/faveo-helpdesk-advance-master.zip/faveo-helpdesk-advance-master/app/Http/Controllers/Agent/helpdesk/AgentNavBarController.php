<?php

namespace App\Http\Controllers\Agent\helpdesk;

use Auth;
use App\User;
use App\Model\helpdesk\Settings\Company;
use App\Http\Controllers\Controller;
use App\Model\helpdesk\Ticket\Tickets;
use App\Model\helpdesk\Agent\Department;
use App\Model\helpdesk\Settings\Approval;
use App\Model\helpdesk\Email\Emails;
use App\Model\helpdesk\Agent\DepartmentAssignAgents;
use App\Model\helpdesk\Settings\CommonSettings;
use App\Policies\TicketPolicy;

class AgentNavBarController extends Controller
{

    private $departmentIds;

    private $user;
    
    public $isAccessRestricted;

    public $isAccessGlobal;

    public function __construct (TicketPolicy $ticketPolicy) {
        
        $this->middleware(['auth', 'role.agent']);

        //has to be moved to tickets count method to skip query while caching
        $this->isAccessRestricted = $ticketPolicy->restrictedAccess();
        $this->isAccessGlobal = $ticketPolicy->globalAccess();
    }


   public function sideBarData(){
        $this->user = Auth::user();
        $ticketCount = [
            'user' => $this->user->first_name.' '.$this->user->last_name,
            'profile_pic' => $this->user->profile_pic,
            'mytickets' => $this->myTicket(),
            'unassigned' => $this->unassigned(),
            'followup' => $this->followupTicket(),
            'closingapproval' => $this->closingApproval(),
            'closed' => $this->closed(),
            'deleted' => $this->deleted(),
            'inbox' => $this->inbox(),
            'overdue' => $this->overdues(),
        ];

        return successResponse('',$ticketCount);
   }

   /**
     * filters tickets accoding to the permission given to the agent/admin
     *
     * @param tickets array
     * @return array
     */
    private function accessibleTickets($status = 'open'){

        $tickets = $this->ticketQueryBuilder($status);
        if($this->user->role == 'agent'){
            if(!$this->isAccessGlobal && !$this->isAccessRestricted){

                //so that departmentId only get populated once to avoid multiple querying
                $this->departmentIds = !$this->departmentIds ? DepartmentAssignAgents::where('agent_id', '=', $this->user->id)->pluck('department_id')->toArray() : $this->departmentIds;
                return $tickets->whereIN('dept_id', $this->departmentIds);       
            }
            if($this->isAccessRestricted){
                return $tickets->where('assigned_to',$this->user->id);
            }
            else{
                return $tickets;
            }
        }
        else {
            return $tickets;
        }   
    }

    /**
     * builds ticket query by joining status type with that
     *
     * @param tickets array
     * @return array
     */
    private function ticketQueryBuilder($status){
        return Tickets::whereHas('statuses.type',function($q1) use ($status){
                        $q1->select('id','name')->where('name', $status);
                    });
    }

   /**
     * all the tickets.
     * @return array
     */
    public function inbox() {
        return $this->accessibleTickets()->count();
    }


   /**
     * In my tickets, only tickets visible to a user would be tickets assigned to him
     * @return array
     */
    public function myTicket() {
        return $this->accessibleTickets()->where('assigned_to', $this->user->id)->count();
    }

    /**
     * All closed tickets.
     * @return array
     */
    public function closed() {
        return $this->accessibleTickets('closed')->count();
    }

   /**
     * Tickets which are not assigned to anyone.
     * @return array
     */
    public function unassigned() {
            return $this->accessibleTickets()->where(function($q){
                        $q->where('team_id',null)->orWhere('team_id',0);
                    })->where(function($q){
                        $q->where('assigned_to',null)->orWhere('team_id',0);
                    })->count();
    }

    public function followupTicket() {
        return $this->accessibleTickets()->where('follow_up',1)->count();
    }


   /**
     * tickets with status type as approval. Visibility depends on the permission
     * @return array
     */
    public function closingApproval() {
        return $this->accessibleTickets('approval')->count();
    }


   /**
     * deleted tickets.
     * @return array
     */
    public function deleted() {
        return $this->accessibleTickets('deleted')->count();
    }


   /**
     * all the overdue tickets. 
     * @return array
     */
    public function overdues() {
        return $this->accessibleTickets()->where('isanswered',0)
                            ->where('duedate','!=', null)
                            ->where('duedate', '!=', '00-00-00 00:00:00')
                            ->where('duedate', '<', \Carbon\Carbon::now())
                            ->count();
    }  
}