<?php

return [
    'settings'=>'Settings',
    'storage'=>'Storage',
    'default'=>'Default',
    'root'=>'Root',
    'private-root'=>'Private Folder',
    'public-root'=>'Public Folder',
    'region'=>'Region',
    'key'=>'Key',
    'secret'=>'Secret',
    'bucket'=>'Bucket',
    'username'=>'Username',
    'container'=>'Container',
    'endpoint'=>'End Point',
    'url_type'=>'Url Type',
    'save'=>'Save',
];

