<?php

namespace App\Console\Commands;

use App\Http\Controllers\Common\Mail\FetchMailController;
use Carbon\Carbon;
use Event;
use Illuminate\Console\Command;
use Lang;
use Logger;

class TicketFetch extends Command
{

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'ticket:fetch';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Fetching the tickets from service provider';

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $startTime = Carbon::now();

        if (env('DB_INSTALL') == 1) {
            try {
                $this->info(Lang::get('lang.ticket-fetch-cron-execution-initiated'));

                $startTime =  Carbon::now()->toDateTimeString();

                (new FetchMailController)->fetchMail();

                Event::fire('ticket.fetch', ['event' => '']);

                $humanReadable = Lang::get('lang.ticket-fetch-cron-execution-completed');

                $this->info($humanReadable);

                $endTime  =  Carbon::now()->toDateTimeString();

                Logger::cron($startTime ,$endTime,'mail-fetch', $humanReadable);

            } catch (\Exception $ex) {

                Logger::exception($ex, 'mail-fetch');

                $this->error(Lang::get('lang.ticket-fetch-cron-error') . $ex->getMessage());
            }
        }
    }
}
