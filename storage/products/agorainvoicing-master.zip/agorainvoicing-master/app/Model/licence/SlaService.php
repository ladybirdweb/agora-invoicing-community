<?php

namespace App\Model\licence;

use App\BaseModel;

class SlaService extends BaseModel
{
}
