<?php

namespace App\Http\Controllers\Common\Mail;

use App\Http\Controllers\Agent\helpdesk\TicketWorkflowController;
use App\Http\Controllers\Common\Mail\BaseMailController;
use App\Model\helpdesk\Email\Emails;
use App\Model\helpdesk\Manage\Help_topic as HelpTopic;
use App\Model\helpdesk\Settings\Email as SettingsEmail;
use App\Model\helpdesk\Ticket\EmailThread;
use App\Model\helpdesk\Ticket\Ticket_source as TicketSource;
use App\User;
use Logger;

/**
 * handles all the fetch related operation while creating/updating a ticket through mail
 * It is child class of BaseMailController
 *
 * @author avinash kumar <avinash.kumar@ladybirdweb.com>
 */
class FetchMailController extends BaseMailController
{

    /**
     * System email
     * There can be multiple system mails. This will be populated with only one system email
     * and will be looped over those to keep changing it
     * @var string
     */
    private $systemEmail;

    /**
     * System mails
     * @use To avoid fetching mail from system mail, we put a check that mails coming from system mails should
     * not generate ticket
     * @var array
     */
    private $systemEmails;

    public function __construct()
    {
        // Get system emails
        $this->systemEmails = Emails::select('email_address')->pluck('email_address')->toArray();
    }

    /**
     * handles fetching of mail
     */
    public function fetchMail()
    {
        // Get email settings
        if (SettingsEmail::first()->email_fetching) {
            $emailsConfig = Emails::where('fetching_status', 1)->get();

            foreach ($emailsConfig as $emailConfig) {
                $this->emailConfig = $emailConfig;
                $this->systemEmail = $emailConfig->email_address;

                $mails = $this->fetchMailByPhpImap();

                // Handles ticket related activity
                $this->handleMailForTicketActivity($mails);

                /**
                 * Handle errors of mail fetching
                 * @source BaseMailController
                 */
                if ($this->error) {
                    Logger::exception($this->error, 'mail-fetch');
                }
            }
        }
    }

    /**
     * handle mails to make it in format that would be appropriate for ticket creation or updation
     * @param array $mails          array of mails in formatted form
     * @return void
     */
    private function handleMailForTicketActivity(array $mails)
    {
        // Format ticket for ticket controller to handle that
        foreach ($mails as $mail) {

            $subject       = $mail['subject'];
            $body          = $this->decoupleReplyFromBody($mail['body']);
            $replyTo       = $mail['reply_to'] ? $mail['reply_to'] : $mail['from'];
            $collaborators = $this->collaborators($mail);

            //splitting all attachments into inline and attachments
            $allAttachments = $this->categorizeAttachments($mail['attachments']);

            /**
             * Changing reference ids to string if it is an empty array.
             * NOTE: it has to change back to empty array once create tiket is rewriten
             */
            $referenceIds = $mail['reference_ids'] ? $mail['reference_ids'] : '';

            $emailIdentity = [
                'message_id'     => $mail['message_id'],
                'uid'            => $mail['uid'],
                'reference_id'   => $referenceIds,
                'fetching_email' => $this->systemEmail,
            ];

            Logger::fetchedMail(['from' => $mail['from'], 'subject' => $subject, 'body' => $body, 'message_id' => $mail['message_id']], $this->systemEmail);

            // Check if ticket need to create
            if (!$this->shallCreateTicket($mail)) {
                continue;
            }

            try {
                $ticket = $this->callToWorkflow($replyTo, $subject, $body, $collaborators, $allAttachments['attachments'], $allAttachments['inlines'], $emailIdentity);
            } catch (\Exception $e) {

                Logger::exception($e, 'mail-fetch');
            }
        }
    }

    /**
     * checks if current mail is valid for creating a ticket
     *
     * @param  array $mail  data of the mail
     * @return boolean
     */
    private function shallCreateTicket(array $mail): bool
    {
        //if mail is coming from system domain
        if ($this->isMailFromSystemMail($mail['from'])) {
            return false;
        }

        //if mail is auto_responded and auto responded mail is blocked, it should not create ticket
        //delivery mail is auto-generated but we consider that as non-auto generated
        if ($this->emailConfig->block_auto_generated && $mail['auto_replied'] && !$mail['is_delivery_mail']) {
            return false;
        }

        //if ticket with same message id is already exists(to avoid case where somebody marks a read mail as unread.
        //In that case that particular mail should not create ticket)
        if ($this->doesTicketExists($mail['message_id'])) {
            return false;
        }

        return true;
    }

    /**
     * checks if mail is coming from system address
     *
     * @param  string  $from  email address
     * @return boolean        true if mail is coming from system mail else false
     */
    private function isMailFromSystemMail(string $from): bool
    {
        // check if from belongs to $this->emails
        if (in_array($from, $this->systemEmails)) {
            return true;
        }

        return false;
    }

    /**
     * checks if ticket is already created  with the given message id
     *
     * @param integer|string $messageId Email messageId
     * @return int|bool Ticket number or False
     */
    private function doesTicketExists(string $messageId)
    {
        $emailThread = EmailThread::where('message_id', $messageId)
            ->where('fetching_email', $this->systemEmail)
            ->select('id')
            ->first();

        if ($emailThread) {
            return true;
        }

        return false;
    }

    /**
     * splits attachement by its disposition into inline and attachments
     * @param array $attachments    array of both inline and attachment files
     * @return object               with inline and attachment as keys
     */
    private function categorizeAttachments(array $attachments): array
    {
        $inlines = [];

        foreach ($attachments as $index => $attachment) {
            //in case of outlook inline images comes with disposition as null
            if (strtolower($attachment->disposition) == 'inline' || !$attachment->disposition) {
                array_push($inlines, $attachment);
                unset($attachments[$index]);
            }
        }

        return ['inlines' => $inlines, 'attachments' => $attachments];
    }

    /**
     * gets collaborators
     * @param object $mailObject        mail object with cc, bcc, to as keys
     * @return array                    array of collaborators with email as key and name as value
     */
    private function collaborators(array $mailObject): array
    {
        //remove all system mails from cc
        $collaborators = array_merge($mailObject['cc'], $mailObject['bcc'], $mailObject['to']);

        //sender cannot be added collaborator
        if (array_key_exists($mailObject['from'], $collaborators)) {
            unset($collaborators[$mailObject['from']]);
        }

        //system mail cannot be collaborator, so removing all system emails from cc
        foreach ($this->systemEmails as $systemEmail) {
            if (array_key_exists($systemEmail, $collaborators)) {
                unset($collaborators[$systemEmail]);
            }
        }

        // Check if name is null, populate it with email and make key as array and array as key as a workaround
        // For create ticket(must be removed in future)
        return $this->formatCollaborators($collaborators);
    }

    /**
     * Check if name is null, populate it with email and make key as array and array as key as a workaround
     * For create ticket(must be removed in future)
     *
     * @param  array $collaborators  list of collaborators
     * @return array                  formatted list of collaborators
     */
    private function formatCollaborators(array $collaborators): array
    {
        // Check if name exists
        $formattedCollaborators = [];

        foreach ($collaborators as $key => $value) {
            // Replace name with email and flip key value
            if (!$value) {
                $value = $key;
            }

            $formattedCollaborators[$value] = $key;
        }

        return $formattedCollaborators;
    }

    /**
     * Filters reply content from rest of the body
     * NOTE: This algorithm must be made very strong. Currently the older method is user as it is
     *
     * @param string $body HTML body
     * @return string Filtered body after removing older mail content (which gets created while replying)
     */
    private function decoupleReplyFromBody(string $body): string
    {
        $body2 = explode('<div style="display:none">---Reply above this line(to trim old messages)--- </div>', $body);

        if (is_array($body2) && array_key_exists(0, $body2)) {
            $body = $body2[0];
        }

        return $body;
    }

    /**
     * TO DO: this method has to be removed and create_user from ticket controller has to be called directly
     * calls to workflow by formatting it in arguments that it accepts
     */
    private function callToWorkflow($replyTo, $subject, $body, $collaborator, $attachments, $inlines, $emailIdentity)
    {
        //remove admin/agent Id from replyTo array
        $adminsOrAgents  = User::whereIn('email', $replyTo)->pluck('email')->toArray();
        $filteredreplyTo = array_except($replyTo, $adminsOrAgents);

        //TO DO: think of what has to be done if there are multiple people in reply to
        $repliersEmail   = array_keys($filteredreplyTo);
        $repliersName    = array_values($filteredreplyTo);
        $helptopicId     = $this->emailConfig->help_topic;
        $departmentId    = $this->emailConfig->department;
        $priorityId      = $this->emailConfig->priority;
        $sourceId        = TicketSource::where('name', 'email')->first()->id;
        $shallAutoAssign = HelpTopic::find($helptopicId)->auto_assign;
        $team_assign     = null;
        $ticket_status   = null;
        $sla             = "";
        $autoResponse    = $this->emailConfig->auto_response;
        $type            = null;

        $ticketWorkFlowController = new TicketWorkflowController;

        return $ticketWorkFlowController->workflow(
            $repliersEmail[0], $repliersName[0], $subject, $body, $phone = '', $phonecode = '', $mobile_number = '',
            $helptopicId, $sla, $priorityId, $sourceId, $collaborator, $departmentId, $shallAutoAssign,
            $team_assign, $ticket_status, $form_data = [], $autoResponse, $type, $attachments, $inlines, $emailIdentity
        );
    }
}
