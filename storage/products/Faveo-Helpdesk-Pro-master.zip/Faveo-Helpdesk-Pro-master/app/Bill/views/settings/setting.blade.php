@extends('themes.default1.admin.layout.admin')

@section('Tickets')
active
@stop

@section('tickets-bar')
active
@stop

@section('bill')
class="active"
@stop

@section('HeadInclude')
@stop
<!-- header -->
@section('PageHeader')
<h4>{{ Lang::get('lang.edit_bill_settings') }}</h4>
@stop
<!-- breadcrumbs -->
@section('breadcrumbs')
<ol class="breadcrumb">
</ol>
@stop
<!-- /breadcrumbs -->
@section('content')
<div class="well" style="display: none"></div>
<div class="box box-primary" ng-controller="typeSettingCtrl">


<form id="Form">
    <!-- /.box-header -->
    <div class="box-body">
        
        @if (count($errors) > 0)
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
        @endif

        @if (Session::has('success'))
        <div class="alert alert-success alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            {{Session::get('success')}}
        </div>
        @endif
        <!-- fail message -->
        @if(Session::has('fails'))
        <div class="alert alert-danger alert-dismissable">
            <i class="fa fa-ban"></i>
            <b>{{Lang::get('message.alert')}}!</b> {{Lang::get('message.failed')}}.
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            {{Session::get('fails')}}
        </div>
        @endif
        <div class="row">
            <div class="form-group col-md-6 {{ $errors->has('status') ? 'has-error' : '' }}">
                <div>
                    {!! Form::label('status',Lang::get('lang.enable')) !!}
                </div>
                <div>
                    <?php
                    $yes = false;
                    $no = false;
                    if(isBill()==true){
                        $yes = true;
                    }else{
                        $no = true;
                    }
                    ?>

                    <div class="col-md-3">
                        <p> {!! Form::radio('status',1,$yes) !!} {!! Lang::get('lang.yes') !!}</p>
                    </div>
                    <div class="col-md-3">
                        <p> {!! Form::radio('status',0,$no) !!} {!! Lang::get('lang.no') !!}</p>
                    </div>
                </div>             
            </div>
            <div class="form-group col-md-6 {{ $errors->has('level') ? 'has-error' : '' }}">
                <div>
                    {!! Form::label('level',Lang::get('lang.level-of-apply')) !!}
                </div>
                <div>
                     <?php
                    $curr = "";
                    $thread = ($level&&$level->option_value=='thread')?true:false;
                    $ticket = ($level&&$level->option_value=='ticket')?true:false;
                    $type = ($level&&$level->option_value=='type')?true:false;

                    if($currency && $currency->option_value){
                        $curr = $currency->option_value;
                    }
                    ?>

                    <div class="col-md-3">
                        <p> {!! Form::radio('level','thread',$thread,['onclick'=>'nontrigger()']) !!} {!!Lang::get('lang.thread')!!}</p>
                    </div>
                    <div class="col-md-3">
                        <p> {!! Form::radio('level','ticket',$ticket,['onclick'=>'trigger()']) !!} {!! Lang::get('lang.ticket') !!}</p>
                    </div>
                    <div class="col-md-3">
                        <p> {!! Form::radio('level','type',$type,['data-toggle'=>'modal','data-target'=>'#typeModal','onclick'=>'typetrigger()','class'=>'billtype']) !!} {!! Lang::get('lang.type') !!}</p>
                    </div>
                </div>             
            </div>
            
            
            <div class="form-group col-md-6 {{ $errors->has('currency') ? 'has-error' : '' }}">
                {!! Form::label('currency',Lang::get('lang.currency')) !!}
                {!! Form::text('currency',$curr,['class'=>'form-control']) !!}             
            </div>
            
            <div class="form-group col-md-6 {{ $errors->has('trigger_on') ? 'has-error' : '' }}" id="trigger" style="display: none;">
                {!! Form::label('trigger_on',Lang::get('lang.trigger-on')) !!}
                {!! Form::select('trigger_on',[''=>'Select','Statuses'=>$statuses],null,['class'=>'form-control']) !!}             
            </div>
            
            

        </div>
  <div class="modal fade" id="typeModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Select Type</h4>
        </div>
        <div class="modal-body">
         <div class="row">
         <div class="well" style="display: none"></div>
          <div class="col-sm-12">
          <div class="col-sm-5"><label>Type</label></div>
          <div class="col-sm-6"><label>Price</label></div>
          <div class='col-sm-1'></div>
          </div>
          <div class="col-sm-12" ng-repeat="bill in billingType">
           <div class="col-sm-5">
             <select class="form-control" ng-model='bill.type' ng-click="getSelectOptions('type',$index)" id="seletom@{{$index}}"  ng-options="opt.optionvalue for opt in bill.option"  style="width:88%;display: inline-block;" ng-change="selectTypeValue(bill.type.optionvalue)">
               <option value="">Select</option>
             </select>
             <span ng-show="loado@{{$index}}" style="width:10%"><img src="{{asset("lb-faveo/media/images/25.gif")}}" style="width:20px;height:20px"></span>
           </div>
           <div class="col-sm-6">
               <input type="number"  placeholder="Enter a Price" class="form-control" ng-model='bill.price' onkeypress="return (event.charCode == 8 || event.charCode == 0 || event.charCode == 13) ? null : event.charCode >= 48 && event.charCode <= 57">
           </div>
            <div class='col-sm-1'>
              <span ng-show="$last"><a href="javascript:void(0)" ng-click="addmoreType()" title="Add Type" style="font-size: 19px"><i class="fa fa-plus-circle" aria-hidden="true"></i></a></span>
              <span ng-show="!$last"><a href="javascript:void(0)" ng-click="removeType($index)" title="remove Type" style="font-size: 19px;color:#dd4b39"><i class="fa fa-minus-circle" aria-hidden="true"></i></a></span>
            </div>
          </div>
         </div>
         <div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Save</button>
        </div>
      </div>
      
    </div>
  </div>
</div>
<div class="showType" style="display: none">
   <table class="table table-striped" style="border: 1px solid gainsboro;">
    <thead>
      <tr>
        <th style="border-right: 1px solid gainsboro">S.No</th>
        <th style="border-right: 1px solid gainsboro;width: 40%">Type</th>
        <th style="border-right: 1px solid gainsboro">Price</th>
      </tr>
    </thead>
    <tbody>
      <tr ng-repeat="bill in billingType">
        <td style="border-right: 1px solid gainsboro">@{{$index+1}}</td>
        <td style="border-right: 1px solid gainsboro">@{{bill.type.optionvalue}}</td>
        <td style="border-right: 1px solid gainsboro">@{{bill.price}}</td>
      </tr>
    </tbody>
  </table>
  <div style="text-align: right;">
   <button type="button" class="btn btn-primary" data-toggle='modal' data-target='#typeModal' >Update Bill</button>
  </div>
</div>
        <!-- /.box-body -->
    </div>
    <div class="box-footer">
       <!-- {!! Form::submit(Lang::get('lang.save'),['class'=>'btn btn-primary']) !!} -->
<!--       {!!Form::button('<i class="fa fa-floppy-o" aria-hidden="true">&nbsp;&nbsp;</i>'.Lang::get('lang.save'),['type' => 'submit', 'class' =>'btn btn-primary','onclick'=>'sendForm()'])!!}-->
           <button type="submit"  class="btn btn-primary"  ng-click="saveBill($event)" ><i class="fa fa-floppy-o">&nbsp;&nbsp;</i>{!!Lang::get('lang.save')!!}</button>
        </div>
        </form>
    </div>
    <!-- /.box -->
<script>
    function trigger() {
        $("#trigger").show();
    }
    function nontrigger() {
        $("#trigger").hide();
    }
    function typetrigger(){
       $('.showType').css('display','block');
    }
</script>
@stop


@section('FooterInclude')
<script type="text/javascript">
   app.directive('input', [function() {
    return {
        restrict: 'E',
        require: '?ngModel',
        link: function(scope, element, attrs, ngModel) {
            if (
                   'undefined' !== typeof attrs.type
                && 'number' === attrs.type
                && ngModel
            ) {
                ngModel.$formatters.push(function(modelValue) {
                    return Number(modelValue);
                });

                ngModel.$parsers.push(function(viewValue) {
                    return Number(viewValue);
                });
            }
        }
    }
}]);
   app.controller('typeSettingCtrl',function($scope,$http){
         $scope.billType={!!$bill_types!!};
        if($('.billtype').is(':checked')) {
          $('.showType').css('display','block');
        }
        if($scope.billType.length!=0){
          $.each($scope.billType,function(key,value){
              this['type']={};
              this.type['id']=this.id;
              this.type['optionvalue']=this.optionvalue;
              this['option']=[];
              this.option.push(this.type);
              delete this.id;
              delete this.optionvalue; 
          })
               $scope.billingType=$scope.billType;
        }
        else{
           $scope.billingType=[{'type':'','price':'','option':[]}];
          }
        $scope.typesArray=[];
    // Add type
     $scope.addmoreType=function(){
        $scope.billingType.push({'type':'','price':'','option':[]});
     }
    // Remove type
    $scope.removeType=function(x){
       $scope.billingType.splice(x,1) 
    }
     //Get Selected Type Values
        $scope.selectTypeValue=function(x){
            $scope.typesArray.push(x);
        }
    //Get select options
        $scope.bou=0;
          
        $scope.getSelectOptions=function(x,y){
             if($('#seletom'+y).val()!=''){
                $('option:selected','#seletom'+y).remove();
             }
             $scope.bou++;
            var dependancy = x;
            if($scope.bou==1){
            $scope['loado'+y]=true;
            $http.get("{{url('ticket/form/dependancy?dependency=')}}"+dependancy,{params:$scope.typesArray}).success(function (data) {
                 $('#seletom'+y).attr('ng-click',null).unbind('click');
                 $scope.billingType[y].option=data;
                 //console.log();
                 $('#seletom'+y).css('height', parseInt($('#seletom'+y+' option').length) * 33);
                 //console.log($('#seletom'+y).css('height'));
                 $scope['loado'+y]=false;
                 $scope.bou=0;
            });
            }
           
        }
        $scope.saveBill=function(y){
               y.currentTarget.innerHTML="<i class='fa fa-circle-o-notch fa-spin fa-1x fa-fw'></i>Saving...";
               var serialize=$('#Form').serialize();
               console.log(serialize); 
               $.each($scope.billingType,function(index, value) {
                    if(typeof this.type=="object"){
                        this['type']=this.type.id;
                    }
                    delete this.option;
               });
               $scope.billingType = $scope.billingType.reduce(function (item, e1) { 
                  //console.log(item, e1);
                   var matches = item.filter(function (e2)  
                        { return e1.type == e2.type});  
                            if (matches.length == 0) {  
                                     item.push(e1);  
                            }  
                         return item;  
                        }, []);  
               console.log($scope.billingType);
             $http.post('{{route("bill.settings.post")}}?'+serialize,$scope.billingType).success(function(data){
                  if(typeof data=="object"){
                    $('.well').html(data.success);
                  }
                   $('.well').css({'color':'white','background':'#5cb85c','border-color':'#4cae4c','display':'block','margin':'10px'});
                   $('html, body').animate({scrollTop: 0}, 500);
                   setTimeout(function(){
                      $(':input').val('');
                       location.href="{{url('bill')}}";
                   },2000)
                   
             }).error(function(data) {
                  
                   if(data.error!=undefined){
                    $('.well').html(data.error);
              }
              else{
                  var res = "";
                $.each(data, function (idx, topic) {
                   res += "<li>" + topic + "</li>";
                });
                $('.well').html(res);
                }
                y.currentTarget.disabled=false;
                 y.currentTarget.innerHTML='<i class="fa fa-floppy-o">&nbsp;&nbsp;</i>Save';
                $('.well').css('display','block');      
                $('.well').css({'color':'white','background':'#dd4b39','border-color':'#d73925'});
                $('html, body').animate({scrollTop: 0}, 500);
              });
        } 
  })
</script>
@stop