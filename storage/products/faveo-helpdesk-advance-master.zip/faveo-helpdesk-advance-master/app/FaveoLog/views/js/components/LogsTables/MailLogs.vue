<template>

	<div>

		<div class="box-container">

			<div class="box-header with-border with-switch">

				<h3 for="mail logs" id="mail_logs_title" class="box-title">{{lang('mail_logs')}}</h3>

			</div>

			<div class="box-body">

				<div class="row">

					<dynamic-select :label="lang('sender')"
						id="sender-select-box"
						:multiple="true"
						name="sender_mails"
						:required="false"
						:prePopulate="true"
						classname="col-xs-6"
						apiEndpoint="/api/dependency/users?meta=true&supplements=true"
						:value="sender_mails"
						:onChange="onChange">
					</dynamic-select>

					<dynamic-select :label="lang('receiver')"
						id="reciever-select-box"
						:multiple="true"
						name="reciever_mails"
						:required="false"
						:prePopulate="true"
						classname="col-xs-6"
						apiEndpoint="/api/dependency/users?meta=true&supplements=true"
						:value="reciever_mails"
						:onChange="onChange">
					</dynamic-select>
				</div>

				<div class="mail-log-table">
					<div class="row">
						<logs-table v-if="!options.length"
							:category_ids="category_ids"
							:created_at_start="created_at_start"
							:created_at_end="created_at_end"
							:sender_mails="sender_mails"
							:reciever_mails="reciever_mails"
							:columns="columns" :options="options" :apiUrl="apiUrl" id="mail_logs_title">
						</logs-table>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>

	import axios from 'axios';

	import Vue from 'vue'

	import { mapGetters } from 'vuex'

	 Vue.component('sender', require('./ReusableComponent/SenderMailHoverComponent'));

	 Vue.component('receiver', require('./ReusableComponent/ReceiverMailHoverComponent'));

	 Vue.component('referee-id', require('./ReusableComponent/RefereeIdComponent'));

	 Vue.component('mail-subject', require('./ReusableComponent/MailSubject'));

	 Vue.component('mail-status', require('./ReusableComponent/MailStatus'));

	export default {

		props : {

			category_ids : { type : Array, default : ()=>[] },

			created_at_start : { type : String, default : '' },

			created_at_end : { type : String, default : '' },
		},

		data() {

			return {

				columns : [],

				options : {},

				apiUrl : '/api/logs/mail' ,

				columns: ['category', 'sender_mail', 'reciever_mail', 'subject', 'referee_id', 'referee_type', 'created_at', 'updated_at','status'],

				options : {},

				reciever_mails : [],

				sender_mails : []
			}
		},

		beforeMount(){
			const self = this;
			this.options = {

				headings: {

					category: 'Category',

					subject : 'Subject',

					sender_mail: 'Sender mail',

					reciever_mail: 'Reciever mail',

					referee_id : 'Referee id',

					referee_type : 'Referee type',

					created_at: 'Created At',

					updated_at: 'Updated At',

					status: 'Status',

				},

				headingTooltips:{
				    category:'Category'
				},

				columnsClasses : {

					category: 'mail-category',

					subject : 'mail-subject',

					sender_mail: 'mail-sender',

					reciever_mail: 'mail-receiver',

					referee_id: 'mail-refree',

					referee_type: 'mail-refree-type',

					created_at: 'mail-created',

					updated_at: 'mail-updated',

					status: 'mail-status'
				},

				texts: { filter: '', limit: '' },

				templates: {

					category(h,row){

						return row.category.name
					},

					created_at(h, row) {

						return self.formattedTime(row.created_at);
					},

					updated_at(h, row) {

						return self.formattedTime(row.updated_at);
					},

					sender_mail : 'sender',

					reciever_mail : 'receiver',

					referee_id : 'referee-id',

					status : 'mail-status',

					subject: 'mail-subject',
				},

				sortable:  ['category', 'referee_id', 'referee_type', 'sender_mail', 'reciever_mail', 'subject', 'source', 'created_at', 'updated_at','status'],

				filterable:  ['category', 'referee_id', ,'referee_type', 'sender_mail', 'reciever_mail', 'subject', 'source', 'created_at'],

				pagination:{chunk:5,nav: 'fixed',edge:true},

				requestAdapter(data) {

					return {

						sort_field: data.orderBy,

						sort_order: data.ascending ? 'desc' : 'asc',

						search_query:data.query,

						page:data.page,

						limit:data.limit,

					}
				},
				responseAdapter({data}) {
					return {

						data: data.data.data,

						count: data.data.total

					}
				},
			}
		},

		computed:{
			...mapGetters(['formattedTime','formattedDate'])
		},

		methods : {

			onChange(value,name){

				this[name] = value

			}
		},

		components : {

			'dynamic-select': require('components/MiniComponent/FormField/DynamicSelect'),

			'logs-table': require('./ReusableComponent/LogsTable.vue')
		}
	};
</script>

<style>

	.mail-category{
		min-width: 110px;
		word-break: break-all;
	}
	.mail-subject{
		width:300px;
		word-break: break-all;
	}
	.mail-sender,.mail-receiver{
		max-width: 200px;
		word-break: break-all;
	}

	.mail-refree-type{
    width: 120px;
		word-break: break-all;
	}
	.mail-created{
		word-break: break-all;
	}

	.mail-refree{
		max-width: 250px;
		word-break: break-all;
	}

	.mail-status{
		word-break: break-all;
	}

	.mail-log-table #logs_table .VueTables .table-responsive {
		overflow-x: scroll;
	}

	.mail-log-table #logs_table .VueTables .table-responsive > table{
		width : max-content;
		min-width : 100%;
		max-width : max-content;
	}



</style>
