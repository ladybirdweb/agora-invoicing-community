<?php
namespace App\Http\Controllers\Agent\helpdesk\TicketsView;

use Illuminate\Http\Request;
use App\Model\helpdesk\Filters\Filter;
use App\Http\Controllers\Agent\helpdesk\TicketsView\TicketsCategoryController;
use App\Model\helpdesk\Ticket\Ticket_Form_Data;
use App\Model\helpdesk\Filters\Tag;
use App\Model\helpdesk\Filters\Label;
use App\Model\helpdesk\Ticket\Tickets;
use App\Model\helpdesk\Settings\Ticket as TicketSetting;
use Illuminate\Database\Eloquent\Builder as QueryBuilder;
use Carbon;
use Cache;
use App\Traits\CustomTicketList;

/**
 * Handles tickets list view by filtering/searching/arranging tickets 
 * USAGE :
 * Request can have following parameters:
 * 
 *               NAME          |        Possible values
 * category (string, required) : all, inbox, mytickets, closed, unassigned, followup, deleted, unapproved 
 * search-query (string, optional) : any string that has to be searched in tickets in the current category
 * sort-order (string, optional) : asc/desc ( ascending/descending ) for sorting. By default its value is 'desc'
 * sort-field (string, optional) : The field that is required to be sorted. By default its value is 'updated_at'
 * limit (string, optional) : Number of tickets that are reuired to display on a partiular page. By default its value is 10
 * page (string, optional) : current page in the ticket list.By default its value is 1
 * 
 * 
 * 
 * ADVANCED SEARCH FILTER
 * 
 * helptopic-ids (array, optional) 
 * dept-ids (array, optional)
 * priority-ids (array, optional)
 * sla-plan-ids (array, optional)
 * ticket-ids (array, optional)
 * owner-ids (array, optional)
 * assignee-ids (array, optional)
 * team-ids (array, optional)
 * status-ids (array, optional)
 * types (array, optional)
 * source-ids (array, optional)
 * assigned (boolean, optional)
 * answered (boolean, optional)
 * tag-ids (array, optional)   //has to be changed
 * label-ids (array, optional) //has to be changed
 * due-on (datetime in agent's timezone, optional)
 * created-start (datetime in agent's timezone, optional)
 * created-end (datetime in agent's timezone, optional)
 * last-modified-start (datetime in agent's timezone, optional)
 * last-modified-end (datetime in agent's timezone, optional)
 * custom-25738765 (string, optional) // has to be changed to standard one
 * 
 * @author avinash kumar <avinash.kumar@ladybirdweb.com>
 */
class TicketListController extends TicketsCategoryController
{
    use CustomTicketList;

    private $request;

    /**
     * Gets ticket-list depending upon which parameter is passed (mytickets, inbox, unassigned etc)
     * @return array => success response with filtered tickets
     */
    public function getTicketsList(Request $request)
    {
        //gets no of tickets per page from cache else 10
        $ticketsPerPage = (Cache::has('ticket_per_page')) ? Cache::get('ticket_per_page') : 10;
        
        $this->request = $request; //for making it available for all methods
        $limit = $request->input('limit') ? $request->input('limit') : $ticketsPerPage;

        //if search query is not defined
        $searchString = $request->input('search-query') ? $request->input('search-query') : '';

        $sortField = $request->input('sort-field') ? $request->input('sort-field') : 'updated_at';
        $sortOrder = $request->input('sort-order') ? $request->input('sort-order') : 'desc';

        $baseQueryWithoutSearch = $this->baseQueryForTickets();
        $baseQuery = $searchString ? $this->generalSearchQuery($baseQueryWithoutSearch, $searchString) : $baseQueryWithoutSearch;

        $tickets = $baseQuery->select('tickets.id', 'tickets.updated_at','tickets.created_at', 'tickets.status', 'tickets.user_id', 'assigned_to', 'ticket_number', 'help_topic_id', 'tickets.dept_id', 'tickets.priority_id', 'tickets.source', 'duedate', 'isanswered','team_id')
                ->orderBy($sortField, $sortOrder)
                ->paginate($limit)->toArray();

        $formattedTickets = $this->formatTickets($tickets);
        return successResponse('', $formattedTickets);
    }

    /**
     * Takes ticket's base query and appends to it search query according to whether that search parameter is present in the request or not
     * @param $ticketsQuery
     * @return object => query
     */
    private function filteredTickets(QueryBuilder $ticketsQuery) : QueryBuilder
    {
        //tickets created under given help topic(s)
        $this->filteredTicketQueryModifierForArrayFields('helptopic-ids', 'help_topic_id', $ticketsQuery);

        //tickets in a given department(s)
        $this->filteredTicketQueryModifierForArrayFields('dept-ids', 'dept_id', $ticketsQuery);

        //tickets with given priority(s) eg. low, high etc.
        $this->filteredTicketQueryModifierForArrayFields('priority-ids', 'priority_id', $ticketsQuery);

        //tickets with given sla-plans
        $this->filteredTicketQueryModifierForArrayFields('sla-plan-ids', 'sla', $ticketsQuery);

        //tickets by ticket ID(s)
        $this->filteredTicketQueryModifierForArrayFields('ticket-ids', 'id', $ticketsQuery);

        //tickets by status(es)
        $this->filteredTicketQueryModifierForArrayFields('status-ids', 'status', $ticketsQuery);

        //tickets owned by given user(s)
        $this->filteredTicketQueryModifierForArrayFields('owner-ids', 'user_id', $ticketsQuery);

        //tickets assigned to a given user(s)
        $this->filteredTicketQueryModifierForArrayFields('assignee-ids', 'assigned_to', $ticketsQuery);

        //tickets assigned to a given team(s)
        $this->filteredTicketQueryModifierForArrayFields('team-ids', 'team_id', $ticketsQuery);

        //ticket type is types of tickets. for eg. question
        $this->filteredTicketQueryModifierForArrayFields('type-ids', 'type', $ticketsQuery);

        //tickets created through given source(s). for eg. mail, web, facebook
        $this->filteredTicketQueryModifierForArrayFields('source-ids', 'source', $ticketsQuery);

        //tickets which are assigned or unassigned
        //TODO : create a seperate method for handling assigned to by team
        $this->filteredTicketQueryForBoolean('assigned', 'assigned_to', $ticketsQuery);

        //tickets which are answered or not answered
        $this->filteredTicketQueryForBoolean('answered', 'isanswered', $ticketsQuery);

        //tickets for given tags
        $this->filteredTicketsByLabelsAndTags('tag-ids', 'tag', $ticketsQuery);

        //tickets for given label
        $this->filteredTicketsByLabelsAndTags('label-ids', 'label', $ticketsQuery);

        //tickets due in a given time range
        $this->filteredTicketQueryModifierForTimeRange('', 'due-on', 'duedate', $ticketsQuery);

        //tickets with created_at in a given time range
        $this->filteredTicketQueryModifierForTimeRange('created-start', 'created-end', 'created_at', $ticketsQuery);

        //tickets with updated_at in a given time range
        $this->filteredTicketQueryModifierForTimeRange('last-modified-start', 'last-modified-end', 'updated_at', $ticketsQuery);

        //custom fields
        $this->searchByCustomField($ticketsQuery);

        return $ticketsQuery;
    }

    /**
     * Gets the base query for tickets. This query can be appended with searchQuery to get desired result
     * @return QueryBuilder
     */
    private function baseQueryForTickets() : QueryBuilder
    {
        $category = $this->request->input('category') ? $this->request->input('category') : 'all';
        $ticketsQueryByCategory = $this->ticketsQueryByCategory($category);
        
        $ticketsQuery = $ticketsQueryByCategory->with([
            'user:id,user_name,first_name,last_name,profile_pic,email',
            'assigned:id,user_name,first_name,last_name,profile_pic,email',
            'firstThread:id,ticket_id,title',
            'priority:priority_id,priority as name,priority_color',
            'sources:id,name,css_class',
            'assignedTeam:id,name',
            'departments:id,name',
            'statuses:id,name,icon_color,icon'
        ]);

        //getting extra fields according to ticket settings
        $ticketsQuery = $this->getExtraFieldsIfRequired($ticketsQuery);

        //if search filter is required
        $filteredTickets = $this->filteredTickets($ticketsQuery);
        return $filteredTickets;
    }

    /**
     * Gets general search query. (this will only be used by 'baseQueryForTickets' method)
     * @param  QueryBuilder $baseQuery base query
     * @param string $searchString string which has to be searched
     * @return QueryBuilder
     */
    private function generalSearchQuery(QueryBuilder $baseQuery, string $searchString) : QueryBuilder
    {
        //search query for team has to be added too
        return $baseQuery->where(function($q) use ($searchString) {
                $q
                    ->where('ticket_number', 'LIKE', "%$searchString%")
                    ->orwhereHas('user', function($query) use ($searchString) {
                        $query->where('first_name', 'LIKE', "%$searchString%")
                        ->orWhere('last_name', 'LIKE', "%$searchString%")
                        ->orWhere('user_name', 'LIKE', "%$searchString%");
                    })
                    ->orWhereHas('assigned', function($query) use($searchString) {
                        $query->where('first_name', 'LIKE', "%$searchString%")
                        ->orWhere('last_name', 'LIKE', "%$searchString%");
                    })
                    ->orWhereHas('firstThread', function($query) use ($searchString) {
                        $query->where('title', 'LIKE', "%$searchString%");
                    });
            });
    }

    /**
     * check for the passed fieldName in request and appends it query to ticketsQuery from DB
     * NOTE: it is just a helper method for  filteredTickets method and should not be used by other methods
     * @param $fieldNameInRequest string => field name in the request coming from front end
     * @param $fieldNameInDB string => field name in the db by which we query
     * @param $ticketsQuery => it is the base query to which search queries has to be appended.
     *                       This is passed by reference, so at the end of the method it gets updated
     * @return object => query
     */
    private function filteredTicketQueryModifierForArrayFields($fieldNameInRequest, $fieldNameInDB, &$ticketsQuery)
    {
        if ($this->request->input($fieldNameInRequest)) {
            $queryIds = $this->request->input($fieldNameInRequest);
            $ticketsQuery = $ticketsQuery->whereIn($fieldNameInDB, $queryIds);
        }
    }

    /**
     * check for the passed fieldName in request and appends it query to ticketsQuery from DB
     * NOTE: it is just a helper method for  filteredTickets method and should not be used by other methods
     * NOTE: All datetime passed are assumed to be in agent's timezone
     * 
     * @param string $startTimeNameInRequest     The name of start_time of a field in request
     * @param string $endTimeNameInRequest       The name of end_time of a field in request
     * @param string $fieldNameInDB              Field name in the db by which we query
     * @param string $ticketsQuery               It is the base query to which search queries has to be appended.
     *                                           This is passed by reference, so at the end of the method it gets updated
     * @return object                            Query after filtering in timesatmp range
     */
    private function filteredTicketQueryModifierForTimeRange($startTimeNameInRequest, $endTimeNameInRequest, $fieldNameInDB, &$ticketsQuery)
    {
        $endTimestamp = $this->request->input($endTimeNameInRequest);
        $startTimestamp = $this->request->input($startTimeNameInRequest);
        if ($endTimestamp) {

            //covert given timestamp from agent timezone to UTC
            $agentTimeZone = agentTimeZone();
            
            //end time in UTC
            $endTime = changeTimezoneForDatetime($endTimestamp, $agentTimeZone, 'UTC');
            
            // current time in UTC
            $currentTime = Carbon\Carbon::now();
            
            //start time in UTC
            $startTime = $startTimestamp ? changeTimezoneForDatetime($startTimestamp, $agentTimeZone, 'UTC') : $currentTime ;
            
            $ticketsQuery = $ticketsQuery->where($fieldNameInDB, '<=', $endTime)->where($fieldNameInDB, '>=', $startTime);
        }
    }

    /**
     * check for the passed fieldName in request and appends it query to ticketsQuery from DB
     * NOTE: it is just a helper method for  filteredTickets method and should not be used by other methods
     * @param string $fieldNameInRequest        Field name in the request coming from front-end
     * @param string $fieldNameInDB             Field name in the db
     * @param string $ticketsQuery              It is the base query to which search queries has to be appended.
     *                                          This is passed by reference, so at the end of the method it gets updated
     * @return
     */
    private function filteredTicketQueryForBoolean($fieldNameInRequest, $fieldNameInDB, &$ticketsQuery)
    {
        if ($this->request->input($fieldNameInRequest) == '0' || $this->request->input($fieldNameInRequest) == '1') {
     
            $value = $this->request->input($fieldNameInRequest); //will be 0 or 1
            
            //in case of unassigned we also need to check if team_id is null
            //TODO: remove this and use polymorphic relationship in ticket table to store both team_id and user_id in assigned to
            //now it modifies ticketsQuery by appending the condition that both teamId and  
            if($fieldNameInRequest == 'assigned'){
                $ticketsQuery = $value ? $ticketsQuery->where(function($q){
                                        $q->where('assigned_to','!=',null)->orWhere('team_id','!=',null);
                                    }) : 
                        $ticketsQuery->where('team_id',null)->where('assigned_to',null);
            }
            else{
                
                //only this part is required for this method to work. Above if part is a workaround until
                // we change the tickets table to use polymorphic relationship for assigned to
                $ticketsQuery = $value ? $ticketsQuery->where($fieldNameInDB, '!=', null)->where($fieldNameInDB,'!=',0): 
                        $ticketsQuery->where(function($q) use ($fieldNameInDB){
                          $q->where($fieldNameInDB, null)->orWhere($fieldNameInDB, 0);  
                        });    
            }
            
            
        }
    }

    /**
     * check for the passed fieldName in request and appends it query to ticketsQuery from DB
     * NOTE: it is just a helper method for  filteredTickets method and should not be used by other methods
     * @param $type => either its tag or label
     * @param $ticketsQuery => it is the base query to which search queries has to be appended.
     *                       This is passed by reference, so at the end of the method it gets updated
     * @return
     */
    private function filteredTicketsByLabelsAndTags($type, $fieldNameInDB, $ticketsQuery)
    {
        if ($this->request->input($type)) {
            
            //value is an array of tags/labels
            $value = $this->request->input($type);
            
            //NOTE: it is a temporary solution for tags/labels to work until DB changes are merged 
            //find tag names in tag table
            if($fieldNameInDB == 'tag'){
                $names = Tag::whereIn('id',$value)->select('name')->pluck('name')->toArray();
            }
            if($fieldNameInDB == 'label'){
                $names = Label::whereIn('id',$value)->select('title')->pluck('title')->toArray();
            }
            
            $ticketIds = Filter::where('key', $fieldNameInDB)->whereIn('value', $names)->select('id', 'ticket_id')->pluck('ticket_id')->toArray();
            $ticketsQuery = $ticketsQuery->whereIn('id', $ticketIds);
        }
    }

    /**
     * Simply, formats unformatted ticket ( nothing fancy at all )
     * @param $tickets => tickets with raw relationships(unformatted)
     * @return object => formatted list of tickets with $limit parameter
     */
    private function formatTickets($tickets)
    {
        $agentTimeZone = agentTimeZone();
        
        $tickets['tickets'] = [];
        foreach ($tickets['data'] as $ticket) {
            $ticket['from'] = $ticket['user'];
            $ticket['title'] = utfEncoding($ticket['first_thread']['title']);
            $ticket['status'] = $ticket['statuses'];
            $ticket['source'] = $ticket['sources'];
            $ticket['priority']['id'] = $ticket['priority']['priority_id'];
            $ticket['department'] = $ticket['departments'];
            
            $ticket['is_overdue'] = Tickets::isOverdue($ticket['duedate']);
            
            $ticket['due_today'] = Tickets::isDueToday($ticket['duedate'], $agentTimeZone);
            unset($ticket['user'], $ticket['user_id'], $ticket['assigned_to'], $ticket['help_topic_id'], $ticket['dept_id'], $ticket['priority_id'], $ticket['first_thread'], $ticket['statuses'], $ticket['sources'], $ticket['priority']['priority_id'], $ticket['departments']);
    
            $this->formatExtraFields($ticket);
            
            array_push($tickets['tickets'], $ticket);
        }

        unset($tickets['data'], $tickets['first_page_url'], $tickets['last_page_url'], $tickets['next_page_url'], $tickets['prev_page_url'], $tickets['path'], $tickets['to'], $tickets['source']);
        return $tickets;
    }

    /**
     * Simply, formats unformatted ticket ( nothing fancy at all )
     * @param object $ticketsQuery it is the base query to which search queries has to be appended.
     *                       This is passed by reference, so at the end of the method it gets updated
     * @return object ticketsQuery appended with custom field search query
     */
    private function searchByCustomField(&$ticketsQuery)
    {
        foreach ($this->request->all() as $key => $value) {
            if (strpos($key, 'custom-') === 0) {
                $customFieldKey = explode('-', $key)[1];
                $ticketsIds = Ticket_Form_Data::where('key', $customFieldKey)->where('content', 'LIKE', "%$value%")->pluck('ticket_id')->toArray();
                $ticketsQuery = $ticketsQuery->whereIn('id', $ticketsIds);
            }
        }
    }


    /**
     * gets ticket numbers based on search string. Search string can be ticket subject or ticket number
     * @param  Request $request 
     * @return Response           
     */
    public function getSuggestionsByTicketSubjectOrNumber(Request $request)
    {
        $searchString = $request->input('search-query') ? $request->input('search-query') : '';
        $limit = $request->input('limit') ? $request->input('limit') : 10;
        $category = $request->input('category') ? $request->input('category') : 'all';
        $ticketsQuery = $this->ticketsQueryByCategory($category);

        $tickets = $ticketsQuery->with('firstThread:id,title,ticket_id')
                ->where(function($q) use($searchString) {
                    $q->whereHas('firstThread', function($q) use($searchString) {
                        $q->where('title', 'LIKE', "%$searchString%");
                    })->orWhere('ticket_number', 'LIKE', "%$searchString%");
                })->select('id', 'ticket_number')
                ->orderBy('updated_at','DESC')
                ->take($limit)->get();

        //formatting tickets
        $formattedTickets = [];
        $i = 0;
        foreach ($tickets as $ticket) {
            $formattedTickets[$i]['id'] = $ticket['id'];
            $formattedTickets[$i]['ticket_number'] = $ticket['ticket_number'];
            $formattedTickets[$i]['title'] = $ticket['firstThread']['title'];
            $i = $i + 1;
        }

        return successResponse('', ['tickets' => $formattedTickets]);
    }
}
