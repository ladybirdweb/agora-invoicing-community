<?php

namespace App\Http\Requests\helpdesk;

use App\Http\Requests\Request;

/**
 * Sys_userRequest.
 *
 * @author  Ladybird <info@ladybirdweb.com>
 */
class WorkflowCreateRequest extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'workflow.name'          => 'required|max:50|unique:workflow_name,name,'.$this->segment(3),
            //'workflow.order'       => 'required',
            'workflow.target'        => 'required',
            'rules'                  => 'required',
            'rules.*.matching_value' => 'required_with:rules.*.matching_scenario',
            'actions'                => 'required',
            'actions.*.action'       => 'required_with:actions.*.condition',
            'actions.*.condition'       => function($attribute, $value, $fail) {
                $array = array_map(function($value){
                    return $value['condition'];
                }, $this->request->all()['actions']);
                if (in_array('team', $array) && in_array('assigned_to', $array)) {
                    $attribute = trans('lang.workflow-actions');
                    return $fail(trans('lang.select_either_agent_or_team', ['attr' => $attribute])); 
                }
            }
        ];
    }
}
