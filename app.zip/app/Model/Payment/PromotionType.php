<?php

namespace App\Model\Payment;

use Illuminate\Database\Eloquent\Model;
use App\BaseModel;
class PromotionType extends BaseModel
{
    protected $table = 'promotion_types';
}
