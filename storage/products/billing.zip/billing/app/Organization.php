<?php

namespace App;

class Organization extends BaseModel
{
    protected $table = 'organization';
}
