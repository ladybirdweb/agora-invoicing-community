<?php

namespace App\Http\Controllers\Admin\helpdesk;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Exception;
use App\Model\helpdesk\TicketRecur\Recur;
use App\Model\helpdesk\TicketRecur\RecureContent;

class TicketRecurController extends Controller
{

    /**
     * Recure model id
     * @var int 
     */
    public $recure_id;

    /**
     * Requesters of recuring
     * @var array 
     */
    public $requesters;

    /**
     * Subject of the ticket
     * @var string 
     */
    public $subject;

    /**
     * Body of the ticket
     * @var string 
     */
    public $body;

    /**
     * Help tipic id of the ticket
     * @var int 
     */
    public $help_topic;

    /**
     * Priority id of the ticket
     * @var int 
     */
    public $priority;

    /**
     * Type of the ticket
     * @var int 
     */
    public $type;

    /**
     * Ticket assigned agent
     * @var int 
     */
    public $assigned;

    /**
     * Status id of the ticket
     * @var int 
     */
    public $status;

    /**
     * Collaborators of the ticket
     * @var array 
     */
    public $cc;

    /**
     * Company id associated with requester
     * @var id 
     */
    public $company;

    /**
     * Attachment of the ticket
     * @var array 
     */
    public $attachments;

    /**
     * Custom field of the ticket
     * @var array 
     */
    public $extra_form;

    /**
     * Department of the ticket
     * @var int 
     */
    public $department;

    /**
     * Source id of the ticket
     * @var int 
     */
    public $source;

    /**
     * Inline images of the ticket 
     * @var array 
     */
    public $inline;

    /**
     * Extra attachment to the ticket (Custom attachment field)
     * @var array 
     */
    public $files;

    /**
     * Get the value from the RecureContent model
     * @param string $option
     * @return RecureContent
     */
    public function getOptions($option)
    {
        return RecureContent::where('recur_id', $this->recure_id)->where('option', $option)->value('value');
    }
    /**
     * Set the requester parameter
     * @return void
     */
    public function setRequesters()
    {
        $requesters = $this->getOptions('requester');
        if ($requesters) {
            $this->requesters = explode(',', $requesters);
        }
    }
    /**
     * Set the subject parameter
     * @return void
     */
    public function setSubject()
    {
        $this->subject = $this->getOptions('subject');
    }
    /**
     * Set the body parameter
     * @return void
     */
    public function setBody()
    {
        $this->body = $this->getOptions('description');
    }
    /**
     * Set the helptopic of the ticket
     * @return void
     */
    public function setHelptopic()
    {
        $this->help_topic = $this->getOptions('help_topic');
    }
    /**
     * Set the department of the ticket
     * @return void
     */
    public function setDepartment()
    {
        $department = $this->getOptions('department');
        if (!$department && $this->help_topic) {
            $department = departmentByHelptopic($this->help_topic);
        }
        $this->department = $department;
    }
    /**
     * Set the source of the ticket
     * @return void
     */
    public function setSource()
    {
        $source = $this->getOptions('source');
        if (!$source) {
            $source = \App\Model\helpdesk\Ticket\Ticket_source::select('id')->value('id');
        }
        $this->source = $source;
    }
    /**
     * Set the priority of the ticket
     * @return void
     */
    public function setPriority()
    {
        $this->priority = $this->getOptions('priority');
    }
    /**
     * Set the type of the ticket
     * @return void
     */
    public function setType()
    {
        $this->type = $this->getOptions('type');
    }
    /**
     * Set the assigned agent of the ticket
     * @return void
     */
    public function setAssigned()
    {
        $this->assigned = $this->getOptions('assigned');
    }
    /**
     * Set the status of the ticket
     * @return void
     */
    public function setStatus()
    {
        $this->status = $this->getOptions('status');
    }
    /**
     * Set the collaborator of the ticket
     * @return void
     */
    public function setCc()
    {
        $this->cc = '';
        $cc       = $this->getOptions('cc');
        if ($cc) {
            $this->cc = explode(',', $cc);
        }
    }
    /**
     * Set the company of the ticket
     * @return void
     */
    public function setCompany()
    {
        $this->company = $this->getOptions('company');
    }
    /**
     * Set the attachment of the ticket
     * @return void
     */
    public function setAttachments()
    {
        $this->attachments = [];
        $json              = $this->getOptions('media_attachment');
        if ($json) {
            $this->attachments = json_decode($json, true);
        }
    }
    /**
     * Set the online of the ticket
     * @return void
     */
    public function setInline()
    {
        $this->inline = [];
        $json         = $this->getOptions('inline');
        if ($json) {
            $this->inline = json_decode($json, true);
        }
    }
    /**
     * Set the extra files of the ticket
     * @return void
     */
    public function setFiles()
    {
        $this->files = [];
        $json        = $this->getOptions('files');
        if ($json) {
            $this->files = json_decode($json, true);
        }
    }
    /**
     * Set the custom field values of the ticket
     * @return void
     */
    public function setExtraForm()
    {
        $this->extra_form = RecureContent::where('recur_id', $this->recure_id)
                ->whereNotIn('option', [
                    'requester', 'subject', 'body', 'help_topic', 'priority', 'type',
                    'assigned', 'status', 'cc', 'company', 'attachments', 'description', 'department', 'linkHelpTopic',
                ])
                ->pluck('value', 'option')
                ->toArray();
    }
    /**
     * Create ticket via Job
     * @param int $recur_id
     * @return void
     */
    public function createTicket($recur_id)
    {
        $this->recure_id = $recur_id;
        $this->setAssigned();
        $this->setAttachments();
        $this->setInline();
        $this->setBody();
        $this->setCc();
        $this->setCompany();
        $this->setExtraForm();
        $this->setHelptopic();
        $this->setDepartment();
        $this->setPriority();
        $this->setStatus();
        $this->setSubject();
        $this->setType();
        $this->setRequesters();
        $this->setSource();
        $this->setFiles();
        if (is_array($this->requesters) && count($this->requesters) > 0) {
            foreach ($this->requesters as $requester) {
                $tickets = $this->ticketValues($requester);
                dispatch(new \App\Jobs\RecurTicket($tickets));
            }
        }
    }
    /**
     * Arrange the ticket parameters
     * @param int $requester
     * @return array
     */
    public function ticketValues($requester)
    {
        $tickets = [
            'requester'     => $requester,
            'subject'       => $this->subject,
            'help_topic'    => $this->help_topic,
            'body'          => $this->body,
            'sla'           => '',
            'priority'      => $this->priority,
            'source'        => $this->source,
            'cc'            => $this->cc,
            'dept'          => $this->department,
            'assigned'      => $this->assigned,
            'extra_form'    => $this->extra_form,
            'status'        => "",
            'type'          => $this->type,
            'attachments'   => array_merge($this->attachments, $this->files),
            'inline'        => $this->inline,
            'email_content' => "",
            'company'       => $this->company,
        ];
        return $tickets;
    }
    /**
     * Get the index page of the Recure
     * @return \Response
     */
    public function index()
    {
        try {
            $items = Recur::with('content')
                    ->get();
            return view('themes.default1.admin.helpdesk.recur.index', compact('items'));
        } catch (Exception $ex) {
            return redirect()->back()->with('fails', $ex->getMessage());
        }
    }
    /**
     * Get the create page of the Recure
     * @return \Response
     */
    public function create()
    {
        try {
            return view('themes.default1.admin.helpdesk.recur.create');
        } catch (Exception $ex) {
            return redirect()->back()->with('fails', $ex->getMessage());
        }
    }
    /**
     * Get the edit page of the Recure
     * @return \Response
     */
    public function edit($id)
    {
        try {
            $recur = Recur::with('content')
                    ->whereId($id)
                    ->first()
            //->toJson()
            ;
            return view('themes.default1.admin.helpdesk.recur.edit', compact('recur'));
        } catch (Exception $ex) {
            return redirect()->back()->with('fails', $ex->getMessage());
        }
    }
    /**
     * Save Recure Model
     * @return \Response
     */
    public function store(Request $request)
    {
        $this->validation($request);
        try {
            $recur       = $request->input('recur');
            $ticket      = $request->input('ticket');
            $recur_id    = $request->input('recur_id');
            $recur_model = new Recur();
            $this->recurSave($recur, $ticket, $recur_model, $request);
            $message     = trans('lang.saved_successfully');
            $status_code = 200;
        } catch (Exception $ex) {
            $message     = $ex->getMessage();
            $status_code = 500;
        }
        return $this->jsonResponse($message, $status_code);
    }
    /**
     * Update Recure Model
     * @return \Response
     */
    public function update($id, Request $request)
    {
        $this->validation($request);
        try {
            $recur_model = Recur::find($id);
            $recur       = $request->input('recur');
            $ticket      = $request->input('ticket');
            $this->recurSave($recur, $ticket, $recur_model, $request);
            $message     = trans('lang.updated_successfully');
            $status_code = 200;
        } catch (Exception $ex) {
            $message     = $ex->getMessage();
            $status_code = 500;
        }
        return $this->jsonResponse($message, $status_code);
    }
    /**
     * Looping the value to save Recure Model
     * @return \Response
     */
    public function recurSave($recur, $ticket, $model, $request)
    {
        $fill = [];
        foreach ($recur as $key => $value) {
            if ($key == 'end_date' && !$value) {
                $value = null;
            }
            $fill[$key] = $value;
        }
        $model->fill($fill)->save();
        $files = $request->file();
        if (count($ticket) > 0) {
            foreach ($ticket as $key => $value) {
                if ($key == 'inline' || $key == 'media_attachment') {
                    $value = $this->getFileArray([], $value);
                }
                elseif (is_array($value)) {
                    $value = implode(',', $value);
                }
                RecureContent::updateOrCreate(['recur_id' => $model->id,
                    'option'   => $key,
                        ], ['value' => $value]);
            }
            if (checkArray('ticket', \Input::file())) {
                RecureContent::updateOrCreate([
                    'recur_id' => $model->id,
                    'option'   => 'files',
                        ], [
                    'value' => $this->getFileArray($files)
                ]);
            }
        }
        return $model;
    }
    /**
     * Return the Json response
     * @param string $message
     * @param int $code
     * @return \Response
     */
    public function jsonResponse($message, $code)
    {
        $m = ['message' => [$message]];
        if ($code != 200) {
            $m = ['error' => [$message]];
        }
        return response()->json($m, $code);
    }
    /**
     * create the ticket via execution
     * @return vide
     */
    public function recur()
    {
        try {
            $this->mailController()->setQueue();
            $recur_ids = $this->execution();
            if (count($recur_ids) > 0) {
                foreach ($recur_ids as $id) {
                    $this->createTicket($id);
                    $this->updateRecur($id);
                }
            }
        } catch (\Exception $e) {
            loging('recurring', $e->getMessage() . ' Line=>' . $e->getLine() . " File=>" . $e->getFile());
        }
    }
    /**
     * Update the Recur model with executuion time
     * @param int $id
     */
    public function updateRecur($id)
    {
        Recur::updateOrCreate(['id' => $id], [
            'last_execution' => \Carbon\Carbon::now(),
        ]);
    }
    /**
     * Initaiate the execution
     * @return array
     */
    public function execution()
    {
        $now   = \Carbon\Carbon::now();
        $recur = Recur::select('id', 'interval', 'delivery_on', 'last_execution')
                ->whereDate('start_date', '<=', $now)
                ->where(function ($query) use($now) {
                    $query->whereDate('end_date', '>', $now)
                    ->orWhereNull('end_date');
                })
                ->get();
        $ids = $this->checking($recur);
        return $ids;
    }
    /**
     * Get the ids of the recure model
     * @param \Collection $recur
     * @return array
     */
    public function checking($recur)
    {
        $id = [];
        if ($recur->count() > 0) {
            foreach ($recur as $item) {
                $id[] = $this->getIdToExecute($item);
            }
        }
        return array_filter($id);
    }
    /**
     * Get the execution period
     * @param string $item
     * @return boolean
     */
    public function getIdToExecute($item)
    {
        $check = "";
        switch ($item->interval) {
            case "daily":
                if (!$item->last_execution || !$item->last_execution->isToday()) {
                    $check = $item->id;
                }
                break;
            case "weekly":
                if (!$item->last_execution || $item->last_execution->isLastWeek()) {
                    $check = $item->id;
                }
                break;
            case "monthly":
                if (!$item->last_execution || $item->last_execution->isLastMonth()) {
                    $check = $item->id;
                }
                break;
            case "yearly":
                if (!$item->last_execution || $item->last_execution->isLastYear()) {
                    $check = $item->id;
                }
                break;
        }
        return $check;
    }
    /**
     * Validate the input data
     * @param Request $request
     */
    public function validation($request)
    {
        $this->validate($request, $this->rules($request), $this->validateMessage());
    }
    /**
     * Rules to validate the input data
     * @param Request $request
     * @return array
     */
    public function rules($request)
    {
        $require = 'nullable';
        if ($request->has('recur.interval') && $request->input('recur.interval')
                != 'daily') {
            $require = 'required';
        }
        $rules = [
            'recur.start_date'  => 'required',
            'recur.interval'    => 'required',
            'recur.end_date'    => 'required_if:end,by',
            'recur.delivery_on' => $require
        ];
        return $rules;
    }
    /**
     * Message to to show validate fail message
     * @return array
     */
    public function validateMessage()
    {
        $message = [
            'recur.start_date.required'  => 'Start date required',
            'recur.interval.required'    => 'Interval required',
            'recur.end_date.required_if' => 'End date required',
            'recur.delivery_on.required' => 'Every required',
        ];
        return $message;
    }
    /**
     * Get the email controller class
     * @return \App\Http\Controllers\Common\PhpMailController
     */
    public function mailController()
    {
        return new \App\Http\Controllers\Common\PhpMailController();
    }
    /**
     * Deleting the recure
     * @param int $id
     * @return \Response
     */
    public function delete($id)
    {
        try {
            $recur = Recur::find($id);
            if ($recur) {
                $recur->delete();
            }
            return redirect()->back()->with('success', \Lang::get('lang.recur-deleted-successfully', ['recur' => $recur->interval]));
        } catch (\Exception $e) {
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }
    /**
     * Return the storage controller class
     * @return \App\FaveoStorage\Controllers\StorageController
     */
    public function storage()
    {
        return new \App\FaveoStorage\Controllers\StorageController();
    }
    /**
     * Rteunr extra files in an array
     * @param array $files
     * @param array $media
     * @return json
     */
    public function getFileArray($files, $media = array())
    {
        $files = checkArray('ticket', $files);
        //echo count($files) . PHP_EOL;
        if (is_array($files)) {
            foreach ($files as $file) {
                if (is_array($file)) {
                    foreach ($file as $attach) {
                        //echo $attach->getRealPath() . PHP_EOL;
                        $media[] = $this->storage()->saveObjectAttachments("", $attach, true);
                    }
                }
            }
        }
        return json_encode($media);
    }
}
