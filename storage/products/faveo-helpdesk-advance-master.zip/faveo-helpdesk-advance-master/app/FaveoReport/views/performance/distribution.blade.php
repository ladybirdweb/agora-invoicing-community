@extends('themes.default1.agent.layout.agent')
@section('Staffs')
active
@stop

@section('staffs-bar')
active
@stop

@section('Report')
class="active"
@stop

<!-- header -->
@section('PageHeader')
<h1>{!! Lang::get('report::lang.performance-distribution') !!}</h1>
@stop
<!-- /header -->
<!-- breadcrumbs -->
@section('breadcrumbs')
<ol class="breadcrumb">
</ol>
@stop
@section('content')
<style>
    .loader{
        position: fixed;
        z-index: 99;
        height: 2em;
        width: 5em;
        overflow: show;
        margin: auto;
        top: 0;
        bottom: 0;
        left: 50%;
        right: 50%;
    }
    .loader:before {
        content: '';
        display: block;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
    }
</style>
<div class="box box-primary">
    <div class="box-header">
        <button class="btn btn-primary" onclick="showhidefilter();">{!! Lang::get('report::lang.filter') !!}</button>
        @include('report::indepth.filter')
    </div>
    <div class="box-body">
        <div class="row">
            <div class="col-md-12">
                <div class="box-header">
                    <h3>{!! Lang::get('report::lang.first-response-avg-response-and-avg-resolution-time') !!}</h3>
                </div>
            </div>
            <div class="col-md-4" style="height: 300px;">
                <canvas id="first-response-time"></canvas>
            </div>
            <div class="col-md-4" style="height: 300px;">
                <canvas id="avg-response-time"></canvas>
            </div>
            <div class="col-md-4" style="height: 300px;">
                <canvas id="resolution-time"></canvas>
            </div>
        </div><br>
        <div class="row">
            <div class="col-md-12">
                <div class="box-header">
                    <h3>{!! Lang::get('report::lang.avg-first-response-and-response-time-trend') !!}</h3>
                </div>
                <div class="btn-group pull-right">
                    <button class="btn btn-default period" value="day">{!! Lang::get('report::lang.day') !!}</button>
                    <button class="btn btn-default period" value="week">{!! Lang::get('report::lang.week') !!}</button>
                    <button class="btn btn-default period" value="month">{!! Lang::get('report::lang.month') !!}</button>
                    <button class="btn btn-default period" value="year">{!! Lang::get('report::lang.year') !!}</button>
                </div>
            </div>
            <div class="col-md-12">
                <canvas id="firstresponse-response-trend"></canvas>
            </div>
        </div>
    </div>
</div>
<div id="loader" class="loader">
    <img src="{{ url(assetLink('image','gifloader3')) }}" style="width: 50px; opacity: 0.7">
</div>
@stop
@section('FooterInclude')
<script src="{{assetLink('js','chart')}}"></script>
<script>
    var options_bar = {
        scales: {
            xAxes: [{
                stacked: true,
                scaleLabel: {
                    display: true,
                    labelString: 'Ticket Count',
                    fontStyle:'bold',
                },
                ticks: {
                    beginAtZero: true,
                    min: 0,
                    suggestedMin: 0,
                    callback: function(value, index, values) {
                        if (Math.floor(value) === value) {
                            return value;
                        }
                    }
                },
                gridLines: {
                    display:false
                },
            }],
            yAxes: [{
                stacked: true,
                barThickness: 10,
                scaleLabel: {
                    display: true,
                    labelString: 'Duration',
                    fontStyle:'bold',
                },
                gridLines: {
                    display:false
                },
            }],
        },
        responsive: true,
        maintainAspectRatio: false,
    };
    var options_line = {
        scales: {
            xAxes: [{
                scaleLabel: {
                    display: true,
                    labelString: 'Day',
                    fontStyle:'bold',
                },
                gridLines: {
                    display:false
                },
            }],
            yAxes: [{
                scaleLabel: {
                    display: true,
                    labelString: 'Rating',
                    fontStyle:'bold',
                },
                gridLines: {
                    display:false
                },
                ticks: {
                    beginAtZero: true,
                    min: 0,
                    suggestedMin: 0,
                    callback: function(value, index, values) {
                        if (Math.floor(value) === value) {
                            return value;
                        }
                    }
                },
            }],
        },
    };
    var filterData;
    var firstRespChart = false;
    var avgRespChart = false;
    var resolChart = false;
    var respTrendChart = false;
    Chart.plugins.register({
        afterDraw: function(chart) {
            var emptyChart = true;
            $.each(chart.data.datasets, function(index, el) {
                if (el.data.length > 0) emptyChart = false;
            });
            
            if (emptyChart) {
                  var ctx = chart.chart.ctx;
                  var width = chart.chart.width;
                  var height = chart.chart.height;
                  var img = $('<img/>');
                  img.attr('src', '{{ url(assetLink("image","nodatafound")) }}');
                  chart.clear();
                  ctx.save();                 
                  $(chart.canvas).siblings('.chart-filter').hide();
                  ctx.drawImage(img[0], width / 2 - img[0].width / 2, height / 2 - img[0].height / 2);
                  ctx.restore();
            } else {
                $(chart.canvas).siblings('.chart-filter').show();
            }
        }
    });    
    function ucFirst(string) {
        return string.charAt(0).toUpperCase() + string.slice(1);
    }
    function firstResponseAjax(canvas, data = "") {
        $.ajax({
            type: "GET",
            dataType: "json",
            url: "{{url('report/performance/first_response')}}",
            data: data,
            beforeSend: function() {
                $('#loader').show();
            },
            success: function (data) {
                $('#loader').hide();
                var ctx = $(canvas).get(0).getContext("2d");
                if (firstRespChart) {
                    firstRespChart.data.labels = data.chart.labels;
                    firstRespChart.data.datasets = data.chart.datasets;
                    firstRespChart.update();
                } else {
                    firstRespChart = new Chart(ctx, {
                        type: 'horizontalBar',
                        data: data.chart,
                        options: options_bar
                    });
                }
            },
            error: function (error) {}
        });
    }
    function avgResponseAjax(canvas, data = "") {
        $.ajax({
            type: "GET",
            dataType: "json",
            url: "{{url('report/performance/avg_response')}}",
            data: data,
            beforeSend: function(){
                $('#loader').show();
            },
            success: function (data) {
                $('#loader').hide();
                var ctx = $(canvas).get(0).getContext("2d");
                if (avgRespChart) {
                    avgRespChart.data.labels = data.chart.labels;
                    avgRespChart.data.datasets = data.chart.datasets;
                    avgRespChart.update();
                } else {
                    avgRespChart = new Chart(ctx, {
                        type: 'horizontalBar',
                        data: data.chart,
                        options: options_bar
                    });
                }                
            },
            error: function (error) {}
        });
    }
    function resolutionAjax(canvas, data = "") {
        $.ajax({
            type: "GET",
            dataType: "json",
            url: "{{url('report/performance/avg_resolution')}}",
            data: data,
            beforeSend: function() {
                $('#loader').show();
            },
            success: function (data) {
                $('#loader').hide();
                var ctx = $(canvas).get(0).getContext("2d");
                if (resolChart) {
                    resolChart.data.labels = data.chart.labels;
                    resolChart.data.datasets = data.chart.datasets;
                    resolChart.update();
                } else {
                    resolChart = new Chart(ctx, {
                        type: 'horizontalBar',
                        data: data.chart,
                        options: options_bar
                    });
                }                
            },
            error: function (error) {}
        });
    }
    function responseTrendsAjax(period, canvas, data = "") {
        $.ajax({
            type: "GET",
            dataType: "json",
            url: "{{url('report/performance/first_response_response_trend')}}",
            data: "period=" + period + "&" + data,
            beforeSend: function(){
                $('#loader').show();
            },
            success: function (data) {
                options_line.scales.xAxes[0].scaleLabel.labelString = ucFirst(period);
                $('#loader').hide();
                var ctx = $(canvas).get(0).getContext("2d");
                if (respTrendChart) {
                    respTrendChart.data.labels = data.data.labels;
                    respTrendChart.data.datasets = data.data.datasets;
                    respTrendChart.options = options_line;
                    respTrendChart.update();
                } else {
                    respTrendChart = new Chart(ctx, {
                        type: 'line',
                        data: data.data,
                        options: options_line
                    });
                }
            },
            error: function (error) {}
        });
    }
    $(function() {
        firstResponseAjax("#first-response-time", "");
        avgResponseAjax("#avg-response-time",  "");
        resolutionAjax("#resolution-time", "");
        responseTrendsAjax('day', "#firstresponse-response-trend", "");

        $('.period').click(function () {
            filterData = $("#filter").serialize();
            responseTrendsAjax($(this).attr("value"), "#firstresponse-response-trend", filterData);
        });

        $("#submit-filter").click(function () {
            filterData = $("#filter").serialize();
            firstResponseAjax("#first-response-time", filterData);
            avgResponseAjax("#avg-response-time", filterData);
            resolutionAjax("#resolution-time", filterData);
            responseTrendsAjax('day', "#firstresponse-response-trend", filterData);
        });
    });
</script>
@stop
