<?php

namespace App\Http\Controllers\Agent\helpdesk;

// controllers
use App\Http\Controllers\Controller;
// requests
use App\Http\Requests\helpdesk\OrganizationRequest;
/* include organization model */
use App\Http\Requests\helpdesk\OrganizationUpdate;
// models
/* Define OrganizationRequest to validate the create form */
use App\Model\helpdesk\Agent_panel\Organization;
use App\Model\helpdesk\Agent_panel\OrganizationDepartment;
use App\Model\helpdesk\Agent_panel\User_org;
/* Define OrganizationUpdate to validate the create form */
use App\User;
// classes
use Exception;
use Lang;
use Illuminate\Http\Request;
use Datatables;
use DB;
use File;
use Auth;
use App\FaveoStorage\Controllers\StorageController;
use Illuminate\Support\Facades\Storage;
use Validator;
use App\Model\helpdesk\Manage\Sla\BusinessHours;

/**
 * OrganizationController
 * This controller is used to CRUD organization detail.
 *
 * @author      Ladybird <info@ladybirdweb.com>
 */
class OrganizationController extends Controller {

    protected $ticket_policy;

    /**
     * Create a new controller instance.
     * constructor to check
     * 1. authentication
     * 2. user roles
     * 3. roles must be agent.
     *
     * @return void
     */
    public function __construct() {
        // checking for authentication
        $this->middleware('auth');
        // checking if the role is agent
        $this->middleware('role.agent');
        $this->ticket_policy = new \App\Policies\TicketPolicy();
    }

    /**
     * Display a listing of the resource.
     *
     * @param type Organization $org
     *
     * @return type Response
     */
    public function index() {
        try {
            $table = \ Datatable::table()
                    ->addColumn(
                            Lang::get('lang.name'), Lang::get('lang.phone'), Lang::get('lang.action'))  // these are the column headings to be shown
                    ->noScript();
            /* get all values of table organization */
            return view('themes.default1.agent.helpdesk.organization.index', compact('table'));
        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }

    /**
     * This function is used to display the list of Organizations.
     *
     * @return datatable
     */
    public function org_list(Request $request) {
        // dd($request->all());
        $organization_list = \DB::table('organization')->select('name', 'website', 'phone', 'id');
        // chumper datable package call to display Advance datatable
        return \DataTables::of($organization_list)
                        ->removeColumn('id', 'website')
                        ->editColumn('name', function($model) {
                            if (strlen($model->name) > 30) {

                                // return '<a href="'.route('organizations.show', $model->id).'" class="btn btn-primary btn-xs">'.mb_substr($model->name, 0, 30, 'UTF-8') . '...</a>';

                                return '<a  href="' . route('organizations.show', $model->id) . '" title="' . $model->name . '">' . mb_substr($model->name, 0, 30, 'UTF-8') . '...</a>';

                                // return '<p title="' . $model->name . '">' . mb_substr($model->name, 0, 30, 'UTF-8') . '...</p>';
                            } else {


                                return '<a  href="' . route('organizations.show', $model->id) . '" title="' . $model->name . '">' . $model->name . '</a>';


                                // return $model->name;
                            }
                        })
                        ->addColumn('action', function($model) {
                            return '<span  data-toggle="modal" data-target="#deletearticle' . $model->id . '"><a href="#" ><button class="btn btn-primary btn-xs"></a><i class="fa fa-trash" style="color:white;">&nbsp; </i> </i> ' . \Lang::get('lang.delete') . ' </button></span>&nbsp;&nbsp;'
                                    . '<a href="' . route('organizations.edit', $model->id) . '" class="btn btn-primary btn-xs"><i class="fa fa-edit" style="color:white;">&nbsp;&nbsp; </i>' . \Lang::get('lang.edit') . '</a>&nbsp;&nbsp;'
                                    . '<a href="' . route('organizations.show', $model->id) . '" class="btn btn-primary btn-xs"><i class="fa fa-eye" style="color:white;">&nbsp;&nbsp; </i>' . \Lang::get('lang.view') . '</a>
                <div class="modal fade" id="deletearticle' . $model->id . '">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                <h4 class="modal-title">' . Lang::get('lang.delete') . '</h4>
                            </div>
                            <div class="modal-body">
                                ' . Lang::get('lang.confirm-to-proceed') . '
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default pull-left" data-dismiss="modal" id="dismis2"><i class="fa fa-times" aria-hidden="true">&nbsp;&nbsp;</i>' . Lang::get('lang.close') . '</button>
                                <a href="' . route('org.delete', $model->id) . '" class="btn btn-danger" onclick="clickAndDisable(this);"><i class="fa fa-trash">&nbsp;&nbsp;</i>'.Lang::get('lang.delete').'</a>

                            </div>
                        </div><!-- /.modal-content -->
                    </div><!-- /.modal-dialog -->
                </div><script> 
   function clickAndDisable(link) {
     // disable subsequent clicks
     link.onclick = function(event) {
        event.preventDefault();
     }
   }   
</script>';
                        })
                        ->rawColumns(['name', 'action'])
                        ->make();
    }

    /**
     * Show the form for creating a new organization.
     *
     * @return type Response
     */
    public function create() {
        try {
            return view('themes.default1.agent.helpdesk.organization.create');
        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }

    /**
     * Store a newly created organization in storage.
     *
     * @param type Organization        $org
     * @param type OrganizationRequest $request
     *
     * @return type Redirect
     */
    public function store(Organization $org, OrganizationRequest $request) {
        try {
        

            $list_of_domains = $request->domain;
            if ($list_of_domains) {
                foreach ($list_of_domains as $list_of_domain) {
                    $querys = DB::table('organization')
                                    ->where('domain', '!=', "")
                                    ->whereRaw('FIND_IN_SET(?,domain)', [$list_of_domain])
                                    ->pluck('id as org_id')->toArray();

                    if ($querys) {
                        return redirect()->back()->with('fails', Lang::get('lang.domain_name_already_taken'));
                    }
                }
            }
            $orgss = new Organization();
            $orgss->name = $request->name;
            $orgss->phone = $request->phone;
            $orgss->website = $request->website;
            $orgss->address = $request->address;
            $orgss->internal_notes = $request->internal_notes;
            $list_of_domain_name = $request->domain;

            if ($list_of_domain_name) {
                $domain_name_string = implode(",", $list_of_domain_name);
                $orgss->domain = $domain_name_string;
            } else {
                $orgss->domain = "";
            }
            if ($request->client_Code) {
                $orgss->client_Code = $request->client_Code;
                $orgss->phone1 = $request->phone1;
                $orgss->line_of_business = $request->line_of_business;
                $orgss->relation_type = $request->relation_type;
                $orgss->branch = $request->branch;
                $orgss->fax = $request->fax;
            }

            $orgss->save();
          
            return redirect('organizations')->with('success', Lang::get('lang.organization_saved_successfully'));
        } catch (Exception $e) {
            /* redirect to Index page with Fails Message */
            return redirect('organizations')->with('fails', Lang::get('lang.organization_can_not_create'));
        }
    }

    /**
     * Display the specified organization.
     *
     * @param type              $id
     * @param type Organization $org
     *
     * @return type view
     */
    public function show($id, Organization $org) {
        try {
            /* select the field by id  */
            $orgs = Organization::
                    with(['extraField' => function($q) {
                            $q->select('value', 'key', 'org_id')->pluck('value', 'key')->toArray();
                        }])
                    ->whereId($id)
                    ->first();

            // $orgs = $org->whereId($id)->first();
            $org_heads_check = User_org::where('org_id', '=', $id)->where('role', '!=', 'members')->select('user_id')->get();
            if (!$org_heads_check->isEmpty()) {

                $org_heads_ids = User_org::where('org_id', '=', $id)->where('role', '!=', 'members')->pluck('user_id')->toArray();
                foreach ($org_heads_ids as $org_heads_id) {
                    $org_heads_emails[] = user::where('id', '=', $org_heads_id)->pluck('id')->first();
                }
            } else {
                $org_heads_emails = 0;
            }

            $ticket_policy = $this->ticket_policy;
            $org_heads = User_org::where('org_id', '=', $id)->where('role', '!=', 'members')->select('user_id')->get();
            if (!$org_heads->isEmpty()) {

                foreach ($org_heads as $org_head) {

                    $userss[] = User::where('id', '=', $org_head->user_id)->select('id', 'email', 'user_name', 'phone_number', 'first_name', 'last_name')->first();
                }
            } else {
                $userss = 0;
            }
            $user = User::all();
            if ($orgs->logo) {


                $path = $orgs->logo;
                $type = pathinfo($path, PATHINFO_EXTENSION);
                $image = file_get_contents($orgs->logo);

                $base64 = 'data:image/' . $type . ';base64,' . base64_encode($image);
            } else {

                $base64 = "";
            }
            /* To view page */
            return view('themes.default1.agent.helpdesk.organization.show', compact('base64', 'user', 'orgs', 'userss', 'org_heads_emails', 'ticket_policy'));
        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }

    /**
     * Show the form for editing the specified organization.
     *
     * @param type              $id
     * @param type Organization $org
     *
     * @return type view
     */
    public function edit($id, Organization $org) {
        try {
            /* select the field by id  */
            $orgs = $org->whereId($id)->first();
            if ($orgs->domain) {
                $selected_domain_name = explode(",", $orgs->domain);
            } else {
                $selected_domain_name = " ";
            }
            // dd($selected_domain_name);
            // dd($orgs->phone);
            /* To view page */
            return view('themes.default1.agent.helpdesk.organization.edit', compact('orgs', 'selected_domain_name'));
        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }

    /**
     * Update the specified organization in storage.
     *
     * @param type                    $id
     * @param type Organization       $org
     * @param type OrganizationUpdate $request
     *
     * @return type Redirect
     */
    public function update($id, Organization $org, OrganizationUpdate $request) {
        try {
            /* select the field by id  */
            // $orgs = $org->whereId($id)->first();
            // /* update the organization table   */
            // /* Check whether function success or not */
            // if ($orgs->fill($request->input())->save() == true) {
            //     /* redirect to Index page with Success Message */
            //     return redirect('organizations')->with('success', Lang::get('lang.organization_updated_successfully'));
            // } else {
            //     /* redirect to Index page with Fails Message */
            //     return redirect('organizations')->with('fails', Lang::get('lang.organization_can_not_update'));
            // }
            $list_of_domains = $request->domain;
            if ($list_of_domains) {
                foreach ($list_of_domains as $list_of_domain) {
                    $querys = DB::table('organization')
                                    ->where('id', '!=', $id)
                                    ->where('domain', '!=', "")
                                    ->whereRaw('FIND_IN_SET(?,domain)', [$list_of_domain])
                                    ->pluck('id as org_id')->toArray();

                    if ($querys) {
                        return redirect()->back()->with('fails', Lang::get('lang.domain_name_already_taken'));
                    }
                }
            }
            $orgss = $org->whereId($id)->first();
            $orgss->name = $request->name;
            $orgss->phone = $request->phone;
            $orgss->website = $request->website;
            $orgss->address = $request->address;
            $orgss->internal_notes = $request->internal_notes;
            $list_of_domain_name = $request->domain;
            if ($list_of_domain_name) {
                $domain_name_string = implode(",", $list_of_domain_name);
                $orgss->domain = $domain_name_string;
            } else {
                $orgss->domain = "";
            }
            if ($request->client_Code) {
                $orgss->client_Code = $request->client_Code;
                $orgss->phone1 = $request->phone1;
                $orgss->line_of_business = $request->line_of_business;
                $orgss->relation_type = $request->relation_type;
                $orgss->branch = $request->branch;
                $orgss->fax = $request->fax;
            }
            $orgss->save();
            // $emailDomainOnly = preg_replace('/.+@/', '', $all_user->email);
            // dd($all_user);
            return redirect('organizations')->with('success', Lang::get('lang.organization_updated_successfully'));
        } catch (Exception $e) {
            //            dd($e);
            /* redirect to Index page with Fails Message */
            return redirect('organizations')->with('fails', $e->getMessage());
        }
    }

    /**
     * Delete a specified organization from storage.
     *
     * @param type int $id
     *
     * @return type Redirect
     */
    public function destroy($id, Organization $org, User_org $user_org) {
        try {

             $querys = DB::table('sla_plan')
                            ->whereRaw('FIND_IN_SET(?,apply_sla_company)', [$id])
                            ->pluck('id')->toArray();
            if ($querys) {
            return redirect()->back()->with('fails', Lang::get('lang.you_cannot_delete_this_organization,organization_associated_sla_plan'));
            }
            OrganizationDepartment::where('org_id','=',$id)->delete();

           
            /* select the field by id  */
            $orgs = $org->whereId($id)->first();
            $user_orgs = $user_org->where('org_id', '=', $id)->get();
            foreach ($user_orgs as $user_org) {
                $user_org->delete();
            }
            /* Delete the field selected from the table */
            /* Check whether function success or not */
            $orgs->delete();
            /* redirect to Index page with Success Message */
            return redirect('organizations')->with('success', Lang::get('lang.organization_deleted_successfully'));
        } catch (Exception $e) {
            /* redirect to Index page with Fails Message */
            return redirect('organizations')->with('fails', $e->getMessage());
        }
    }

    public function getHrdname(Request $request, $org_id) {
        try {
            $term = trim($request->q);
            if (empty($term)) {
                return \Response::json([]);
            }

            $orgs = Organization::select('id', 'domain')->where('id', '=', $org_id)->first();
            $user_orga_relations = \App\Model\helpdesk\Agent_panel\User_org::where('org_id', '=', $orgs->id)->pluck('user_id')->toArray();
            $users = $user_orga_relations;
            if ($orgs['domain'] != '') {
                $str = str_replace(",", '|@', '@' . $orgs['domain']);
                $domain_users = \App\User::select('id')->where('role', '=', 'user')->whereRaw("email REGEXP '" . $str . "'")->whereNOtIn('id', $users);
                $domain_users = $domain_users->where('is_delete', '!=', 1)->where('ban', '!=', 1)->get()->toArray();
                if (count($domain_users) > 0) {
                    $users = array_merge($users, array_column($domain_users, 'id'));
                }
            }

           $org_user = \App\User::wherein('id', $users)->where('ban', '!=', 1)->where('active', '=', 1)->where('is_delete','!=',1)
                                                 ->when($term, function($q) use($term) {
                                $q->where(function($org_user) use($term) {
                                    $org_user->select('email','id', 'first_name', 'last_name', 'profile_pic')
                                    ->where('first_name', 'LIKE', '%' . $term . '%')
                                    ->orwhere('last_name', 'LIKE', '%' . $term . '%')
                                    ->orwhere('user_name', 'LIKE', '%' . $term . '%')
                                    ->orwhere('email', 'LIKE', '%' . $term . '%');
                                });
                                  })->get();

           $formatted_tags = [];
            foreach ($org_user as $org) {
                $formatted_orgs[] = ['id' => $org->id, 'text' => $org->email,'profile_pic' => $org->profile_pic,'first_name'=>$org->first_name,'last_name'=>$org->last_name ];
            }
            return \Response::json($formatted_orgs);
        } catch (\Exception $e) {
            // returns if try fails with exception meaagse
            return \Response::json([]);
        }
    }

  /**
 * This method create organization manager
 * @param Request $request
 * @return type Redirect
 */
public function createOrgManager(Request $request)
    {
        try {
            $orgManagerUserIds = $request->user;

            if (!count($orgManagerUserIds)) {
                return redirect()->back()->with('fails1', Lang::get('lang.please_select_manager'));
            }
            else{
            User_org::where('org_id', $request->org_id)->update(['role' => 'members']);
            
               foreach ($orgManagerUserIds as $userid) {
                   User_org::where('org_id', $request->org_id)->where('user_id', $userid)->update(['role' => 'manager']);
                }
            return redirect()->back()->with('success1', Lang::get('lang.organization_updated_successfully'));
            }
        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }

    /**
 * This method edit organization manager
 * @param Request $request
 * @return type Redirect
 */
    public function editOrgManager(Request $request)
    {
        try {
            $orgManagerUserIds = $request->user;
            User_org::where('org_id', $request->org_id)->update(['role' => 'members']);
            if($orgManagerUserIds){
                foreach ($orgManagerUserIds as $userid) {
                User_org::where('org_id', $request->org_id)->where('user_id', $userid)->update(['role' => 'manager']);
               }
            }
            
            return redirect()->back()->with('success1', Lang::get('lang.organization_updated_successfully'));
        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }

    /**
     * Display the specified organization.
     *
     * @param type              $id
     * @param type Organization $org
     *
     * @return type view
     */
    public function HeadDelete(Request $request) {
        try {
            $user_id = $request->user_id;
            $org_head = User_org::where('org_id', '=', $orgs_id)->where('user_id', '=', $user_id)->delete();
            // return redirect('themes.default1.agent.helpdesk.organization.show')->with('success', Lang::get('lang.organization_maneger_delete_successfully'));
            return 'maneger successfully delete';
        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }

    /**
     * get the report of organizations.
     *
     * @param type $id
     * @param type $date111
     * @param type $date122
     *
     * @return type array
     */
    public function orgChartData($id, $date111 = '', $date122 = '') {

// $a = array($id);
// $result = array_reduce($a,array());
// dd($result);
//         dd(explode(",",$id));
        $date11 = strtotime($date122);
        $date12 = strtotime($date111);
        if ($date11 && $date12) {
            $date2 = $date12;
            $date1 = $date11;
        } else {
            // generating current date
            $date2 = strtotime(date('Y-m-d'));
            $date3 = date('Y-m-d');
            $format = 'Y-m-d';
            // generating a date range of 1 month
            $date1 = strtotime(date($format, strtotime('-1 month' . $date3)));
        }
        $return = '';
        $last = '';
        for ($i = $date1; $i <= $date2; $i = $i + 86400) {
            $thisDate = date('Y-m-d', $i);

            $user_orga_relation_id = [];

            $user_orga_relations = User_org::where('org_id', '=', $id)->pluck('user_id')->ToArray();


            if ($user_orga_relations) {


                foreach ($user_orga_relations as $user_orga_relation) {
                    $user_orga_relation_id[] = $user_orga_relation;
                }
                $created = \DB::table('tickets')->select('created_at')->whereIn('user_id', $user_orga_relation_id)->where('created_at', 'LIKE', '%' . $thisDate . '%')->count();
                $closed = \DB::table('tickets')->select('closed_at')->whereIn('user_id', $user_orga_relation_id)->where('closed_at', 'LIKE', '%' . $thisDate . '%')->count();
                $reopened = \DB::table('tickets')->select('reopened_at')->whereIn('user_id', $user_orga_relation_id)->where('reopened_at', 'LIKE', '%' . $thisDate . '%')->count();
            } else {
                $created = 0;
                $closed = 0;
                $reopened = 0;
            }
            $value = ['date' => date('j M', $i), 'open' => $created, 'closed' => $closed, 'reopened' => $reopened];
            $array = array_map('htmlentities', $value);
            $json = html_entity_decode(json_encode($array));
            $return .= $json . ',';
        }
        $last = rtrim($return, ',');
        $users = User::whereId($id)->first();

        return '[' . $last . ']';
    }

    public function getOrgAjax(Request $request) {
        $org = new Organization();
        $q = $request->input('term');
        $orgs = $org->where('name', 'LIKE', '%' . $q . '%')
                ->select('name as label', 'id as value')
                ->get()
                ->toJson();
        return $orgs;
    }

    /**
     * This function is used autofill organizations name .
     *
     * @return datatable
     */
    public function organizationAutofill() {
        return view('themes.default1.agent.helpdesk.organization.getautocomplete');
    }

    public function createOrgApi(OrganizationRequest $request) {
        try {

        $validator = Validator::make($request->all(), [
            
            "domain.*" => 'max:60|regex:/^([A-Z0-9.-]+\.[A-Z]{2,5})$/i',
        ]);
          if (!$validator->passes()) {
             $fail = $validator->errors();
             
            foreach(json_decode($fail) as $key => $value){
                return response()->json(['error' =>Lang::get('lang.enter_valid_domain_name')], 500);
            }
        }

      
            $list_of_domains = $request->domain;

            if ($list_of_domains) {

                foreach ($list_of_domains as $list_of_domain) {
                    $querys = DB::table('organization')
                                    ->where('domain', '!=', "")
                                    ->whereRaw('FIND_IN_SET(?,domain)', [$list_of_domain])
                                    ->pluck('id as org_id')->toArray();

                    if ($querys) {
                        $fail = Lang::get('lang.domain_name_already_taken');
                        return response()->json(['message1' => $fail], 500);
                        return redirect()->back()->with('fails', Lang::get('lang.domain_name_already_taken'));
                    }
                }
            }


            $domain = $request->domain;
            if ($domain) {
                $domain_name = implode(",", $domain);
            } else {
                $domain_name = " ";
            }

            $default = ['name', 'phone', 'website', 'address', 'head', 'internal_notes', 'domain', 'department', 'organization_logo'];
            $extra = $request->except($default);
            $org = new Organization();
            $org->name = $request->name;
            $org->phone = $request->phone;
            $org->address = $request->address;
            $org->head = $request->head;
            $org->internal_notes = $request->internal_notes;
            $org->save();
            $organization = Organization::where('id', '=', $org->id)->first();
            $organization->domain = $domain_name;

            $organization->save();

            $department = $request->department;


            if ($department) {
                $department_names = $request->department;
                foreach ($department_names as $department_name) {
                    $org_dept = new OrganizationDepartment();
                    $org_dept->org_id = $organization->id;
                    $org_dept->org_deptname = $department_name;
                    $org_dept->business_hours_id = null;
                    $org_dept->save();
                }
            } else {
                $department_name = " ";
            }

            if (count($extra) > 0) {

                foreach ($extra as $key => $value) {
                    $org->extraField()->create([
                        'key' => $key,
                        'value' => $value
                    ]);
                }
            }



            if ($request->file('organization_logo')) {
                $files = $request->file('organization_logo');
                $root_path = (new StorageController)->root();
                $logo_name = $files[0]->getClientOriginalName();
                $fileName = rand(0000, 9999) . '.' . $logo_name;
                $check = uploadInLocal($files[0], $root_path, $fileName);
                $org = Organization::where('id', '=', $org->id)->first();
                $org->logo = $root_path . DIRECTORY_SEPARATOR . $fileName;
                $org->save();
            }

            // $model = $org->create($request->input());
            // if (count($extra) > 0) {
            //     foreach ($extra as $key => $value) {
            //         $model->extraField()->create([
            //             'key' => $key,
            //             'value' => $value
            //         ]);
            //     }
            // }
            return response()->json(['message' => Lang::get('lang.organization_saved_successfully')]);
        } catch (\Exception $e) {
            dd($e);
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    public function editOrgApi($id) {
        $org = Organization::
                with(['extraField' => function($q) {
                        $q->select('value', 'key', 'org_id')->pluck('value', 'key')->toArray();
                    }])
                ->whereId($id)
                ->first();


        if ($org->extraField) {
            $org->extraField->transform(function($value) {
                return [$value->key => $value->value];
            });
        }
        if ($org->domain) {
            $org_domains = explode(",", $org->domain);
        } else {
            $org_domains = "";
        }
        $org_dept = OrganizationDepartment::where('org_id', '=', $id)->pluck('org_deptname')->take(100);
        if ($org->logo) {
            $path = $org->logo;
            $type = pathinfo($path, PATHINFO_EXTENSION);
            $image = file_get_contents($org->logo);
            $base64 = 'data:image/' . $type . ';base64,' . base64_encode($image);
        } else {
            $base64 = "";
        }
        $response = ['organization_details' => $org->toArray(), 'org_dept' => $org_dept, 'org_domain' => $org_domains, 'logo' => $base64];

        return response()->json($response);

        return $org;
    }

    public function updateOrgApi($id, OrganizationUpdate $request) {
          try {
            $validator = Validator::make($request->all(), [
                        "domain.*" => 'max:60|regex:/^([A-Z0-9.-]+\.[A-Z]{2,5})$/i',
            ]);
            if (!$validator->passes()) {
                $fail = $validator->errors();
                foreach (json_decode($fail) as $key => $value) {
                    return response()->json(['error' => $value], 500);
                }
            }
            $listOfDomains = $request->domain;
            if ($listOfDomains) {
                foreach ($listOfDomains as $listOfDomain) {
                    $querys = DB::table('organization')
                                    ->where('id', '!=', $id)
                                    ->where('domain', '!=', "")
                                    ->whereRaw('FIND_IN_SET(?,domain)', [$listOfDomain])
                                    ->pluck('id')->toArray();
                    if ($querys) {
                        $fail = Lang::get('lang.domain_name_already_taken');
                        return response()->json(['message' => $fail], 500);
                    }
                }
            }
            $domainName = ($request->domain) ? implode(",", $request->domain) : " ";
            $default = ['name', 'phone', 'website', 'address', 'head', 'internal_notes', 'domain', 'department', 'organization_logo', 'delete_logo'];
            $extra = $request->except($default);
            $org = Organization::where('id', $id)->update(['name' => $request->name, 'phone' => $request->phone, 'address' => $request->address, 'head' => $request->head, 'internal_notes' => $request->internal_notes, 'domain' => $domainName]);

            if ($request->department) {
                $organizationDeptIds = OrganizationDepartment::whereIn('org_deptname', $request->department)->pluck('id');
                OrganizationDepartment::select('id')->whereNotIn('id', $organizationDeptIds)->where('org_id', $id)->delete();
                $departmentNames = $request->department;
                foreach ($departmentNames as $departmentName) {
                    OrganizationDepartment::updateOrCreate(['org_deptname' => $departmentName, 'org_id' => $id]);
                }
            }
            else{
                 OrganizationDepartment::where('org_id', $id)->delete();
            }

            $orgDeptIds=User_org::where('id','!=',0)->where('org_department','!=',null)->pluck('org_department')->toArray();
            if($orgDeptIds){
                User_org::whereNotIn('id',$orgDeptIds)->update(['org_department'=>null]);
            }
            $org =Organization::where('id', $id)->first();
            if (count($extra) > 0) {
                $org->extraField()->where('org_id', $id)->delete();
                foreach ($extra as $key => $value) {
                    $org->extraField()->Create([
                        'key' => $key,
                        'value' => $value
                    ]);
                }
            }
            if ($request->delete_logo == true && $org->logo) {
                $fullPath = $org->logo;
                File::delete($fullPath);
                Organization::where('id', $id)->update(['logo' => ""]);
            }
            if ($request->file('organization_logo')) {
                if ($org->logo) {
                    $fullPath = $org->logo;
                    File::delete($fullPath);
                }
                $files = $request->file('organization_logo');
                $root_path = (new StorageController)->root();
                $logo_name = $files[0]->getClientOriginalName();
                $fileName = rand(0000, 9999) . '.' . $logo_name;
                $check = uploadInLocal($files[0], $root_path, $fileName,$root_path);
                $org = Organization::where('id', $id)->first();
                $org->logo = $root_path . DIRECTORY_SEPARATOR . $fileName;
                $org->save();
            }
            return response()->json(['message' => Lang::get('lang.organization_updated_successfully')]);
        } catch (\Exception $e) {
            dd($e);
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    /**
     * This method Edit organization Department
     * @param type $orgId of the Organization
     * @param \Illuminate\Http\Request $request
     * return Type json
     */
    public function EditOrgDept($orgId, Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                 'org_deptname'   => 'required|max:25',
            ]);
          if (!$validator->passes()) {
                return response()->json(['error' => $validator->errors()->all()]);
            }
            $check=OrganizationDepartment::where('org_id', $orgId)->where('id','!=',$request->input('deptId'))->where('org_deptname',$request->input('org_deptname'))->count();

            if($check == 1){
                return response()->json(['error' => [Lang::get('lang.the_org_deptname_has_already_been_taken')]]);
            }
           
            $managerId = ($request->input('managerId')) ? $request->input('managerId')[0] : null;
            OrganizationDepartment::where('org_id', $orgId)->where('id', $request->input('deptId'))->update(['org_deptname' => $request->input('org_deptname'), 'business_hours_id' => $request->input('businessHoursId'), 'org_dept_manager' => $managerId]);
            return response()->json(['success' => Lang::get('lang.updated_successfully')]);
        } catch (Exception $e) {
            dd($e);
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }

/**
 * This method return user list of particuler organization
 * @param type $orgId of Organization
 * @return type json
 */
    public function getOrgUserList(int $orgId)
    {
        try {
            $userId = User_org::where('org_id', $orgId)->pluck('user_id')->toArray();
            $users = User::whereIn('id', $userId)->select('id', 'first_name', 'last_name', 'user_name', 'phone_number', 'email', 'ban', 'active','email_verify','mobile_otp_verify','is_delete');
           
            return \DataTables::of(User::whereIn('id', $userId)->select('id', 'first_name', 'last_name', 'user_name', 'phone_number', 'email', 'ban', 'active','email_verify','mobile_otp_verify','is_delete')->take(100))
                            ->removeColumn('id')
                            ->setTotalRecords($users->count())
                            ->editColumn('first_name', function($users) {

                                 return '<a  href="' . route('user.show', $users->id) . '" title="' . $users->fullName . '">' . str_limit(($users->fullName)?$users->fullName:'Not Available ',15) . '</a>';
                               
                            })
                            ->editColumn('email', function($users) {
                                return '<span  title="' . $users->email . '">' . mb_substr($users->email, 0, 15, 'UTF-8') . '...</span>';


                            })
                            ->editColumn('phone_number', function($users) {
                                return $users->phone_number;
                            })
                            ->editColumn('active', function($users) {
                               return  UserController::userStatus($users);
                            })
                       
                            ->addColumn('action', function($users) {

                                return "<a href=" . route('user.edit', $users->id) . " class='btn btn-primary btn-xs'><i class='fa fa-edit' style='color:white;''> </i>&nbsp;&nbsp;" . Lang::get('lang.edit') . "</a>
                               &nbsp;&nbsp;
                              
                                <a href=" . route('user.show', $users->id) . " class='btn btn-primary btn-xs'><i class='fa fa-eye' style='color:white;'> </i>&nbsp;&nbsp;" . Lang::get('lang.view') . "</a>";
                            })
                            
                            ->rawColumns(['first_name', 'email', 'phone_number', 'active', 'action'])
                            ->make(true);
        } catch (Exception $e) {
          
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }
/**
 * This methode return user list of organization department
 * @param type $orgId of the Organization
 * @param type $deptId of Organizationdepartment
 * @param Request $request
 * @return type json
 */
    public function getOrgDeptUserList(int $orgId, int $deptId, Request $request)
    {
        try {
           
            $deptId = OrganizationDepartment::where('id', $deptId)->value('id');

            $userId = User_org::where('org_id',$orgId)->where('org_department', $deptId)->pluck('user_id')->toArray();
            $users = User::whereIn('id', $userId)->select('id', 'first_name', 'last_name', 'user_name', 'email', 'ban', 'active');
            return \DataTables::of($users->take(100))
                            ->removeColumn('id')
                            ->setTotalRecords($users->count())
                            ->editColumn('user_name', function($users) {

                                if ($users->first_name && $users->last_name) {
                                    return "<a href=" . route('user.show', $users->id) . ">" . $users->first_name . ' ' . $users->last_name . "</a>";
                                } else {
                                    return "<a href=" . route('user.show', $users->id) . ">" . $users->user_name . "</a>";
                                }
                            })
                            ->editColumn('email', function($users) {
                                return $users->email;
                            })
                            ->rawColumns(['user_name', 'email'])
                            ->make(true);
        } catch (Exception $e) {
            
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }
/**
 * 
 * @param type $orgId of Organization
 * @param Request $request
 * @return type
 */
    public function getOrgDeptList(int $orgId, Request $request)
    {
        try {

            $orgDeptIds = OrganizationDepartment::where('org_id', $orgId)->pluck('id')->toArray();
            $orgDept = OrganizationDepartment::whereIn('id', $orgDeptIds)->select('id', 'org_deptname', 'business_hours_id', 'org_dept_manager');


            return \DataTables::of(OrganizationDepartment::whereIn('id', $orgDeptIds)->select('id', 'org_deptname', 'business_hours_id', 'org_dept_manager')->take(100)->get())
                            ->removeColumn('id')
                             ->setTotalRecords($orgDept->count())
                            ->editColumn('org_deptname', function($orgDept) {
                                return "<span title=" . $orgDept->org_deptname . ">" . str_limit($orgDept->org_deptname, 20) . "</span>";
                            })
                            ->editColumn('business_hours_id', function($orgDept) {

                                $businessHours = BusinessHours::where('id', $orgDept->business_hours_id)->value('name');
                                $businessHoursName = ($businessHours) ? $businessHours : null;
                                
                                return "<span   title='".$businessHoursName."'>".str_limit($businessHoursName, 20) ."</span>";
                            })
                            ->editColumn('org_dept_manager', function($orgDept) {
                              
                                if ($orgDept->org_dept_manager) {
                                    $UserDetails = User::where('id', $orgDept->org_dept_manager)->select('first_name', 'last_name', 'user_name', 'email')->first();

                                    $managerName = null;
                                    if ($UserDetails) {
                                        $managerName = ($UserDetails->first_name != null || $UserDetails->last_name != null) ? $UserDetails->first_name . ' ' . $UserDetails->last_name : $UserDetails->user_name;
                                    }
                                    return "<span title=" . $managerName . ">" . str_limit($managerName, 20) . "</span>";
                                }
                            })
                            ->addColumn('action', function($orgDept) {
                                $deptManager=($orgDept->org_dept_manager) ? $orgDept->org_dept_manager : 0;

                                return "<a href='' class='btn btn-primary btn-xs' data-toggle='modal' data-target='#micro_org_view' data-deptid=" . $orgDept->id . "><i class='fa fa-edit' style='color:white;''> </i>&nbsp;&nbsp;" . Lang::get('lang.user_list') . "</a>
                               &nbsp;&nbsp;
                              
                                <a href='' class='btn btn-primary btn-xs' data-toggle='modal' data-target='#micro_org_edit' data-deptid=" . $orgDept->id . " data-deptname=" . $orgDept->org_deptname . " data-deptmanager=".$deptManager." data-businesshours=" . $orgDept->business_hours_id . "><i class='fa fa-eye' style='color:white;'> </i>&nbsp;&nbsp;" . Lang::get('lang.edit') . "</a>&nbsp;&nbsp;
                              
                                <a href='' class='btn btn-primary btn-xs' data-toggle='modal' data-target='#deleteDept' data-deptid=" . $orgDept->id . " data-deptname=" . $orgDept->org_deptname . "><i class='fa fa-trash' style='color:white;'> </i>&nbsp;&nbsp;" . Lang::get('lang.delete') . "</a>";
                            })
                            ->rawColumns(['org_deptname', 'business_hours_id', 'org_dept_manager', 'action'])
                            ->make(true);
        } catch (Exception $e) {
           
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }
    /**
     * this method create organization department
     * @param type $orgId of Organization
     * @param Request $request
     * @return string
     */
    public function createNewOrgDept(int $orgId, Request $request)
    {

        try {
            $validator = Validator::make($request->all(), [
                        "org_deptname" => 'required|max:25',
            ]);

            if (!$validator->passes()) {
                return response()->json(['error' => $validator->errors()->all()]);
            }

            $check=OrganizationDepartment::where('org_id', $orgId)->where('org_deptname',$request->input('org_deptname'))->count();

            if($check == 1){
                return response()->json(['error' => [Lang::get('lang.the_org_deptname_has_already_been_taken')]]);
            }


            //Store organization department
            $managerId = ($request->input('managerId')) ? $request->input('managerId')[0] : null;

            OrganizationDepartment::create(['org_id' => $orgId, 'org_deptname' => $request->input('org_deptname'), 'business_hours_id' => $request->input('businessHoursId'), 'org_dept_manager' => $managerId]);

            return response()->json(['success' => Lang::get('lang.organization_department_created_successfully')]);
        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }

    /**
 * this method deleting organization department
 * @param Request $request
 * @return string
 */
    public function deleteOrgDept(Request $request)
    {
        try {
            OrganizationDepartment::where('id', $request->input('deptId'))->delete();
            return Lang::get('lang.organization_department_deleted_successfully');
        } catch (Exception $e) {

            return redirect()->back()->with('fails', $e->getMessage());
        }
    }

}
