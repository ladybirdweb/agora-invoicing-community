<?php

namespace App\Http\Controllers\Agent\helpdesk\TicketsView;

use App\Http\Controllers\Controller;
use App\Model\helpdesk\Agent\Department;
use App\Model\helpdesk\Ticket\TicketFilter;
use App\Model\helpdesk\Ticket\TicketFilterMeta;
use App\User;
use Auth;
use Cache;
use Exception;
use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Http\Request;
use Lang;
use Validator;

class TicketFilterController extends Controller
{
    /**
     * Get list of ticket filters of logged in user
     *
     * @return \Illuminate\Http\Response json
     */
    public function index()
    {
        try {
            // Get current authenticated user
            $currentUser = Auth::user();

            // Get shared ticket filters
            $ticketFilterIds = $currentUser->ticketFilterShares()->pluck('ticket_filter_id')->toArray();

            // Get shared ticket filters of current user's department
            $users = User::where('id', $currentUser->id)->with('departments.ticketFilterShares')->first();
            foreach ($users->departments as $departments) {
                $deptFilterIds = $departments->ticketFilterShares()->pluck('ticket_filter_id')->toArray();

                foreach ($deptFilterIds as $filterId) {
                    array_push($ticketFilterIds, $filterId);
                }
            }

            // Filter created by currnet user
            $data['own'] = $currentUser->ticketFilters()->where('status', 1)->get(['id', 'name']);

            // Filter shared with current user
            $data['shared'] = TicketFilter::where('status', 1)
                ->whereIn('id', array_unique($ticketFilterIds))
                ->where('user_id', '<>', $currentUser->id)
                ->get(['id', 'name']);

            // Filter is remembered
            $data['selected_filter_id'] = $this->getSelectedFilterId();

            return successResponse('', $data);
        } catch (Exception $e) {
            return errorResponse($e->getMessage());
        }
    }

    /**
     * Get ticket filter fields of logged in user
     *
     * @param $ticketFilter int Id of ticket filter
     * @return \Illuminate\Http\Response json
     */
    public function show($ticketFilter)
    {
        try {
            // Get current authenticated user
            $currentUser = Auth::user();

            $ticketFilter = TicketFilter::find($ticketFilter);

            // Check if ticket filter exists
            if (is_null($ticketFilter)) {
                return errorResponse(Lang::get('lang.ticket-filter-not-found'));
            }

            $ownFilter = $ticketFilter->user_id == $currentUser->id;

            $sharedFilter = $ticketFilter->whereHas('sharedUsers', function ($query) use ($currentUser) {
                $query->where([
                    ['ticket_filter_shareable_id', $currentUser->id],
                    ['ticket_filter_shareable_type', User::class],
                ])->orWhere(function ($query) use ($currentUser) {
                    $query->whereIn('ticket_filter_shareable_id', $currentUser->departments()
                            ->pluck('department.id')
                            ->toArray())
                        ->where('ticket_filter_shareable_type', Department::class);
                });
            })->get()->toArray();

            // Check if current user has access to this ticket filter
            if ($ownFilter === false && empty($sharedFilter)) {
                return errorResponse(Lang::get('lang.ticket-filter-not-found'));
            }

            // Ticket filter data
            $data['id']         = $ticketFilter->id;
            $data['name']       = $ticketFilter->name;
            $data['created_at'] = $ticketFilter->created_at->toDateTimeString();
            $data['updated_at'] = $ticketFilter->updated_at->toDateTimeString();

            // Is current user is the owner
            $data['is_shareable'] = $ownFilter;

            // Ticket filter fields
            $data['fields'] = $ticketFilter->filterMeta()->get(['key', 'value']);

            // Ticket filter shared with departments
            $data['departments'] = Department::whereHas('ticketFilterShares', function ($query) use ($ticketFilter) {
                $query->where('ticket_filter_id', $ticketFilter->id);
            })->get(['id', 'name']);

            // Ticket filter shared with agents
            $agents = User::whereHas('ticketFilterShares', function ($query) use ($ticketFilter) {
                $query->where('ticket_filter_id', $ticketFilter->id);
            })->get(['id', 'first_name', 'last_name', 'user_name']);

            $data['agents'] = $agents->map(function ($item) {
                return [
                    'id'   => $item->id,
                    'name' => $item->full_name,
                ];
            });

            return successResponse('', $data);
        } catch (Exception $e) {
            return errorResponse($e->getMessage());
        }
    }

    /**
     * Store a ticket filter of logged in user
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response json
     */
    public function store(Request $request)
    {
        // Validate request data
        $this->validateInputs($request);

        try {
            // If update action
            if ($request->has('id') && $request->id != 0) {
                // Find ticket filter
                $ticketFilter = TicketFilter::find($request->id);

                // If ticket filter not found
                if (is_null($ticketFilter)) {
                    return errorResponse(Lang::get('lang.ticket-filter-not-found'));
                }

                $this->update($request, $ticketFilter);
            } else {
                // Get current authenticated user
                $currentUser = Auth::user();

                // Store ticket filter data
                $ticketFilter = $currentUser->ticketFilters()->create([
                    'name'   => $request->name,
                    'status' => 1,
                ]);

                // Store filter fields
                foreach ($request->fields as $field => $field_data) {
                    $ticketFilter->filterMeta()->create([
                        'key'   => $field,
                        'value' => $field_data,
                    ]);
                }
            }

            // Store ticket filter sharing
            $this->saveTicketFilterSharing($request, $ticketFilter);

            return successResponse(Lang::get('lang.ticket-filter-save-successful'), $ticketFilter->first());
        } catch (Exception $e) {
            return errorResponse($e->getMessage());
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\TicketFilter  $ticketFilter
     * @return \Illuminate\Http\Response
     */
    public function destroy($ticketFilter)
    {
        try {
            // Find ticket filter
            $ticketFilter = TicketFilter::find($ticketFilter);

            // If ticket filter not found
            if (is_null($ticketFilter)) {
                return errorResponse(Lang::get('lang.ticket-filter-not-found'));
            }

            // Remove filter fields
            $ticketFilter->filterMeta()->delete();

            // Remove shared user if exists
            if ($ticketFilter->has('sharedUsers')) {
                $ticketFilter->sharedUsers()->detach();
            }

            // Remove shared department if exists
            if ($ticketFilter->has('sharedDepartments')) {
                $ticketFilter->sharedDepartments()->detach();
            }

            // Remove ticket filter
            $ticketFilter->delete();

            return successResponse(Lang::get('lang.ticket-filter-delete-successful'));
        } catch (Exception $e) {
            return errorResponse($e->getMessage());
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\TicketFilter  $ticketFilter
     * @return \Illuminate\Http\Response
     */
    protected function update(Request $request, TicketFilter $ticketFilter)
    {
        // Update ticket filter
        $ticketFilter->name = $request->name;

        $ticketFilter->save();

        // Update filter fields
        foreach ($request->fields as $field => $field_data) {
            $ticketFilterMeta = new TicketFilterMeta;

            $ticketFilterMeta->key   = $field;
            $ticketFilterMeta->value = $field_data;

            $ticketFilter->filterMeta()->save($ticketFilterMeta);
        }
    }

    /**
     * Store ticket filter sharing
     *
     * @param \Illuminate\Http\Request  $request
     * @return Void
     */
    private function saveTicketFilterSharing($request, $ticketFilter)
    {
        // share with agents
        if ($request->has('agents')) {
            foreach ($request->agents as $user_id) {
                $user = User::find($user_id);

                // check if user exists
                if (!is_null($user)) {
                    $user->ticketFilterShares()->sync([$user->id => ['ticket_filter_id' => $ticketFilter->id]]);
                }
            }
        }

        // share with departments
        if ($request->has('departments')) {
            foreach ($request->departments as $department_id) {
                $department = Department::find($department_id);

                // check if department exists
                if (!is_null($department)) {
                    $department->ticketFilterShares()->sync([$department->id => ['ticket_filter_id' => $ticketFilter->id]]);
                }
            }
        }
    }

    /**
     * Validate input parameters
     *
     * @param \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response If validation failed return error response
     */
    private function validateInputs($request)
    {
        $validator = Validator::make($request->all(), [
            'name'        => 'required|string|max:255',
            'fields'      => 'required|array',
            'id'          => 'sometimes|numeric',
            'agents'      => 'sometimes|array',
            'departments' => 'sometimes|array',
        ]);

        if ($validator->fails()) {
            $errors          = $validator->errors()->messages();
            $formattedErrors = array();

            foreach ($errors as $field => $message) {
                $formattedErrors[$field] = array_first($message);
            }

            throw new HttpResponseException(errorResponse($formattedErrors, 412));
        }
    }

    /**
     * Writes selected filter Id to cache
     *
     * @param Number|String $id  id of the selected filter
     * @return \Illuminate\Http\Response
     */
    public function saveSelectedFilter($id)
    {
        //removing the older cache before updating the new one
        Cache::forget('save_selected_filter_'.Auth::user()->id);
        // A validation can be put which says that selected filter id must be a valid ID
        // but it will be used by the frontend to know
        Cache::rememberForever('save_selected_filter_'.Auth::user()->id, function () use ($id) {
            return $id;
        });

        return successResponse(Lang::get('lang.success'));
    }

    /**
     * Checks if selected_filter_id is there is cache. If yes, then checks for validation
     * in the database. If not found, it returns that as 0
     *
     * @return int  selected filter id
     */
    private function getSelectedFilterId()
    {
        $selectedFilterId = Cache::has('save_selected_filter_'.Auth::user()->id) ?
        Cache::get('save_selected_filter_'.Auth::user()->id) : 0;

        if (!TicketFilter::find($selectedFilterId)) {
            $selectedFilterId = 0;
        }

        return $selectedFilterId;
    }
}
