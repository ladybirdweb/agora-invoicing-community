<?php

namespace App\Http\Controllers\Admin\helpdesk;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Exception;
use App\Model\helpdesk\TicketRecur\Recur;
use App\Model\helpdesk\TicketRecur\RecureContent;

class TicketRecurController extends Controller
{

    public $recure_id;
    public $requesters;
    public $subject;
    public $body;
    public $help_topic;
    public $priority;
    public $type;
    public $assigned;
    public $status;
    public $cc;
    public $company;
    public $attachments;
    public $extra_form;
    public $department;
    public $source;
    public $inline;

    public function getOptions($option)
    {
        return RecureContent::where('recur_id', $this->recure_id)->where('option', $option)->value('value');
    }
    public function setRequesters()
    {
        $requesters = $this->getOptions('requester');
        if ($requesters) {
            $this->requesters = explode(',', $requesters);
        }
    }
    public function setSubject()
    {
        $this->subject = $this->getOptions('subject');
    }
    public function setBody()
    {
        $this->body = $this->getOptions('description');
    }
    public function setHelptopic()
    {
        $this->help_topic = $this->getOptions('help_topic');
    }
    public function setDepartment()
    {
        $department = $this->getOptions('department');
        if (!$department && $this->help_topic) {
            $department = departmentByHelptopic($this->help_topic);
        }
        $this->department = $department;
    }
    public function setSource()
    {
        $source = $this->getOptions('source');
        if (!$source) {
            $source = \App\Model\helpdesk\Ticket\Ticket_source::select('id')->value('id');
        }
        $this->source = $source;
    }
    public function setPriority()
    {
        $this->priority = $this->getOptions('priority');
    }
    public function setType()
    {
        $this->type = $this->getOptions('type');
    }
    public function setAssigned()
    {
        $this->assigned = $this->getOptions('assigned');
    }
    public function setStatus()
    {
        $this->status = $this->getOptions('status');
    }
    public function setCc()
    {
        $this->cc = '';
        $cc = $this->getOptions('cc');
        if ($cc) {
            $this->cc = explode(',', $cc);
        }
    }
    public function setCompany()
    {
        $this->company = $this->getOptions('company');
    }
    public function setAttachments()
    {
        $this->attachments = [];
        $json              = $this->getOptions('media_attachment');
        if ($json) {
            $this->attachments = json_decode($json, true);
        }
    }
    public function setInline()
    {
        $this->inline = [];
        $json         = $this->getOptions('inline');
        if ($json) {
            $this->inline = json_decode($json, true);
        }
    }
    public function setExtraForm()
    {
        $this->extra_form = RecureContent::where('id', $this->recure_id)
                ->whereNotIn('option', [
                    'requester', 'subject', 'body', 'help_topic', 'priority', 'type',
                    'assigned', 'status', 'cc', 'company', 'attachments'
                ])
                ->pluck('value', 'option')
                ->toArray();
    }
    public function createTicket($recur_id)
    {
        $this->recure_id = $recur_id;
        $this->setAssigned();
        $this->setAttachments();
        $this->setInline();
        $this->setBody();
        $this->setCc();
        $this->setCompany();
        $this->setExtraForm();
        $this->setHelptopic();
        $this->setDepartment();
        $this->setPriority();
        $this->setStatus();
        $this->setSubject();
        $this->setType();
        $this->setRequesters();
        $this->setSource();
        if (is_array($this->requesters) && count($this->requesters) > 0) {
            foreach ($this->requesters as $requester) {
                $tickets = $this->ticketValues($requester);
                dispatch(new \App\Jobs\RecurTicket($tickets));
            }
        }
    }
    public function ticketValues($requester)
    {
        $tickets = [
            'requester'     => $requester,
            'subject'       => $this->subject,
            'help_topic'    => $this->help_topic,
            'body'          => $this->body,
            'sla'           => '',
            'priority'      => $this->priority,
            'source'        => $this->source,
            'cc'            => $this->cc,
            'dept'          => $this->department,
            'assigned'      => $this->assigned,
            'extra_form'    => $this->extra_form,
            'status'        => "",
            'type'          => $this->type,
            'attachments'   => $this->attachments,
            'inline'        => $this->inline,
            'email_content' => "",
            'company'       => $this->company,
        ];
        return $tickets;
    }
    public function index()
    {
        try {
            $items = Recur::with('content')
                    ->get();
            return view('themes.default1.admin.helpdesk.recur.index', compact('items'));
        } catch (Exception $ex) {
            return redirect()->back()->with('fails', $ex->getMessage());
        }
    }
    public function create()
    {
        try {
            return view('themes.default1.admin.helpdesk.recur.create');
        } catch (Exception $ex) {
            return redirect()->back()->with('fails', $ex->getMessage());
        }
    }
    public function edit($id)
    {
        try {
            $recur = Recur::with('content')
                    ->whereId($id)
                    ->first()
            //->toJson()
            ;
            return view('themes.default1.admin.helpdesk.recur.edit', compact('recur'));
        } catch (Exception $ex) {
            return redirect()->back()->with('fails', $ex->getMessage());
        }
    }
    public function store(Request $request)
    {
        //dd($request->all());
        $this->validation($request);
        try {
            $recur       = $request->input('recur');
            $ticket      = $request->input('ticket');
            $recur_id    = $request->input('recur_id');
            $recur_model = new Recur();
            $this->recurSave($recur, $ticket, $recur_model);
            $message     = trans('lang.saved_successfully');
            $status_code = 200;
        } catch (Exception $ex) {
            $message     = $ex->getMessage();
            $status_code = 500;
        }
        return $this->jsonResponse($message, $status_code);
    }
    public function update($id, Request $request)
    {
        try {
            $recur_model = Recur::find($id);
            $recur       = $request->input('recur');
            $ticket      = $request->input('ticket');
            $this->recurSave($recur, $ticket, $recur_model);
            $message     = trans('lang.updated_successfully');
            $status_code = 200;
        } catch (Exception $ex) {
            $message     = $ex->getMessage();
            $status_code = 500;
        }
        return $this->jsonResponse($message, $status_code);
    }
    public function recurSave($recur, $ticket, $model)
    {
        $fill = [];
        foreach ($recur as $key => $value) {
            if ($key == 'end_date' && !$value) {
                $value = null;
            }
            $fill[$key] = $value;
        }
        $model->fill($fill)->save();
        if (count($ticket) > 0) {
            foreach ($ticket as $key => $value) {
                if ($key == 'inline' || $key == 'media_attachment') {
                    $value = json_encode($value);
                }
                elseif (is_array($value)) {
                    $value = implode(',', $value);
                }
                RecureContent::updateOrCreate(['recur_id' => $model->id,
                    'option'   => $key,
                        ], ['value' => $value]);
            }
        }
        return $model;
    }
    public function jsonResponse($message, $code)
    {
        $m = ['message' => [$message]];
        if ($code != 200) {
            $m = ['error' => [$message]];
        }
        return response()->json($m, $code);
    }
    public function recur()
    {
        $this->mailController()->setQueue();
        $recur_ids = $this->execution();
        if (count($recur_ids) > 0) {
            foreach ($recur_ids as $id) {
                $this->createTicket($id);
                $this->updateRecur($id);
            }
        }
    }
    public function updateRecur($id)
    {
        Recur::updateOrCreate(['id' => $id], [
            'last_execution' => \Carbon\Carbon::now(),
        ]);
    }
    public function execution()
    {
        $now   = \Carbon\Carbon::now();
        $recur = Recur::select('id', 'interval', 'delivery_on', 'last_execution')
                ->whereDate('start_date', '<=', $now)
                ->where(function ($query) use($now) {
                    $query->whereDate('end_date', '>', $now)
                    ->orWhereNull('end_date');
                })
                ->get();
        $ids = $this->checking($recur);
        return $ids;
    }
    public function checking($recur)
    {
        $id = [];
        if ($recur->count() > 0) {
            foreach ($recur as $item) {
                $id[] = $this->getIdToExecute($item);
            }
        }
        return array_filter($id);
    }
    public function getIdToExecute($item)
    {
        $check = "";
        switch ($item->interval) {
            case "daily":
                if (!$item->last_execution || !$item->last_execution->isToday()) {
                    $check = $item->id;
                }
                break;
            case "weekly":
                if (!$item->last_execution || $item->last_execution->isLastWeek()) {
                    $check = $item->id;
                }
                break;
            case "monthly":
                if (!$item->last_execution || $item->last_execution->isLastMonth()) {
                    $check = $item->id;
                }
                break;
            case "yearly":
                if (!$item->last_execution || $item->last_execution->isLastYear()) {
                    $check = $item->id;
                }
                break;
        }
        return $check;
    }
    public function validation($request)
    {
        $this->validate($request, $this->rules($request), $this->validateMessage());
    }
    public function rules($request)
    {
        $require = 'nullable';
        if ($request->has('recur.interval') && $request->input('recur.interval')
                != 'daily') {
            $require = 'required';
        }
        $rules = [
            'recur.start_date'  => 'required',
            'recur.interval'    => 'required',
            'recur.end_date'    => 'required_if:end,by',
            'recur.delivery_on' => $require
        ];
        return $rules;
    }
    public function validateMessage()
    {
        $message = [
            'recur.start_date.required'  => 'Start date required',
            'recur.interval.required'    => 'Interval required',
            'recur.end_date.required_if' => 'End date required',
            'recur.delivery_on.required' => 'Every required',
        ];
        return $message;
    }
    public function mailController()
    {
        return new \App\Http\Controllers\Common\PhpMailController();
    }
}
