<?php

namespace App\Http\Controllers\Agent\helpdesk;

// controllers
use App\Http\Controllers\Controller;
use App\FaveoStorage\Controllers\AttachmentStoreController;
// requests
use App\Http\Requests\helpdesk\CannedRequest;
use App\Http\Requests\helpdesk\CannedUpdateRequest;
// model
use App\Model\helpdesk\Agent_panel\Canned;
use App\Model\helpdesk\Agent_panel\DepartmentCannedResponse as DeptCann;
use App\Model\helpdesk\Agent\DepartmentAssignAgents;
use App\Model\helpdesk\Agent\Department;
use App\User;
// classes
use Exception;
use Lang;
use Auth;

/**
 * CannedController.
 *
 * This controller is for all the functionalities of Canned response for Agents in the Agent Panel
 *
 * @author      Ladybird <info@ladybirdweb.com>
 */
class CannedController extends Controller
{
    /**
     * Create a new controller instance.
     * constructor to check
     * 1. authentication
     * 2. user roles
     * 3. roles must be agent.
     *
     * @return void
     */
    public function __construct()
    {
        // checking authentication
        $this->middleware('auth');
        // checking if role is agent
        $this->middleware('role.agent');
    }

    /**
     * Display a listing of the Canned Responses.
     *
     * @return type View
     */
    public function index()
    {
        try {
            $Canneds = $this->getCannedBuilder(\Auth::user()->id);
            return view('themes.default1.agent.helpdesk.canned.index', compact('Canneds'));
        } catch (Exception $ex) {
            return redirect()->back()->with('fails', $ex->getMessage());
        }
    }

    /**
     * Show the form for creating a new Canned Response.
     *
     * @return type View
     */
    public function create()
    {
        try {
            return view('themes.default1.agent.helpdesk.canned.create');
        } catch (Exception $ex) {
            return redirect()->back()->with('fails', $ex->getMessage());
        }
    }

    /**
     * Store a newly created Canned Response.
     *
     * @param type CannedRequest $request
     * @param type Canned        $canned
     *
     * @return type Redirect
     */
    public function store(CannedRequest $request, Canned $canned)
    {
        try {
            $has_dept_share = $request->filled('share');
            // fetching all the requested inputs
            $canned->user_id = \Auth::user()->id;
            $canned->title = $request->input('title');
            $canned->message = $request->input('message');
            // saving inputs
            $canned->save();
            if ($has_dept_share) {
                $dept_ids = \DB::table('department')->whereIn('name', $request->get('d_id[]'))->pluck('id');
                if(count($dept_ids) >0) {
                    foreach ($dept_ids as $dept_id) {
                        $dept_cann =  new DeptCann;
                        $dept_cann->dept_id   = $dept_id;
                        $dept_cann->canned_id = $canned->id;
                        $dept_cann->save();
                    }
                }
            }
            $this->storeCannedAttachments($canned, $request->get('inline'), $request->get('attachment'));
            return successResponse(Lang::get('lang.canned_response_saved_successfully'));
        } catch (Exception $e) {
            
            return errorResponse($e->getMessage(), FAVEO_EXCEPTION_CODE);
        }
    }

    /**
     * Show the form for editing the Canned Response.
     *
     * @param type        $id
     * @param type Canned $canned
     *
     * @return type View
     */
    public function edit($id, Canned $canned)
    {
        try {
            $found = 0;
            $Canneds = $this->getCannedBuilder(\Auth::user()->id);
            foreach ($Canneds->toArray() as $value) {
                if (array_search($id, $value)) {
                    $found = 1;
                    break;
                }
            }
            if ($found == 1) {
                $canned = $canned->where('id', '=', $id)->first();
                $attachments = $canned->linkedAttachments()->get()->toJson();
                // fetching requested canned response
                $dept_cann_count = DeptCann::select('id')->where('canned_id', '=', $id)->count();
                $is_shared = 0;
                if ($dept_cann_count > 0) {
                    $is_shared = 1;
                }
                return view('themes.default1.agent.helpdesk.canned.edit', compact('canned', 'is_shared', 'attachments'));
            } else {

                return redirect()->route('canned.list')->with('fails', Lang::get('lang.not-autherised'));
            }
        } catch (Exception $ex) {
            return redirect()->back()->with('fails', $ex->getMessage());
        }
    }

    /**
     * Update the Canned Response in database.
     *
     * @param type                     $id
     * @param type CannedUpdateRequest $request
     * @param type Canned              $canned
     *
     * @return type Redirect
     */
    public function update($id, CannedUpdateRequest $request, Canned $canned)
    {
        try {
            if ($request->filled('share')) {
                $dept_ids = \DB::table('department')->whereIn('name', $request->get('d_id[]'))->pluck('id');
                $delete = DeptCann::select('id')->whereNotIn('dept_id', $dept_ids)->where('canned_id', '=', $id)->delete();
                foreach ($dept_ids as $dept_id) {
                    DeptCann::updateOrCreate([
                        'dept_id' => $dept_id,
                        'canned_id' => $id
                    ]);
                }
            } else {
                $dept_cann = DeptCann::where('canned_id', '=', $id)->delete();
            }
            /* select the field where id = $id(request Id) */
            $canned = $canned->where('id', '=', $id)->first();
            // fetching all the requested inputs
            $canned->user_id = \Auth::user()->id;
            $canned->title = $request->input('title');
            $canned->message = $request->input('message');
            // saving inputs
            $canned->save();
            $this->storeCannedAttachments($canned, $request->get('inline'), $request->get('attachment'));

            return successResponse(Lang::get('lang.canned_response_updated_successfully'));
        } catch (Exception $e) {
            
            return errorResponse($e->getMessage(), FAVEO_EXCEPTION_CODE);
        }
    }

    /**
     * Delete the Canned Response from storage.
     *
     * @param type        $id
     * @param type Canned $canned
     *
     * @return type Redirect
     */
    public function destroy($id, Canned $canned, DeptCann $dept_cann)
    {
        try {
            $dept_cann = $dept_cann->where('canned_id', '=', $id)->delete();
            /* select the field where id = $id(request Id) */
            $canned = $canned->whereId($id)->first();
            /* delete the selected field */
            /* Check whether function success or not */
            $canned->delete();
            /* redirect to Index page with Success Message */
            return redirect()->route('canned.list')->with('success', Lang::get('lang.canned_deleted_successfully'));
        } catch (Exception $e) {
            /* redirect to Index page with Fails Message */
            return redirect()->route('canned.list')->with('fails', $e->getMessage());
        }
    }

    /**
     * NOTE : it has to be depreciated after new-inbox is finalized
     * Fetch Canned Response in the ticket detail page.
     *
     * @param type $id
     *
     * @return type json
     */
    public function getCanned($id)
    {   
        $responseValues = [];
        $cannedResponses = $this->getCannedBuilder($id);
        if ($cannedResponses) {
            foreach ($cannedResponses as $cannedResponse) {
                array_push($responseValues, [$cannedResponse->id, $cannedResponse->title]);
            }
        }
        if (sizeof($responseValues) != 0) {
            $response = $responseValues;
        } else {
            $response = [['zzz', 'select canned_response']];
        }
         return json_encode($response);
    }


    /**
     * gets canned response allowed for logged in user
     * @param integer $id   id of the agent/admin 
     * @return array        array of canned responses
     */
    public function getCannedResponseForCurrentUser()
    {  
        $deptIds = DepartmentAssignAgents::select('department_id')->where('agent_id', Auth::user()->id)->pluck('department_id')->toArray();
        $cannedResponse = Canned::whereHas('departments', function($q) use ($deptIds){
                            $q->whereIn('department.id',$deptIds);
                        })->orWhere('user_id',Auth::user()->id)->select('id', 'title')->get();
        return successResponse('', $cannedResponse);
    }


    /**
     * NOTE : it has to be depreciated after new-inbox is finalized
     * @category function to get querybuilder collection of canned responses
     * @param type int $id //id of an agent 
     * @var $dept_id, $dept_cann, $user_departments, $user_department, $user_dept_canns, $user_dept_cann, $canned_responses
     * @return builder
     */
    public function getCannedBuilder($id) {
        $dept_id = [];
        $dept_cann = [];
        $user_departments = DepartmentAssignAgents::select('department_id')->where('agent_id', '=', $id)->get();
        if ($user_departments) {
            foreach ($user_departments as $user_department) {
                array_push($dept_id, $user_department->department_id);
            }               
        }
        $user_dept_canns = DeptCann::select('canned_id')->whereIn('dept_id', $dept_id)->groupBy('canned_id')->orderBy('canned_id')->get();
        if ($user_dept_canns) {
            foreach ($user_dept_canns as $user_dept_cann) {
                array_push($dept_cann, $user_dept_cann->canned_id);
            }
        }
        $canned_responses = Canned::select('id', 'title')->where('user_id', '=', $id)->orWhereIn('id', $dept_cann)->groupBy('id')->orderBy('id')->get();
        return $canned_responses;
    }

    /**
     * @category function to send response to ajax call with depratment names and id to which the calling 
     *canned response is shared with 
     * @param int $id
     * @var $dept, $dept_id, $departments, $department_json
     * @return type json object $departments_json
     */
    public function getCannedDepartments($id)
    {
        $dept = '';
        $dept_id = [];
        $departments = DeptCann::select('dept_id')->where('canned_id', '=', $id)->get();
        if ($departments) {
            foreach ($departments as $department) {
                array_push($dept_id, $department->dept_id);
            }
        }
        if (!empty($dept_id)) {
            $dept = Department::select('name as name_id', 'name as text')
                ->whereIn('id', $dept_id)->get();
        }
        $dropdown_controller = new \App\Http\Controllers\Agent\helpdesk\DropdownController();
        $departments_json = $dropdown_controller->formatToJson($dept, 'department-list');
        return $departments_json;
    }

    /**
     * @category function to send canned response message body
     * @param int $id 
     * @
     * @return string HTML code
     */
    public function getCannedMessage($cannedId)
    {
        $canned = Canned::where('id', '=', $cannedId)->first();
        $linkedAttachments = $canned->attachments()->whereNotIn('disposition', ['inline', 'INLINE'])->get(['name', 'path'])->toArray();
        $linkedInlineAttachments = $canned->attachments()->whereNotIn('disposition', ['attachment', 'ATTACHMENT'])->get(['name', 'path'])->toArray();
        $attachments = $this->formatAttachments($linkedAttachments);
        $inline = $this->formatAttachments($linkedInlineAttachments);
        
        return successResponse('', ['title' => $canned->title,'message' => $canned->message, 'attachments' => $attachments, 'inline' => $inline]);
    }

    /**
     * Function to return attachments in formatted array
     * @param   Array  $linkedAttachments  array containing attachment details
     * @return  Array                      formatted array of attachments
     */
    public function formatAttachments(array $linkedAttachments =[])
    {
        $attachments = [];
        foreach ($linkedAttachments as $key => $file) {
            $fileObj = new \Symfony\Component\HttpFoundation\File\File($file['path'].DIRECTORY_SEPARATOR.$file['name']);
            $mime                           = \File::mimeType($fileObj->getPathname());
            $attachments[$key]['pathname']  = $fileObj->getPathname();
            $attachments[$key]['extension'] = $fileObj->getExtension();
            $attachments[$key]['filename']  = $fileObj->getFilename();
            $attachments[$key]['size']      = $fileObj->getSize();
            $attachments[$key]['type']      = substr($mime, 0, strpos($mime, "/"));
            $attachments[$key]['path']      = $fileObj->getPath();
            $attachments[$key]['modified']  = date("F j, Y, g:i a", \File::lastModified($fileObj->getPathname()));
            $attachments[$key]['category']  = 'canned';
            if (starts_with($mime, 'image')) {
                list($width, $height) = getimagesize($fileObj->getPathname());
                $attachments[$key]['width']   = $width;
                $attachments[$key]['height']  = $height;
                $attachments[$key]['type']    = 'image';
                $attachments[$key]['base_64'] = "data:$mime;base64," . base64_encode(file_get_contents($fileObj->getPathname()));
            }
        }
        return $attachments;
    }

    /**
     * Function to store inline and attachment files infromation in database
     * @param  Canned   $canned        
     * @param  Array    $inline       canned inline attachments submitted by users
     * @param  Array    $attachments  canned attachments submitted by users
     */
    public function storeCannedAttachments(Canned $canned, array $inline =[], array $attachments =[])
    {
        $attachedId = [];
        foreach ($inline as $key => $value) {
            $attachedId[] = ['attachment_id' => (new AttachmentStoreController)->storeAttachments($value, 'inline')];
        }

        foreach ($attachments as $key => $value) {
            $attachedId[] = ['attachment_id' => (new AttachmentStoreController)->storeAttachments($value, 'attachment')];
        }
        $toAdd = [];
        foreach ($attachedId as $key => $value) {
            array_push($toAdd, $value['attachment_id']);
        }
        $canned->linkedAttachments()->whereNotIn('attachment_id', $toAdd)->delete();
        foreach ($attachedId as $value) {
            $canned->linkedAttachments()->updateOrCreate($value, $value);
        }
    }
}
