<?php
Route::post('ticket','App\Api\v2\ClientApiController@ticketCreate');
Route::post('ticket/reply','App\Api\v2\ClientApiController@ticketReply');
Route::get('profile','App\Api\v2\ClientApiController@getDetails');
Route::patch('profile','App\Api\v2\ClientApiController@updateDetails');
Route::patch('profile/password','App\Api\v2\ClientApiController@changePassword');
Route::get('tickets','App\Api\v2\ClientApiController@allTickets');
Route::get('ticket','App\Api\v2\ClientApiController@getTicket');