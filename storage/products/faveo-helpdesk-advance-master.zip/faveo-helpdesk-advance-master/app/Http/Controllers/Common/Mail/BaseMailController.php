<?php

namespace App\Http\Controllers\Common\Mail;

use App\Http\Controllers\Controller;
use Exception;
use PhpImap\IncomingMail;
use App\Http\Controllers\Common\Mail\CustomMailBox as Mailbox;
use Config;
use App\Model\helpdesk\Email\Emails;
use Lang;
use Mail;
use Logger;

/**
 * this class handles all the basic functionality related to sending/fetching mail.
 * It can be extended by other child classes to use its functionality.
 *
 * @author avinash kumar <avinash.kumar@ladybirdweb.com>
 *
 */
class BaseMailController extends Controller
{

    /**
     * @var object          email config object, with all the email configuration values.
     */
    protected $emailConfig;

    /**
     * @var object          stores exceptions|error-messages thrown by php-imap(in case any)
     */
    protected $error;

    /**
     * gets mail fetch connection
     * @param string $encoding      email encoding
     * @return Mailbox              connection for Mailbox
     */
    private function getFetchMailConnection(string $encoding = 'UTF-8')
    {
        \File::makeDirectory('mail-fetch',0777, true, true);
        \File::cleanDirectory('mail-fetch');
        $testDirectory = 'mail-fetch'; //directory that is going to store attachments
        $host = $this->emailConfig->fetching_host;
        $driver = $this->emailConfig->fetching_protocol;
        $port = $this->emailConfig->fetching_port;
        $encryption = $this->emailConfig->fetching_encryption == 'none' ? 'notls' : $this->emailConfig->fetching_encryption;
        $certificate = $this->emailConfig->mailbox_protocol ? $this->emailConfig->mailbox_protocol : 'novalidate-cert';

        //has to decide whether we need username or email address
        $username = $this->emailConfig->user_name ? $this->emailConfig->user_name : $this->emailConfig->email_address;

        $password = $this->emailConfig->password;

        $mailbox = new Mailbox('{' . "$host:$port/$driver/$encryption/$certificate" . '}INBOX', $username, $password,

        $testDirectory, $encoding);

        return $mailbox;
    }

    /**
     * fetches mail from the mail server and returns array of mails
     * @return array                array of all the fetched mails
     */
    protected function fetchMailByPhpImap()
    {
        //search condition
        $date = date("d M Y", strToTime("-1 days"));

        try {
                $connection = $this->getFetchMailConnection();
                //gets all unseen messages since last day
                $mailIds = $connection->searchMailbox("SINCE \"$date\" UNSEEN");

        } catch (Exception $e) {

                if(strpos($e->getMessage(),'US-ASCII') == false){
                    // dd($e);
                    $this->error = $e;
                    //returns an empty array for functionality not to break
                    return [];
                }

                //getting connection with US-ASCII encoding
                $connection = $this->getFetchMailConnection('US-ASCII');

                //gets all unseen messages since last day
                $mailIds = $connection->searchMailbox("SINCE \"$date\" UNSEEN");

        }

        //if no mail is found, return an empty array
        if (!$mailIds) {
            return [];
        }

        //only pick 10 of those
        if (count($mailIds) > 10) {
            $mailIds = array_slice($mailIds, 0, 10);
        }

        //if delete_email is on, it should delete email after reading it
        $deleteAfterReading = $this->emailConfig->delete_email;

        //should return all the emails and also mark those as deleted
        return $this->getMailsByIds($mailIds, $connection, $deleteAfterReading);

    }

    /**
     * gets all mails by mail Ids
     * @param array $mailIds                     mailIds that has to be fetched
     * @param Mailbox $mailbox                   an instance of Mailbox which represents the fetch connection
     * @param boolean $shallDeleteAfterReading   whether mail should be deleted after reading
     * @return array                    array of mails
     */
    private function getMailsByIds($mailIds, Mailbox $mailbox, $shallDeleteAfterReading)
    {
        try {
            $mails = [];
            foreach ($mailIds as $mailId) {

                //getting mail
                $mail = $mailbox->getMail($mailId, true); //should make it true once done
                //get mail in a format
                $formattedMail = $this->formatMail($mail);

                //deleting mail
                if ($shallDeleteAfterReading) {
                    $mailbox->deleteMail($mailId);
                }

                //pushing it to an array
                array_push($mails, $formattedMail);
            }

            return $mails;
        } catch (\Exception $e) {
            Logger::exception($e, 'mail-fetch');
            $this->error = $e;
        }
    }

    /**
     * formats the mail which is passed as an instance of PhpImap\IncomingMail
     * @param PhpImap\IncomingMail  $mail           mail object
     * @return object                               formatted mail with specified fields like from, to, cc, body, subject etc
     */
    private function formatMail(IncomingMail $mail)
    {
        $formattedMail = [];

        $formattedMail['subject'] = $mail->subject;

        $formattedMail['from'] = $mail->fromAddress;

        $formattedMail['to'] = $mail->to;

        $formattedMail['cc'] = $mail->cc;

        $formattedMail['bcc'] = $mail->bcc;

        $formattedMail['reply_to'] = $mail->replyTo;

        $formattedMail['body'] = $this->getPurifiedMailBody($mail);

        $formattedMail['attachments'] = $mail->getAttachments();

        $formattedMail['created_at'] = $mail->date;

        $formattedMail['uid'] = $mail->id;

        //check if references exists, if not then make it an empty array
        $headers = $mail->headers;

        //making reference id as string if not found because ticket controller accepts it this way
        $formattedMail['reference_ids'] = array_key_exists('references', $headers) ?
            explode(' ', str_replace(['<', '>'], '', $mail->headers->references)) : [];

        //check for auto response
        $headersRaw = $mail->headersRaw;
        $formattedMail['auto_replied'] = $this->isAutoResponded($headersRaw);

        //message id
        $formattedMail['message_id'] = str_replace(['<', '>'], '', $mail->messageId);

        $formattedMail['is_delivery_mail'] = $this->isDeliveryFailureStatusMail($mail->fromAddress);

        return $formattedMail;
    }

  	/**
  	 * Strips all new lines if mail is html
  	 * REASON : If HTML mail has \n into it, it will be regarded as another new line which causes one extra new line
  	 * if kept outside div
  	 * @return string
  	 */
  	protected function getPurifiedMailBody(IncomingMail $mail) : string
  	{
  		if($mail->textHtml){
  			return preg_replace( "/\r|\n/", "", $mail->textHtml );
  		}

      if($mail->textPlain){
        return $mail->textPlain;
      }

      return '';
  	}

    /**
     * Algorithm that checks if a mail is auto reponded by inspeting its header
     * WORKING: it checks for certain strings in the header(like auto-response)
     * NOTE: more and more conditions should be keep adding to it to make it a stronger algorithm
     * @param string $headersRaw    Raw header of a mail
     * @return boolean              true if auto responded else false
     */
    private function isAutoResponded($headersRaw)
    {
        //text that are found in auto replied mail till now. More text can be added to it to block auto responded mail
        $autoRepliedStrings = ['Auto-Submitted: auto-replied', 'X-Autorespond','X-Autoreply'];

        foreach ($autoRepliedStrings as $autoRepliedString) {
            $isAutoResponded = (strpos($headersRaw, $autoRepliedString) !== false) ? true : false;
            if ($isAutoResponded) {
                return true;
            }
        }
        return false;
    }

    /**
     * checks if mail is delivery failure mail
     * @param string $sender        email of the person who sent the mail
     * @return boolean              true/false
     */
    private function isDeliveryFailureStatusMail($sender)
    {
        if (strpos($sender, 'mailer-daemon') !== false) {
            return true;
        }
        return false;
    }

    protected function checkFetchConnection(Emails $emailConfig){
        try{
            $this->emailConfig = $emailConfig;


            $this->getFetchMailConnection()->getImapStream();
            return true;

        }
        catch(Exception $e){
            $this->error = $e;
            return false;
        }
    }

    /**
     * checks send connection based on the mail driver
     * @param Emails $emailConfig   emailConfig object
     */
    protected function checkSendConnection(Emails $emailConfig){
        $this->emailConfig = $emailConfig;

        //if sending protocol is mail, no connection check is required
        if($this->emailConfig->sending_protocol == 'mail'){
            return $this->checkMailConnection();
        }

        //set outgoing mail configuation to the passed one
        setServiceConfig($this->emailConfig);
        if($this->emailConfig->sending_protocol == 'smtp'){
            return $this->checkSMTPConnection();
        }

        return $this->checkServices();
    }


    /**
     * checks if php's mail function is enabled on current server
     * @return boolean  true if enabled else false
     */
    private function checkMailConnection(){
        if(function_exists('mail')){
            return true;
        }
        $this->error = Lang::get('lang.mail_function_disabled');
        return false;
    }

    /**
     * Checks services status by raw sending mail and waiting for the response
     * @return boolean      true if success else false
     */
    private function checkServices(){
        try{

            $protocolName = $this->emailConfig->sending_protocol;

            //sending a text message and checking if respond comes. If yes, connection is considered to be successful
            $hasMailSent = Mail::raw("This is a test mail for successful $protocolName connection", function ($message){
                 $message->to($this->emailConfig->email_address);
            });

            if(count(Mail::failures()) > 0) {
                $this->error = Lang::get('lang.unknown_error_occured');
                return false;
            }

            // if(!$hasMailSent){
            //     $this->error = Lang::get('lang.unknown_error_occured');
            //     return false;
            // }

            return true;

        }catch(\Exception $e){

            $this->error = $e;
            return false;
        }
    }

    /**
     * Checks smtp connection stream. If exception is found, it writes the exception method to $this->error
     * TO DO: it is not required to set email configuration before checking the stream in above method,
     * because it is in this method too.
     * @return boolean      true if success else false
     */
    private function checkSMTPConnection(){
        try{

            $https = [];
            $https['ssl']['verify_peer']      = false;
            $https['ssl']['verify_peer_name'] = false;

            $transport = new \Swift_SmtpTransport(Config::get('mail.host'), Config::get('mail.port'), Config::get('mail.security'));
            $transport->setUsername(\Config::get('mail.username'));
            $transport->setPassword(\Config::get('mail.password'));
            $transport->setStreamOptions($https);
            $mailer = new \Swift_Mailer($transport);
            $mailer->getTransport()->start();

            return true;
        } catch(\Swift_TransportException $e){
            $this->error = $e;
            return false;
        } catch(\Exception $e){
            $this->error = $e;
            return false;
        }
    }
}
