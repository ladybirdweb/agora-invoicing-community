<?php

namespace App\Http\Controllers\Common;

use App\Http\Controllers\Controller;
use App\Http\Requests\kb\SearchRequest;
use App\Model\kb\Article;
use App\Model\kb\Category;
use App\Model\kb\Relationship;
use App\Model\kb\Settings;
use Auth;
use Lang;
use Illuminate\Http\Request;
use App\Model\kb\Comment;
use App\Model\kb\Page;

class KnowledgeBaseController extends Controller {

    /**
     * function to search an article.
     *
     * @param \App\Http\Requests\kb\SearchRequest $request
     * @param \App\Model\kb\Article               $article
     *
     * @return json
     */
    public function search(SearchRequest $request, Article $article)
    {
       // dd(utf8_decode(urldecode($request->input('s'))));
        $pagination = Settings::first()->pagination;
        $allowedArticles = $this->getArticleListForUser();
        $search =utf8_decode(urldecode($request->input('s')));
        $currentTime = date("Y-m-d H:i:s");
        $articles = $article->with(['categories' => function($q) {
                        $q->select('kb_category.name', 'kb_category.id');
                    }])->whereIN('visible_to', $allowedArticles)
                                ->where('type', '1')
                                ->where('publish_time', '<', $currentTime)
                               ->where(function($query) use ($search){
                                $query->where('name', 'LIKE', '%' . $search . '%')
                                ->orWhere('slug', 'LIKE', '%' . $search . '%');
                                // ->orWhere('description', 'LIKE', '%' . $search . '%');
                              })
                        ->select('id', 'name', 'description', 'publish_time', 'created_at', 'updated_at', 'slug')->paginate($pagination);
       

        return successResponse('', ['articles' => $articles]);
    }

    /**
     * to get category list with article count.
     * @param $category an instance of Category
     * @return array
     */
    public function getCategoryListWithArticleCount(Category $category)
    {
       
         $currentTime = date("Y-m-d H:i:s");
         $allowedArticles = $this->getArticleListForUser();
         $result = $category->where('status', 1)
                ->select('id', 'name', 'slug')
                ->withCount(['articles'=>function($q) use($currentTime,$allowedArticles){
                    $q->where('type', '1')->where('publish_time', '<', $currentTime)->whereIN('visible_to', $allowedArticles);
                }])->get();
                
          return successResponse('', ['categories' => $result]);
    }

  /**
     * to get category list with article names.
     * @param $category an instance of Category
     * @return array
     */
    public function getCategoryListWithArticles1(Category $category)
    {

        $allowedArticles = $this->getArticleListForUser();
        $currentTime = date("Y-m-d H:i:s");
        $result = $category->where('status', 1)
                        ->select('id', 'name', 'slug', 'created_at', 'updated_at')
                        ->with(['articles' => function($query) use ($currentTime, $allowedArticles) {
                                $query->whereIN('visible_to', $allowedArticles)
                                ->where('type', '1')
                                ->where('publish_time', '<', $currentTime)
                                ->select('kb_article.id', 'kb_article.name', 'kb_article.slug');
                            }])->get();
        return successResponse('', ['categories' => $result]);
    }

    /**
     * to get category list with article names.
     * @param $category an instance of Category
     * @return array
     */
    public function getCategoryListWithArticles(Category $category)
    {

        $allowedArticles = $this->getArticleListForUser();
        $currentTime = date("Y-m-d H:i:s");
        $pagination = Settings::first()->pagination;
        $result = $category->where('status', 1)
                        ->select('id', 'name', 'slug', 'created_at', 'updated_at')
                        ->with(['articles' => function($query) use ($currentTime, $allowedArticles) {
                                $query->whereIN('visible_to', $allowedArticles)
                                ->where('type', '1')
                                ->orderBy('publish_time','desc')
                                ->where('publish_time', '<', $currentTime)
                                ->select('kb_article.id', 'kb_article.name', 'kb_article.slug');
                            }])->paginate($pagination);
        return successResponse('', ['categories' => $result]);
    }

    /**
     * to get category list with article names.
     * @param $article an instance of Article
     * @return array
     */
    public function getArticleListWithCategories(Article $article)
    {
        $pagination = Settings::first()->pagination;
        $allowedArticles = $this->getArticleListForUser();
        $currentTime = date("Y-m-d H:i:s");
        $articles = $article->with(['categories' => function($q) {
                        $q->select('kb_category.name', 'kb_category.id');
                    }])->whereIN('visible_to', $allowedArticles) ->where('publish_time', '<', $currentTime)->where('type', '1')->select('id', 'name', 'description', 'publish_time', 'created_at', 'updated_at', 'slug')->paginate($pagination);
        return successResponse('', ['articles' => $articles]);
    }

    /**
     * to get category list with article names.
     * @param $article an instance of Article
     * @return array
     */
    public function getArticleListWithCategories1(Article $article)
    {
        $allowedArticles = $this->getArticleListForUser();
        $currentTime = date("Y-m-d H:i:s");
        $articles = $article->with(['categories' => function($q) {
                        $q->select('kb_category.name', 'kb_category.id');
                    }])->whereIN('visible_to', $allowedArticles) ->where('publish_time', '<', $currentTime)->where('type', '1')->select('id', 'name', 'description', 'publish_time', 'created_at', 'updated_at', 'slug')->get();

        return successResponse('', ['articles' => $articles]);
    }

    /**
     * gets articles for a given category
     * @param $categoryId 
     * @param $category an instance of Category 
     * @return array
     */
    public function getArticlesForCategory($categoryId, Category $category)
    {
        $currentTime = date("Y-m-d H:i:s");
        $allowedArticles = $this->getArticleListForUser();
        $pagination = Settings::first()->pagination;
        $result = $category->where('id', $categoryId)
                        ->select('id', 'name', 'slug', 'created_at', 'updated_at')
                        ->with(['articles' => function($query) use ($currentTime, $allowedArticles) {
                                $query->whereIN('visible_to', $allowedArticles)
                                ->where('type', '1')
                                ->where('publish_time', '<', $currentTime);
                            }])->first()->toArray();

        if (count($result['articles']) > 0) {
            foreach ($result['articles'] as $key => $value) {
                $articleIds[] = $value['id'];
            }
            $article = Article::whereIn('id', $articleIds)->orderBy('publish_time','desc')->paginate($pagination);
        } else {
            $article = [];
        }
        $Category = Category::where('id', $categoryId)->select('id', 'name', 'slug', 'created_at', 'updated_at')->first();
        return successResponse('', ['category' => $Category->name, 'article' => $article]);
    }

    /**
     * gets article for a given getArticleBySlug
     * @param $articleId articleId
     * @param $article an instance of Article
     * @return any
     */
    public function getArticleBySlug($articleSlug, Article $article)
    {
        $pagination = Settings::first()->pagination;
        $articleId = Article::where('slug',$articleSlug)->value('id');
        $allowedArticles = $this->getArticleListForUser();
        if(!$articleId){
             return errorResponse( Lang::get('lang.article_not_found'),404);

        }
        $result = $article->where('id', $articleId)->whereIN('visible_to', $allowedArticles)
                        // ->where('status', '1')
                        ->where('type', '1')
                        ->with(['categories' => function($query) {
                                $query->select('kb_category.id', 'kb_category.name','kb_category.slug');
                            }])->first();
        $comments = (!Auth::guest() && Auth::user()->role == 'admin') ? Comment::where('article_id', $articleId)->orderBy('created_at', 'desc')->paginate($pagination) : Comment::where('article_id', $articleId)->where('status', '1')->orderBy('created_at', 'desc')->paginate($pagination);


        return successResponse('', ['article' => $result, 'comments' => $comments]);
    }

    /**
     * gets category list for the logged in user
     * takes care of whether a user is allowed to see a category or not
     *
     * @return array
     */
    protected function getArticleListForUser()
    {
        $kbSettings = Settings::where('id', 1)->first();

        //kb accessibility if turned off
        if ($kbSettings->status != 1) {
            return [];
        }

        $loggedInUser = Auth::user();

        $visibleTo = !$loggedInUser ? ['all_users'] : ( $loggedInUser->role == 'user' ? ['logged_in_users', 'all_users'] :
                ( $loggedInUser->role == 'agent' ? ['all_users', 'agents'] : ['all_users', 'logged_in_users', 'agents'] ) );
    // $articles = Article::whereIN('visible_to', $visibleTo)->select('id', 'name')->get();

        return $visibleTo;
    }

    /**
     * This method return page detals
     *
     * @return json
     */

    public function pageDetails(Request $request){
        
        $page = Page::where('slug', $request->slug)->select('name','description')->first();
        return successResponse('',  $page);
    }

}
