<?php

namespace App\Model\Common;

use App\BaseModel;

class Timezone extends BaseModel
{
    protected $table = 'timezone';
}
