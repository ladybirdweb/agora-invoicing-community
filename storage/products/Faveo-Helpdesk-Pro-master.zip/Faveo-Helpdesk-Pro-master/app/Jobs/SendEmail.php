<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use App\Http\Controllers\Common\PhpMailController;

class SendEmail implements ShouldQueue
{
    use Dispatchable,
        InteractsWithQueue,
        Queueable,
        SerializesModels;
    
    public $tries = 5;
    protected $from;
    protected $to;
    protected $message;
    protected $template;
    protected $thread;
    protected $auto_respond;
    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($from, $to, $message,$template_variables='',$thread="",$auto_respond="")
    {
        $this->from = $from;
        $this->to = $to;
        $this->message = $message;
        $this->template = $template_variables;
        $this->thread = $thread;
        $this->auto_respond = $auto_respond;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle(PhpMailController $PhpMailController)
    {
        $p = $PhpMailController->sendEmail($this->from, $this->to, $this->message,$this->template,$this->thread,$this->auto_respond);
        return $p;
        
    }
    
      
}
