<?php

namespace App\FaveoLog\Model;

use App\BaseModel;
use App\Model\helpdesk\Ticket\EmailThread;

class MailLog extends BaseModel
{
    protected $table    = 'mail_logs';

    protected $fillable = [

      /**
       * Foriegn key for log category
       */
      'log_category_id',

      /**
       * The person to whom we are sending the mail
       */
      'sender_mail',

      /**
       * The person who recieves the mail
       */
      'reciever_mail',

      /**
       * The referee id from which log has come (ticket or user or mail)
       */
      'referee_id',

      /**
       * The referee type from which log has come (ticket or user or mail)
       */
      'referee_type',

      /**
       * Subject of the mail
       */
      'subject',

      /**
       * Body of the mail
       */
      'body',

      /**
       * Source from which it was generated (mail, web, recur)
       */
      'source',

      /**
       * Status of the mail `QUEUED`, `SENT`, `ACCEPTED`, `REJECTED`
       */
      'status',

    ];

	 /**
    * Will morph to ticket table, user table
    */
    public function reference()
    {
    	return $this->morphTo();
    }

    public function category()
    {
        return $this->belongsTo('App\FaveoLog\Model\LogCategory','log_category_id');
    }

    public function getStatusAttribute($value)
    {
      if($value || $this->category->name != 'mail-fetch'){
        return $value;
      }

      // if log category is mail-fetch
      // check for referee id, if found in email_thread table, means ticket has been created with that mail
      // so status will be accepted
      // if not found, means ticket has been rejected
      if(EmailThread::where('message_id', $this->referee_id)->first()){
          $this->status = 'accepted';
          $this->save();
          return 'accepted';
      }

      $this->status = 'rejected';
      $this->save();
      return 'rejected';
    }
}
