<?php

namespace App\Http\Controllers\Agent\helpdesk;

// controllers
use App\Http\Controllers\Controller;
use App\Http\Controllers\Common\PhpMailController;
use App\Http\Controllers\Agent\helpdesk\Notifications\NotificationController as Notify;
// requests
/*  Include Sys_user Model  */
use App\Http\Requests\helpdesk\ProfilePassword;
/* For validation include Sys_userRequest in create  */
use App\Http\Requests\helpdesk\ProfileRequest;
/* For validation include Sys_userUpdate in update  */
use App\Http\Requests\helpdesk\Sys_userRequest;
use App\Http\Requests\helpdesk\AgentUpdate;
/*  include guest_note model */
use App\Http\Requests\helpdesk\Sys_userUpdate;
use App\Http\Requests\helpdesk\OtpVerifyRequest;
// change password request 
use App\Http\Requests\helpdesk\ChangepasswordRequest;
use App\Model\helpdesk\Ticket\Ticket_Status;
// models
use App\Model\helpdesk\Agent_panel\Organization;
use App\Model\helpdesk\Agent_panel\User_org;
use App\Model\helpdesk\Settings\CommonSettings;
use App\Model\helpdesk\Utility\CountryCode;
use App\Model\helpdesk\Utility\Otp;
use App\Model\helpdesk\Email\Emails;
use App\Model\helpdesk\Settings\Email;
use App\Model\helpdesk\Ticket\Tickets;
use App\Model\helpdesk\Agent\Assign_team_agent;
use App\Model\helpdesk\Ticket\Ticket_Thread;
use App\Model\helpdesk\Notification\UserNotification;
use App\Model\helpdesk\Notification\Notification;
use App\Model\helpdesk\Ticket\Ticket_Collaborator;
use App\Model\helpdesk\Agent\Teams;
use App\Model\helpdesk\Ticket\Ticket_attachments;
// use App\Http\Controllers\Agent\helpdesk\Timezones;
use App\Model\helpdesk\Utility\Timezones;
use App\Model\helpdesk\Agent\Groups;
use App\Model\helpdesk\Agent\Department;
use App\Model\helpdesk\Agent\DepartmentAssignAgents;
use App\User;
// classes
use Auth;
use Exception;
use Hash;
use Input;
use Lang;
use Redirect;
use Illuminate\Http\Request;
use DateTime;
use DB;
use Datatables;
use App\Model\helpdesk\Agent_panel\OrganizationDepartment;
use App\Model\helpdesk\Settings\ApprovalMeta;
use App\Model\helpdesk\Agent\DepartmentAssignManager;
use App\Model\kb\Comment;
use App\Http\Controllers\Agent\helpdesk\UserController;
/**
 * UserController
 * This controller is used to CRUD an User details, and proile management of an agent.
 *
 * @author      Ladybird <info@ladybirdweb.com>
 */
class UserController extends Controller {

    protected $ticket_policy;

    /**
     * Create a new controller instance.
     * constructor to check
     * 1. authentication
     * 2. user roles
     * 3. roles must be agent.
     *
     * @return void
     */
    public function __construct(PhpMailController $PhpMailController) {
        $this->PhpMailController = $PhpMailController;
        // checking authentication
        //$this->middleware('auth');
        // checking if role is agent
        $this->middleware('role.agent', ['except' => ['createUserApi']]);
        $this->ticket_policy = new \App\Policies\TicketPolicy();
        //$this->middleware('limit.reached', ['only' => ['store']]);
    }

    /**
     * Display all list of the users.
     *
     * @param type User $user
     *
     * @return type view
     */
    public function index() {
        try {
            /* get all values in Sys_user */
            $table = \ Datatable::table()
                    ->addColumn(
                            Lang::get('lang.name'), Lang::get('lang.user_name'), Lang::get('lang.email'), Lang::get('lang.phone'), Lang::get('lang.status'), Lang::get('lang.last_login'), Lang::get('lang.role'), Lang::get('lang.action')
                    )  // these are the column headings to be shown
                    ->noScript();
            return view('themes.default1.agent.helpdesk.user.index', compact('table'));
        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }

    public function deletedUser() {
        try {
            // dd('here');
            /* get all values in Sys_user */
            return view('themes.default1.agent.helpdesk.user.deleteduser');
        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }

    /**
     * This function is used to display the list of users using chumper datatables.
     *
     * @return datatable
     */
    public function user_list(Request $request) {
        $type = $request->input('profiletype');
        $search = $request->input('searchTerm');
        if ($type === 'agents') {
            $users = User::where('role', '=', 'agent')->where('ban', '=', 0)->where('is_delete', '=', 0);
        } elseif ($type === 'users') {
            $users = User::where('role', '=', 'user')->where('ban', '=', 0)->where('is_delete', '=', 0);
        } elseif ($type === 'active-users') {
            $users = User::where('role', '!=', 'admin')->where('active', '=', 1)->where('ban', '=', 0)->where('is_delete', '=', 0);
        } elseif ($type === 'inactive') {
            $users = User::where('role', '!=', 'admin')->where('active', '=', 0);
        } elseif ($type === 'deleted') {
            $users = User::where('role', '!=', 'admin')->where('is_delete', '=', 1);
        } elseif ($type === 'banned') {
            $users = User::where('role', '!=', 'admin')->where('ban', '=', 1);
        } elseif ($type === 'mobile-unverified') {
            $users = User::where('mobile_verify', '=', 0);
        } elseif ($type === 'mobile-verified') {
            $users = User::where('mobile_verify', '=', 1);
        } 
        elseif ($type === 'verified') {
            $users = User::where('role', '!=', 'admin')->where('active',  1);
        }

        elseif ($type === 'unverified') {
            $users = User::where('role', '!=', 'admin')->where('active', 0);
        }
        else {
            $users = User::where('role', '!=', 'admin');
        }
        $users = $users->select('first_name', 'user_name', 'email', 'mobile', 'active', 'updated_at', 'role', 'id', 'last_name', 'country_code', 'phone_number','email_verify','mobile_otp_verify','ban','is_delete');
        if ($search !== '') {
            $users = $users->where(function ($query) use ($search) {
                $query->where('user_name', 'LIKE', '%' . $search . '%');
                $query->orWhere('email', 'LIKE', '%' . $search . '%');
                $query->orWhere('first_name', 'LIKE', '%' . $search . '%');
                $query->orWhere('last_name', 'LIKE', '%' . $search . '%');
                $query->orWhere('mobile', 'LIKE', '%' . $search . '%');
                $query->orWhere('updated_at', 'LIKE', '%' . $search . '%');
                $query->orWhere('country_code', 'LIKE', '%' . $search . '%');
            });
        }

        // displaying list of users with chumper datatables
        // return \Datatable::collection(User::where('role', "!=", "admin")->get())
        return \DataTables::of($users)
                        /* column username */
                        ->removeColumn('id', 'last_name', 'country_code', 'phone_number')
                        ->editColumn('first_name', function ($model) {
                            $name = Lang::get('lang.not-available');
                            if ($model->first_name !== '' && $model->first_name !== null) {
                                $name = $model->first_name . ' ' . $model->last_name;
                                if (strlen($model->first_name . ' ' . $model->last_name) > 15) {
                                    $name = mb_substr($model->first_name . ' ' . $model->last_name, 0, 10, 'UTF-8') . '...';
                                }
                                return '<a  href="' . route('user.show', $model->id) . '" title="' . $model->first_name . ' ' . $model->last_name . '">' . $name . '</a>';
                            }
                            return $name;
                        })
                        ->editColumn('user_name', function ($model) {
                            $user_name = $model->user_name;
                            if (strlen($model->user_name) > 15) {
                                $user_name = mb_substr($model->user_name, 0, 10, 'UTF-8') . '...';
                            }
                            return '<a  href="' . route('user.show', $model->id) . '" title="' . $model->user_name . '">' . $user_name . '</a>';
                        })
                        /* column email */
                        ->addColumn('email', function ($model) {
//                            $email = "<a href='" . route('user.show', $model->id) . "'>" . $model->email . '</a>';
//                            return $email;
                            $email = $model->email;
                            if (strlen($model->email) > 15) {
                                $email = mb_substr($model->email, 0, 10, 'UTF-8') . '...';
                            }
                            return '<a  href="' . route('user.show', $model->id) . '" title="' . $model->email . '">' . $email . '</a>';
                        })
                        /* column phone */
                        ->addColumn('mobile', function ($model) {
                            $phone = '';
                            if ($model->phone_number) {
                                $phone = $model->ext . ' ' . $model->phone_number;
                            }
                            $mobile = '';
                            if ($model->mobile) {
                                $mobile = $model->mobile;
                            }
                            $phone = $phone . ' ' . $mobile;
                            return $phone;
                        })
                        /* column account status */
                        ->addColumn('active', function ($model) {
               
                          return $this->userStatus($model);
                        })
                        /* column last login date */
                        ->addColumn('updated_at', function ($model) {
                            $t = $model->updated_at;
                            return faveoDate($t);
                        })
                        /* column Role */
                        ->addColumn('role', function ($model) {
                            if ($model->role === 'agent') {
                                return '<p class="btn btn-xs btn-default" style="pointer-events:none"><a href="#"><i class="fa fa-user" aria-hidden="true"></i>&nbsp;&nbsp;' . ucfirst($model->role) . '</a></p>';
                            }
                            if ($model->role === 'user') {
                                return '<p class="btn btn-xs btn-default" style="pointer-events:none"><a href="#" style="color:black"><i class="fa fa-user" aria-hidden="true"></i>&nbsp;&nbsp;&nbsp;' . ucfirst($model->role) . '</a></p>';
                            }
                           })
                        
                        /* column actions */
                        ->addColumn('actions', function ($model) {
                            if ($model->is_delete == 0) {
                                return '<a href="' . route('user.edit', $model->id) . '" class="btn btn-primary btn-xs"><i class="fa fa-edit" style="color:white;">&nbsp;</i>' . \Lang::get('lang.edit') . '</a>&nbsp; <a href="' . route('user.show', $model->id) . '" class="btn btn-primary btn-xs"><i class="fa fa-eye" style="color:white;">&nbsp;</i>' . \Lang::get('lang.view') . '</a>';
                            } else {
                                if (Auth::user()->role == 'admin') {
                                    // @if(Auth::user()->role == 'admin')
                                    return '<a href="' . route('user.show', $model->id) . '" class="btn btn-primary btn-xs">' . \Lang::get('lang.view') . '</a>';
                                }
                                if (Auth::user()->role == 'agent') {
                                    // @if(Auth::user()->role == 'admin')
                                    if ($model->role == 'user') {
                                        return '<a href="' . route('user.show', $model->id) . '" class="btn btn-primary btn-xs">' . \Lang::get('lang.view') . '</a>';
                                    }
                                }
                            }
                        })
                        ->rawColumns(['first_name', 'user_name', 'email', 'active','actions','role', 'mobile'])
                        ->make();
    }

    /**
     * This method restore user account 
     * @param type $userId of User
     * @return type string
     */
    public function restoreUser(string $userId)
    {
        try {
            User::where('id', $userId)->update(['is_delete' => 0, 'active' => 1, 'ban' => 0]);
            return redirect()->back()->with('success1', Lang::get('lang.user_restore_successfully'));
        } catch (Exception $ex) {
            return redirect()->back()->with('fails', $ex->getMessage());
        }
    }

    /**
     * Show the form for creating a new users.
     *
     * @return type view
     */
    public function create(CountryCode $code) {
        try {
            $aoption = getAccountActivationOptionValue();
            $email_mandatory = CommonSettings::select('status')->where('option_name', '=', 'email_mandatory')->first();
            $org = Organization::all();
            return view('themes.default1.agent.helpdesk.user.create', compact('org', 'email_mandatory', 'aoption'));
        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }

    /**
     * Store a newly created users in storage.
     *
     * @param type User            $user
     * @param type Sys_userRequest $request
     *
     * @return type redirect
     */
    public function store(User $user, Sys_userRequest $request) {
        try {
            /* insert the input request to sys_user table */
            /* Check whether function success or not */
            // dd($request->org_id);
            if ($request->org_id != "") {
                $org_id = Organization::where('id', '=', $request->org_id)->select('id')->first();
                // dd($org_id);
                // ->route('user.edit', $id)
                if ($org_id == null) {
                    return redirect()->back()->with('fails', Lang::get('lang.please_type_correct_organization_name'));
                }
            }
            if ($request->input('email') != '') {
                $user->email = $request->input('email');
            } else {
                $user->email = null;
            }
            $user->first_name = $request->input('first_name');
            $user->last_name = $request->input('last_name');
            $user->user_name = strtolower($request->input('user_name'));
            if ($request->input('mobile') != '') {
                $user->mobile = $request->input('mobile');
            } else {
                $user->mobile = null;
            }
            $user->ext = $request->input('ext');
            $user->phone_number = $request->input('phone_number');
            $user->country_code = $request->input('country_code');
            $user->active = $request->input('active');
            $user->internal_note = $request->input('internal_note');
            $password = $this->generateRandomString();
            $user->password = Hash::make($password);
            $user->role = 'user';
            $active_code = '';
            if ($request->get('active') == 0) {
                $active_code = str_random(60);
                $user->email_verify = $active_code;
            }
            $user->mobile_otp_verify = 'verifymobileifenable';
            if ($request->get('country_code') == '' && $request->get('mobile') != '') {
                return redirect()->back()->with(['fails' => Lang::get('lang.country-code-required-error'), 'country_code_error' => 1])->withInput();
            } else {
                $code = CountryCode::select('phonecode')->where('phonecode', '=', $request->get('country_code'))->get();
                if (!count($code)) {
                    return redirect()->back()->with(['fails' => Lang::get('lang.incorrect-country-code-error'), 'country_code_error' => 1])->withInput();
                }
            }
            // save user credentails
            if ($user->save() == true) {
                if ($request->input('org_id') != "") {
                    // $org_id = Organization::where('name', '=', $request->org_id)->select('id')->first();
                    // $add_user_from_org->org_id= $org_id->id;
                    $orgid = $request->org_id;
                    // $orgid = $request->input('org_id');
                    foreach ($orgid as $key => $value) {
                        $role = 'members';
                        $user_assign_organization = new User_org;
                        $user_assign_organization->org_id = $value;
                        $user_assign_organization->user_id = $user->id;
                        $user_assign_organization->role = $role;
                        $user_assign_organization->save();
                        // $this->storeUserOrgRelation($user->id, $value, $role);
                    }
                }
                // fetch user credentails to send mail
                $name = $user->first_name;
                $email = $user->email;
                // send mail on registration
                $notification[] = [
                    'registration_notification_alert' => [
                        'userid' => $user->id,
                        'from' => $this->PhpMailController->mailfrom('1', '0'),
                        'message' => ['subject' => null, 'scenario' => 'registration-notification'],
                        'variable' => ['new_user_name' => $name, 'new_user_email' => $email, 'user_password' => $password]
                    ],
                    'new_user_alert' => [
                        'model' => $user,
                        'userid' => $user->id,
                        'from' => $this->PhpMailController->mailfrom('1', '0'),
                        'message' => ['subject' => null, 'scenario' => 'new-user'],
                        'variable' => ['new_user_name' => $name, 'new_user_email' => $email, 'user_profile_link' => faveoUrl('user/' . $user->id)]
                    ],
                ];
                if ($active_code != '') {
                    $notification[] = [
                        'registration_alert' => [
                            'userid' => $user->id,
                            'from' => $this->PhpMailController->mailfrom('1', '0'),
                            'message' => ['subject' => null, 'scenario' => 'registration'],
                            'variable' => ['new_user_name' => $name, 'new_user_email' => $request->input('email'), 'account_activation_link' => faveoUrl('account/activate/' . $active_code)],
                        ]
                    ];
                }
                $notify = new Notify();
                if (!$request->input('email')) {
                    $notify->setParameter('send_mail', false);
                }
                $notify->setDetails($notification);
                \Event::fire(new \App\Events\LoginEvent($request));
                return redirect('user')->with('success', Lang::get('lang.user-saved-successfully'));
            }
            /* redirect to Index page with Success Message */
            return redirect()->back()->with('success', Lang::get('lang.user-saved-successfully'));
        } catch (\Exception $e) {
            /* redirect back with Fails Message */
            return redirect()->back()->with('fails', $e->getMessage())->withInput();
        }
    }

    /**
     * Random Password Genetor for users
     *
     * @param type int  $id
     * @param type User $user
     *
     * @return type view
     */
    public function randomPassword() {
        try {
            $alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890~!@#$%^&*(){}[]';
            $pass = array(); //remember to declare $pass as an array
            $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
            for ($i = 0; $i < 10; $i++) {
                $n = rand(0, $alphaLength);
                $pass[] = $alphabet[$n];
            }
            return implode($pass);
        } catch (Exception $e) {
            /* redirect to Index page with Fails Message */
            return redirect()->back()->with('fails1', $e->getMessage());
            // return redirect('user')->with('fails', $e->getMessage());
        }
    }

    /**
     * Random Password Genetor for users
     *
     * @param type int  $id
     * @param type User $user
     *
     * @return type view
     */
    public function randomPostPassword($id, ChangepasswordRequest $request) {
        try {
            $changepassword = $request->change_password;
            $user = User::whereId($id)->first();
            $password = $request->change_password;
            $user->password = Hash::make($password);
            $user->save();
            $name = $user->first_name;
            $email = $user->email;
            $this->PhpMailController->sendmail($from = $this->PhpMailController
                    ->mailfrom('1', '0'), $to = ['name' => $name, 'email' => $email], $message = ['subject' => null, 'scenario' => 'reset_new_password'], $template_variables = ['user' => $name, 'user_password' => $password]);
            return redirect()->back()->with('success1', Lang::get('lang.password_change_successfully'));
            // return redirect('user')->with('success', Lang::get('lang.password_change_successfully'));
        } catch (Exception $e) {
            return redirect()->back()->with('fails1', $e->getMessage());
        }
    }

    /**
     * @param type $id
     * @param Request $request
     * @return type
     */
    public function changeRoleAdmin($id, Request $request) {
        try {

            $user = User::whereId($id)->first();
            $agent_limit = \Config::get('auth.agent_limit');
            if ($agent_limit != 0) {
                $system_agent = User::where('role', '!=', 'user')->count();
                if (($system_agent) >= $agent_limit) {
                   if ($user->role == 'user') {
                        return redirect()->back()->with('fails', Lang::get('lang.user-limit-reached-message'));
                    }
                }
            }
            $user->role = 'admin';
            if($user->agent_tzone == '') {
                $user->agent_tzone = getGMT(true);
            }
              if (!$request->primary_department) {
                return redirect()->back()->with('fails', Lang::get('lang.please_select_department'));
            }
            $delete_dept = DepartmentAssignAgents::where('agent_id', '=', $user->id)->delete();
            $primary_dpt = $request->primary_department;
            foreach ($primary_dpt as $primary_dpts) {
                $dept_assign_agent = new DepartmentAssignAgents;
                $dept_assign_agent->agent_id = $user->id;
                $dept_assign_agent->department_id = $primary_dpts;
                $dept_assign_agent->save();
            }
            // $user->primary_dpt = $primary_dpt[0];
            $user->save();
            OrganizationDepartment::where('org_dept_manager', $id)->update(['org_dept_manager'=>null]);
            User_org::where('user_id',$id)->delete();


            return redirect()->back()->with('success', Lang::get('lang.role_change_successfully'));
        } catch (Exception $e) {
            /* redirect to Index page with Fails Message */
            // return redirect('user')->with('fails', $e->getMessage());
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }

    /**
     *
     * @param type $id
     * @param Request $request
     * @return type
     */
    public function changeRoleAgent($id, Request $request) {
        try {

            $user = User::whereId($id)->first();
            $agent_limit = \Config::get('auth.agent_limit');
            if ($agent_limit != 0) {
                $system_agent = User::where('role', '!=', 'user')->count();
                if (($system_agent) >= $agent_limit) {
                    if ($user->role == 'user') {
                        return redirect()->back()->with('fails1', Lang::get('lang.user-limit-reached-message'));
                    }
                }
            }
            if (!$request->primary_department) {
                return redirect()->back()->with('fails1', Lang::get('lang.please_select_department'));
            }

            $user->role = 'agent';
            if($user->agent_tzone == '') {
                $user->agent_tzone = getGMT(true);
            }
            $delete_dept = DepartmentAssignAgents::where('agent_id', '=', $user->id)->delete();
            $primary_dpt = $request->primary_department;
            foreach ($primary_dpt as $primary_dpts) {
                $dept_assign_agent = new DepartmentAssignAgents;
                $dept_assign_agent->agent_id = $user->id;
                $dept_assign_agent->department_id = $primary_dpts;
                $dept_assign_agent->save();
            }
            $user->primary_dpt = $primary_dpt[0];
            $user->save();
            OrganizationDepartment::where('org_dept_manager', $id)->update(['org_dept_manager'=>null]);
            User_org::where('user_id',$id)->delete();
            // $dept_assign_agent = DepartmentAssignAgents::where('agent_id', '=', $user->id)->first();
            // if ($dept_assign_agent) {
            //     $dept_assign_agent->agent_id = $user->id;
            //     $dept_assign_agent->department_id = $request->primary_department;
            //     $dept_assign_agent->save();
            // } else {
            //     $dept_assign_agent = new DepartmentAssignAgents;
            //     $dept_assign_agent->agent_id = $user->id;
            //     $dept_assign_agent->department_id = $request->primary_department;
            //     $dept_assign_agent->save();
            // }
            // return redirect('user')->with('success', Lang::get('lang.role_change_successfully'));
            return redirect()->back()->with('success1', Lang::get('lang.role_change_successfully'));
        } catch (Exception $e) {
            /* redirect to Index page with Fails Message */
            // return redirect('user')->with('fails', $e->getMessage());
            return redirect()->back()->with('fails1', $e->getMessage());
        }
    }

    /**
     * this method change role to user
     * @param type $userId of user
     * @return type string
     */
    public function changeRoleUser($userId) {
        try {
            $ticket = Tickets::where('assigned_to',$userId)->where('status','1')->get();
            if ($ticket) {
                $ticket = Tickets::where('assigned_to', $userId)->update(array("assigned_to" => null));
            }
            $user = User::whereId($userId)->first();
            $user->role = 'user';
            $user->assign_group = null;
            $user->primary_dpt = null;
            $user->remember_token = null;
            $user->save();
            if ($user->role != 'user') {
                $user->ticketsAssigned()->whereHas('statuses.type', function($query) {
                    $query->where('name', 'open');
                })->update(['assigned_to' => null]);
            }
            DepartmentAssignAgents::where('agent_id', $userId)->delete();
            Assign_team_agent::where('agent_id',$userId)->delete();
            DepartmentAssignManager::where('manager_id',$userId)->delete();
            Teams::where('team_lead','$userId')->update(['team_lead'=>null]);
            return redirect()->back()->with('success1', Lang::get('lang.role_change_successfully'));
        } catch (Exception $e) {
            /* redirect to Index page with Fails Message */
           return redirect()->back()->with('fails1', $e->getMessage());
        }
    }

    /**
     * This method deactivate user or agent
     * @param intiger $id of User
     * @return type string
     */
    public function deactivateUser($userId)
    {
        try {

            $deleteAll = Input::get('delete_all');
            $authUser = \Auth::user();
            $users = User::where('id', $userId)->first();

            ApprovalMeta::where('value', $userId)->delete();
            DepartmentAssignManager::where('manager_id', $userId)->delete();
            Teams::where('team_lead', $userId)->update(['team_lead' => null]);
            Teams::where('team_lead', $userId)->update(array('team_lead' => NULL));
            Department::where('manager', $userId)->update(array('manager' => NULL));
            OrganizationDepartment::where('org_dept_manager', $userId)->update(['org_dept_manager' => null]);
            if ($users->role == 'user' && \Auth::check() && $authUser->role != 'user') {
                $deleteAllUser = Input::get('delete_all_user');

                $tickets = Tickets::where('user_id', $users->id)->pluck('id')->toArray();

                if ($tickets && !Input::get('delete_all_user') && !Input::get('assign_to_user')) {
                    return redirect()->back()->with('fails1', Lang::get('lang.select_another_user'));
                }

                if (!$deleteAllUser) {
                    $assignUserEmail = Input::get('assign_to_user');

                    if ($assignUserEmail) {
                        $userEmail = explode('_', $assignUserEmail);

                        if ($users->id == $userEmail[1]) {
                            return redirect()->back()->with('fails1', Lang::get('lang.select_another_user'));
                        }

                        if ($tickets) {
                            foreach ($tickets as $ticketId) {
                                Tickets::where('id', $ticketId)->update(['user_id' => $userEmail[1]]);
                                //use name helper function
                                $assignee = User::where('id', Auth::user()->id)->first();
                                Ticket_Thread::create(['ticket_id' => $ticketId, 'user_id' => Auth::user()->id, 'body' => Lang::get('lang.this-ticket-owner-changed-by') . '' . $assignee->fullName]);
                            }
                        }
                    }
                } else {

                    $tickets = Tickets::where('user_id', $userId)->pluck('id')->toArray();
                    if ($tickets) {
                        $status = Ticket_Status::select('id')->where('purpose_of_status', 2)->orderBy('order')->min('id');
                        foreach ($tickets as $ticketId) {
                            Tickets::where('id', $ticketId)->update(['status' => $status]);
                            //use name helper function
                            $assignee = User::where('id', Auth::user()->id)->first();

                            Ticket_Thread::create(['ticket_id' => $ticketId, 'user_id' => Auth::user()->id, 'body' => Lang::get('lang.this-ticket-has-been-close-by') . '' . $assignee->fullName]);
                        }
                    }
                }
                User::where('id', $users->id)->update(['is_delete' => 1, 'active' => 0]);
                return redirect()->back()->with('success1', Lang::get('lang.user_deactivated_successfully'));
            }

            if (($users->role != 'user' && \Auth::check() && $authUser->role == 'admin' && $authUser->id != $users->id)) {
                $ticketIds = Tickets::where('assigned_to', $userId)->where('status', 1)->pluck('id')->toArray();

                if (count($ticketIds) && !$deleteAll && !Input::get('assign_to')) {
                    return redirect()->back()->with('fails1', Lang::get('lang.select_another_agent'));
                }

                // Disable ticket filters created by agent
                $this->disableTicketFilters($users);
                if ($deleteAll == 1) {

                    if (count($ticketIds)) {
                        foreach ($ticketIds as $ticketId) {
                            Tickets::where('id', $ticketId)->update(['assigned_to' => null]);

                            Ticket_Thread::create(['ticket_id' => $ticketId, 'is_internal'=>1,'user_id' => Auth::user()->id, 'body' => Lang::get('lang.this-ticket-has-been-unassigned')]);
                        }
                    }

                    User::where('id', $users->id)->update(['is_delete' => 1, 'active' => 0]);
                    return redirect()->back()->with('success1', Lang::get('lang.agent_deactivated_successfully'));
                } else {

                    $userEmail = Input::get('assign_to');
                    $assignTo = explode('_', $userEmail);
                    if ($assignTo[0] == 'user') {
                        if ($users->id == $assignTo[1]) {
                            return redirect()->back()->with('fails1', Lang::get('lang.select_another_agent'));
                        }

                        $ticketIds = Tickets::where('assigned_to', $userId)->pluck('id')->toArray();
                        if (count($ticketIds)) {
                            foreach ($ticketIds as $ticketId) {
                                Tickets::where('id', $ticketId)->update(['assigned_to' => $assignTo[1]]);
                                //use name helper function

                                $assignee = User::where('id', Auth::user()->id)->first();
                                Ticket_Thread::create(['ticket_id' => $ticketId, 'is_internal'=>1,'user_id' => Auth::user()->id, 'body' => Lang::get('lang.this-ticket-has-been-assigned-to') . ' ' . $assignee->fullName]);
                            }
                        }

                        User::where('id', $users->id)->update(['is_delete' => 1, 'active' => 0]);
                        if ($users->role != 'user') {
                            $users->ticketsAssigned()->whereHas('statuses.type', function($query) {
                                $query->where('name', 'open');
                            })->update(['assigned_to' => null]);
                        }

                        return redirect()->back()->with('success1', Lang::get('lang.agent_deactivated_successfully_and_ticket_assign_to_another_agent'));
                    }

                    User::where('id', $users->id)->update(['is_delete' => 1, 'active' => 0]);
                    return redirect()->back()->with('success1', Lang::get('lang.agent_deactivated_successfully'));
                }
            }
        } catch (Exception $ex) {
            // redirect to Index page with Fails Message 
            return redirect('user')->with('fails', $ex->getMessage());
        }
    }

    /**
     * Display the specified users.
     *
     * @param type int  $id
     * @param type User $user
     *
     * @return type view
     */
    public function show($id) {
        try {
            $users = User::
                    with(['userExtraField.getKeyRelation' => function($q) {
                            $q->where('form', 'user');
                        }])
                    ->where('id', $id)
                    ->first();
            $country_code = "auto";
            $code = CountryCode::select('iso')->where('phonecode', '=', $users->country_code)->first();
            if ($code && $users->country_code != 0) {
                $country_code = $code->iso;
            }
            $ticket_policy = $this->ticket_policy;
            $policy = $this->ticket_policy;
            if ($users) {
                return view('themes.default1.agent.helpdesk.user.show', compact('users', 'policy','ticket_policy', 'country_code'));
            } else {
                return redirect()->back()->with('fails', Lang::get('lang.user-not-found'));
            }
        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param type int  $id
     * @param type User $user
     *
     * @return type Response
     */
    public function edit($id) {
        try {

            $email_mandatory = CommonSettings::select('status')->where('option_name', '=', 'email_mandatory')->first();
            $aoption = getAccountActivationOptionValue();
            $user = User::where('id', '=', $id)->first();
            if ($user) {
                $country_code = "auto";
                $country = CountryCode::select('iso')->where('phonecode', '=', $user->country_code)->first();
                if ($country && $user->country_code != 0) {
                    $country_code = $country->iso;
                }
                if ($user->role == 'admin' || $user->role == 'agent') {
                    $team = Teams::where('status', '=', 1)->get();
                    $teams1 = $team->pluck('name', 'id');
                    //use helper function
                     $timezones = timezoneFormat();

                    // $groups = Groups::where('group_status', '=', 1)->get();
                    $departments = Department::get();
                    $dept = DepartmentAssignAgents::where('agent_id', '=', $id)->pluck('department_id')->toArray();
                    $table = Assign_team_agent::where('agent_id', $id)->first();
                    $teams = $team->pluck('id', 'name')->toArray();
                    $assign = Assign_team_agent::where('agent_id', $id)->pluck('team_id')->toArray();
                    return view('themes.default1.agent.helpdesk.user.agentedit', compact('teams', 'assign', 'table', 'teams1', 'selectedTeams', 'user', 'timezones', 'departments', 'dept', 'team', 'exp', 'counted', 'country_code', 'aoption'));
                } else {
                    $users = $user;
                    $orgs = Organization::all();
                    $organization = User_org::where('user_id', '=', $id)->where('role', '=', 'members')->pluck('org_id')->toArray();
                    $term = preg_replace('/.+@/', '', $users->email);
                    $query = DB::table('organization')
                                    ->whereRaw('FIND_IN_SET(?,domain)', [$term])
                                    ->pluck('id as org_id')->toArray();
                    $check_org = array_merge($organization, $query);
                    $organization_id = array_unique($check_org);
                    // dd($organization_id );
                    return view('themes.default1.agent.helpdesk.user.edit', compact('users', 'orgs', '$settings', 'email_mandatory', 'organization_id', 'country_code', 'aoption'));
                }
            } else {
                return redirect()->back()->with('fails', Lang::get('lang.user-not-found'));
            }
        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }

// orgAutofill
    /**
     * Update the specified user in storage.
     *
     * @param type int            $id
     * @param type User           $user
     * @param type Sys_userUpdate $request
     *
     * @return type Response
     */
    public function update($id, AgentUpdate $request) {
        try {

            if ($request->get('country_code') == '' && $request->get('mobile') != '') {
                return redirect()->back()->with(['fails' => Lang::get('lang.country-code-required-error'), 'country_code' => 1])->withInput();
            } else {
                $code = CountryCode::select('phonecode')->where('phonecode', '=', $request->get('country_code'))->get();
                if (!count($code)) {
                    return redirect()->back()->with(['fails' => Lang::get('lang.incorrect-country-code-error'), 'country_code' => 1])->withInput();
                }
            }
            $user = User::whereId($id)->first();
            $old_mobile_number = $user->mobile;
            if ($request->input('country_code') != '' or $request->input('country_code') != null) {
                $user->country_code = $request->input('country_code');
            }
            $user->mobile = ($request->input('mobile') == '') ? null : $request->input('mobile');
            $user->fill($request->except('daylight_save', 'limit_access', 'directory_listing', 'vocation_mode', 'assign_team', 'mobile'));
            if ($user->role != 'user') {

                //saving agent specific details
                // storing all the details
                $daylight_save = $request->input('daylight_save');
                $limit_access = $request->input('limit_access');
                $directory_listing = $request->input('directory_listing');
                $vocation_mode = $request->input('vocation_mode');
                //==============================================
                $table = Assign_team_agent::where('agent_id', $id);
                $table->delete();
                $requests = $request->input('team');
                if ($requests != null) {
                    // inserting team details
                    foreach ($requests as $req) {
                        DB::insert('insert into team_assign_agent (team_id, agent_id) values (?,?)', [$req, $id]);
                    }
                }
                $user->assign_group = $request->group;
                $permission = $request->input('permission');
                $user->permision()->updateOrCreate(['user_id' => $user->id], ['permision' => json_encode($permission)]);
                $delete_dept = DepartmentAssignAgents::where('agent_id', '=', $id)->delete();
                $primary_dpt = $request->primary_department;
                foreach ($primary_dpt as $primary_dpts) {
                    $dept_assign_agent = new DepartmentAssignAgents;
                    $dept_assign_agent->agent_id = $user->id;
                    $dept_assign_agent->department_id = $primary_dpts;
                    $dept_assign_agent->save();
                }
                $user->primary_dpt = $primary_dpt[0];
                $user->agent_tzone = $request->agent_time_zone;

                $this->typeRelation($user, $request->input('type'));
            } else {
                //saving client specific details
                if ($request->org_id != "") {
                    $org_id = Organization::where('id', '=', $request->org_id)->select('id')->first();
                    if ($org_id == null) {
                        return redirect()->route('user.edit', $id)->with('fails', Lang::get('lang.please_type_correct_organization_name'));
                    }
                }
                if ($request->input('org_id') == "") {
                    $delete_user_from_org = User_org::where('user_id', '=', $id)->delete();
                } else {
                    $delete_user_from_org = User_org::where('user_id', '=', $id)->delete();
                    $orgid = $request->org_id;
                    foreach ($orgid as $key => $value) {
                        $role = 'members';
                        $user_assign_organization = new User_org;
                        $user_assign_organization->org_id = $value;
                        $user_assign_organization->user_id = $user->id;
                        $user_assign_organization->role = $role;
                        $user_assign_organization->save();
                    }
                }
            }
            if ($old_mobile_number != $request->input('mobile')) {
                $user->mobile_otp_verify = "verifymobileifenable";
            }
            $user->save();
            $this->removeGlobalAccess($id);
            return redirect()->back()->with('success', Lang::get('lang.User-profile-Updated-Successfully'));
        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }

    /**
     * get agent profile page.
     *
     * @return type view
     */
    public function getProfile() {
        $user = Auth::user();
        try {
            return view('themes.default1.agent.helpdesk.user.profile', compact('user'));
        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }

    /**
     * get profile edit page.
     *
     * @return type view
     */
    public function getProfileedit(CountryCode $code) {
        $user = Auth::user();
        $country_code = "auto";
        $code = CountryCode::select('iso')->where('phonecode', '=', $user->country_code)->first();
        if ($code && $user->country_code != 0) {
            $country_code = $code->iso;
        }
        $aoption = getAccountActivationOptionValue();
        try {
            return view('themes.default1.agent.helpdesk.user.profile-edit', compact('user', 'country_code', 'aoption'));
        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }

    /**
     * post profile edit.
     *
     * @param type int            $id
     * @param type ProfileRequest $request
     *
     * @return type Redirect
     */
    public function postProfileedit(ProfileRequest $request) {
        try {
            // geet authenticated user details
            $user = Auth::user();
            if ($request->get('country_code') == '' && $request->get('mobile') != '') {
                return redirect()->back()->with(['fails' => Lang::get('lang.country-code-required-error'), 'country_code_error' => 1])->withInput();
            } else {
                $code = CountryCode::select('phonecode')->where('phonecode', '=', $request->get('country_code'))->get();
                if (!count($code)) {
                    return redirect()->back()->with(['fails' => Lang::get('lang.incorrect-country-code-error'), 'country_code_error' => 1])->withInput();
                }
                $user->country_code = $request->country_code;
            }
            $user->fill($request->except('profile_pic', 'mobile'));
            $user->gender = $request->input('gender');
            $user->location = $request->input('location');
            $user->save();
            if (Input::file('profile_pic')) {
                // fetching picture name
                $name = Input::file('profile_pic')->getClientOriginalName();
                // fetching upload destination path
                $destinationPath = public_path('uploads' . DIRECTORY_SEPARATOR . 'profilepic');
                // adding a random value to profile picture filename
                $fileName = rand(0000, 9999) . '.' . str_replace(" ", "_", $name);
                // moving the picture to a destination folder
                Input::file('profile_pic')->move($destinationPath, $fileName);
                // saving filename to database
                $user->profile_pic = $fileName;
            }
            if ($request->get('mobile')) {
                $user->mobile = $request->get('mobile');
            } else {
                $user->mobile = null;
            }
            if ($user->save()) {
                //profile pic change  if some body change profile pic
                 Comment::where('email',$user->email)->update(['profile_pic'=>$user->profile_pic]);
                $admin_agent_ctrl = new \App\Http\Controllers\Admin\helpdesk\AgentController();
                $admin_agent_ctrl->typeRelation($user, $request->input('type'));


                return Redirect::route('profile')->with('success', Lang::get('lang.Profile-Updated-sucessfully'));
            } else {
                return Redirect::route('profile')->with('fails', Lang::get('lang.Profile-Updated-sucessfully'));
            }
        } catch (Exception $e) {
            return Redirect::route('profile')->with('fails', $e->getMessage());
        }
    }

    /**
     * Post profile password.
     *
     * @param type int             $id
     * @param type ProfilePassword $request
     *
     * @return type Redirect
     */
    public function postProfilePassword($id, ProfilePassword $request) {
        // get authenticated user
        $user = Auth::user();
        // checking if the old password matches the new password
        if (Hash::check($request->input('old_password'), $user->getAuthPassword())) {
            $user->password = Hash::make($request->input('new_password'));
            try {
                $user->save();
                return redirect('profile-edit')->with('success1', Lang::get('lang.password_updated_sucessfully'));
            } catch (Exception $e) {
                return redirect('profile-edit')->with('fails', $e->getMessage());
            }
        } else {
            return redirect('profile-edit')->with('fails1', Lang::get('lang.password_was_not_updated_incorrect_old_password'));
        }
    }

    /**
     * Assigning an user to an organization.
     *
     * @param type $id
     *
     * @return type boolean
     */
    public function UserAssignOrg($id)
    {

        $orgIds = Input::get('org');
        
        if ($orgIds) {
            User_org::where('user_id', $id)->delete();
            foreach ($orgIds as $orgId) {
                User_org::create(['org_id' => $orgId, 'user_id' => $id, 'role' => 'members']);
            }
            //for micro organization button on
            $orgDept = Input::get('org_dept');
            if ($orgDept) {
                $checkOrgDept = OrganizationDepartment::where('id', $orgDept)->first();
                User_org::where('user_id', $id)->where('org_id', $checkOrgDept->org_id)->update(['org_department' => Input::get('org_dept')]);
            }
            return 1;
        } else {
            return 2;
        }
    }

    /**
     * 
     * @param type $id
     * @return int
     */
    public function UsereditAssignOrg($id) {
        $org_name = Input::get('org');
        if ($org_name) {
            $org = Organization::where('name', '=', $org_name)->pluck('id')->first();
            if ($org) {
                $user_org = User_org::where('user_id', '=', $id)->first();
                $user_org->org_id = $org;
                $user_org->user_id = $id;
                $user_org->role = 'members';
                $user_org->save();
                return 1;
            } else {
                return 0;
            }
        } else {
            return 2;
        }
    }

    /**
     * 
     * @param type $id
     * @return int
     */
    public function orgAssignUser($id) {
        $org = Input::get('org');
        $user_org = new User_org();
        $user_org->org_id = $id;
        $user_org->user_id = $org;
        $user_org->role = 'members';
        $user_org->save();
        return 1;
    }
/**
 * this method delete organization and organization department  from user 
 * @param type $id of user
 * @param type $org_id of organization id
 * @return type
 */
    public function removeUserOrg($id, $org_id)
    {
        try {
            $orgDept = User_org::where('user_id', $id)->where('org_id', $org_id)->value('org_department');
            if ($orgDept) {
                UserAdditionalInfo::where('owner', $id)->where('key', 'department')->update(['value' => null]);
            }
            User_org::where('user_id', $id)->where('org_id', $org_id)->delete();
            return redirect()->back()->with('success1', Lang::get('lang.the_user_has_been_removed_from_this_organization'));
        } catch (Exception $ex) {
            return redirect()->back()->with('fails', $ex->getMessage());
        }
    }

    /**
     * creating an organization in user profile page via modal popup.
     * @param type $id
     * @return type int
     */
    public function userCreateOrganization($id) {
        // checking if the entered value for website is available in database
        if (Input::get('website') != null) {
            // checking website
            $check = Organization::where('website', Input::get('website'))->first();
        } else {
            $check = null;
        }
        // checking if the name is unique
        $check2 = Organization::where('name', Input::get('name'))->first();
        // if any of the fields is not available then return false
        if (\Input::get('name') == null) {
            return 'Name is required';
        } elseif ($check2 != null) {
            return 'Name should be Unique';
        } elseif ($check != null) {
            return 'Website should be Unique';
        } else {
            // storing organization details and assigning the current user to that organization
            $org = new Organization();
            $org->name = Input::get('name');
            $org->phone = Input::get('phone');
            $org->website = Input::get('website');
            $org->address = Input::get('address');
            $org->internal_notes = Input::get('internal');
            $org->save();

            User_org::create(['org_id'=>$org->id,'user_id'=>$id,'role'=>'members']);
            // for success return 0
            return 0;
        }
    }

    /**
     * Generate a random string for password.
     *
     * @param type $length
     *
     * @return string
     */
    public function generateRandomString($length = 10) {
        // list of supported characters
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        // character length checked
        $charactersLength = strlen($characters);
        // creating an empty variable for random string
        $randomString = '';
        // fetching random string
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        // return random string
        return $randomString;
    }

    /**
     * 
     * @param type $userid
     * @param type $orgid
     * @param type $role
     */
    public function storeUserOrgRelation($userid, $orgid, $role) {
        $org_relations = new User_org();
        $org_relation = $org_relations->where('user_id', $userid)->first();
        if ($org_relation) {
            $org_relation->delete();
        }
        $org_relations->create([
            'user_id' => $userid,
            'org_id' => $orgid,
            'role' => $role,
        ]);
    }

    /**
     * 
     * @return type
     */
    public function getExportUser() {
        try {
            return view('themes.default1.agent.helpdesk.user.export');
        } catch (Exception $ex) {
            return redirect()->back()->with('fails', $ex->getMessage());
        }
    }

    /**
     * 
     * @param Request $request
     * @return type
     */
    public function exportUser(Request $request) {
        try {
            $date = $request->input('date');
            $date = str_replace(' ', '', $date);
            $date_array = explode(':', $date);
            $first = $date_array[0] . " 00:00:00";
            $second = $date_array[1] . " 23:59:59";
            $first_date = $this->convertDate($first);
            $second_date = $this->convertDate($second);
            $users = $this->getUsers($first_date, $second_date);
            $excel_controller = new \App\Http\Controllers\Common\ExcelController();
            $filename = "users" . $date;
            $excel_controller->export($filename, $users);
        } catch (Exception $ex) {
            return redirect()->back()->with('fails', $ex->getMessage());
        }
    }

    /**
     * 
     * @param type $date
     * @return type
     */
    public function convertDate($date) {
        $converted_date = date('Y-m-d H:i:s', strtotime($date));
        return $converted_date;
    }

    /**
     * 
     * @param type $first
     * @param type $last
     * @return type
     */
    public function getUsers($first, $last) {
        $user = new User();
        $users = $user->leftJoin('user_assign_organization', 'users.id', '=', 'user_assign_organization.user_id')
                ->leftJoin('organization', 'user_assign_organization.org_id', '=', 'organization.id')
                ->whereBetween('users.created_at', [$first, $last])
                ->where('users.role', '!=', 'admin')
                //->where('users.active', 1)
                ->select('users.user_name as Username', 'users.email as Email', 'users.first_name as Fisrtname', 'users.last_name as Lastname', 'organization.name as Organization', 'users.role as Role', 'users.active as Active')
                ->get()
                ->toArray();
        return $users;
    }

    /**
     * 
     * @param OtpVerifyRequest $request
     * @return string|int
     */
    public function resendOTP(OtpVerifyRequest $request) {
        if (\Schema::hasTable('sms')) {
            $sms = DB::table('sms')->get();
            if (count($sms) > 0) {
                \Event::fire(new \App\Events\LoginEvent($request));
                return 1;
            }
        } else {
            return "Plugin has not been setup successfully.";
        }
    }

    /**
     * 
     * @return int
     */
    public function verifyOTP() {
        $user = User::select('id', 'mobile', 'country_code', 'user_name', 'mobile_otp_verify', 'updated_at')->where('id', '=', Input::get('u_id'))->first();
        $otp = Input::get('otp');
        if ($otp != null || $otp != '') {
            $otp_length = strlen(Input::get('otp'));
            if (($otp_length == 6 && !preg_match("/[a-z]/i", Input::get('otp')))) {
                $otp2 = Hash::make(Input::get('otp'));
                $date1 = date_format($user->updated_at, "Y-m-d h:i:sa");
                $date2 = date("Y-m-d h:i:sa");
                $time1 = new DateTime($date2);
                $time2 = new DateTime($date1);
                $interval = $time1->diff($time2);
                if ($interval->i > 10 || $interval->h > 0) {
                    $message = Lang::get('lang.otp-expired');
                    return $message;
                } else {
                    if (Hash::check(Input::get('otp'), $user->mobile_otp_verify)) {
                        User::where('id', '=', $user->id)
                                ->update([
                                    'mobile_otp_verify' => '1',
                                    'mobile' => Input::get('mobile'),
                                    'country_code' => str_replace('+', '', Input::get('country_code'))
                        ]);
                        return 1;
                    } else {
                        $message = Lang::get('lang.otp-not-matched');
                        return $message;
                    }
                }
            } else {
                $message = Lang::get('lang.otp-invalid');
                return $message;
            }
        } else {
            $message = Lang::get('lang.otp-not-matched');
            return $message;
        }
    }

    /**
     * 
     * @param Request $request
     */
    public function getAgentDetails(Request $request) {
        // $ids=$request->ticket_id;
        // $ticket_dept_ids = Tickets::whereIn('id',$ids)->pluck('dept_id')->unique();
        // foreach($ticket_dept_ids as $id){
        //     $users_ids = DepartmentAssignAgents::where('department_id',$id);
        // }
        // $agent_ids = $users_ids->pluck('agent_id')->unique()->toArray();
        // $users_ids = DepartmentAssignAgents::whereIn('department_id',$ticket_dept_ids)->pluck('agent_id')->unique()->toArray();
        // $agents = User::whereIn('id',$agent_ids)->select('id','user_name','first_name','last_name')->get();
        $assignto_agent = User::where('role', '!=', 'user')->select('id', 'user_name', 'first_name', 'last_name')->where('active', '=', 1)->orderBy('first_name')->get();
        $count_assign_agent = count($assignto_agent);
        $teams = Teams::where('status', '=', '1')->where('team_lead', '!=', null)->get();
        $count_teams = count($teams);
        $html111 = "";
        $html11 = "";
        $html1 = "";
        // $html111.= "<option value=' '>" . 'select assigner' . "</option>";
        foreach ($assignto_agent as $agent) {
            $html1 .= "<option value='user_" . $agent->id . "'>" . $agent->first_name . ' ' . $agent->last_name . "</option>";
        }
        $html11.="<optgroup label=" . 'Agents(' . $count_assign_agent . ')' . ">";
        $html22 = "";
        $html2 = "";
        foreach ($teams as $team) {
            $html2 .= "<option value='team_" . $team->id . "'>" . $team->name . "</option>";
        }
        $html22.="<optgroup label=" . 'Teams(' . $count_teams . ')' . ">";
        echo $html11, $html1, $html22, $html2;
        //     if($agents){
        //     foreach ($agents as $user) {
        //          echo "<option value='user_$user->id'>".$user->name().'</option>';
        //     }
        // }
        // else{
        // }
    }

    /**
     *
     * @param Request $request
     * @return string
     */
    public function settingsUpdateStatus(Request $request) {
        try {
            $user =User::where('id', $request->user_id)->select('role')->first();
            if ((!$this->ticket_policy->accountActivation() && $users->role == 'user') || (!$this->ticket_policy->agentAccountActivation() && $users->role == 'agent')){
                return redirect('dashboard')->with('fails', Lang::get('lang.permission_denied'));
            }
            $user_id = $request->user_id;
            $user_status = $request->settings_status;
            User::where('id', $user_id)->update(['active' => $user_status]);
            return Lang::get('lang.your_status_updated_successfully');
        } catch (Exception $e) {
            return Redirect()->back()->with('fails', $e->getMessage());
        }
    }

    /**
     *
     * @param Request $request
     * @return string
     */
    public function settingsUpdateBan(Request $request) {
        if (!$this->ticket_policy->ban()) {
            if ($request->ajax()) {
                return response()->make('Permission denied', 500);
            }
            return redirect('dashboard')->with('fails', Lang::get('lang.permission_denied'));
        }
        try {
            $user_id = $request->user_id;
            $user_ban = $request->settings_ban;
            $update_user = User::where('id', '=', $user_id)->first();
            $update_user->ban = $user_ban;
            $update_user->save();
            $user = User::find($user_id)->first();
            if ($user->role != 'user') {
                $user->ticketsAssigned()->whereHas('statuses.type', function($query) {
                    $query->where('name', 'open');
                })->update(['assigned_to' => null]);
            }
            $checkPermissionForApproval=ApprovalMeta::where('value','=',$request->user_id)->count();
                if($checkPermissionForApproval>0){
                    ApprovalMeta::where('value','=',$request->user_id)->delete();
                }

                 $check_dept_maneger = DepartmentAssignManager::where('manager_id','=',$request->user_id)->count();
                if($check_dept_maneger>0){
                DepartmentAssignManager::where('manager_id','=',$request->user_id)->delete();
                }
                $checkTeamLead=Teams::where('team_lead','=',$request->user_id)->count();
                if($checkTeamLead>0){
                Teams::where('team_lead','=',$request->user_id)->delete();
                }
                 OrganizationDepartment::where('org_dept_manager', $request->user_id)->update(['org_dept_manager'=>null]);

           if ($request->ajax()) {
                return response()->make(Lang::get('lang.your_status_updated_successfully'));
            }
            return Lang::get('lang.your_status_updated_successfully');
        } catch (Exception $e) {
            if ($request->ajax()) {
                return response()->make($e->getMessage(), 500);
            }
            return Redirect()->back()->with('fails', $e->getMessage());
        }
    }

    /**
     * 
     * @param Request $request
     * @return type
     */
    public function settingsUpdateMobileVerify(Request $request) {
        try {
            if (!$this->ticket_policy->mobileVerification()) {
                return redirect('dashboard')->with('fails', Lang::get('lang.permission_denied'));
            }
            $user_id = $request->user_id;
            $user_ban = $request->settings_ban;
            User::where('id', $user_id)->update(['mobile_verify' => $user_ban]);
            return Lang::get('lang.your_status_updated_successfully');
        } catch (Exception $e) {
            return $e->getMessage();
        }
    }

    /**
     * 
     * @return type
     */
    public function orgAutofill() {

        return view('themes.default1.agent.helpdesk.user.orgautocomplite');
    }

    /**
     * 
     * @param Request $request
     * @return type json
     */
    public function createRequester(Request $request, $type = null) {
        $this->validate($request, [
          'email'         =>  'required|unique:users,email|unique:emails,email_address',
          'full_name'     => 'required'
        ]);
            try {
            $auth_control = new \App\Http\Controllers\Auth\AuthController();
            $user_create_request = new \App\Http\Requests\helpdesk\RegisterRequest();
            $user = new User();
            $password = str_random(8);
            $all = $request->all() + ['password' => $password, 'password_confirmation' => $password];
            $user_create_request->replace($all);
            $response = $auth_control->postRegister($user, $user_create_request, true);
            
            if ($request->company) {
                $orgids = $request->company;
                foreach ($orgids as $orgid) {
                    $role = 'members';
                    $user_assign_organization = new User_org;
                    $user_assign_organization->org_id = $orgid;
                    $user_assign_organization->user_id = $user->id;
                    $user_assign_organization->role = $role;
                    $user_assign_organization->save();
                }
            }
            //associate user to organization base on domain match
             $this->domainConnection($user->id);
             $status = 200;
        } catch (\Exception $e) {
            $response = ['error' => [$e->getMessage()]];
            $status = 500;
            return response()->json($response, $status);
        }

        if($type == 'batch-ticket'){
            return $response;
        }
        return response()->json(compact('response'), $status);
    }

     

    /**
     * 
     * @param Request $request
     * @return type json
     */
    public function getRequesterForCC(Request $request) {
        try {
            $this->validate($request, [
                'term' => 'required',
            ]);
            $term = $request->input('term');
            $requester = User::where('ban', 0)
                    ->where('active', 1)
                    ->where('is_delete', 0)
                    ->whereNotNull('email')
                    ->where('email', 'LIKE', '%' . $term . '%')
                    ->select('id', 'user_name', 'email', 'first_name', 'last_name', 'profile_pic')
                    ->get();
            $response = $requester->toArray();
            $status = 200;
        } catch (\Exception $e) {
            $response = ['error' => [$e->getMessage()]];
            $status = 500;
            return response()->json($response, $status);
        }
        return response()->json(compact('response'), $status);
    }

    /**
     * 
     * @param \Illuminate\Http\Request $request
     * @return type json
     */
    public function find(Request $request) {
        try {
            if ($request->q) {
                $term = trim($request->q);
                if (empty($term)) {
                    return \Response::json([]);
                }
            }
            if ($request->term) {
                $term = $request->term;
            }
            $orgs = Organization::where('name', 'LIKE', '%' . $term . '%')->select('id', 'name')->get();
            $formatted_tags = [];
            foreach ($orgs as $org) {
                $formatted_orgs[] = ['id' => $org->id, 'text' => $org->name];
            }
            return \Response::json($formatted_orgs);
        } catch (Exception $e) {
            // returns if try fails with exception meaagse
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }

    /**
     * 
     * @param \Illuminate\Http\Request $request
     * @return type
     */
    public function findOrgDepartment(Request $request) {
        try {
            if ($request->companydept && $request->term) {
                $formatted_orgs = DB::table('organization_dept')
                        ->join('organization', function($q) {
                            $q->on('organization.id', '=', 'organization_dept.org_id');
                        })
                        ->whereIn('organization.name', $request->companydept)
                        ->where('organization_dept.org_deptname', 'LIKE', '%' . $request->term . '%')
                        ->select("organization_dept.id", "organization_dept.org_id", "organization_dept.org_deptname", "organization.name")
                        ->get();

                foreach ($formatted_orgs as $key => $value) {
                    $display = $value->org_deptname . "(" . $value->name . ")";
                    $formatted_orgs_dept[] = ['id' => $value->id, 'text' => $display];
                }
                return \Response::json($formatted_orgs_dept);
            } else {
                $formatted_orgs_dept[] = "";
                return \Response::json($formatted_orgs_dept);
            }
        } catch (Exception $e) {
            // returns if try fails with exception meaagse
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }

    /**
     * This method for create user information 
     * @param \App\Http\Requests\helpdesk\RegisterRequest $request
     * @return type
     */
    public function createUserApi(\App\Http\Requests\helpdesk\RegisterRequest $request)
    {
        try {

            $captcha = $request->captcha;
            if ($captcha) {
                $FormController = new \App\Http\Controllers\Utility\FormController();
                $validCapcha = $FormController->captchaValidation($captcha);
                if ($validCapcha != true)
                    return response()->json(['error' => 'Captcha not valid'], 500);
            }
            $user = new User();
            $authController = new \App\Http\Controllers\Auth\AuthController();
            $authController->postRegister($user, $request, true, true);

            $phNo = ($request->phone_number) ? $request->phone_number : " ";
            $user->phone_number = $phNo;
            $user->save();
           if ($request->organisation) {
                $orgid = $request->organisation;
                foreach ($orgid as $key => $value) {
                    User_org::create(['org_id' => $value, 'user_id' => $user->id, 'role' => 'members']);
                }
            }
            if ($request->department && $request->department != 'null') {
                $orgDept = OrganizationDepartment::where('id', $request->department)->select('org_id')->first();
                User_org::where('user_id', $user->id)->where('org_id', $orgDept->org_id)->update(['org_department' => $request->department]);
            }
           
            //associate user to organization base on domain match
             $this->domainConnection($user->id);
            return response()->json(['message' => 'Registered Successfully']);
        } catch (\Exception $e) {
            
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    /**
     * 
     * @param type $id
     * @return type json
     */
    public function editUserApi($id) {
        $user = User::
                with(['userExtraField' => function($q) {
                        $q->select('owner', 'key', 'value')
                        ->pluck('key', 'value')
                        ;
                    }])
                ->where('id', '=', $id)
                ->first();
        $user_assign_organization = User_org::where('user_id', '=', $id)->pluck('org_id')->toArray();
        $org_name = Organization::whereIn('id', $user_assign_organization)->pluck('name', 'id')->toArray();
        $org_depts = User_org::where('user_id', '=', $id)->pluck('org_department')->toArray();

        if ($org_depts) {
            $org_dept_names = OrganizationDepartment::whereIN('id', $org_depts)->pluck('org_deptname', 'id')->toArray();
        } else {
            $org_dept_names = [];
        }
        // dd($org_deptsept_names);
        if ($user->userExtraField) {
            $user->userExtraField->transform(function($value) {
                return [$value->key => $value->value];
            });
        }
        $userDetails = $user->toArray();
        ($userDetails['mobile'] == trans('lang.not-available')) && ($userDetails['mobile'] = '');
        $response = ['user_details' => $userDetails, 'user_orgs' => $org_name, 'user_orgs_dept' => $org_dept_names];
        return response()->json($response);
        return $user;
    }
    /**
     * This method for update the user information
     * @param type $id
     * @param Request $request
     * @return type json
     */
    public function updateUserApi($id, Request $request)
    {
        try {

            $user = User:: where('id', $id)->first();
            $authController = new \App\Http\Controllers\Auth\AuthController();
            $authController->postRegister($user, $request, true, false);
            $phNo = ($request->phone_number) ? $request->phone_number : " ";
            $user->phone_number = $phNo;
            $user->save();

            $arrayOrgIds = User_org::where('user_id', $id)->pluck('org_id')->toArray();
            if ($request->organisation) {
                $user->organizations()->sync($request->organisation);
                User_org::where('role',"")->update(['role'=>'members']);
            } 
            else{
                 User_org::where('user_id', $id)->delete();
            }
            if ($request->department && $request->department != 'null') {
                $orgDept = OrganizationDepartment::where('id', $request->department)->first();
                User_org::where('user_id', $user->id)->where('org_id', $orgDept->org_id)->update(['org_department' => $request->department]);
            }

            return response()->json(['message' => 'Updated Successfully']);
        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }
    /**
     * 
     * @param Request $request
     * @return type json
     */
    public function findType(Request $request)
    {
        try {
            $term = trim($request->q);
            if (empty($term)) {
                return \Response::json([]);
            }
            $depts = \App\Model\helpdesk\Manage\Tickettype::where('name', 'LIKE', '%' . $term . '%')->select('id', 'name')->where('status', '=', 1)->get();
            $formatted_tags = [];
            foreach ($depts as $dept) {
                $formatted_depts[] = ['id' => $dept->id, 'text' => $dept->name];
            }
            return \Response::json($formatted_depts);
        } catch (Exception $e) {
            // returns if try fails with exception meaagse
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }

    /**
     * 
     * @param type $user
     * @param type $types
     */
    public function typeRelation($user, $types) {
        if ($types && count($types) > 0) {
            $user->type()->delete();
            foreach ($types as $type) {
                $user->type()->create([
                    'agent_id' => $user->id,
                    'type_id' => $type,
                ]);
            }
        } else {
            $user->type()->delete();
        }
    }

    /**
     * 
     * @param Request $request
     * @return type json
     */
    public function findDept(Request $request) {
        try {
            $term = trim($request->q);
            if (empty($term)) {
                return \Response::json([]);
            }
            $depts = Department::where('name', 'LIKE', '%' . $term . '%')->select('id', 'name')->get();
            $formatted_tags = [];

            foreach ($depts as $dept) {
                $formatted_depts[] = ['id' => $dept->id, 'text' => $dept->name];
            }

            return \Response::json($formatted_depts);
        } catch (Exception $e) {
            // returns if try fails with exception meaagse
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }

    public function postManualVerify(Request $request)
    {
        $user = User::find($request->get('id'));
        if ($request->has('country_code') && $request->get('country_code') != '') {
            $mobile_exists = User::where([
                ['mobile', '=', $request->get('mobile')],
                ['country_code', '=', $request->get('country_code')]
            ])->count();
            if ($mobile_exists > 0) {
                return redirect()->back()->with('fails1', Lang::get('lang.mobile-has-been-taken'));
            }
            $user->update([
                'mobile' => $request->get('mobile'),
                'country_code' => $request->get('country_code'),
                'mobile_otp_verify' => 1
            ]);            
        } else {
            $user->update([
                'email' => $request->get('email'),
                'email_verify' => 1
            ]);
        }
        return redirect()->back()->with('success1', Lang::get('lang.verified_manually'));
    }

     /**
     *  linking between user and organization 
     *
     * @param type $userId  of user
     * @return type boolean true
     */

    public static function domainConnection($userId){

             //associate user to organization base on domain match
             $orgs=Organization::where('domain','!=', '')->select('id','domain')->get(); 
             if (count($orgs) > 0) {

                foreach ($orgs as $org) {
                     $str = str_replace(",", '|@', '@' . $org->domain);
                     $domainUserId = User::where('id',$userId)->where('role', '=', 'user')->whereRaw("email REGEXP '" . $str . "'")->value('id');
                     if($domainUserId != 0){
                        User_org::updateOrCreate(['org_id' => $org->id, 'user_id' => $domainUserId, 'role' => 'members']);
                     }
                }
            }
            return true;
        }
        /**
         * This method return user status with icon
         * @param User $model
         * @return string
         */
    public static function userStatus( User $model) :string
    {

      
        $sColor = ($model->active == '1') ? "green" : "red";
        $sTitle = ($model->active == '1') ? Lang::get('lang.user_account_is_verified_tooltip') : Lang::get('lang.user_account_not_verified_tooltip');
        $eColor = ($model->email_verify != '1') ? "red" : "green";
        $eTitle = ($model->email_verify != '1') ? Lang::get('lang.user_has_not_verified_email_tooltip') : Lang::get('lang.user_email_is_verified_tooltip');
        $mColor = ($model->mobile_otp_verify == '1') ? "green" : "red";
        $mTitle = ($model->mobile_otp_verify == '1') ? Lang::get('lang.user_mobile_is_verified_tooltip') : Lang::get('lang.user_has_not_verified_contact_number_tooltip');

        $banColor = ($model->ban == 0) ? "green" : "red";
        $banTitle = ($model->ban == 0) ? Lang::get('lang.users_email_is_not_banned') : Lang::get('lang.users_email_is_banned');

        $deactiveColor = ($model->is_delete == 0) ? "green" : "red";
        $deactiveTitle = ($model->is_delete == 0) ? Lang::get('lang.activated_mod') : Lang::get('lang.deactivated_mod');
        $html = '<span style="margin-left: 17px;"><span class="fa fa-check-circle-o"  title="' . $sTitle . '" style="color:' . $sColor . '">&nbsp;&nbsp<span class="fa fa-envelope" title="' . $eTitle . '" style="font-size: 15px;color: ' . $eColor . '">&nbsp;&nbsp;<span class="fa fa-mobile-phone"  title="' . $mTitle . '" style="color:' . $mColor . '">&nbsp;&nbsp<span class="fa fa-ban"   title="' . $banTitle . '" style="color:' . $banColor . '">&nbsp;&nbsp;<span class ="fa fa-trash" title="' . $deactiveTitle . '" style="color:' . $deactiveColor . '" > </span>';

        return $html;
    }
    /**
     *  If agent remove from global access or any department  if any open which is not matched with agent department that tickets will go to unassign mode  
     *
     * @param type $userId  of user
     * @return type boolean true
     */
    public static function removeGlobalAccess(string $userId)
    {
        try {
            $agentId = getAgentbasedonPermission('global_access');
            if (in_array($userId, $agentId)) {
                return true;
            }
            $openTicketQuery = Tickets::where('assigned_to', $userId)->where(function ($query) {
                        $query->whereIN('tickets.status', getStatusArray('open'))
                                ->orWhereIN('tickets.status', getStatusArray('approval'))->get();
                    })->pluck('dept_id')->toArray();

            $deptId = DepartmentAssignAgents::where('agent_id', $userId)->pluck('department_id')->toArray();

            if (count($openTicketQuery) > 0) {

                foreach ($openTicketQuery as $ticketDeptId) {

                    if (!in_array($ticketDeptId, $deptId)) {
                         Tickets::where('assigned_to', $userId)->where('dept_id', $ticketDeptId)->update(['assigned_to' => NULL]);
                    }
                }
            }

            return true;
        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }

    /**
     * Disable ticket filters created by agent
     *
     * @param $user User instance
     * @return void
     */
    private function disableTicketFilters(User $user)
    {
        $user->ticketFilterShares()->update(['status' => 0]);
    }

}
