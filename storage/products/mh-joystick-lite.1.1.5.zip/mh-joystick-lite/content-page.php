<article <?php post_class('post-wrapper'); ?>>
	<header class="entry-header">
		<h1 class="entry-title">
			<?php the_title(); ?>
		</h1>
	</header>
	<div class="entry-content clearfix">
		<?php the_content(); ?>
	</div>
</article>