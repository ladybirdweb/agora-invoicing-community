<?php
namespace App\Itil\Database\seeds;

use App\Itil\database\seeds\SdChangePriority;
use App\Itil\database\seeds\SdChangeStatus;
use App\Itil\database\seeds\SdChangeType;
use App\Itil\database\seeds\SdReleasePriority;
use App\Itil\database\seeds\SdReleaseStatus;
use App\Itil\database\seeds\SdReleaseType;
use App\Itil\database\seeds\SdAssetAttachmentTypes;
use Illuminate\Database\Seeder;
use App\Itil\Models\Problem\Impact;
use App\Plugins\ServiceDesk\database\seeds\SdLocationCategorySeeder;

class ServiceDeskSeeder extends Seeder {

    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run() {

        $seed1 = new SdImpactSeeder();
        $seed1->run();

        $seed2 = new SdLocationCategorySeeder();
        $seed2->run();
        
        $seed7 = new SdAssetAttachmentTypes();
        $seed7->run();
        
        $seed8 = new SdChangePriority();
        $seed8->run();
        
        $seed9 = new SdChangeType();
        $seed9->run();
        
        $seed10 = new SdChangeStatus();
        $seed10->run();

        $seed11 = new SdReleasePriority();
        $seed11->run();
        
        $seed12 = new SdReleaseStatus();
        $seed12->run();
        
        $seed13 = new SdReleaseType();
        $seed13->run();

      
        
    }

}

