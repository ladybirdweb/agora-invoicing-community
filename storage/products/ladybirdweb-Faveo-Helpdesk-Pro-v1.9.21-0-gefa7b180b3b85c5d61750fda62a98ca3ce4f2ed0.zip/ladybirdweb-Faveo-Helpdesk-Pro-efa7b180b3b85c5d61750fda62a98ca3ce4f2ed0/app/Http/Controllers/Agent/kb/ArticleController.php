<?php

namespace App\Http\Controllers\Agent\kb;

// Controllers
use App\Http\Controllers\Controller;
// Requests
use App\Http\Requests\kb\ArticleRequest;
use App\Http\Requests\kb\ArticleUpdate;
use App\Http\Requests\kb\ArticletemplateRequest;
use App\Http\Requests\kb\ArticletemplateUpdateRequest;

// Models
use App\Model\kb\Article;
use App\Model\kb\Category;
use App\Model\kb\Comment;
use App\Model\kb\Relationship;
use App\Model\kb\Settings;
use App\Model\kb\ArticleTemplate;
// Classes
use Auth;
use Chumper\Datatable\Table;
use Datatable;
use DB;
use Exception;
use Illuminate\Http\Request;
use Lang;
use Redirect;

/**
 * ArticleController
 * This controller is used to CRUD Articles.
 *
 * @author      Ladybird <info@ladybirdweb.com>
 */
class ArticleController extends Controller
{

    /**
     * Create a new controller instance.
     * constructor to check
     * 1. authentication
     * 2. user roles
     * 3. roles must be agent.
     *
     * @return void
     */
    protected $ticket_policy;

    public function __construct()
    {
        // checking authentication
        $this->middleware('auth');
        $this->ticket_policy = new \App\Policies\TicketPolicy();
        SettingsController::language();
    }

    public function test()
    {
        //$table = $this->setDatatable();
        return view('themes.default1.agent.kb.article.test');
    }

    /**
     * Fetching all the list of articles in a chumper datatable format.
     *
     * @return type void
     */
    public function getData()
    {
        $article = new Article();
        $articles = $article
                ->select('id', 'name', 'description', 'publish_time', 'slug')
                ->orderBy('publish_time', 'desc')
                ->get();
//        dd($articles);
        // returns chumper datatable
        return Datatable::Collection($articles)

                        /* add column name */
                        ->addColumn('name', function ($model) {
                            $name = str_limit($model->name, 20, '...');

                            return "<p title=$model->name>$name</p>";
                        })
                        /* add column Created */
                        ->addColumn('publish_time', function ($model) {
//                            $t = $model->publish_time;
                            return $model->publish_time->todatetimestring();
                        })
                        /* add column action */
                        ->addColumn('Actions', function ($model) {
                            /* here are all the action buttons and modal popup to delete articles with confirmations */
                            return '<span  data-toggle="modal" data-target="#deletearticle' . $model->id . '"><a href="#" ><button class="btn btn-primary btn-xs"></a><i class="fa fa-trash">&nbsp;&nbsp;</i> ' . \Lang::get('lang.delete') . ' </button></span>&nbsp;&nbsp;<a href=' . url("article/$model->id/edit") . ' class="btn btn-primary btn-xs"><i class="fa fa-edit">&nbsp;&nbsp;</i>' . \Lang::get('lang.edit') . '</a>&nbsp;&nbsp;<a href=' . url("show/$model->slug") . ' class="btn btn-primary btn-xs"><i class="fa fa-eye">&nbsp;&nbsp;</i> ' . \Lang::get('lang.view') . '</a>
				<div class="modal fade" id="deletearticle' . $model->id . '">
        			<div class="modal-dialog">
            			<div class="modal-content">
                			<div class="modal-header">
                    			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    			<h4 class="modal-title">'.Lang::get('lang.delete').'</h4>
                			</div>
                			<div class="modal-body">
                				 <p>Are you sure ?</p>
                			</div>
                			<div class="modal-footer">
                    			<button type="button" class="btn btn-default pull-left" data-dismiss="modal" id="dismis2"><i class="fa fa-times" aria-hidden="true">&nbsp;&nbsp;</i>Close</button>
                    			<a href=' . url("article/delete/$model->slug") . '><button class="btn btn-danger"><i class="fa fa-trash" aria-hidden="true">&nbsp;&nbsp;</i>Delete</button></a>
                			</div>
            			</div>
        			</div>
    			</div>';
                        })
                        ->searchColumns('name', 'description', 'publish_time')
                        ->orderColumns('name', 'description', 'publish_time')
                        ->make();
    }

    /**
     * List of Articles.
     *
     * @return type view
     */
    public function index()
    {
        /* show article list */
        try {
            if (!$this->ticket_policy->kb()) {
                return redirect('dashboard')->with('fails', Lang::get('lang.permission_denied'));
            }
            return view('themes.default1.agent.kb.article.index');
        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }

    /**
     * Creating a Article.
     *
     * @param type Category $category
     *
     * @return type view
     */
    public function create(Category $category)
    {
        /* get the attributes of the category */
        $category = $category->pluck('id', 'name');
        $template = ArticleTemplate::where('status','=',1)->get();
        /* get the create page  */
        try {
            if (!$this->ticket_policy->kb()) {
                return redirect('dashboard')->with('fails', Lang::get('lang.permission_denied'));
            }
            return view('themes.default1.agent.kb.article.create', compact('category','template'));
        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }

    /**
     * Insert the values to the article.
     *
     * @param type Article        $article
     * @param type ArticleRequest $request
     *
     * @return type redirect
     */
    public function store(Article $article, ArticleRequest $request)
    {
        if (!$this->ticket_policy->kb()) {
            return redirect('dashboard')->with('fails', Lang::get('lang.permission_denied'));
        }
          // requesting the values to store article data
        $publishTime = $request->input('year') . '-' . $request->input('month') . '-' . $request->input('day') . ' ' . $request->input('hour') . ':' . sprintf("%02d", $request->input('minute')) . ':00';
        // dd('ok');
        $sl = $request->input('name');
        $slug = str_slug($sl, '-');
        $article->slug = $slug;
        $article->publish_time = $publishTime;
        $article->fill($request->except('created_at', 'slug'))->save();
        // creating article category relationship
        $requests = $request->input('category_id');
        $id = $article->id;

        foreach ($requests as $req) {
            DB::insert('insert into kb_article_relationship (category_id, article_id) values (?,?)', [$req, $id]);
        }
        /* insert the values to the article table  */
        try {
            $article->fill($request->except('slug'))->save();
                $check=Article::where('id','=',$article->id)->first();

            if(!$check->meta_description){
                     $check->meta_description= substr(strip_tags($check['description']),0,160) . "..."; 
                    }
                 else{
                    $check->meta_description=$request->meta_description;
                 }
                if(!$check->sco_title){
                $check->sco_title= $check->name;
                }
             else{
                $check->sco_title= $request->sco_title;
             }

        $check->save();


            return redirect('article')->with('success', Lang::get('lang.article_saved_successfully'));
        } catch (Exception $e) {
            return redirect('article')->with('fails', Lang::get('lang.article_not_inserted') . '<li>' . $e->getMessage() . '</li>');
        }
    }

    /**
     * Edit an Article by id.
     *
     * @param type Integer      $id
     * @param type Article      $article
     * @param type Relationship $relation
     * @param type Category     $category
     *
     * @return view
     */
    public function edit($slug)
    {
        if (!$this->ticket_policy->kb()) {
            return redirect('dashboard')->with('fails', Lang::get('lang.permission_denied'));
        }
        $article = new Article();
        $relation = new Relationship();
        $category = new Category();
        $aid = $article->where('id', $slug)->first();
        $id = $aid->id;
        /* define the selected fields */
        $assign = $relation->where('article_id', $id)->pluck('category_id');
        /* get the attributes of the category */
        $category = $category->pluck('id', 'name');
        /* get the selected article and display it at edit page  */
        /* Get the selected article with id */
        $article = $article->whereId($id)->first();
        /* send to the edit page */
        $template = ArticleTemplate::where('status','=',1)->get();
        try {
            return view('themes.default1.agent.kb.article.edit', compact('assign', 'article', 'category','template'));
        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }

    /**
     * Update an Artile by id.
     *
     * @param type Integer        $id
     * @param type Article        $article
     * @param type Relationship   $relation
     * @param type ArticleRequest $request
     *
     * @return Response
     */
    public function update($slug, ArticleUpdate $request)
    {
        // dd($request);
        if (!$this->ticket_policy->kb()) {
            return redirect('dashboard')->with('fails', Lang::get('lang.permission_denied'));
        }
        $article = new Article();
        $relation = new Relationship();
        $aid = $article->where('id', $slug)->first();
        // $publishTime =$request->input('publish_time');
        $publishTime = $request->input('year') . '-' . $request->input('month') . '-' . $request->input('day') . ' ' . $request->input('hour') . ':' . sprintf("%02d", $request->input('minute')) . ':00';

        $id = $aid->id;
        $sl = $request->input('slug');
        $slug = str_slug($sl, '-');
        // dd($slug);

        $article->slug = $slug;
        /* get the attribute of relation table where id==$id */
        $relation = $relation->where('article_id', $id);
        $relation->delete();
        /* get the request of the current articles */
        $article = $article->whereId($id)->first();
        $requests = $request->input('category_id');
        $id = $article->id;
        foreach ($requests as $req) {
            DB::insert('insert into kb_article_relationship (category_id, article_id) values (?,?)', [$req, $id]);
        }
        /* update the value to the table */
        try {
            $article->fill($request->all())->save();
            $article->slug = $slug;
            $article->publish_time = $publishTime;
            $article->save();

             $check=Article::where('id','=',$article->id)->first();

            if(!$check->meta_description){
                     $check->meta_description= substr(strip_tags($check['description']),0,160) . "..."; 

                 }
                 else{
                    $check->meta_description=$request->meta_description;
                 }
                if(!$check->sco_title){
                $check->sco_title= $check->name;
          
             }
             else{
                $check->sco_title= $request->sco_title;
             }

        $check->save();
      return redirect()->back()->with('success', Lang::get('lang.article_updated_successfully'));
        } catch (Exception $e) {
            return redirect()->back()->with('fails', Lang::get('lang.article_not_updated') . '<li>' . $e->getMessage() . '</li>');
        }
    }

    /**
     * Delete an Agent by id.
     *
     * @param type         $id
     * @param type Article $article
     *
     * @return Response
     */
    public function destroy($slug, Article $article, Relationship $relation, Comment $comment)
    {
        if (!$this->ticket_policy->kb()) {
            return redirect('dashboard')->with('fails', Lang::get('lang.permission_denied'));
        }
        /* delete the selected article from the table */
        $article = $article->where('slug', $slug)->first(); //get the selected article via id
        $id = $article->id;
        $comments = $comment->where('article_id', $id)->get();
        if ($comments) {
            foreach ($comments as $comment) {
                $comment->delete();
            }
        }
        // deleting relationship
        $relation = $relation->where('article_id', $id)->first();
        if ($relation) {
            $relation->delete();
        }
        if ($article) {
            if ($article->delete()) {//true:redirect to index page with success message
                return redirect('article')->with('success', Lang::get('lang.article_deleted_successfully'));
            } else { //redirect to index page with fails message
                return redirect('article')->with('fails', Lang::get('lang.article_not_deleted'));
            }
        } else {
            return redirect('article')->with('fails', Lang::get('lang.article_can_not_deleted'));
        }
    }

    /**
     * user time zone
     * fetching timezone.
     *
     * @param type $utc
     *
     * @return type
     */
    public static function usertimezone($utc)
    {
        $user = Auth::user();
        $tz = $user->timezone;
        $set = Settings::whereId('1')->first();
        $format = $set->dateformat;
        //$utc = date('M d Y h:i:s A');
        date_default_timezone_set($tz);
        $offset = date('Z', strtotime($utc));
        $date = date($format, strtotime($utc) + $offset);
        echo $date;
    }


    /**
     * Create a Article Template.
     *
     * @param type Category $category
     *
     * @return type view
     */
    public function articleAlltemplateList()
    {
       try {

            return view('themes.default1.agent.kb.article.template.index');
        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }
 /**
     * Create a Article Template.
     *
     * @param type Category $category
     *
     * @return type view
     */
    public function allArticleTemplate()
    {
       try {


         $article = new ArticleTemplate();
         $articles = $article
                ->select('id', 'name', 'status')
                ->orderBy('created_at', 'desc')
                ->get();
       // dd($articles);
        // returns chumper datatable
        return Datatable::Collection($articles)

                        /* add column name */
                        ->addColumn('name', function ($model) {
                            $name = str_limit($model->name, 20, '...');

                            return "<p title=$model->name>$name</p>";
                        })
                     ->addColumn('status', function ($model) {
                             if ($model->status == 1) {
                return '<p class="btn btn-xs btn-default" style="pointer-events:none;color:green">'.Lang::get('lang.active').'</p>';
            }else{


            return '<p class="btn btn-xs btn-default" style="pointer-events:none;color:red">'.Lang::get('lang.inactive').'</p>';
                        }
                        })
                     
                        /* add column action */
                        ->addColumn('Actions', function ($model) {
                            /* here are all the action buttons and modal popup to delete articles with confirmations */
                            return '<span  data-toggle="modal" data-target="#deletearticle' . $model->id . '"><a href="#" ><button class="btn btn-primary btn-xs"></a><i class="fa fa-trash">&nbsp;</i> ' . \Lang::get('lang.delete') . ' </button></span>&nbsp;&nbsp;<a href=' . url("articletemplate/$model->id/edit") . ' class="btn btn-primary btn-xs"><i class="fa fa-edit">&nbsp;&nbsp;</i>' . \Lang::get('lang.edit') . '</a>&nbsp;&nbsp;
                <div class="modal fade" id="deletearticle' . $model->id . '">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                <h4 class="modal-title">'.Lang::get('lang.delete').'</h4>
                            </div>
                            <div class="modal-body">
                             <p>Are you sure ?</p>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default pull-left" data-dismiss="modal" id="dismis2"><i class="fa fa-times" aria-hidden="true">&nbsp;&nbsp;</i>Close</button>
                                <a href=' . url("article/deletetemplate/$model->id") . '><button class="btn btn-danger"><i class="fa fa-trash" aria-hidden="true">&nbsp;&nbsp;</i>Delete</button></a>
                            </div>
                        </div>
                    </div>
                </div>';
                        })
                        ->searchColumns('name')
                        ->orderColumns('name')
                        ->make();
   
            
        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }




 /**
     * Create a Article Template.
     *
     * @param type Category $category
     *
     * @return type view
     */
    public function createTemplate()
    {
        /* Get the all attributes in the category model */
        // $category = $category->pluck('name','id')->toArray();
        /* get the view page to create new category with all attributes
          of category model */
        try {
            // dd('l');
            return view('themes.default1.agent.kb.article.template.create');
        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }


/**
     * Create a Article Template.
     *
     * @param type Category $category
     *
     * @return type view
     */
    public function postTemplate(ArticletemplateRequest $request)
    {
      
        try {

            $template=new ArticleTemplate();
            $template->name=$request->name;
            $template->status=$request->status;
            $template->description=$request->description;
            $template->save();


            return redirect('article/alltemplate/list')->with('success', Lang::get('lang.articletemplate_saved_successfully'));


        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }

     /**
     * Create a Article Template.
     *
     * @param type Category $category
     *
     * @return type view
     */
    public function editTemplate($id)
    {
        
        $article_template = ArticleTemplate::where('id','=',$id)->first();
      
        try {
            // dd( $article_template);
            return view('themes.default1.agent.kb.article.template.edit',compact('article_template'));
        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }

    /**
     * Create a Article Template.
     *
     * @param type Category $category
     *
     * @return type view
     */
    public function editPostTemplate($id,ArticletemplateUpdateRequest $request)
    {
    try {
          
            $article_template = ArticleTemplate::findOrFail($id);
            $article_template->name=$request->name;
            $article_template->status=$request->status;
            $article_template->description=$request->description;
            $article_template->save();

          return redirect('article/alltemplate/list')->with('success', Lang::get('lang.articletemplate_updated_successfully'));
        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }

    /**
     * Create a Article Template.
     *
     * @param type Category $category
     *
     * @return type view
     */
    public function PostTemplateDelete($id,Request $request)
    {
    try {

         $check_template= Article::where('template','=',$id)->count();

            if($check_template>0){
               return redirect()->back()->with('fails',Lang::get('lang.this_template_already_applyed_in_article_you_can_not_delete_this_template'));
             }
          

             $template = ArticleTemplate::findOrFail($id);
             $template->delete();
            

          return redirect('article/alltemplate/list')->with('success', Lang::get('lang.articletemplate_deleted_successfully'));
        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }





       public function searchTemplate(Request $request)
        {
        
        $article_template = ArticleTemplate::findOrFail($request->temp_name);
        $description=$article_template->description;
        return  $description;

      
   
    }



}
