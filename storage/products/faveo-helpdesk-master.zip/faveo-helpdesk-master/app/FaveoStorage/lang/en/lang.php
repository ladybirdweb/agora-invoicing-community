<?php

return [
    'settings' => 'Settings',
    'storage'  => 'Storage',
    'default'  => 'Default',
    'root'     => 'Root',
    'region'   => 'Region',
    'key'      => 'Key',
    'secret'   => 'Secret',
    'bucket'   => 'Bucket',
    'username' => 'Username',
    'container'=> 'Container',
    'endpoint' => 'End Point',
    'url_type' => 'Url Type',
];
