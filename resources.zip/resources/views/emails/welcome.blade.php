User Name: {{$email}}
<br>
Password: {{$pass}}
<br>
<br>
To activate your account:  <a href='{{ url('activate/'.$token) }}'>Click Here</a>