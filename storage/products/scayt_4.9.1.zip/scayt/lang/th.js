﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'scayt', 'th', {
	btn_about: 'About SCAYT',
	btn_dictionaries: 'Dictionaries',
	btn_disable: 'Disable SCAYT',
	btn_enable: 'Enable SCAYT',
	btn_langs:'Languages',
	btn_options: 'Options',
	text_title:  'Spell Check As You Type' // MISSING
});
