<?php

namespace App\Model\helpdesk\Theme;

use Illuminate\Database\Eloquent\Model;

class Footer4 extends Model
{
    protected $table = 'footer4';
    protected $fillable = ['title', 'footer'];
}
