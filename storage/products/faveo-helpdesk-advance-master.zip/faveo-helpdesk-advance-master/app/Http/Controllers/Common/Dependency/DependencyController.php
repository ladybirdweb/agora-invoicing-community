<?php
namespace App\Http\Controllers\Common\Dependency;

use App\Http\Controllers\Common\Dependency\NonPublicDependencies;
use App\Model\helpdesk\Agent_panel\Organization;
use App\Model\helpdesk\Manage\Help_topic as HelpTopic;
use App\Model\helpdesk\Manage\Tickettype as TicketType;
use App\Model\helpdesk\Manage\UserType;
use App\Model\helpdesk\Ratings\Rating;
use App\Model\helpdesk\Ticket\Ticket_Priority as TicketPriority;
use App\Model\helpdesk\Ticket\Ticket_source as TicketSource;
use App\Model\helpdesk\Ticket\Ticket_Status as TicketStatus;
use App\Model\helpdesk\Utility\CountryCode;
use App\Policies\TicketPolicy;
use Auth;
use Config;
use Illuminate\Database\Eloquent\Builder as QueryBuilder;
use Illuminate\Http\Request;
use Lang;

/**
 * handles auto suggestions/dependency list  of fields(like helpTppic, priorities, statuses etc.) throughout the project
 *
 * USAGE:
 * A request sent to method 'handle' can have four parameters
 *
 *  1. search-query (string, optional) => The string that is required to be searched.If it is not passed in the parameter,
 *                                        all the records (maximum 10, if limit parameter is also not passed) will be returned.
 *  2. limit (integer, optional)       => Number of records that is needed to be fetched from DB. If it is not passed,
 *                                        first 10 records will be returned.
 *  3. meta (boolean, optional)        => In some scenario, we need more information from a table then just ‘id’ and ‘name’.
 *                                        In that case *meta* will be passed as true.For eg. In case of user, at some places
 *                                        we only need just id and name, but at some places we need profile_pic and email also.
 *                                        So, for getting more detailed information meta must be passed as true.
 *                                          Possible use cases:
 *                                              1. users (email, profile_pic)
 *                                              2. statuses (icon, icon_class)
 *                                              3. priority (priority_color)
 *                                              4. agents (email, profile_pic)
 *                                              5. types (type_desc)
 *                                              6. sources (css_class)
 *
 *                                        Fields in bracket are the extra fields which will be returned in the response
 *                                        when meta is passed as true.
 *
 *  4. config (boolean, optional)       => In admin panel, certain fields (such as status) are configured so, for that purpose
 *                                         all the fields are required irrespective of that field is private/public or active/inactive.
 *                                         But in agent panel, only those fields are required which are activated through admin panel.
 *                                         So, if this parameter is passed as true, backend will send all the rows and columns available
 *                                         in the table
 *
 *
 * Now, these four parameter can/cannot be passed. So for that method *initializeParameterValues()* initilises those values for the other
 * class methods to work.
 *
 * @author avinash kumar <avinash.kumar@ladybirdweb.com>
 */
class DependencyController extends NonPublicDependencies
{
    /**
     * Gets list of elements according to the passed Type.
     * @param string $type      dependency type (like help-topics, priorities etc)
     * @param object $request
     * @return array            Success response or error response
     */
    public function handle($type, Request $request)
    {
        try {
            //populating parameter variables to handle addition params in the request . For eg. search-query, limit, meta, config
            $this->initializeParameterValues($request);

            /*
             * Once class variables like config, meta, limit, search-query, userRole is populated, it can be used throughout the class
             * to give user relavent information according to the paramters passed and userType
             */
            $data = $this->handleDependencies($type);

            if (!$data) {
                return errorResponse(Lang::get('lang.fails'));
            }

            return successResponse('', $data);
        } catch (\Exception $e) {
            return errorResponse($e->getMessage());
        }
    }

    /**
     * Populates class variables to handle addition params in the request . For eg. search-query, limit, meta, config, so that
     * it can be used throughout the class to give user relavent information according to the paramters passed and userType
     * @param object $request
     * @return
     */
    private function initializeParameterValues($request)
    {

        $this->searchQuery = $request->input('search-query') ? $request->input('search-query') : '';

        $this->limit = $request->input('limit') ? $request->input('limit') : 10;

        $this->userRole = Auth::check() ? Auth::user()->role : 'user';

        //only admin can set config as true
        $this->config = ($request->input('config') && $this->userRole == 'admin') ? $request->input('config') : false;

        //Config will be true if it is accessed from admin panel, in that case all the data & columns in the table will be returned
        //So meta don't have to be true
        $this->meta        = ($request->input('meta') && !$this->config) ? $request->input('meta') : false;
        $this->supplements = $request->input('supplements') ? $request->input('supplements') : [];
    }

    /**
     * Gets dependency data according to the value of $type
     * @param string $type      Dependency type (like help-topics, priorities etc)
     * @return array|boolean    Array of dependency data on success, false on failure
     */
    private function handleDependencies($type)
    {
        switch ($type) {

            //public/private dependencies
            case 'help-topics': //if department is passed
                return $this->helpTopics();

            case 'priorities':
                return $this->priorities();

            case 'users':
                return $this->users();

            case 'user-types':
                return $this->userTypes();

            case 'types':
                return $this->types();

            case 'sources':
                return $this->sources();

            case 'statuses':
                return $this->statuses();

            case 'languages':
                return $this->languages();

            case 'rating-types':
                return $this->ratingTypes();

            case 'country-codes':
                return $this->countryCodes();

            case 'organizations':
                return $this->organizations();
            default:
                return $this->handleNonPublicDependencies($type);
        }
    }

    /**
     * Gets list of helpTopic with necessary fields.
     * @return array    list of helptopics
     */
    protected function helpTopics()
    {

        //check for the link up
        $baseQuery = HelpTopic::where('topic', 'LIKE', "%$this->searchQuery%");

        //if not called from admin panel, it should return values only where status is 1
        if (!$this->config) {
            $baseQuery = $baseQuery->where('status', 1)->select('id', 'topic as name');
        }

        //if user is logged in as client or not logged in at all
        if ($this->userRole == 'user') {

            //type 1 means public, 0 means private
            $baseQuery = $baseQuery->where('type', 1);
        }

        $helpTopics = $this->getDataRecords($baseQuery, true, true, 'updated_at', 'DESC');

        return ['help_topics' => $helpTopics];
    }

    /**
     * Gets list of priority with necessary fields.
     * @return array    list of users
     */
    protected function priorities()
    {
        $baseQuery = TicketPriority::where('priority', 'LIKE', "%$this->searchQuery%");

        if (!$this->config) {
            $baseQuery = $baseQuery->where('status', 1)->select('priority_id as id', 'priority as name');
        }

        if ($this->meta) {
            $baseQuery->addSelect('priority_color');
        }

        if ($this->userRole == 'client') {
            $baseQuery = $baseQuery->where('ispublic', 1);
        }

        $priorities = $this->getDataRecords($baseQuery, true);
        return ['priorities' => $priorities];
    }

    /**
     * Gets list of users with necessary fields.
     * @return array    list of users
     */
    protected function users()
    {
        $roles = ['agent', 'admin', 'user'];
        $users = $this->getUsersByRoles($roles);
        return ['users' => $users];
    }

    protected function userTypes()
    {
        // Get user types by search string
        $baseQuery = UserType::where('name', 'LIKE', "%$this->searchQuery%");

        if (!$this->meta) {
            $baseQuery = $baseQuery->whereIn('name', ['department_manager', 'team_lead'])->select('id', 'name');
        }

        $userTypes = $this->getDataRecords($baseQuery, true);

        return ['user_types' => $userTypes];
    }

    /**
     * Gets list of people and teams to whom a ticket can be assigned with necessary fields.
     * @return array    list of available ticket types
     */
    protected function types()
    {
        //check for foriegn key for helptopic
        //requires authentication
        $baseQuery = TicketType::where('name', 'LIKE', "%$this->searchQuery%");

        if (!$this->config) {
            $baseQuery = $baseQuery->where('status', 1)->select('id', 'name');
        }

        if ($this->meta) {
            $baseQuery->addSelect('type_desc');
        }

        if ($this->userRole == 'user') {
            $baseQuery = $baseQuery->where('ispublic', 1);
        }

        $types = $this->getDataRecords($baseQuery, true, true, 'updated_at', 'DESC');

        return ['types' => $types];
    }

    /**
     * Gets list of sources by which a ticket can be created.
     * @return array list of available ticket sources
     */
    protected function sources()
    {
        $baseQuery = TicketSource::where('name', 'LIKE', "%$this->searchQuery%");

        if (!$this->config) {
            $baseQuery = $baseQuery->select('id', 'name');
        }

        if ($this->meta) {
            $baseQuery->addSelect('value')->addSelect('css_class');
        }

        //not sorting because there are limited number of sources and cannot be added more
        $sources = $this->getDataRecords($baseQuery, true);

        return ['sources' => $sources];
    }

    /**
     * Gets list of people and teams to whom a ticket can be assigned with necessary fields.
     * @return array list of statuses
     */
    protected function statuses()
    {
        $baseQuery = (!empty($this->supplements)) ? $this->getOverrideStatuses($this->supplements, $this->searchQuery) : TicketStatus::where('name', 'LIKE', "%$this->searchQuery%");

        \Event::fire('dependency-statuses-query-build', [$baseQuery, $this->supplements]);

        if (!$this->config) {
            //unapproved and approval status has to be skipped
            $baseQuery = $baseQuery->where('purpose_of_status', '!=', 5)->where('purpose_of_status', '!=', 7)->select('id', 'name');
        }

        if ($this->userRole == 'user') {
            $baseQuery = $baseQuery->where('visibility_for_client', 1);
        }

        if ($this->userRole == 'agent') {
            // $baseQuery = $baseQuery->where('visibility_for_agent', 1); //column visibility_for_agent is not used

            //if delete permission is not granted to an agent, he should won't be seeing deleted status (purpose_of_status is 4)
            $ticketPolicy = new TicketPolicy;
            $baseQuery    = !$ticketPolicy->delete() ? $baseQuery->where('purpose_of_status', '!=', 4) : $baseQuery;
        }

        if ($this->meta) {
            $baseQuery->addSelect('icon_color')->addSelect('purpose_of_status')->addSelect('icon')->addSelect('allow_client');
        }

        $statuses = $this->getDataRecords($baseQuery, true, true, 'order');

        return ['statuses' => $statuses];
    }

    /**
     * Gets list of languages availble in faveo
     * @return array list of languages
     */
    protected function languages()
    {
        try {
            $appPath      = base_path();
            $languageList = array_map('basename', \File::directories("$appPath/resources/lang"));
            $languages    = [];

            foreach ($languageList as $key => $langLocale) {
                $language       = [];
                $language['id'] = $key;
                $languageArray  = Config::get("languages.$langLocale");
                if ($this->meta) {
                    $language['locale']      = $langLocale;
                    $language['translation'] = $languageArray[1];
                    //TODO: direction must be moved to a configuration file
                    $language['direction'] = $langLocale == 'ar' ? 'rtl' : 'ltr';
                }
                $language['name'] = $languageArray[0];
                array_push($languages, $language);
            }
            return ['languages' => $languages];
        } catch (\Exception $e) {
            return exceptionResponse($e);
        }
    }

    /**
     * gets the rating types from the DB
     * @return array        array of available rating types
     */
    protected function ratingTypes()
    {
        try {

            $baseQuery = Rating::where('name', 'LIKE', "%$this->searchQuery%");

            if (!$this->config) {
                $baseQuery->addSelect('id')->addSelect('name');
            }

            if ($this->meta) {
                $baseQuery->addSelect('rating_scale')->addSelect('rating_area')->addSelect('allow_modification')->addSelect('restrict');
            }

            $ratingTypes = $this->getDataRecords($baseQuery, true, true, 'display_order');

            return ['rating_types' => $ratingTypes];

        } catch (\Exception $e) {
            return exceptionResponse($e);
        }
    }

    /**
     * gives array of country codes
     * @return array            array of country codes
     */
    protected function countryCodes()
    {
        try {
            $baseQuery = CountryCode::where('name', 'LIKE', "%$this->searchQuery%");

            if (!$this->config) {
                $baseQuery->addSelect('id')->addSelect('nicename as name');
            }

            if ($this->meta) {
                $baseQuery->addSelect('iso')->addSelect('phonecode')->addSelect('example');
            }

            //not putting any limits as all phone codes are required at once
            $countryCode = $this->getDataRecords($baseQuery, false, true, 'name');

            return ['country_codes' => $countryCode];

        } catch (\Exception $e) {
            return exceptionResponse($e);
        }
    }

    /**
     * gives array of Organization
     * @return array            array of organizations
     */
    protected function organizations()
    {
        try {
            $baseQuery = Organization::where('name', 'LIKE', "%$this->searchQuery%");

            if (!$this->config) {
                $baseQuery = $baseQuery->select('id', 'name');
            }
            $organizations = $this->getDataRecords($baseQuery, true);

            return ['organizations' => $organizations];

        } catch (\Exception $e) {
            return exceptionResponse($e);
        }
    }

    /**
     * To get the result data from QueryBuilder after applying limit and order by
     *
     * @param  QueryBuilder  $baseQuery base query for model
     * @param  Boolean       $take      Decide to limit the data default FALSE
     * @param  Boolean       $order     Decide to order the result default False
     * @param  String        $column    Name of column to sort data defalt id
     * @param  String        $direction Direction of sorting 'ASC' or 'DESC' default ASC
     * @return Collection/null
     */
    protected function getDataRecords(QueryBuilder $baseQuery, bool $take = false, bool $order = false, String $column = 'id', String $direction = 'ASC')
    {
        $baseQuery = ($order) ? $baseQuery->orderBy($column, $direction) : $baseQuery;
        if ($take && is_numeric($this->limit)) {
            $baseQuery = $baseQuery->take($this->limit);
        }

        return $baseQuery->get();
    }
}
