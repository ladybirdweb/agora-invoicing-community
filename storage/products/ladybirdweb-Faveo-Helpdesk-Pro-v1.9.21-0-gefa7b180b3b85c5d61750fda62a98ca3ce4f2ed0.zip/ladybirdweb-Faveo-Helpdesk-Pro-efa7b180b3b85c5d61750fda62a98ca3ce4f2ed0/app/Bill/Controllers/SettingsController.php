<?php

namespace App\Bill\Controllers;

use App\Http\Controllers\Controller;
use Exception;
use Illuminate\Http\Request;
use App\Model\helpdesk\Settings\CommonSettings;
use App\Model\helpdesk\Ticket\Ticket_Status;
use App\Bill\Requests\BillRequest;
use Lang;

/**
 * Setting for the bill module
 * 
 * @abstract Controller
 * @author Ladybird Web Solution <admin@ladybirdweb.com>
 * @name SettingsController
 * 
 */
class SettingsController extends Controller
{
    public function __construct()
    {
        //$this->middleware(['auth', 'roles']);
    }
    /**
     * 
     * get the setting icon on admin panel
     * 
     * @return string
     */
    public function settingsLink()
    {
        return ' <div class="col-md-2 col-sm-6">
                    <div class="settingiconblue">
                        <div class="settingdivblue">
                            <a href="' . url('bill') . '" onclick="sidebaropen(this)">
                                <span class="fa-stack fa-2x">
                                    <i class="fa fa-money fa-stack-1x"></i>
                                </span>
                            </a>
                        </div>
                        <p class="box-title" >' . Lang::get('lang.bill') . '</p>
                    </div>
                </div>';
    }
    /**
     * 
     * get the setting view for bill
     * 
     * @return view
     */
    public function setting()
    {
        try {
            $bill_types = collect([]);
            $status     = new Ticket_Status();
            $statuses   = $status->pluck('name', 'id')->toArray();
            $set        = new CommonSettings();
            $level      = $set->getOptionValue('bill', 'level');
            $currency   = $set->getOptionValue('bill', 'currency');
            if ($level && $level->option_value == 'type') {
                $bill_types = \App\Bill\Models\BillType::
                        with(['types'])
                        ->select('id', 'type', 'price')->get()
                        ->transform(function($v) {
                    if ($v) {
                        return [
                            'id'          => $v->types->id,
                            'optionvalue' => $v->types->name,
                            'price'       => $v->price,
                        ];
                    }
                    return [
                        'id'          => '',
                        'optionvalue' => '',
                        'price'       => '',
                    ];
                });
            }
            return view('bill::settings.setting', compact('statuses', 'level', 'currency', 'bill_types'));
        } catch (Exception $ex) {
            dd($ex);
            return redirect()->back()->with('fails', $ex->getMessage());
        }
    }
    /**
     * 
     * Billing post settings request
     * 
     * @param Request $request
     * @return string
     */
    public function postSetting(Request $request)
    {

        $this->validate($request, [
            'currency' => 'max:15',
        ]);
        try {
            $set         = new CommonSettings();
            $option_name = "bill";
            $requests    = $request->except('_token', 'trigger_on');
            $req         = $request->except('_token', 'trigger_on', 'status', 'level', 'currency');
            if (count($requests) > 0) {
                foreach ($requests as $key => $value) {
                    if ($key == 'status' && !is_array($value)) {
                        $create         = $set->firstOrCreate(['option_name' => $option_name]);
                        $create->status = $value;
                        $create->save();
                    }
                    elseif (!is_array($value)) {
                        $create               = $set->firstOrCreate(['option_name' => $option_name, 'optional_field' => $key]);
                        $create->option_value = $value;
                        $create->save();
                    }
                }
            }
            $this->billType($req);
            return response()->json(['success' => Lang::get('lang.bill_settings_saved_successfully')]);
        } catch (Exception $ex) {
            return response()->json(['error' => $ex->getMessage()], 500);
        }
    }
    public function billType($request = [])
    {
        if ($request) {
            $bill_type = new \App\Bill\Models\BillType();
            $bill_type->truncate();
            foreach ($request as $req) {
                if (is_array($req)) {
                    $bill_type->updateOrCreate(['type' => $req['type']], ['price' => $req['price']]);
                }
            }
        }
    }
}
