<?php

/**
 * Plugin Name: CCAvenue & Paypal payment plugin
 * Plugin URI: 
 * Description:  
 * File Description: 
 * Author: Ladybird Web Solution Pvt Ltd
 * Author URI: http://www.ladybirdweb.com
 * Version: 1.0
 * Copyright 2016 Ladybird Web Solution
 * @package  CCAvenue & Paypal payment plugin
 * License: Regular License
 * License URI: 
 */

/** CCAvenue Merchant ID */
$merchant_id = "15675"; //This id(also User Id)  available at "Generate Working Key" of "Settings & Options" 

/** CCAvenue Working Key or Encryption Key */
//$working_key = "BB2C768665B51ACB70EFA02E8E3F52B1"; //Shared by CCAVENUES
$working_key = "38133DD6258ADF5FC02E9C900DCE12C6"; //test

/** CCAvenue Access Code */
//$access_code = "AVRN05CG89CN72NRNC"; //Shared by CCAVENUES
$access_code = "AVRO01EK31CB19ORBC"; //test (sandbox)

/** paypal email */
$paypal_email = "accounts@ladybirdweb.com"; //Shared by Paypal


/** Redirection URL */
$redirect_url = "https://www.faveohelpdesk.com/pay1/response/";

/** Cancel URL */
$cancel_url = "https://www.faveohelpdesk.com/pay1/response/";

/** Action URL from Chekout page */
$action_url = "https://www.faveohelpdesk.com/pay1/submit";


/** CCAvenue Gateway Post URL */
// $base_url_ccavenue = "https://secure.ccavenue.com/transaction/transaction.do?command=initiateTransaction";
$base_url_ccavenue = "https://test.ccavenue.com/transaction/transaction.do?command=initiateTransaction";
// 	Test: https://test.ccavenue.com/transaction/transaction.do?command=initiateTransaction
// 	Live: https://secure.ccavenue.com/transaction/transaction.do?command=initiateTransaction

/** Paypal Gateway Post URL */
$base_url_paypal = "https://www.sandbox.paypal.com/cgi-bin/webscr";
// 	Test: "https://www.sandbox.paypal.com/cgi-bin/webscr
// 	Live: "https://www.paypal.com/cgi-bin/webscr

/** Paypal return URL */
$paypal_return_url = "https://www.faveohelpdesk.com/pay1/paypal-response/";

/** Paypal Cancel URL */
$paypal_cancel_url = "https://www.faveohelpdesk.com/pay1/paypal-response/";

/** Paypal Notify URL */
$paypal_notify_url = "https://www.faveohelpdesk.com/pay1/paypal-response/";

/** Payu Money Salt */
$payu_money_salt = "vAUsVb2Q";  

/** Payu Money Key */
$payu_money_key = "emnQbA"; //Shared by Payu Money

/** Payu Money Gateway Post URL */
$base_url_payu_money = "https://secure.payu.in/_payment";
// 	Test: https://test.payu.in/_payment

/** Payu Money sucess URL */
$surl1 = "https://www.faveohelpdesk.com/pay1/paypal-response";

/** Payu Money Failure URL */
$furl1 = "https://www.faveohelpdesk.com/pay1/paypal-response";

/** Payu Money Cancel URL */
$curl1 = "https://www.faveohelpdesk.com/pay1/paypal-response";

/** Language */
$language = "en";
?>




