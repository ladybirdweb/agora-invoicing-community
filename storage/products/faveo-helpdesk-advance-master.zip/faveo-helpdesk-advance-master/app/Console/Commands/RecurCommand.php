<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Lang;
use App\Http\Controllers\Admin\helpdesk\TicketRecurController;
use Logger;
use Carbon\Carbon;


class RecurCommand extends Command
{

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'ticket:recur';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Execute ticket recurring command';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }
    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        if (isInstall()) {
            try {
                $startTime =  Carbon::now()->toDateTimeString();

                (new ticketRecurController)->recur();

                $humanReadable = Lang::get('lang.recurring-ticket-executed');
                $this->info($humanReadable);

                $endTime  =  Carbon::now()->toDateTimeString();

                Logger::cron($startTime ,$endTime,'ticket-create', $humanReadable);

            } catch (\Exception $ex) {

                Logger::exception($ex , 'ticket-create');
            }
        }
    }
    public function ticketRecurController()
    {
        $recur = new \App\Http\Controllers\Admin\helpdesk\TicketRecurController();
        return $recur;
    }
}
