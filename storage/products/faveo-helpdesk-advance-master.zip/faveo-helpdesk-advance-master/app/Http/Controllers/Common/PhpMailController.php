<?php

namespace App\Http\Controllers\Common;


use App\Http\Controllers\Controller;
use App\Http\Controllers\Common\TemplateVariablesController;
use App\Model\Common\TemplateType;
use App\Model\helpdesk\Agent\Department;
use App\Model\helpdesk\Email\Emails;
use App\Model\helpdesk\Settings\Company;
use App\Model\helpdesk\Settings\Email;
use App\User;
use Auth;
use Mail;
use Exception;
use Lang;
use Logger;
use App\Model\helpdesk\Ticket\Tickets;
use Config;
use Cache;

class PhpMailController extends Controller {
    /**
     *@var variable to instantiate common mailer class
     */
    protected $commonMailer, $queueManager;


    public function __construct()
    {
        $this->commonMailer = new CommonMailer;
        $this->queueManager = app('queue');
    }
    /**
     * get the configured email
     * @param integer $id
     * @return Emails
     */
    public function fetch_smtp_details($id = "")
    {
        if ($id) {
            $emails = Emails::where('id', '=', $id)->first();
        }
        else {
            $emails = Emails::first();
        }
        return $emails;
    }
    /**
     * Fetching comapny name to send mail.
     *
     * @return type
     */
    public function company()
    {
        $company = Company::Where('id', '=', '1')->first();
        if ($company->company_name == null) {
            $company = 'Support Center';
        }
        else {
            $company = $company->company_name;
        }

        return $company;
    }
    /**
     * Function to choose from address.
     *
     * @param type Reg        $reg
     * @param type Department $dept_id
     *
     * @return type integer
     */
    public function mailfrom($reg, $dept_id)
    {
        $email    = Email::find(1);
        $email_id = $email->sys_email;

        $dept_email = Department::select('outgoing_email')->where('id', '=', $dept_id)->first();
        if ($dept_email) {
            if ($dept_email->outgoing_email != "" || $dept_email->outgoing_email
                    != null) {
                $email_id = $dept_email->outgoing_email;
            }
        }
        return $email_id;
    }
    /**
     * send mail to job
     * @param integer $from
     * @param array $to
     * @param array $message
     * @param array $template_variables
     * @param mixed $thread
     * @param string $auto_respond
     */
    public function sendmail($from, $to, $message, $template_variables, $thread = "", $auto_respond
    = "")
    {
        //putting a check here because is called at multiple places and hence not possible to change everywhere
        $sendingEmail = Emails::where('sending_status',1)->find($from);

        if($sendingEmail ){
            $this->sendEmail($from, $to, $message, $template_variables, $thread, $auto_respond);
        }
    }
    /**
     * set up sending mail configuration
     * @param integer $from
     * @param array $to
     * @param array $message
     * @param array $template_variables
     * @param mixed $thread
     * @param string $auto_respond
     * @return mixed
     * @throws Exception
     */
    public function sendEmail($from, $to, $message, $template_variables, $thread
    = "", $auto_respond = "")
    {
        $email_reciever_name = "";
        $reciever            = User::where('email', '=', $to['email'])->first();
        if ($reciever) {
            $email_reciever_name = $reciever->name();
        }
        $template_variables['receiver_name'] = $email_reciever_name;
        $from_address                        = $this->fetch_smtp_details($from);

        //$this->setMailConfig($from_address);
        $recipants     = $this->checkElement('email', $to);
        $recipantname  = $this->checkElement('name', $to);
        $recipant_role = $this->checkElement('role', $to);
        $recipant_lang = $this->checkElement('preferred_language', $to);
        $isManager     = $this->isManager($recipants, $template_variables, $recipant_role);
        $cc            = $this->checkElement('cc', $message);
        $bc            = $this->checkElement('bc', $message);
        $subject       = $this->checkElement('subject', $message);
        $template_type = $this->checkElement('scenario', $message);
        $attachment    = $this->checkElement('attachments', $message);
        if ($recipants == $this->checkElement('agent_email', $template_variables)) {
            $assigned_agent = true;
        }
        else {
            $assigned_agent = false;
        }
        $content_array = $this->mailTemplate($template_type, $template_variables, $message, $subject, $assigned_agent, $recipant_role, $recipant_lang, $isManager);
        $content       = $this->checkElement('body', $message);
        if ($content_array) {
            $content = checkArray('content', $content_array);
            $subject = checkArray('subject', $content_array);
        }
        $send = FALSE;
        try {
            $logReference = Logger::logMailByCategory($from_address->email_address, $recipants, $subject, $content, $template_variables, $template_type);

            // dispatch the job from here
            $this->setQueue();
            $job = new \App\Jobs\SendEmail($recipants, $recipantname, $subject, $content, $from_address,$cc, $attachment, $thread, $auto_respond, $logReference->id);
            dispatch($job);

        } catch (\Exception $e) {
            Logger::exception($e);
        }
        $this->updateFilePermission($thread);
        return $send;
    }

    /**
     * sending email via swiftmailer
     * @param string $to
     * @param string $toname
     * @param string $subject
     * @param string $data
     * @param array $cc
     * @param mixed $attach
     * @param mixed $thread
     * @param string $auto_respond
     * @param int $logIdentifier  idetifies which mail it is sending, so that status of the log can be updated
     * @return int
     */
    public function laravelMail($to, $toname, $subject, $data, $from_address, $cc = [], $attach
    = "", $thread = "", $auto_respond = "", $logIdentifier) {

      try{
        if ($from_address != null) {
            $this->setMailConfig($from_address);
        } else {
            //log new Exception("Invalid Email Configuration", 601);
            loging('email-config', 'Invalid Email Configuration');
        }

        $reference = $this->getReference($thread);
        $mail      = Mail::send('emails.mail', ['data' => $data, 'thread' => $thread], function ($m) use ($to, $subject, $toname, $from_address, $cc, $attach, $thread, $auto_respond, $reference)
                {
                    $m->to($to, $toname)->subject($subject);
                    $m->from($from_address->email_address, $from_address->email_name);
                    $swiftMessage = $m->getSwiftMessage();
                    $headers      = $swiftMessage->getHeaders();
                    if ($auto_respond) {
                        $headers->addTextHeader('X-Autoreply', 'true');
                        $headers->addTextHeader('Auto-Submitted', 'auto-replied');
                        //$headers->addTextHeader('Content-Transfer-Encoding', 'base64');
                    }
                    if ($reference) {
                        $headers->addTextHeader('References', $reference);
                        $headers->addTextHeader('In-Reply-To', $reference);
                    }
                    if ($cc) {
                        $m->cc($cc);
                    }
                    if ($thread && is_object($thread)) {
                        $attach = $thread->attach()
                                        ->where('poster', 'ATTACHMENT')
                                        ->select(\DB::raw('type as mime'), \DB::raw('name as file_name'), \DB::raw('path as file_path'), \DB::raw('path as file_path'), \DB::raw('path as file_path'), \DB::raw('file as data'), 'poster')->get()->toArray();
                    }
                    $size = ($attach) ? count($attach) : 0 ;
                     if ($size>0) {
                       for ($i = 0; $i < $size; $i++) {
                            if (is_array($attach) && array_key_exists($i, $attach)) {
                                $mode = 'normal';
                                if (!is_object($attach[$i])) {

                                    $file = $attach[$i]['file_path'];
                                    if (checkArray('poster', $attach[$i])) {
                                        $file = $attach[$i]['file_path'] . DIRECTORY_SEPARATOR . $attach[$i]['file_name'];
                                    }
                                    if (checkArray('poster', $attach[$i]) && checkArray('data', $attach[$i])) {
                                        $file = $attach[$i]['data'];
                                        $mode = 'data';
                                    }
                                    if (is_array($attach[$i]) && array_key_exists('mode', $attach[$i])) {
                                        $mode = $attach[$i]['mode'];
                                    }

                                    $name = $attach[$i]['file_name'];
                                    $mime = $attach[$i]['mime'];
                                }
                                else {

                                    $file = $attach[$i]->getRealPath();
                                    $name = $attach[$i]->getFilename();
                                    $mime = $attach[$i]->getMimetype();
                                }

                                $this->attachmentMode($m, $file, $name, $mime, $mode);
                            }
                        }
                    }
                    $this->saveEmailThread($swiftMessage->getId(), $thread);
                });


        // TODO: need to handle the case where job fails
        Logger::updateSentMailLog($logIdentifier, 'sent');

        if (is_object($mail) || (is_object($mail) && $mail->getStatusCode() == 200)) {
            return 1;
        }
        return $mail;

      } catch(Exception $e){
        Logger::updateSentMailLog($logIdentifier, 'failed');
        throw $e;
      }
    }


    /**
     * update the file permision for the attachment
     * @param mixed $thread
     */
    public function updateFilePermission($thread)
    {
        $attach = [];
        if ($thread && is_object($thread)) {
            $attach = $thread->attach()
                            ->where('poster', 'ATTACHMENT')
                            ->select(\DB::raw('type as mime'), \DB::raw('name as file_name'), \DB::raw('path as file_path'), \DB::raw('path as file_path'), \DB::raw('path as file_path'), \DB::raw('file as data'), 'poster')->get()->toArray();
        }
        if ($attach && is_array($attach)) {
            foreach ($attach as $attachment) {
                $mime      = checkArray('mime', $attachment);
                $file_path = checkArray('file_path', $attachment);
                $file_name = checkArray('file_name', $attachment);
                if (mime($mime) != 'image' && $file_path && $file_name) {
                    $file = $file_path . "/" . $file_name;
                    //chmod($file, 1204);
                }
            }
        }
    }
    /**
     * set the email configuration
     * @param Email $from_address
     */
    public function setMailConfig($mail) {
        switch ($mail->sending_protocol) {
            case "smtp":
                $config = [ "host" => $mail->sending_host,
                            "port" => $mail->sending_port,
                            "security" => $mail->sending_encryption,
                            'username' => $mail->user_name,
                            'password' => $mail->password
                        ];
                if (!$this->commonMailer->setSmtpDriver($config)) {
                    \Log::info("Invaid configuration :- ".$config);
                    return "invalid mail configuration";
                }

                break;

            case "send_mail":
                $config = [
                            "host" => \Config::get('mail.host'),
                            "port" => \Config::get('mail.port'),
                            "security" => \Config::get('mail.encryption'),
                            'username' => \Config::get('mail.username'),
                            'password' => \Config::get('mail.password')
                        ];
                $this->commonMailer->setSmtpDriver($config);
                break;

            default:
                setServiceConfig($mail);
                break;
        }


        /******** old code   *****************/
        // $email    = $from_address->email_address;
        // $username = $from_address->user_name;
        // if (!$username) {
        //     $username = $email;
        // }
        // $fromname   = $from_address->email_name;
        // $password   = $from_address->password;
        // $smtpsecure = $from_address->sending_encryption;
        // $host       = $from_address->sending_host;
        // $port       = $from_address->sending_port;
        // $protocol   = $from_address->sending_protocol;
        // $this->setServices($from_address->id, $protocol);
        // if ($protocol == 'mail') {
        //     $username   = '';
        //     $fromname   = '';
        //     $host       = '';
        //     $smtpsecure = '';
        //     $port       = '';
        // }
        // $configs = [
        //     'username'   => $username,
        //     'from'       => ['address' => $email, 'name' => $fromname,],
        //     'password'   => $password,
        //     'encryption' => $smtpsecure,
        //     'host'       => $host,
        //     'port'       => (int) $port,
        //     'driver'     => $protocol,
        // ];
        // foreach ($configs as $key => $config) {
        //     if (is_array($config)) {
        //         foreach ($config as $from) {
        //             \Config::set('mail.' . $key, $config);
        //         }
        //     }
        //     else {
        //         \Config::set('mail.' . $key, $config);
        //     }
        // }
    }

    public function defaultMailConfig($from_address)
    {
        $email = $from_address->email_address;
        $username   = $from_address->user_name;
        if(!$username){
            $username = $email;
        }
        $fromname   = $from_address->email_name;
        $password   = $from_address->password;
        $smtpsecure = $from_address->sending_encryption;
        $host       = $from_address->sending_host;
        $port       = $from_address->sending_port;
        $protocol   = $from_address->sending_protocol;
        $this->setServices($from_address->id, $protocol);
        if ($protocol == 'mail')
        {
            $username   = '';
            $fromname   = '';
            $host       = '';
            $smtpsecure = '';
            $port       = '';
        }
        $configs = [
            'username'   => $username,
            'from'       => ['address' => $email, 'name' => $fromname,],
            'password'   => $password,
            'encryption' => $smtpsecure,
            'host'       => $host,
            'port'       => (int)$port,
            'driver'     => $protocol,
        ];
        foreach ($configs as $key => $config)
        {
            if (is_array($config))
            {
                foreach ($config as $from)
                {
                    \Config::set('mail.' . $key, $config);
                }
            }
            else
            {
                \Config::set('mail.' . $key, $config);
            }
        }
    }

    /**
     * set the services like maildrill
     * @param integer $emailid
     * @param string $protocol
     */
    public function setServices($emailid, $protocol)
    {
        $service    = new \App\Model\MailJob\FaveoMail();
        $services   = $service->where('email_id', $emailid)->pluck('value', 'key')->toArray();
        $controller = new \App\Http\Controllers\Admin\helpdesk\EmailsController();
        $controller->setServiceConfig($protocol, $services);
    }
    public function checkElement($element, $array)
    {
        $value = "";
        if (is_array($array)) {
            if (key_exists($element, $array)) {
                $value = $array[$element];
            }
        }
        return $value;
    }
    /**
     * get the reference ket from mail
     * @param mixed $thread
     * @return string
     */
    public function getReference($thread)
    {
        $reference = "";
        if ($thread) {
            $emailThread = $thread->emailThread()->first();
            if ($emailThread) {
                $reference = $emailThread->message_id;
            }
        }
        return $reference;
    }

    /**
     * save the email keys like reference in db and associate with ticket
     * @param integer $msg_id
     * @param mixed $thread
     */
    public function saveEmailThread($msg_id, $thread)
    {
        if ($thread) {
            $content           = ['message_id' => $msg_id];
            $ticket_controller = new \App\Http\Controllers\Agent\helpdesk\TicketController();
            $ticket_controller->saveEmailThread($thread, $content);
        }
    }
    /**
     * set the queue service
     */
    public function setQueue()
    {
        $short        = 'database';
        $field        = [
            'driver' => 'database',
            'table'  => 'jobs',
            'queue'  => 'default',
            'expire' => 60,
        ];
        $queue        = new \App\Model\MailJob\QueueService();
        $active_queue = $queue->where('status', 1)->first();
        if ($active_queue) {
            $short  = $active_queue->short_name;
            $fields = new \App\Model\MailJob\FaveoQueue();
            $field  = $fields->where('service_id', $active_queue->id)->pluck('value', 'key')->toArray();
        }

        $this->setQueueConfig($short, $field);
    }
    /**
     * set the que configuration
     * @param string $short
     * @param string $field
     */
    public function setQueueConfig($short, $field)
    {
        $this->queueManager->setDefaultDriver($short);
        // \Config::set('queue.default', $short);
        // foreach ($field as $key => $value) {
        //     \Config::set("queue.connections.$short.$key", $value);
        // }
    }
    /**
     * attachment mode data/html
     * @param mixed $message
     * @param mixed $file
     * @param string $name
     * @param string $mime
     * @param string $mode
     * @return mixed
     */
    public function attachmentMode($message, $file, $name, $mime, $mode)
    {
        //chmod($file, 0755);
        if ($mode == 'data') {
            return $message->attachData(base64_decode($file, true), $name, ['mime' => $mime]);
        }
        return $message->attach($file, ['as' => $name, 'mime' => $mime]);
    }
    /**
     * embed the mail template with conversion
     * @param array $templateVariables
     * @param string $templateType, $lang, $role, $assigned_agent, $subject,$message, $from
     * @return array
     */
    public function mailTemplate($templateType, $templateVariables, $message, $subject, $assignedAgent, $role, $lang, $isManager=false)
    {
        $templateCategory = $this->getTemplateCategory($templateType, $role, $assignedAgent, $message, $isManager);
        $content       = $this->checkElement('body', $message);
        $ticketNumber = $this->checkElement('ticket_number', $templateVariables);
        $template      = TemplateType::where('name', '=', $templateType)->first();
        $set           = $this->getTemplateSet($lang);
        $temp = [];
        if ($template) {
            $temp                = $this->set($set->id, $ticketNumber, $message, $template, $templateCategory);
            $contents            = $temp['content'];
            $messageBody         = $this->replaceShortcodeInTemplates($templateVariables, $contents, $content);
            $content = '<div style="display:none">---Reply above this line(to trim old messages)--- </div>' . $messageBody;
        }
        (checkArray('subject', $temp)) && ($subject = $this->replaceShortcodeInTemplates($templateVariables, checkArray('subject', $temp), $content));
        return ['content' => $content, 'subject' => $subject];
    }

    /**
     *
     * @param string $set
     * @param string $ticket_number
     * @param string $message
     * @param string $template
     * @param string $template_category
     * @return array
     */
    public function set($set, $ticket_number, $message, $template, $template_category)
    {
        $contents = null;
        $subject  = null;
        if (isset($set)) {
            $subject       = checkArray('subject', $message);
            $template_data = \App\Model\Common\Template::where('set_id', '=', $set)->where('type', '=', $template->id)->where('template_category', '=', $template_category)->first();
            $contents      = $template_data->message;
            if ($template_data->variable == 1) {
                if ($template_data->subject) {
                    $subject = $template_data->subject;
                    if ($ticket_number != null) {
                        $subject = $subject . ' [#' . $ticket_number . ']';
                    }
                }
            }
        }
        return ['content' => $contents, 'subject' => $subject];
    }

    /**
     * function method is used to get reciever is manager or not which then passed to getTemplateCateogry()
     * @param   string   $recipants           email address of reciever
     * @param   arrray   $templateVariables   variables passed in notification array object
     * @return  boolean                       true if reciepant is manager and not owner of the ticket
     */
    protected function isManager($recipants, $templateVariables,  $role = 'agent')
    {
        if (($recipants == $this->checkElement('client_email', $templateVariables)) || ($role != 'user')) {
           return false;
        }
        return User::where('email', $recipants)->first()->isManagerOf();
    }

    /**
     * function takes 5 arguments like type of template type, reciever role etc
     * then returns a srting value for template category
     * @param   string     $templateType   type of template
     * @param   array      $message        array contianing for scenario mail
     * @param   boolean    $isManager      true if reciever is an Organization Manager
     * @param   strin      $role           role of reciepant user
     * @param   boolean    $assignedAgent  true if reciever is an agent and the ticket is assigned to him/her
     * @return  string                     template category name
     */
    protected function getTemplateCategory($templateType, $role, $assignedAgent, $message, $isManager)
    {
        $commonTmeplates = ['registration-notification', 'reset-password', 'reset_new_password', 'registration', 'registration-and-verify'];
        if (in_array($templateType, $commonTmeplates)) {
            return 'common-tmeplates';
        } elseif (in_array($message['scenario'], ['check-ticket', 'invoice'])) {//strict client templates
            return 'client-templates';
        } elseif ($role == 'user' || in_array($message['scenario'], ['create-ticket', 'create-ticket-by-agent'])) {
            return ($isManager) ? 'org-mngr-templates' : 'client-templates';
        }
        return ($assignedAgent) ? 'assigend-agent-templates' : 'agent-templates';
    }

    /**
     * function to replace short codes with their actual values
     * @param   array   $templateVariables  array containing short codes values in key value pair
     * @param   string  $contents           email content in which short codes need to be replaced 
     * @param   string  $content            custom message content to use in place of short code
     * @return  string       
     */
    private function replaceShortcodeInTemplates($templateVariables, $contents, $content='')
    {
        $tempVarCntroller    = new TemplateVariablesController;
        $variables           = $tempVarCntroller->getVariableValues($templateVariables, $content);
        foreach ($variables as $k => $v) {
            $messageBody = str_replace($k, $v, $contents);
            $contents    = $messageBody;
        }
        return $messageBody;
    }

    /**
     * Function to return template set according to user language preference and availability of the set
     * @param String       $userLanguage
     * @param TemplateSet  $defaultSet
     */
    private function getTemplateSet(String $userLanguage = null)
    {
        $systemLanguage = Cache::get('language');
        $defaultSet = \App\Model\Common\TemplateSet::where('id', '=', 1)->first();
        $userLanguageSet = \App\Model\Common\TemplateSet::where('active', '=', 1)->where('template_language', '=', $userLanguage)->first();
        $systemLanguageSet = \App\Model\Common\TemplateSet::where('active', '=', 1)->where('template_language', '=', $systemLanguage)->first();
        if ($userLanguageSet != null) {
            $defaultSet = $userLanguageSet;
        } elseif ($systemLanguageSet != null) {
            $defaultSet = $systemLanguageSet;
        }
        return $defaultSet;
    }
}
