<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Http\Controllers\Update\SyncFaveoToLatestVersion;

class SyncDatabaseToLatestVersion extends Command {

  //NOTE: it is made only for testing purpose and must be removed once code is merged

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'database:sync';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'update testing';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct() {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        echo (new SyncFaveoToLatestVersion)->sync();
    }
}
