<?php

namespace App\FaveoReport\Jobs;

use App\Events\ReportExportEvent;
use App\FaveoReport\Models\Report;
use App\Http\Controllers\Common\PhpMailController;
use App\Model\Custom\Required;
use App\Model\helpdesk\Settings\CommonSettings;
use App\Model\helpdesk\Ticket\Tickets;
use Carbon\Carbon;
use Excel;
use Exception;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Http\Request;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Lang;

class ManagementReportExportJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    protected $request;

    protected $report;

    protected $limit;

    protected $offset;

    protected $agentTimezone;

    protected $dateFormat;

    protected $reportFilePath;

    protected $reportHeader;

    /**
     * The number of seconds the job can run before timing out.
     *
     * @var int
     */
    public $timeout = 180;

    /**
     * Create a new job instance.
     * 1, 1
     * @return void
     */
    public function __construct(array $request, Report $report, $offset = 0)
    {
        $this->request        = $this->setUpFilters($request);
        $this->report         = $report;
        $this->limit          = (new CommonSettings)->getOptionValue('reports_records_per_file')->first()->option_value;
        $this->offset         = $offset;
        $this->agentTimezone  = agentTimezone();
        $this->dateFormat     = dateformat();
        $this->reportFilePath = storage_path('reports/export/' . $this->report->file);
    }

    /**
     * Execute the job.
     *
     * @return void|bool
     */
    public function handle()
    {
        try {
            // Get report columns
            $reportColumns = $this->getReoprtColumns();
        } catch (Exception $e) {
            loging("report-error", "Failed to get report columns. Caught exception: " . $e->getMessage() . "\n");
        }

        try {
            // Get tickets with eger loading
            $tickets = $this->getTickets();
        } catch (Exception $e) {
            loging("report-error", "Failed to get tickets. Caught exception: " . $e->getMessage() . "\n");
        }

        if ($tickets->count() === 0 || $this->report->is_completed == 1) {
            $this->reportExportCompleted();

            return true;
        }

        $this->createNewExcelfile($reportColumns, $tickets);

        // Trigger next part of export job
        $this->triggerChildExportJob();
    }

    /**
     * The job failed to process.
     *
     * @param  Exception  $exception
     * @return void
     */
    public function failed(Exception $exception)
    {
        // Delete exported file from file system if exists
        $this->removeGeneratedReport();

        // Delete report form database
        $this->report->delete();

        loging("report-error", "Report export job failed after max retries. Caught exception: " . $exception->getMessage() . "\n");
    }

    /**
     * Get the tags that should be assigned to the job.
     *
     * @return array
     */
    public function tags()
    {
        return ['management-report-export', Report::class . ':'. $this->report->id];
    }

    /**
     * Get report columns
     *
     * @return Array All report columns
     */
    protected function getReoprtColumns()
    {
        // Ticket form default fields
        $default_fields = ['company', 'assigned', 'department', 'help_topic', 'priority', 'type', 'status', 'subject', 'requester', 'organization', 'location', 'org_dept'];

        // Report default columns
        $reportColumns = [
            'Ticket Number', 'Subject', 'Status', 'Created Date', 'Type', 'Priority', 'Organization',
            'Email', 'Location', 'Department', 'Helptopic', 'Source', 'Agent Responded Time',
            'Last Response', 'Closed At', 'Assigned', 'Assigned Team',
            'Response SLA Met', 'Resolution SLA Met', 'Duedate', 'Overdue', 'First Response In BH',
        ];

        // Get custom ticket form fields
        $custom_fields = Required::select('field', 'label')
            ->where([
                ['form', 'ticket'],
                ['label', '!=', ''],
            ])
            ->whereNotIn('field', $default_fields)
            ->orderBy('label')
            ->pluck('label', 'field')
            ->toArray();

        // Create report header from custom field lables
        $this->reportHeader = array_merge($reportColumns, array_values($custom_fields));

        // Merge reports coulumns and custom fileds identities
        return array_merge($reportColumns, array_keys($custom_fields));
    }

    /**
     * Get all tickets with filter and eger loading
     *
     * @return Tickets instance
     */
    protected function getTickets()
    {
        $agents        = $this->request['agents'];
        $departments   = $this->request['departments'];
        $client        = $this->request['clients'];
        $source        = $this->request['sources'];
        $priority      = $this->request['priorities'];
        $type          = $this->request['types'];
        $status        = $this->request['status'];
        $helptopic     = $this->request['helptopic'];
        $team          = $this->request['team'];
        $createStart   = $this->request['start_date'];
        $createEnd     = $this->request['end_date'];
        $updateStart   = $this->request['update_start'];
        $updateEnd     = $this->request['update_end'];
        $agentTimezone = $this->agentTimezone;

        if (empty($createStart) && empty($updateStart)) {
            $createStart = Carbon::now()->subMonth()->addDay()->format('Y-m-d');
            $createEnd   = Carbon::now()->format('Y-m-d');
        }

        return Tickets::
            with([
            'thread' => function ($query) {
                $query->select('id', 'ticket_id', 'thread_type', 'title', 'poster', 'created_at')
                    ->where('thread_type', 'first_reply')->orWhere('title', '!=', '');
            },
            'assigned:id,email,first_name,last_name',
            'assignedTeam:id,name',
            'statuses:id,name',
            'types:id,name',
            'priority:priority_id,priority',
            'user:id,email',
            'departments:id,name',
            'helptopic:id,topic',
            'sources:id,name',
            'formdata:ticket_id,content,key',
            'formdata.getKeyRelation:field,label',
        ])
            ->when($createStart, function ($q) use ($createStart, $createEnd, $agentTimezone) {
                $q->whereBetween('tickets.created_at', [
                    Carbon::parse($createStart, $agentTimezone)->timezone('UTC'),
                    Carbon::parse($createEnd, $agentTimezone)->endOfDay()->timezone('UTC'),
                ]);
            })
            ->when($updateStart, function ($q) use ($updateStart, $updateEnd, $agentTimezone) {
                $q->whereBetween('tickets.updated_at', [
                    Carbon::parse($updateStart, $agentTimezone)->timezone('UTC'),
                    Carbon::parse($updateEnd, $agentTimezone)->endOfDay()->timezone('UTC'),
                ]);
            })
            ->when($agents, function ($q) use ($agents) {
                $q->whereIn('assigned_to', $agents);
            })
            ->when($departments, function ($q) use ($departments) {
                $q->whereIn('dept_id', $departments);
            })
            ->when($client, function ($q) use ($client) {
                $q->whereIn('user_id', $client);
            })
            ->when($source, function ($q) use ($source) {
                $q->whereIn('source', $source);
            })
            ->when($priority, function ($q) use ($priority) {
                $q->whereIn('priority_id', $priority);
            })
            ->when($type, function ($q) use ($type) {
                $q->whereIn('type', $type);
            })
            ->when($status, function ($q) use ($status) {
                $q->whereIn('status', $status);
            })
            ->when($helptopic, function ($q) use ($helptopic) {
                $q->whereIn('help_topic_id', $helptopic);
            })
            ->when($team, function ($q) use ($team) {
                $q->whereIn('team_id', $team);
            })
            ->latest()->limit($this->limit)->offset($this->offset)
            ->get([
                'id', 'ticket_number', 'assigned_to', 'team_id', 'status', 'type',
                'priority_id', 'user_id', 'dept_id', 'help_topic_id', 'source', 'duedate',
                'created_at', 'closed_at', 'updated_at', 'is_response_sla', 'is_resolution_sla',
            ]);
    }

    /**
     * Create new report excel file
     *
     * @param array $reportColumns Report columns
     * @param collection Tickets collection
     * @return void
     */
    protected function createNewExcelfile(array $reportColumns, Collection $tickets)
    {
        try {
            // Create Excel
            Excel::create($this->report->file . '_' . $this->offset, function ($excel) use ($reportColumns, $tickets) {

                // Set excel title
                $excel->setTitle('Management Report Data');

                // Add sheet in excel
                $excel->sheet('sheet 1', function ($sheet) use ($reportColumns, $tickets) {

                    // Add header row
                    $sheet->row(1, $this->reportHeader);

                    // Add header rows style
                    $sheet->row(1, function ($row) {
                        $row->setFontSize(12);
                        $row->setFontWeight('bold');
                        $row->setAlignment('center');
                    });

                    // Freeze the ticket number column
                    $sheet->freezeFirstColumn();

                    // Loop through each ticket
                    foreach ($tickets as $row) {
                        // Get ticket data and append row at very last
                        $sheet->appendRow($this->getTicketData($reportColumns, $row));
                    }

                });

            })->store($this->report->ext, storage_path('reports/export/' . $this->report->file));
        } catch (Exception $e) {
            loging("report-error", "Failed to generate excel. Caught exception: " . $e->getMessage() . "\n");
        }
    }

    /**
     * Trigger clild export job
     *
     * @return void
     */
    protected function triggerChildExportJob()
    {
        try {

            // Setting queue driver
            (new PhpMailController)->setQueue();

            // Dispatch export job
            self::dispatch($this->request, $this->report, $this->offset + $this->limit)->onQueue('reports')->delay(now()->addSeconds(5));
        } catch (Exception $e) {
            loging("report-error", "Failed to despatch child job. Caught exception: " . $e->getMessage() . "\n");
        }
    }

    /**
     * Store exported report details
     *
     * @return Stored report model instance
     */
    protected function updateExportedReport()
    {
        $this->report->expired_at   = Carbon::now()->addHours(6);
        $this->report->is_completed = 1;

        return $this->report->save();
    }

    /**
     * Remove generated file
     *
     * @return void
     */
    protected function removeGeneratedReport()
    {
        // Get all file names
        $files = glob($this->reportFilePath . DIRECTORY_SEPARATOR . '*');

        // Iterate over files and delete
        foreach ($files as $file) {
            if (is_file($file)) {
                unlink($file);
            }
        }

        // Remove export directory
        rmdir($this->reportFilePath);
    }

    /**
     * Post report export actions
     *
     * @return void
     */
    protected function reportExportCompleted()
    {
        try {
            // Update report details in db
            $this->updateExportedReport();
        } catch (Exception $e) {
            loging("report-error", "Failed to update report in database. Caught exception: " . $e->getMessage() . "\n");
        }

        try {
            // Dispatch report export event
            event(new ReportExportEvent($this->report));
        } catch (Exception $e) {
            loging("report-error", "Failed to dispatch report export event. Caught exception: " . $e->getMessage() . "\n");
        }
    }

    /**
     * Get ticket data
     *
     * @param array $reportColumns Report columns
     * @param instance Ticket instance
     * @return array Ticket data
     */
    private function getTicketData(array $reportColumns, $row)
    {
        // Set all fields as key and set value to null
        $reportRow = array_fill_keys($reportColumns, null);

        // First response from agent
        $first_response = $row->thread
            ->where('thread_type', 'first_reply')
            ->where('poster', 'support')
            ->where('title', '')
            ->first();

        // Check overdue
        if (!is_null($row->duedate)) {
            $overdue = Lang::get($row->isOverdue($row->duedate) ? "report::lang.yes" : "report::lang.no");
        } else if ($row->statuses->name == 'Closed') {
            $overdue = Lang::get($row->is_resolution_sla == 1 ? "report::lang.no" : "report::lang.yes");
        } else {
            $overdue = Lang::get('lang.sla-halted');
        }

        // Get first thread
        $firstThred = $row->thread->first();

        // Get location
        $location = $row->formdata->where('key', 'location')->first();

        $reportRow['Ticket Number'] = $row->ticket_number;
        $reportRow['Subject']       = is_null($firstThred) ? null : utfEncoding(trim($firstThred->title));
        $reportRow['Status']        = is_null($row->statuses) ? null : $row->statuses->name;
        $reportRow['Created Date']  = $row->created_at->timezone($this->agentTimezone)->format($this->dateFormat);
        $reportRow['Type']          = is_null($row->types) ? null : $row->types->name;
        $reportRow['Priority']      = is_null($row->priority) ? null : $row->priority->priority;
        $reportRow['Organization']  = is_null($row->user) ? null : $row->user->getOrganization();
        $reportRow['Email']         = is_null($row->user) ? null : $row->user->email;
        $reportRow['Location']      = is_null($location) ? null : $location->content;
        $reportRow['Department']    = is_null($row->departments) ? null : $row->departments->name;
        $reportRow['Helptopic']     = is_null($row->helptopic) ? null : $row->helptopic->topic;
        $reportRow['Source']        = is_null($row->sources) ? null : $row->sources->name;

        $reportRow['Agent Responded Time'] = is_null($first_response) ? null : $first_response->created_at->timezone($this->agentTimezone)->format($this->dateFormat);
        $reportRow['Last Response']        = $row->updated_at->timezone($this->agentTimezone)->format($this->dateFormat);
        $reportRow['Closed At']            = is_null($row->closed_at) ? null : $row->closed_at->timezone($this->agentTimezone)->format($this->dateFormat);
        $reportRow['Assigned']             = is_null($row->assigned) ? null : $row->assigned->full_name;
        $reportRow['Assigned Team']        = is_null($row->assignedTeam) ? null : $row->assignedTeam->name;
        $reportRow['Response SLA Met']     = Lang::get($row->is_response_sla == 1 ? "report::lang.yes" : "report::lang.no");
        $reportRow['Resolution SLA Met']   = Lang::get($row->is_resolution_sla == 1 ? "report::lang.yes" : "report::lang.no");
        $reportRow['Duedate']              = is_null($row->duedate) ? null : $row->duedate->timezone($this->agentTimezone)->format($this->dateFormat);
        $reportRow['Overdue']              = $overdue;
        $reportRow['First Response In BH'] = is_null($first_response) ? null : $first_response->created_at->diffForHumans($row->created_at, true, false, 6);

        // Loop through the custom fields value
        foreach ($row->formdata as $field) {
            if (!is_null($field->getKeyRelation)) {
                // Check if the key exists. Only to check old data
                if (array_key_exists($field->getKeyRelation->field, $reportRow)) {
                    $reportRow[$field->getKeyRelation->field] = utfEncoding($field->content);
                }
            }
        }

        return array_values($reportRow);
    }

    /**
     * Set up report filters
     *
     * @param array $request Request data
     * @return array Filters
     */
    private function setUpFilters(array $request)
    {
        $filters = array('agents', 'departments', 'clients', 'sources', 'priorities', 'types', 'status', 'helptopic', 'team', 'start_date', 'end_date', 'update_start', 'update_end');

        foreach ($filters as $filter) {
            if (!array_key_exists($filter, $request)) {
                $request[$filter] = null;
            }
        }

        return $request;
    }
}
