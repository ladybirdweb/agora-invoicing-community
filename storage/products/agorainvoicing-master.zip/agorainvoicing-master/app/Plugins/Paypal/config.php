<?php


return [

    'name' => 'Paypal',

    'author' => 'Ladybird Web Solution',

    'description' => 'This is the paypal paymeny gateway plugin for the Agora. It will give you Payment payment gateway',

    'version' => '1.0.0',

    'settings' => 'payment-gateway/paypal',

    'website' => 'http://www.faveohelpdesk.com/',

];
