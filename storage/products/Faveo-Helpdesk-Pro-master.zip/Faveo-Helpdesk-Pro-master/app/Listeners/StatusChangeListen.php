<?php

namespace App\Listeners;

use App\Events\StatusChange;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;

class StatusChangeListen
{
    
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  StatusChange  $event
     * @return void
     */
    public function handle(StatusChange $event)
    {
        return $this->approvalController()->eventExecute($event->event);
    }
    
    public function approvalController(){
        return new \App\Http\Controllers\Agent\helpdesk\Approval\ApprovalController();
    }
}
