<?php

namespace App\Http\Controllers\Agent\helpdesk;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\helpdesk\Ticket\Tickets;
use App\Model\helpdesk\Ticket\Ticket_Status;
use App\Http\Controllers\Agent\helpdesk\TicketController;
use Exception;
use Input;
use Validator;

class TicketForkController extends Controller
{
    public function __construct()
    {
        $this->middleware('role.agent');
    }
    /**
     * get the ticket to fork from ticket id
     * @param integer $ticketid
     * @return json
     * @throws Exception
     */
    public function fork($ticketid)
    {
        $ticket = Tickets::whereId($ticketid)->first();
        if (!$ticket) {
            throw new Exception('Ticket not found');
        }
        $new_ticket       = $this->newTicket($ticket);
        $this->ticketForkingThread($ticket, $new_ticket);
        $this->changeStatus($ticketid);
        $response_status  = 200;
        $response_message = ['success' => trans('lang.ticket-id-from-to', ['from_id' => $ticketid, 'to_id' => $new_ticket->id])]; //'ticket id forked from ' . $ticketid . " to " . $new_ticket->id;
        return $this->responseMessage($response_message, $response_status);
    }
    /**
     * forking ticket's thread
     * @param model $ticket
     * @param model $new_ticket
     * return void
     */
    public function ticketForkingThread($ticket, $new_ticket)
    {
        $ticket_url = faveoUrl('thread/' . $new_ticket->id);
        $user_id    = "";
        if (\Auth::check()) {
            $user_id = \Auth::user()->id;
        }
        $ticket->thread()->create([
            'ticket_id'   => $ticket->id,
            'user_id'     => $user_id,
            'is_internal' => 1,
            'body'        => trans('lang.ticket-forked-to', ['url' => $ticket_url]),
        ]);
    }
    /**
     * change the status of the old ticket
     * @param integer $ticketid
     * @param string $status_type
     * @throws Exception
     * @return void
     */
    public function changeStatus($ticketid, $status_type = 'closed')
    {
        $status = Ticket_Status::whereHas('type', function($q) use($status_type) {
                    $q->where('name', $status_type);
                })->first();
        if (!$status) {
            throw new Exception('Closed status not found');
        }
        $status_id         = $status->id;
        $ticket_controller = new TicketController();
        $ticket_controller->changeStatus($ticketid, $status_id);
    }
    /**
     * create a new ticket from old
     * @param model $ticket
     * @return collection
     */
    public function newTicket($ticket)
    {
        $tickets       = $this->createNewTicketForFork($ticket);
        $form_data     = $ticket->formdata->toArray();
        $collaborators = $ticket->collaborator->toArray();
        $threads       = $ticket->thread()->with(['attach'])->get();
        $this->createFormExtraData($tickets, $form_data);
        $this->addCollaboratorToForkedTicket($tickets, $collaborators);
        $this->createThreadsForForkedTicket($tickets, $threads);
        return $tickets;
    }
    /**
     * create copy of extra form data
     * @param model $tickets
     * @param array $form_data
     * @return void
     */
    public function createFormExtraData($tickets, $form_data)
    {
        if ($form_data) {
            $tickets->formdata()->createMany($form_data);
        }
    }
    /**
     * create the copy of collaborator for new ticket
     * @param model $tickets
     * @param array $collaborators
     * @return void
     */
    public function addCollaboratorToForkedTicket($tickets, $collaborators)
    {
        if ($collaborators) {
            foreach($collaborators as $collaborator){
                $cc[] = array_except($collaborator, ['id','ticket_id','created_at','updated_at']);
            }
            $tickets->collaborator()->createMany($cc);
        }
    }
    /**
     * create thread for new ticket from old
     * @param model $tickets
     * @param array $threads
     * @retrun void
     */
    public function createThreadsForForkedTicket($tickets, $threads)
    {
        if ($threads) {
            foreach ($threads as $thread) {
                $thread_array = array_except($thread->toArray(), ['id', 'ticket_id', 'created_at', 'updated_at']);
                $thread_data  = $tickets->thread()->create($thread_array);
                $this->addAttachmentsToForkedTicket($thread_array, $thread_data);
                if ($thread->emailThread()->get()->count() > 0) {
                    $thread->emailThread()->update([
                        'ticket_id' => $thread_data->ticket_id,
                        'thread_id' => $thread_data->id,
                    ]);
                }
                if(\Schema::hasTable('social_channel')){
                  \App\Plugins\Social\Model\SocialChannel::where('ticket_id',$thread->ticket_id)
                          ->update(['ticket_id'=>$thread_data->ticket_id]);
                }
            }
        }
    }
    /**
     * create copy of the attachments of old ticket
     * @param array $thread_array
     * @param model $thread_data
     * @return void
     */
    public function addAttachmentsToForkedTicket($thread_array, $thread_data)
    {
        $thread_attach = checkArray('attach', $thread_array);
        if ($thread_attach) {
            foreach ($thread_attach as $attach) {
                $attach_array = array_except($attach, ['id', 'ticket_id', 'created_at', 'updated_at']);
                $thread_data->attach()->create($attach_array);
            }
        }
    }
    /**
     * pass the values to TicketController
     * @param model $ticket
     * @return collection
     */
    public function createNewTicketForFork($ticket)
    {
        $ticket_controller = new TicketController();
        $result            = $this->createTicketParams($ticket);
        $new_ticket        = $ticket_controller->createTicket($result['user_id'], "", "", $result['help_topic_id'], $result['sla'], $result['priority_id'], $result['source'], [], $result['dept_id'], $result['assign_to'], [], $result['status'], $result['type'], [], [], [], "", "", true);

        return $new_ticket;
    }
    public function createTicketParams($ticket)
    {
        $result['user_id']       = $ticket->user_id;
        $result['help_topic_id'] = $ticket->help_topic_id;
        $result['sla']           = $ticket->sla;
        $result['priority_id']   = $ticket->priority_id;
        $result['source']        = $ticket->source;
        $result['dept_id']       = $ticket->dept_id;
        $result['assign_to']     = $ticket->assign_to;
        $result['status']        = 1;
        $result['type']          = $ticket->type;
        if (Input::has('user_id')) {
            $result['user_id'] = Input::get('user_id');
        }
        if (Input::has('help_topic_id')) {
            $result['help_topic_id'] = Input::get('help_topic_id');
        }
        if (Input::has('sla')) {
            $result['sla'] = Input::get('sla');
        }

        if (Input::has('priority_id')) {
            $result['priority_id'] = Input::get('priority_id');
        }
        if (Input::has('source')) {
            $result['source'] = Input::get('source');
        }

        if (Input::has('dept_id')) {
            $result['dept_id'] = Input::get('dept_id');
        }
        if (Input::has('assign_to')) {
            $result['assign_to'] = Input::get('assign_to');
        }

        if (Input::has('status')) {
            $result['status'] = Input::get('status');
        }
        if (Input::has('type')) {
            $result['type'] = Input::get('type');
        }
        else{
            $result['type'] = null;
        }
        return $result;
    }
    /**
     * forking api
     * @param Request $request
     * @return json
     */
    public function postFork(Request $request)
    {

        $validator = Validator::make($request->all(), [
            
            'help_topic_id' => 'required',
            'source' => 'required',
            'priority_id' => 'required',
        ]);
        if (!$validator->passes()) {
             $fail = $validator->errors();
             
            foreach(json_decode($fail) as $key => $value){
                return response()->json(['error' => $value], 500);
            }
        }
        $tickets_id = $request->get('ticket_id');
        if ($tickets_id) {
            return $this->forking($tickets_id);
        }
         
    }
    /**
     * differentiating array request and string request
     * @param integer $tickets_id
     * @return json
     */
    public function forking($tickets_id)
    {
        try {
            if (is_array($tickets_id)) {
                foreach ($tickets_id as $ticket_id) {
                    $this->fork($ticket_id);
                }
            }
            else {
                return $this->fork($tickets_id);
            }
            $response_status  = 200;
            $response_message = ['success' => trans("lang.forked-successfully")];
        } catch (Exception $ex) {
            $response_status  = 500;
            $response_message = ['error' => $ex->getMessage() . PHP_EOL . " File=>" . $ex->getFile() . PHP_EOL . " Line=>" . $ex->getLine()];
        }
        return $this->responseMessage($response_message, $response_status);
    }
    /**
     * return the meesage in json format
     * @param string $message
     * @param integer $status
     * @return json
     */
    public function responseMessage($message, $status = 200)
    {
        return response()->json($message, $status);
    }
}
