<?php

return [

    'view' => '_partials.breadcrumbs',

];
