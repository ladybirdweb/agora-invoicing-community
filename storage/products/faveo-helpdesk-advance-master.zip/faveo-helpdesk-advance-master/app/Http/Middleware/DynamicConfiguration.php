<?php

namespace App\Http\Middleware;

use Cache;
use Config;
use Closure;

/**
 * All the dynamic configurations can be added to this middleware
 */
class DynamicConfiguration
{
    public function handle($request, Closure $next)
    {
        $this->configureSessionLifetime();

        return $next($request);
    }

    private function configureSessionLifetime()
    {
      if(isInstall()){

        //getting session lifetime configured at admin panel
        $sessionLifetime = Cache::rememberForever('session_lifetime', function(){
            return \App\Model\helpdesk\Settings\Security::select('session_lifetime')->first()->session_lifetime;
        });

        //setting session lifetime before creating session
        Config::set('session.lifetime', $sessionLifetime);
      }
    }

}
