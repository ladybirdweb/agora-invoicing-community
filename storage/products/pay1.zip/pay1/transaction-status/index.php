<?php 
session_start();
@session_save_path("./");  
include('../config.php');
//require('functions.php');
include('../crypto.php');
$command='orderLookup';

$merchant_data=	'&response_type=JSON'.'&from_date=01-10-2017'.'&order_email=splitnavz@yahoo.in'.'&order_currency=INR';
var_dump($merchant_data);
					
$encrypted_data=encrypt($merchant_data,$working_key);
echo("<br><br><br>");
var_dump($encrypted_data);

?>
Testting
<form method="post" name="paymentpage" action="https://180.179.175.17/apis/servlet/DoWebTrans">
    <input type="hidden" name="enc_request" value="<?php echo $encrypted_data;?>">
    <input type="hidden" name="access_code" value="<?php echo $access_code;?>">
    <input type="hidden" name="command" value="orderLookup">
    <input type="hidden" name="request_type" value="STRING">
            
  <input type="hidden" value="submit">
  <input type="submit">
</form>