<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Http\Controllers\Client\helpdesk\UnAuthController;
use App\Http\Controllers\Common\PhpMailController;
use Lang;
use Carbon\Carbon;
use Logger;


class CloseWork extends Command {

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'ticket:close';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Ticket will close according to workflow';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct() {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle() {
        if (isInstall()) {
            try {
               $startTime =  Carbon::now()->toDateTimeString();

               (new UnAuthController(
                    new PhpMailController
                ))->autoCloseTickets();


                $humanReadable = Lang::get('lang.close-ticket-workflow-executed');
                $endTime  =  Carbon::now()->toDateTimeString();

                Logger::cron($startTime ,$endTime,'ticket-update', $humanReadable);

                $this->info($humanReadable);

            } catch (\Exception $ex) {

                Logger::exception($ex , 'ticket-update');
            }
        }
    }

}
