<?php

namespace App\Model\licence;

use Illuminate\Database\Eloquent\Model;
use App\BaseModel;
class SlaService extends BaseModel
{
}
