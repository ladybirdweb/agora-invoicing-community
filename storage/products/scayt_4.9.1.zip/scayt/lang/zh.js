/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'scayt', 'zh', {
	btn_about: '關於即時拼寫檢查',
	btn_dictionaries: '字典',
	btn_disable: '關閉即時拼寫檢查',
	btn_enable: '啟用即時拼寫檢查',
	btn_langs: '語言',
	btn_options: '選項',
	text_title:  '即時拼寫檢查'
});
