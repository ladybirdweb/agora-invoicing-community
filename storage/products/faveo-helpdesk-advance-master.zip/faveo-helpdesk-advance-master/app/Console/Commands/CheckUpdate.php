<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Http\Controllers\Update\AutoUpdateController;

class CheckUpdate extends Command
{
    /**
     * The console command name.
     *
     * @var string
     */
    protected $name = 'faveo:checkupdate';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Check for system updates';

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        AutoUpdateController::getLatestRelease();
    }
}
