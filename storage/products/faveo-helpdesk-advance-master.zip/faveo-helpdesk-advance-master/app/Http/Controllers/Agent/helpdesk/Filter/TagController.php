<?php

namespace App\Http\Controllers\Agent\helpdesk\Filter;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Exception;
use App\Model\helpdesk\Filters\Tag;
use App\Model\helpdesk\Manage\Tickettype;
use Lang;
use DB;

class TagController extends Controller {
    
    public function __construct() {
        $this->middleware(['auth', 'role.agent']);
        $this->middleware('roles', ['only' => ['tag', 'create', 'edit']]);
    }

    public function store(Request $request) {
        try {
            $tag = new Tag();
            return $this->save($tag, $request->input());
        } catch (Exception $ex) {
//            dd($ex);
        }
    }

    public function save($model, $request) {
        $tags = explode(",", $request->input('tags'));
        if (is_array($tags) && count($tags) > 0) {
            foreach ($tags as $t) {
                $tag = $model->where('name', $t)->first();
                if (!$tag) {
                    if ($t != '') { 
                        $model->create([
                            'name' => $t,
                            'description' => '',
                        ]);
                    }
                }
            }
        }
    }

    public function addToFilter(Request $request) {
        $ticket_id = $request->input('ticket_id');
        $tags = explode(',', $request->input('tags'));
        $tag = new Tag();
        $this->save($tag, $request);
        $this->saveToFilter($ticket_id, $tags);
    }

    public function saveToFilter($ticket_id, $tags) {
        $filters = new \App\Model\helpdesk\Filters\Filter();
        $filter = $filters->where('key', 'tag')->where('ticket_id', $ticket_id)->get();
        if ($filter->count() > 0) {
            foreach ($filter as $f) {
                $f->delete();
            }
        }
        if ($tags && is_array($tags)) {
            foreach ($tags as $tag) {
                if ($tag != '') { 
                    $filters->create([
                        'ticket_id' => $ticket_id,
                        'key' => 'tag',
                        'value' => $tag
                    ]);
                }
            }
        }
    }
/**
 * 
 * @param Request $request
 * @return type
 */
    public function getTag(Request $request) {
        $term = $request->input('term');
        $tag = new Tag();
        $tags = $tag->where('name', 'LIKE', '%' . $term . '%')->pluck('name')->toArray();
        return $tags;
    }
/**
 * 
 * @param Request $request
 * @return type
 */
    public function getType(Request $request) {
        $term = $request->input('term');

        $types = new Tickettype();

        $type = $types->where('name', 'LIKE', '%' . $term . '%')->where('status', '=', 1)->pluck('name')->toArray();

        return $type;
    }
/**
 * 
 * @return type
 */
    public function tag() {
        return view('themes.default1.admin.helpdesk.tag.index');
    }
/**
 * 
 * @return type
 */
    public function ajaxDatatable() {
        $tags = Tag::leftJoin('filters', function($join) {
                    $join->on('tags.name', '=', 'filters.value')
                    ->where('filters.key', '=', 'tag')
                    ;
                })
                ->select(
                        'tags.id'
                        , 'tags.name'
                        , 'tags.description'
                        , \DB::raw('count(filters.ticket_id) as count')
                )
                ->groupBy('tags.name')
        //->get()        
        ;
        return \DataTables::of($tags)
                        ->editColumn('count', function($tag) {
                            return "<a href='" . url('/tickets?tags[]=') .$tag->name."'>" . $tag->count . "</a>";
                        })
                        ->addColumn('action', function ($tag) {
                            $delete = deletePopUp($tag->id, url('tag/' . $tag->id . '/delete'));
                            $edit = "<a href='" . url('tag/' . $tag->id . '/edit') . "' class='btn btn-primary btn-xs'><i class='fa fa-edit' style='color:white;'>&nbsp;</i>" . trans('lang.edit') . "</a>&nbsp;";
                           
                            return $edit . " " . $delete;
                        })
                        ->filterColumn('count', function($query, $keyword){
                            //for making search by name possible
                        })
                        ->removeColumn('id')
                        ->rawColumns(['count','action','description'])
                        ->make();
    }
/**
 * 
 * @return type
 */
    public function create() {
        try {
            return view('themes.default1.admin.helpdesk.tag.create');
        } catch (Exception $ex) {
            return redirect()->back()->with('fails', $ex->getMessage());
        }
    }
/**
 * 
 * @param type $id
 * @return type
 */
    public function edit($id) {
        try {
            $tag = Tag::find($id);
            if (!$tag) {
                return redirect()->back()->with('fails', 'Tag not found');
            }
            return view('themes.default1.admin.helpdesk.tag.edit', compact('tag'));
        } catch (Exception $ex) {
            return redirect()->back()->with('fails', $ex->getMessage());
        }
    }
/**
 * 
 * @param type $id
 * @param Request $request
 * @return type
 */
    public function update($id, Request $request) {
        $this->validate($request, [
            'name' => 'max:20|required|unique:tags,name,' . $id,
             'description' => 'max:50'
        ]);
        try {
            $tag = Tag::find($id);
            if ($tag) {
                $tag->update([
                    'name' => $request->input('name'),
                    'description' => $request->input('description')
                ]);
            } else {
                return redirect()->back()->with('fails', 'Tag not found');
            }
            return redirect('tag')->with('success',Lang::get('lang.tag_updated_successfully'));
        } catch (Exception $ex) {
            return redirect()->back()->with('fails', $ex->getMessage());
        }
    }
/**
 * 
 * @param Request $request
 * @return type
 */
    public function postCreate(Request $request) {
        $this->validate($request, [
            'name' => 'required|unique:tags,name|max:20',
            'description' => 'max:50'
        ]);
        try {
            Tag::create([
                'name' => $request->input('name'),
                'description' => $request->input('description')
            ]);
            return redirect('tag')->with('success',Lang::get('lang.tag_saved_successfully'));
        } catch (Exception $ex) {
            return redirect()->back()->with('fails', $ex->getMessage());
        }
    }
/**
 * 
 * @param type $id
 * @return type
 */
    public function destroy($id) {
        try {
            $tag = Tag::find($id);
            $querys = DB::table('sla_plan')
                            ->whereRaw('FIND_IN_SET(?,apply_sla_tags)', [$tag->name])
                            ->pluck('id')->toArray();
            if ($querys) {
                return redirect()->back()->with('fails', Lang::get('lang.you_cannot_delete_this_tag,this_tag_applied_sla_plan'));
            }
            if ($tag) {
                $tag->delete();
            } else {
                return redirect()->back()->with('fails', 'Tag not found');
            }
            return redirect('tag')->with('success', Lang::get('lang.tag_deleted_successfully'));
        } catch (Exception $ex) {
            return redirect()->back()->with('fails', $ex->getMessage());
        }
    }

}
