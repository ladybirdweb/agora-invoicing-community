<?php

namespace App\Model\Common;

use App\BaseModel;

class TemplateType extends BaseModel
{
    //
}
