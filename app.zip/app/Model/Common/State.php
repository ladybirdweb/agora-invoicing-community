<?php

namespace App\Model\Common;

use Illuminate\Database\Eloquent\Model;
use App\BaseModel;
class State extends BaseModel
{
    protected $table = 'states_subdivisions';
}
