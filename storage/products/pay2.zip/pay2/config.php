<?php
/**
 * Plugin Name: CCAvenue Payment Gateway for Reseller Club
 * Plugin URI: http://codecanyon.net/item/ccavenue-payment-gateway-for-reseller-club/6858951
 * Description: This extends Reseller Club to accepts money/payments through CCAvenues Payment gateway on your supersite. 
 * File Description: The base configurations of the plugin.
 * This file has the following configurations:  Reseller Club Key, CCAvenue Merchant ID, CCAVenue Working Key and CCAvenue Access Code
 * Author: Ladybird Web Solution
 * Author URI: http://www.ladybirdweb.com
 * Version: 1.2.4
 * Copyright 2014 Ladybird Web Solution
 * @package  CCAvenue Payment Gateway for Reseller Club
 * License: Envato/codecanyon Regular License
 * License URI: http://codecanyon.net/licenses/regular
 */


/** Reseller Club Key */
$key = "YXy4oDX6aukDQjj2KZqCUb4puJWA7aXB"; //replace ur 32 bit secure key , Get your secure key from your Reseller Control panel

/** CCAvenue Merchant ID*/
$merchant_id = "15675" ;//This id(also User Id)  available at "Generate Working Key" of "Settings & Options" 

/** CCAvenue Working Key or Encryption Key*/
$working_key="00FB29A6CDD6690CF392D48171026B5C";//Shared by CCAVENUES

/** CCAvenue Access Code */
$access_code="YCUA8EE3YOEPMMUG";//Shared by CCAVENUES

/** Directry URL */
$directory_url =  "http://www.ladybirdweb.com/pay2" ;

/** Redirection URL */
$redirect_url =  "http://www.ladybirdweb.com/pay2/ccavresponsehandler.php" ;

/** Action URL from Chekout page */
$action_url =  "http://www.ladybirdweb.com/pay2/checkout.php" ;

/** Currency */
$currency =  "INR" ;

/** Gateway Post URL */
$base_url="https://secure.ccavenue.com/transaction/transaction.do?command=initiateTransaction";

?>




