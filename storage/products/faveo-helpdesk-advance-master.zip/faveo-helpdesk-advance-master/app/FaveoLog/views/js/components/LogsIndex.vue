<template>

	<div>
		<alert componentName="dataTableModal"/>

		<div class="box box-primary">

			<div class="box-header with-border">

				<div class="row">

					<div class="col-md-6">
						<h2 class="box-title" id="logs_title">{{lang('logs')}}</h2>
					</div>

					<div class="col-md-6 pull-right">
						<button type="button" id="log_delete" class="btn btn-primary pull-right" @click="showModal = true">		<i class="fa fa-trash"></i> {{lang('delete_logs')}}
						</button>
					</div>

				</div>

			</div>

			<div class="box-body">

				<div class="row align_left">

					<dynamic-select :label="lang('category')"
						:multiple="true"
						name="category_ids"
						:required="false"
						:prePopulate="true"
						classname="col-xs-6"
						apiEndpoint="/api/log-category-list"
						:value="category_ids"
						:onChange="onChange">
					</dynamic-select>

					<date-time-field :label="lang('created_date')"
						:value="created_date"
						type="datetime"
						:time-picker-options="timeOptions"
						name="created_date"
						:required="false"
						:onChange="onChange" range
						:currentYearDate="false"
						format="YYYY-MM-DD HH:mm:ss" classname="col-xs-6"
						:clearable="true" :editable="true" :disabled="false">
						</date-time-field>
				</div>

				<div class="row">

					<exception-logs :category_ids="category_ids" :created_at_start="created_at_start" :created_at_end="created_at_end"></exception-logs>

				</div>

				<div class="row">

					<cron-logs :category_ids="category_ids" :created_at_start="created_at_start" :created_at_end="created_at_end"></cron-logs>

				</div>

				<div class="row">

					<mail-logs :category_ids="category_ids" :created_at_start="created_at_start" :created_at_end="created_at_end"></mail-logs>

				</div>

			</div>

		</div>

		<transition name="modal">
			<logs-modal v-if="showModal" title="delete_logs" :onClose="onClose" :showModal="showModal">

			</logs-modal>
		</transition>

	</div>

</template>

<script>

	import axios from 'axios';

	import moment from 'moment';

	import Vue from 'vue';

	Vue.component('logs-trace', require('./LogsTables/ReusableComponent/LogsTrace.vue'));

	export default {

		name : 'system-logs',

		description : 'System logs component',

		data(){

			return {

				showModal : false,

				category_ids : [],

				created_date : '',

				created_at_start : '',

				created_at_end : '',

				timeOptions:{
						start: '00:00',
						step: '00:30',
						end: '23:30'
			},

			}

		},

		methods : {

			onChange(value,name){

				this[name] = value;

				if(name === 'created_date'){

					this.created_at_start = value[0] !== null ? moment(value[0]).format('YYYY-MM-DD+HH:mm:ss') : '';

					this.created_at_end =  value[1] !== null ? moment(value[1]).format('YYYY-MM-DD+HH:mm:ss') : '';
				}
			},

			onClose(){

		        this.showModal = false;

		        this.$store.dispatch('unsetValidationError');
		    },

		},

		components : {

			'dynamic-select': require('components/MiniComponent/FormField/DynamicSelect'),

			'date-time-field': require('components/MiniComponent/FormField/DateTimePicker'),

			'exception-logs': require('./LogsTables/ExceptionLogs'),

			'cron-logs': require('./LogsTables/CronLogs'),

			'mail-logs': require('./LogsTables/MailLogs'),

			'logs-modal': require('./LogsTables/ReusableComponent/LogsModal'),

			"alert": require("components/MiniComponent/Alert"),
		}
	};

</script>

<style scoped>
	.align_left {
		margin-left: -20px;
	}
	#log_delete{
		    margin-right: -9px;
	}
</style>
