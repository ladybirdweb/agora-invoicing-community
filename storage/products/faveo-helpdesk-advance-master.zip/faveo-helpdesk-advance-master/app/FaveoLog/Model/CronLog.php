<?php

namespace App\FaveoLog\Model;

use App\BaseModel;

class CronLog extends BaseModel
{
  protected $table    = 'cron_logs';

  protected $fillable = ['log_category_id', 'start_time', 'end_time', 'message'];

  public function category()
  {
      return $this->belongsTo('App\FaveoLog\Model\LogCategory','log_category_id');
  }
}
