@extends('themes.default1.admin.layout.admin')
@section('Log')
active
@stop

@section('logs')
class="active"
@stop

@section('HeadInclude')
@stop
<!-- header -->
@section('PageHeader')
<h1>{{Lang::get('log::lang.logs')}}</h1>
@stop
<!-- /header -->
<!-- breadcrumbs -->
@section('breadcrumbs')
<ol class="breadcrumb">
</ol>
@stop
@section('content')
<style>


    .stack {
        font-size: 0.85em;
    }
    .date {
        min-width: 75px;
    }
    .text {
        word-break: break-all;
    }
    a.llv-active {
        z-index: 2;
        background-color: #f5f5f5;
        border-color: #777;
    }
    .readmore-tooltip {
    position: relative;
    display: inline-block;
    border-bottom: 1px dotted black;
}

.readmore-tooltip .readmore-tooltip-text {
    visibility: hidden;
    width: 500px;
    background-color: #FED85D;
    color: #fff;
    text-align: justify;
    word-break:break-all;
    white-space: normal;
    border-radius: 6px;
    padding: 15px;

    /* Position the tooltip */
    position: absolute;
    right: 100%;
    z-index: 999
}

.readmore-tooltip:hover .readmore-tooltip-text {
    visibility: visible;
}
</style>
<div class="container-fluid">
    <div class="box box-primary">
        <div class="box-header with-border">
            <h4>System Logs</h4>

        </div>
        <div class="box-body">
            <div class="row">
                <div class="col-md-2">
                    <div class="list-group">
                        @foreach($files as $file)
                        <a href="?l={{ base64_encode($file) }}" class="list-group-item @if ($current_file == $file) llv-active @endif">
                            {{$file}}
                        </a>
                        @endforeach
                    </div>
                </div>
                <div class="col-md-10 table-container ">
                    <div>
                        <table id="table-log" class="table table-striped">
                            <thead>
                                <tr>
                                    <th style="width:10%">Level</th>
                                    <th style="width:12%">Context</th>
                                    <th>Date</th>
                                    <th>Content</th>
                                </tr>
                            </thead>
                            <tbody>



                            </tbody>
                        </table>
                    </div>
                    <div>
                        <!--<a href="?dl={{ base64_encode($current_file) }}"><span class="glyphicon glyphicon-download-alt"></span> Download file</a>-->
                        -
                        <!--<a id="delete-log" href="?del={{ base64_encode($current_file) }}"><span class="glyphicon glyphicon-trash"></span> Delete file</a>-->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


@stop
@section('FooterInclude')
<!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>-->
<!--<script src="https://cdn.datatables.net/1.10.4/js/jquery.dataTables.min.js"></script>-->
<script src="https://cdn.datatables.net/plug-ins/9dcbecd42ad/integration/bootstrap/3/dataTables.bootstrap.js"></script>
<script>
$(document).ready(function () {
    $('#table-log').DataTable({
        processing: true,
        serverSide: true,
        "oLanguage": {
            "sLengthMenu": "_MENU_ Records per page",
            "sSearch"    : "Search: ",
            "sProcessing": '<img id="blur-bg" class="backgroundfadein" style="top:40%;left:50%; width: 50px; height:50 px; display: block; position:    fixed;" src="{!! asset("lb-faveo/media/images/gifloader3.gif") !!}">'
        },
        columns:[
            {data: 'level', name:'level'},
            {data: 'context', name:'context'},
            {data: 'date', name:'date'},
            {data: 'text', name:'text'}
        ],
        "fnDrawCallback": function( oSettings ) {
            $(".col-sm-12").css({"opacity": "1"});
            $('#blur-bg').css({"opacity": "1", "z-index": "99999"});
            $('.loader').css('display', 'none');
        },
        "fnPreDrawCallback": function(oSettings, json) {
            $(".col-sm-12").css({"opacity":"0.3"});
            $('.loader').css('display', 'block');
        },
        ajax: "{{url('logs/api/'.$l)}}",
    });
    $('.table-container').on('click', '.expand', function () {
        $('#' + $(this).data('display')).toggle();
    });
    $('#delete-log').click(function () {
        return confirm('Are you sure?');
    });
});
</script>
@stop