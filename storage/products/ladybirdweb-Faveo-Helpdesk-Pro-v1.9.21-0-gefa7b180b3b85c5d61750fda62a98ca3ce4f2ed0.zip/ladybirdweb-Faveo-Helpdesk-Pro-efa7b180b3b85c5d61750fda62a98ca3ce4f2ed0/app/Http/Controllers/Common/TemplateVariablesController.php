<?php

namespace App\Http\Controllers\Common;

//controllers
use App\Http\Controllers\Controller;
// models
use App\Model\helpdesk\Settings\Company;
use App\Model\helpdesk\Settings\System;

//classes
use Finder;
use Lang;

/**
 * |======================================================
 * | Class Template Variables Controller
 * |======================================================
 * This controller is used to get all the varables used in Email/SMS templates
 * @author manish.verma@ladybirdweb.com
 * @copyright Ladybird Web Solutions
 */
class TemplateVariablesController extends Controller
{
    /**
     * @category function to replace template variable with values
     * @param array $template_variables (list of template variables)
     * @return array $variables (value of replaced template variables)
     */
    public function getVariableValues($template_variables, $content = '')
    {
        if (checkArray('message_content', $template_variables) != '') {
            $content = checkArray('message_content', $template_variables);
        }
        $company_name = $this->checkElement('company_name', $template_variables);
        if ($company_name === "") {
            $company_name = $this->company();
        }

        $system_from = $this->checkElement('system_from', $template_variables);
        if ($system_from == '') {
            $system_from = $this->system();
        }

        $system_link = $this->checkElement('system_link', $template_variables);
        if ($system_link === "") {
            $system_link = $this->system('link');
        }

        $company_link = $this->checkElement('company_link', $template_variables);
        if ($company_link === "") {
            $company_link = $this->company('link');
        }

        $variables = [
            '{!! $receiver_name !!}' => checkArray('receiver_name', $template_variables),
            '{!! $new_user_name !!}' => checkArray('new_user_name', $template_variables),
            '{!! $new_user_email !!}' => checkArray('new_user_email', $template_variables),
            '{!! $password_reset_link !!}' => checkArray('password_reset_link', $template_variables),
            '{!! $reference_link !!}' => checkArray('reference_link', $template_variables),
            '{!! $user_password !!}' => checkArray('user_password', $template_variables),
            '{!! $account_activation_link !!}' => checkArray('account_activation_link', $template_variables),
            '{!! $ticket_link !!}' => checkArray('ticket_link', $template_variables),
            '{!! $ticket_number !!}' => checkArray('ticket_number', $template_variables),
            '{!! $department_signature !!}' => checkArray('department_signature', $template_variables),
            '{!! $client_name !!}' => checkArray('client_name', $template_variables),
            '{!! $client_email !!}' => checkArray('client_email', $template_variables),
            '{!! $agent_name !!}' => checkArray('agent_name', $template_variables),
            '{!! $agent_email !!}' => checkArray('agent_email', $template_variables),
            '{!! $agent_contact !!}' => checkArray('agent_contact', $template_variables),
            '{!! $agent_signature !!}' => checkArray('agent_sign', $template_variables),
            '{!! $client_name !!}' => checkArray('client_name', $template_variables),
            '{!! $client_email !!}' => checkArray('client_email', $template_variables),
            '{!! $client_contact !!}' => checkArray('client_contact', $template_variables),
            '{!! $user_profile_link !!}' => checkArray('user_profile_link', $template_variables),
            '{!! $activity_by !!}' => checkArray('activity_by', $template_variables),
            '{!! $assigned_team_name !!}' => checkArray('assigned_team_name', $template_variables),
            '{!! $ticket_subject !!}' => checkArray('ticket_subject', $template_variables),
            '{!! $ticket_due_date !!}' => checkArray('ticket_due_date', $template_variables),
            '{!! $ticket_created_at !!}' => checkArray('ticket_created_at', $template_variables),
            '{!! $otp_code !!}' => checkArray('otp_code', $template_variables),
            '{!! $system_from !!}' => $system_from,
            '{!! $system_link !!}' => $system_link,
            '{!! $company_name !!}' => $company_name,
            '{!! $company_link !!}' => $company_link,
            '{!! $message_content !!}' => $content,
            '{!! $approve_url !!}'=>checkArray('approve_url', $template_variables),
            '{!! $deny_url !!}'=>checkArray('deny_url', $template_variables),
            '{!! $ticket_edit_link !!}'=>  checkArray('ticket_client_edit_link', $template_variables),
            '{!! $total_time !!}'=>  checkArray('total_time', $template_variables),
            '{!! $cost !!}'=>  checkArray('cost', $template_variables),
            '{!! $bill_date !!}'=>  checkArray('bill_date', $template_variables),
            '{!! $currency !!}'=>checkArray('currency', $template_variables),
//  Task template variables need to check once for complete fuctionality of templates
            '{!! $task_name !!}' => checkArray('task_name', $template_variables),
            '{!! $task_end_date !!}' => checkArray('task_end_date', $template_variables),
            '{!! $status !!}' => checkArray('status', $template_variables),
            '{!! $updated_by !!}' => checkArray('updated_by', $template_variables),
            '{!! $created_by !!}' => checkArray('created_by', $template_variables),
/*=====================================TIll HERE  ========================*/
        ];
        return $variables;
    }

    /**
     * @category function to replace shortcode in template to display in front end
     * @param string $content
     * @var array: $variables, $data, string: $body
     * @return string $body
     */
    public function stringReplaceVariables($contents)
    {
        $variables = [
            '{!! $receiver_name !!}',
            '{!! $new_user_name !!}',
            '{!! $new_user_email !!}',
            '{!! $reference_link !!}',
            '{!! $user_password !!}',
            '{!! $system_from !!}',
            '{!! $system_link !!}',
            '{!! $company_name !!}',
            '{!! $company_link !!}',
            '{!! $password_reset_link !!}',
            '{!! $account_activation_link !!}',
            '{!! $ticket_link !!}',
            '{!! $ticket_number !!}',
            '{!! $department_signature !!}',
            '{!! $agent_name !!}',
            '{!! $agent_email !!}',
            '{!! $agent_contact !!}',
            '{!! $agent_signature !!}',
            '{!! $client_name !!}',
            '{!! $client_email !!}',
            '{!! $client_contact !!}',
            '{!! $user_profile_link !!}',
            '{!! $message_content !!}',
            '{!! $activity_by !!}',
            '{!! $assigned_team_name !!}',
            '{!! $ticket_subject !!}',
            '{!! $ticket_due_date !!}',
            '{!! $ticket_created_at !!}',
            '{!! $otp_code !!}',
            '{!! $ticket_edit_link !!}',
            '{!! $approve_url !!}',
            '{!! $deny_url !!}',
            '{!! $total_time !!}',
            '{!! $cost !!}',
            '{!! $bill_date !!}',
            '{!! $currency !!}',
            '{!! $task_name !!}',
            '{!! $task_end_date !!}',
            '{!! $status !!}',
            '{!! $updated_by !!}',
            '{!! $created_by !!}',

        ];
        $data = [
            '%receiver_name%',
            '%new_user_name%',
            '%new_user_email%',
            '%reference_link%',
            '%user_password%',
            '%system_name%',
            '%system_link%',
            '%company_name%',
            '%company_link%',
            '%password_reset_link%',
            '%account_activation_link%',
            '%ticket_link%',
            '%ticket_number%',
            '%department_signature%',
            '%agent_name%',
            '%agent_email%',
            '%agent_contact%',
            '%agent_signature%',
            '%client_name%',
            '%client_email%',
            '%client_contact%',
            '%user_profile_link%',
            '%message_content%',
            '%activity_by%',
            '%assigned_team_name%',
            '%ticket_subject%',
            '%ticket_due_date%',
            '%ticket_created_at%',
            '%otp_code%',
            '%ticket_edit_link%',
            '%$approve_url%',
            '%deny_url%',
            '%total_time%',
            '%cost%',
            '%bill_date%',
            '%currency%',
            '%task_name%',
            '%task_end_date%',
            '%status%',
            '%updated_by%',
            '%created_by%'
        ];
        $body = Finder::replaceTemplateVariables($variables, $data, $contents);
        return $body;
    }

    /**
     * @category function to replace shortcode in template to store in Database
     * @param string $content
     * @var array: $variables, $data, string: $body
     * @return string $body
     */
    public function stringReplaceVariablesReverse($contents)
    {
        $data = [
            '{!! $receiver_name !!}',
            '{!! $new_user_name !!}',
            '{!! $new_user_email !!}',
            '{!! $reference_link !!}',
            '{!! $user_password !!}',
            '{!! $system_from !!}',
            '{!! $system_link !!}',
            '{!! $company_name !!}',
            '{!! $company_link !!}',
            '{!! $password_reset_link !!}',
            '{!! $account_activation_link !!}',
            '{!! $ticket_link !!}',
            '{!! $ticket_number !!}',
            '{!! $department_signature !!}',
            '{!! $agent_name !!}',
            '{!! $agent_email !!}',
            '{!! $agent_contact !!}',
            '{!! $agent_signature !!}',
            '{!! $client_name !!}',
            '{!! $client_email !!}',
            '{!! $client_contact !!}',
            '{!! $user_profile_link !!}',
            '{!! $message_content !!}',
            '{!! $activity_by !!}',
            '{!! $assigned_team_name !!}',
            '{!! $ticket_subject !!}',
            '{!! $ticket_due_date !!}',
            '{!! $ticket_created_at !!}',
            '{!! $otp_code !!}',
            '{!! $ticket_edit_link !!}',
            '{!! $approve_url !!}',
            '{!! $deny_url !!}',
            '{!! $total_time !!}',
            '{!! $cost !!}',
            '{!! $bill_date !!}',
            '{!! $currency !!}',
            '{!! $task_name !!}',
            '{!! $task_end_date !!}',
            '{!! $status !!}',
            '{!! $updated_by !!}',
            '{!! $created_by !!}',

        ];
        $variables = [
            '%receiver_name%',
            '%new_user_name%',
            '%new_user_email%',
            '%reference_link%',
            '%user_password%',
            '%system_name%',
            '%system_link%',
            '%company_name%',
            '%company_link%',
            '%password_reset_link%',
            '%account_activation_link%',
            '%ticket_link%',
            '%ticket_number%',
            '%department_signature%',
            '%agent_name%',
            '%agent_email%',
            '%agent_contact%',
            '%agent_signature%',
            '%client_name%',
            '%client_email%',
            '%client_contact%',
            '%user_profile_link%',
            '%message_content%',
            '%activity_by%',
            '%assigned_team_name%',
            '%ticket_subject%',
            '%ticket_due_date%',
            '%ticket_created_at%',
            '%otp_code%',
            '%ticket_edit_link%',
            '%approve_url%',
            '%deny_url%',
            '%total_time%',
            '%cost%',
            '%bill_date%',
            '%currency%',
            '%task_name%',
            '%task_end_date%',
            '%status%',
            '%updated_by%',
            '%created_by%'
        ];
        $body = Finder::replaceTemplateVariables($variables, $data, $contents);
        return $body;
    }

    /**
     * @category function to return list of avaialable variables for templates
     * @param string $scenario (type of event)
     * @var array $variables
     * @return array $variables list of available variables
     */
    public function getAvailableTemplateVariables($scenario)
    {
        //base template variables
        $variables['%receiver_name%'] = Lang::get('lang.shortcode_receiver_name_description');
        $variables['%system_link%'] = Lang::get('lang.shortcode_system_link_description');
        $variables['%system_name%'] = Lang::get('lang.shortcode_system_from_description');
        $variables['%company_name%'] = Lang::get('lang.shortcode_company_name_description');
        $variables['%company_link%'] = Lang::get('lang.shortcode_company_link_description');
        //common template variables
         $variables['%new_user_name%'] = Lang::get('lang.shortcode_new_user_name_description');
        $variables['%new_user_email%'] = Lang::get('lang.shortcode_new_user_email_description');
        $variables['%user_password%'] = Lang::get('lang.shortcode_user_password_description');
        $variables['%password_reset_link%'] = Lang::get('lang.shortcode_password_reset_link_description');
        // template links
        $variables['%account_activation_link%'] = Lang::get('lang.shortcode_account_activation_link_description');
        $variables['%ticket_link%'] = Lang::get('lang.shortcode_ticket_link_description');
        $variables['%ticket_number%'] = Lang::get('lang.shortcode_ticket_number_description');
        $variables['%ticket_subject%'] = Lang::get('lang.shortcode_ticket_subject_description');
        $variables['%ticket_due_date%'] = Lang::get('lang.shortcode_ticket_due_date_description');
        $variables['%ticket_created_at%'] = Lang::get('lang.shortcode_ticket_created_at_description');
        $variables['%department_signature%'] = Lang::get('lang.shortcode_department_signature_description');
        $variables['%agent_name%'] = Lang::get('lang.shortcode_agent_name_description');
        $variables['%agent_email%'] = Lang::get('lang.shortcode_agent_email_description');
        $variables['%agent_contact%'] = Lang::get('lang.shortcode_agent_contact_description');
        $variables['%agent_signature%'] = Lang::get('lang.shortcode_agent_signature_description');
        $variables['%client_name%'] = Lang::get('lang.shortcode_client_name_description');
        $variables['%client_email%'] = Lang::get('lang.shortcode_client_email_description');
        $variables['%client_contact%'] = Lang::get('lang.shortcode_client_contact_description');
        $variables['%user_profile_link%'] = Lang::get('lang.shortcode_user_profile_link_description');
        $variables['%message_content%'] = Lang::get('lang.shortcode_message_content_description');
        $variables['%activity_by%'] = Lang::get('lang.shortcode_activity_by_description');
        $variables['%assigned_team_name%'] = Lang::get('lang.shortcode_assigned_team_name_description');
        $variables['%otp_code%'] = Lang::get('lang.shortcode_otp_code_description');
        $variables['%ticket_edit_link%'] = Lang::get('lang.shortcode_to_send_ticket_edit_link');

        $variables['%approve_url%'] = Lang::get('lang.shortcode_approve_url_description');
        $variables['%deny_url%'] = Lang::get('lang.shortcode_deny_url_description');
        $variables['%total_time%'] = Lang::get('lang.shortcode_total_time_description');
        $variables['%cost%'] = Lang::get('lang.shortcode_cost_description');
        $variables['%bill_date%'] = Lang::get('lang.shortcode_bill_date_description');
        $variables['%currency%'] = Lang::get('lang.shortcode_currency_description');
        $variables['%task_name%'] = Lang::get('lang.shortcode_task_name_description');
        $variables['%task_end_date%'] = Lang::get('lang.shortcode_task_end_date_description');
        $variables['%status%'] = Lang::get('lang.shortcode_status_description');
        $variables['%updated_by%'] = Lang::get('lang.shortcode_updated_by_description');
        $variables['%created_by%'] = Lang::get('lang.shortcode_created_by_description');
        
        return $variables;
    }

    public function checkElement($element, $array)
    {
        $value = "";
        if (is_array($array)) {
            if (key_exists($element, $array)) {
                $value = $array[$element];
            }
        }
        return $value;
    }

    /**
     * Fetching comapny name to send mail.
     * @var $fetch string to identify what needs to be fetched
     * @return type
     */
    public function company($fetch = 'name')
    {
        $company = Company::Where('id', '=', '1')->first();
        if ($fetch == 'name') {
            if ($company->company_name == null) {
                $company = 'Support Center';
            } else {
                $company = $company->company_name;
            }
        } else {
            $company = $company->website;
        }

        return $company;
    }

    /**
     * system.
     *
     * @return type
     */
    public function system($fetch = 'name')
    {
        $system = System::Where('id', '=', '1')->first();
        if ($fetch == 'name') {
            if ($system->name == null) {
                $system = 'Support Center';
            } else {
                $system = $system->name;
            }
        } else {
            $system = $system->url;
        }
        return $system;
    }
}
