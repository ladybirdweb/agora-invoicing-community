<?php

namespace App\Http\Controllers\Utility;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Custom\Form;
use DB;
use Auth;
use Input;
use App\User;
use App\Model\helpdesk\Agent\Teams;
use App\Model\helpdesk\Agent\Assign_team_agent;
use App\Model\helpdesk\Ticket\Ticket_Status;

class FormController extends Controller
{
    /**
     * get the form in json format
     * @param boolean $array
     * @return array|json
     */
    public function getTicketFormJson($type = "ticket", $array = false)
    {
        $form   = new Form();
        $custom = $form->where('form', $type)->select('json')->first();
        $json   = "";
        if ($custom) {
            if(stripos($custom->json, "'unique':'requester'") || strpos($custom->json, "'unique':'first_name'") ||
                strpos($custom->json, "'unique':'name'")){
                $json = str_replace("'", '"', $custom->json);
            } else {
                $json = str_replace("'", '\'', $custom->json);
            }
        }
        $json = $this->addAdditionalFields($json, Input::all());
        $jsonEvent = checkArray('0', event(new \App\Events\ClientTicketForm($json)));
        if ($jsonEvent) {
            $json = json_encode($jsonEvent);
        }
        return ($array) ? $json : '[' . $json . ']';
    }

    /**
     * Function to add custom fields of department and helptopic in ticket form json
     * @param   String  json encoded string of forms fields
     * @param   Array   array containing input data from ajax call
     * @return  String  json encoded string after adding additional fields
     */
    private function addAdditionalFields(string $json, array $array=[])
    {
        $decodedJson = json_decode($json);
        foreach ($array as $table => $id) {
            if($table === 'department' || $table === 'help_topic') {
                $additionalJson = \DB::table($table)->where('id', $id)->value('nodes');
                if(json_decode($additionalJson)) {
                    $decodedJson = array_merge($decodedJson, json_decode($additionalJson));
                }   
            }
        }
        return json_encode($decodedJson);
    }

    /**
     * get all dependencies
     * @param Request $request
     * @return mixed
     */
    public function dependancy(Request $request)
    {

        try{
            $linked_topic = ($request->has('linkedtopic')) ? $request->get('linkedtopic')
                        : '';
            $dependency   = $request->input('dependency', 'priority');

            return $this->getDependancy($dependency, $linked_topic, $request);
        }  catch (\Exception $e){
            return response()->json(['error'=>$e->getMessage()]);
        }
    }
    /**
     * get the model for every dependency
     * @param string $dependency
     * @return mixed
     */
    public function getDependancyApproval($dependency, $term)
    {

        switch ($dependency) {
            case "priority":
                $auth_user = \Auth::user();
                if ($auth_user && $auth_user->role != 'user') {
                    return DB::table('ticket_priority')->where('priority', 'LIKE', '%' . $term . '%')->where('status', '=', 1)->select('priority_id as id', 'priority as optionvalue')->get()->toJson();
                }
                else {
                    return DB::table('ticket_priority')->where('priority', 'LIKE', '%' . $term . '%')->where('status', '=', 1)->where('ispublic', 1)->select('priority_id as id', 'priority as optionvalue')->get()->toJson();
                }
            case "faveo_department":
                return DB::table('department')->where('name', 'LIKE', '%' . $term . '%')->select('id', 'name as optionvalue')->get()->toJson();
            case "type":
                $auth_user = \Auth::user();
                if ($auth_user && $auth_user->role != 'user') {

                    return DB::table('ticket_type')->where('name', 'LIKE', '%' . $term . '%')->where('status', '=', 1)->select('id', 'name as optionvalue')->get()->toJson();
                }
                else {
                    return DB::table('ticket_type')->where('name', 'LIKE', '%' . $term . '%')->where('status', '=', 1)->where('ispublic', '=', 1)->select('id', 'name as optionvalue')->get()->toJson();
                }
            case "assigned_to":
                return DB::table('users')->where('role', '!=', 'user')->where('is_delete', '!=', 1)->where('ban', '!=', 1)->select('id', 'user_name as optionvalue')->get()->toJson();
        }
    }
    /**
     * get the model for every dependency
     * @param string $dependency
     * @return mixed
     */
    public function getDependancy($dependency, $linked_topic = '', $request = '')
    {
     switch ($dependency) {
            case "priority":
                $auth_user = \Auth::user();
                if ($auth_user && $auth_user->role != 'user') {
                    return DB::table('ticket_priority')->where('status', '=', 1)->select('priority_id as id', 'priority as optionvalue')->get()->toJson();
                }
                else {
                    return DB::table('ticket_priority')->where('status', '=', 1)->where('ispublic', 1)->select('priority_id as id', 'priority as optionvalue')->get()->toJson();
                }
            case "department":
                $departments = DB::table('department')->select('id', 'name as optionvalue', 'nodes');
                if ($linked_topic != '') {
                    $help_topic = DB::table('help_topic')->select('linked_departments', 'department')->where('topic', '=', $linked_topic)->first();
                    if ($help_topic->linked_departments == null || $help_topic->linked_departments
                            == '') {
                        if(Auth::user() && Auth::user()->role=='admin' || Auth::user() && Auth::user()->role=='agent'){
                            $departments = $departments->where('id', '=', $help_topic->department)->orderBy('optionvalue')->get();
                        }
                        else{
                            $departments = $departments->where('type','!=',0)->where('id', '=', $help_topic->department)->orderBy('optionvalue')->get();
                        }
                    }
                    else {
                        $dept_ids    = explode(",", $help_topic->linked_departments);
                         if(Auth::user() && Auth::user()->role=='admin' || Auth::user() && Auth::user()->role=='agent'){
                        $departments = $departments->whereIn('id', $dept_ids)->orderBy('optionvalue')->get();
                          }
                          else{
                             $departments = $departments->where('type','!=',0)->whereIn('id', $dept_ids)->orderBy('optionvalue')->get();
                          }
                    }
                    
                }
                else {

                         if(Auth::user() && Auth::user()->role=='admin' || Auth::user() && Auth::user()->role=='agent'){

                        $departments = $departments->orderBy('optionvalue')->get();
                    }
                    else{
                        $departments = $departments->where('type',1)
                        ->orderBy('optionvalue')->get();
                    }
                }
                foreach ($departments as $value) {
                    $value->optionvalue = [['language' => 'en', 'option' => $value->optionvalue, 'flag' => asset("lb-faveo/flags/en.png")]];
                    if ($value->nodes != null) {
                        $value->nodes = json_decode(str_replace("'", '"', $value->nodes));
                    }
                    else {
                        $value->nodes = [];
                    }
                }
               
                return response()->json($departments);
            case "faveo_department":
                return DB::table('department')->select('id', 'name as optionvalue')->get()->toJson();
            case "type":
                $auth_user = \Auth::user();
                if ($auth_user && $auth_user->role != 'user') {

                    return DB::table('ticket_type')->where('status', '=', 1)->select('id', 'name as optionvalue')->get()->toJson();
                }
                else {
                    return DB::table('ticket_type')->where('status', '=', 1)->where('ispublic', '=', 1)->select('id', 'name as optionvalue')->get()->toJson();
                }
            case "assigned_to":
                return DB::table('users')->where('role', '!=', 'user')
                                ->where([
                                    ['active', '=', 1],
                                    ['is_delete', '!=', 1],
                                    ['ban', '!=', 1]
                                ])->select('id', 'user_name as optionvalue')->orderBy('optionvalue')->get()->toJson();
                return DB::table('users')->where('role', '!=', 'user')->where('active', '=', 1)->where('is_delete', '!=', 1)->where('ban', '!=', 1)->select('id', 'user_name as optionvalue')->get()->toJson();
            case "company":
                return DB::table('organization')->where('name','LIKE','%'.$request->term.'%')->select('id', 'name as optionvalue')->get()->toJson();
            case "status":
                if (Auth::user() && Auth::user()->role != 'user') {
                    $obj = new \App\Policies\TicketPolicy();
                    $status = Ticket_Status::select('id', 'name as optionvalue');
                    
                    // if (!$obj->viewUnapprovedTickets()) {
                    // AVINASH : permission has been commented as we are not sure whether unapproved
                    // should be visible or not
                        $status = $status->where('purpose_of_status', '!=', 7);
                    // }
                    
                    return $status->get()->toJson();
                }
                return Ticket_Status::where('visibility_for_client', 1)->where('allow_client', 1)->select('id', 'name as optionvalue')->whereIn('purpose_of_status', [1,2])->get()->toJson();
            
            //all status shows all the statuses irrespective of its purpose of status. It will be used in workflow of list all status including unapproved. Only admin will be able to see it
            case "all-status":
                if (Auth::user() && Auth::user()->role == 'admin') {
                    return Ticket_Status::select('id', 'name as optionvalue')->get()->toJson();
                }
                return [];
                
            case "help_topic":
                $auth_user = \Auth::user();
                if ($auth_user && $auth_user->role != 'user') {
                    $help_topics = DB::table('help_topic')->where('status', '=', 1)->select('id', 'topic as optionvalue', 'nodes')->get()->toJson();
                }
                else {
                    $help_topics = DB::table('help_topic')->where('status', '=', 1)->where('type', '=', 1)->select('id', 'topic as optionvalue', 'nodes')->get()->toJson();
                }
                return $help_topics;
            // case "status":
            //     return DB::table('ticket_status')->select('id', 'name as optionvalue')->get()->toJson();
            case "helptopic":
                $help_topics = DB::table('help_topic');
                if ($linked_topic != '') {
                    $dept        = DB::table('department')->where('name', '=', $linked_topic)->pluck('id')->toArray()[0];
                    $help_topics = $help_topics->whereRaw("find_in_set('" . $dept . "', linked_departments)")->orWhere('department', '=', $dept);
                    if ($help_topics->count() == 0) {
                        $help_topics = DB::table('help_topic');
                    }
                }
                $auth_user = \Auth::user();
                if ($auth_user && $auth_user->role != 'user') {
                    $help_topics = $help_topics->where('status', '=', 1)->select('id', 'topic as optionvalue', 'nodes')->orderBy('optionvalue')->get();
                }
                else {
                    $help_topics = $help_topics->where('status', '=', 1)->where('type', '=', 1)->select('id', 'topic as optionvalue', 'nodes')->orderBy('optionvalue')->get();
                }
                foreach ($help_topics as $value) {
                    $value->optionvalue = [['language' => 'en', 'option' => $value->optionvalue, 'flag' => asset("lb-faveo/flags/en.png")]];
                    if ($value->nodes != null) {
                        $value->nodes = json_decode(str_replace("'", '"', $value->nodes));
                    }
                    else {
                        $value->nodes = [];
                    }
                }
                return response()->json($help_topics);
            case "source":
                return DB::table('ticket_source')->select('id', 'value as optionvalue')->get()->toJson();
            case "approval":
                return $this->getDependancyApproval($request->get('req'), $request->get('term'));
            case "location":
                // return DB::table('location')->select('title', 'title as optionvalue')->get()->toJson();
                $auth_user = \Auth::user();
                if ($auth_user && $auth_user->role != 'user') {
                    if (\Auth::user()->role === 'admin') {
                        return DB::table('location')->orderBy('title', 'asc')->select('title as id', 'title as optionvalue')->get()->toJson();
                    }
                    else {
                        $agent_location = User::where('id', '=', \Auth::user()->id)->select('location')->first();

                        if ($agent_location->location) {
                            return DB::table('location')->orderBy('title', 'asc')->where('title', '=', $agent_location->location)->select('title as id', 'title as optionvalue')->get()->toJson();
                        }
                        else {
                            return DB::table('location')->orderBy('title', 'asc')->select('title as id', 'title as optionvalue')->get()->toJson();
                        }
                    }
                }
                else {
                    return DB::table('location')->orderBy('title', 'asc')->select('title as id', 'title as optionvalue')->get()->toJson();
                }

            case "org_dept":
            // dd($request->input('company'));
                // $test = \App\Model\helpdesk\Agent_panel\OrganizationDepartment::whereIn('org_id', $company)->select('id', 'org_deptname as optionvalue')->get()->toJson();
                if ($request->input('company')) {
                    $company = $request->input('company');
                    $company_name = DB::table('organization')->whereIn('id', $company)->pluck('name')->toArray();
                    $formatted_orgs = DB::table('organization_dept')
                            ->join('organization', function($q) {
                                $q->on('organization.id', '=', 'organization_dept.org_id');
                            })
                            ->whereIn('organization.name', $company_name)
                            ->where('organization_dept.org_deptname', 'LIKE', '%' . $request->term . '%')
                            ->select("organization_dept.id", "organization_dept.org_id", "organization_dept.org_deptname", "organization.name")
                            ->get();
                    foreach ($formatted_orgs as $key => $value) {
                        $display = $value->org_deptname . "(" . $value->name . ")";
                        $formatted_orgs_dept[] = ['id' => $value->id, 'optionvalue' => $display];
                    }
                    return \Response::json($formatted_orgs_dept);
                } else {
                    $formatted_orgs_dept[] = DB::table('organization_dept')->select("organization_dept.id", "organization_dept.org_id", "organization_dept.org_deptname")
                            ->get();
                    return \Response::json($formatted_orgs_dept);
                }



                 case "helpdesk-name":
                return DB::table('satellite_helpdesk')->where('status', '=', 1)->select('id', 'name as optionvalue')->get()->toJson();

        }
    }
    
     /**(Dependency places [create ticket (requester),deactivate agent(assign open ticket) ,team create(team lead)])
     * get requester in form
     * @param Request $request
     * @return json
     */
    public function requester(Request $request)
    {

        if($request->has('team')){
            $id = $request->team;
            $term = $request->input('term');
            $team = new Teams();
            $teams = $team->whereId($id)->first();


            $assign_team_agent = new Assign_team_agent();
            $agent_team = $assign_team_agent->where('team_id', $id)->get();

            $agent_id = $agent_team->pluck('agent_id', 'agent_id');

            $query = User::whereIn('id', $agent_id)->where('active', '=', 1)->where('ban', '!=', 1)->where('is_delete', '!=', 1)
                            ->when($term, function($q) use($term) {
                                $q->where(function($query) use($term) {
                                    $query->select('id', 'first_name', 'last_name', 'email', 'user_name', 'profile_pic')
                                    ->where('first_name', 'LIKE', '%' . $term . '%')
                                    ->orwhere('last_name', 'LIKE', '%' . $term . '%')
                                    ->orwhere('user_name', 'LIKE', '%' . $term . '%')
                                    ->orwhere('email', 'LIKE', '%' . $term . '%');
                                });
                            })->get();
            return $query;
        }
        else{
            $method   = $request->input('type', 'agent','user','admin','agent-only');
            $user_ids = explode(',', $request->input('user_id', ''));
            if (count($user_ids) == 1 && $user_ids[0] == '') {
                $user_ids = '';
            }
            //$method = 'requester';
            //$user_ids = [];
            $user     = new \App\User();
            $term     = $request->input('term');
            $query = $user
                        ->leftJoin('user_assign_organization', 'users.id', '=', 'user_assign_organization.user_id')
                        ->leftJoin('organization', 'organization.id', '=', 'user_assign_organization.org_id')
                        ->when($term, function($q) use($term) {
                           $q->where(function($query) use($term){
                               $query
                               ->where('users.first_name', 'LIKE', '%' . $term .'%')
                               ->orWhere('users.last_name','LIKE','%'. $term .'%')
                               ->orWhere('user_name', 'LIKE', '%' . $term . '%')
                               ->orWhere('email', 'LIKE', '%' . $term . '%')
                               ->orWhere('organization.address', 'LIKE', '%' . $term . '%')
                                ->orWhere('organization.name', 'LIKE', '%' . $term . '%');
                           });
                       })
                        ->when($user_ids, function($q)use($user_ids) {
                            $q->whereIn('users.id', $user_ids);
                        })
                        
                        ->where('is_delete', '!=', 1)
                        ->where('active', '=', 1)
                        ->where('ban', '!=', 1)
                        ->when($term, function($q) use($term) {
                            $q->where(function($query) use($term){
                                $query->where('users.first_name', 'LIKE', '%' . $term . '%')
                                ->orWhere('users.last_name', 'LIKE', '%' . $term . '%')
                                ->orWhere('user_name', 'LIKE', '%' . $term . '%')
                                ->orWhere('email', 'LIKE', '%' . $term . '%')
                                ->orWhere('organization.address', 'LIKE', '%' . $term . '%')
                                ->orWhere('organization.name', 'LIKE', '%' . $term . '%');
                            });
                        })

                        ->with(['org' => function($org) {
                                $org->select('id', 'org_id', 'user_id', 'role', 'org_department');
                            }, 'org.organisation' => function($company) {
                                $company->select('id', 'name as company' ,'address as address ');
                            },
                            'org.orgDepartment' => function($q) {
                               $q->select('id', 'org_deptname', 'business_hours_id');
                                }
                         ]);
             
    //Returns all Admins n Agents only               
            if ($method == 'agent') {
                $users = $query
                        ->where('users.role', '!=', 'user')
                        ->select('users.id','users.email as name','users.first_name','users.last_name','users.profile_pic','users.email','users.role')
                        ->get();
               
                // dd($users);
                return $users;
            }
    //Returns all Admins n Agents n Users  
            if ($method == 'requester') {
                $users = $query->groupBy('users.id')
                        ->select('users.id', 'users.email as name', 'users.first_name', 'users.last_name','users.email','users.profile_pic','users.role')
                        ->get();
               
               // dd($users);
                return $users;
            }
    //Returns all Users only  
            if ($method == 'user') {
                $users = $query->groupBy('users.id')
                        ->where('users.role', '=', 'user')
                        ->select('users.id','users.user_name','users.first_name','users.last_name','users.profile_pic','users.email','users.role')
                        ->get();
               
               // dd($users);
                return $users;
            }
    //Returns all Admins only  
            if ($method == 'admin') {
                $users = $query->groupBy('users.id')
                        ->where('users.role', '=', 'admin')
                        ->select('users.id','users.user_name','users.first_name','users.last_name','users.profile_pic','users.email','users.role')
                        ->get();
               
               // dd($users);
                return $users;
            }
    //Returns all Agents only  
             if ($method == 'agent-only') {
                $users = $query->groupBy('users.id')
                        ->where('users.role', '=', 'agent')
                        ->select('users.id','users.user_name','users.first_name','users.last_name','users.profile_pic','users.email','users.role')
                        ->get();
              
               // dd($users);
                return $users;
            }

            //approver
            if ($method == 'approver') {
                $users = $query
                        ->where('users.role', '!=', 'user')
                        ->select('users.id','users.email as name','users.first_name','users.last_name','users.profile_pic','users.email','users.role')
                        ->get()->toArray();
                       
            $default = array('department manager', 'team lead','Department manager', 'Team lead');
            $term     = $request->input('term');
           
            $defaultarray = [];
            foreach ($default as $value) {
                if (preg_match('/^' . $term . '/', $value))
                    array_push($defaultarray, $value);
            }
            $url= " ";
            if((implode(',',$defaultarray)=="team lead")|| (implode(',',$defaultarray)=="Team lead")){
                $url= url('/').'/lb-faveo/media/images/team.jpg';
            }
            if((implode(',',$defaultarray)=="department manager") || (implode(',',$defaultarray)=="Department manager")){
                $url=  url('/').'/lb-faveo/media/images/department.jpg';
            }
            $extraArray[]=['id'=>str_slug(implode(',',$defaultarray), '_'),'name'=>'','first_name'=>implode(',',$defaultarray),'last_name'=>'','profile_pic'=>$url,'email'=>'','role'=>''];

            $extraArray= ($url == " ")? [] :$extraArray;
           return array_merge($users, $extraArray);
            }


            else {
                $users = $user->where('user_name', $term)
                        ->where('is_delete', '!=', 1)
                        ->select('id', 'user_name as name', 'first_name', 'last_name','role')
                        ->first();
                
                //dd($users);
                return $users;
            }
        }  
   }
    /**
     * get the authentcated user deatails in client page
     * @return json
     */
    public function authRequesterClient()
    {
        $user = NULL;
        if (\Auth::user()) {
            $user               = \Auth::user()->load(['org' => function($q) {
                    $q->select('id', 'org_id', 'user_id', 'role', 'org_department');
                }, 'org.orgDepartment' => function($q) {
                    $q->select('id', 'org_deptname', 'business_hours_id');
                }, 'org.organisation' => function($company) {
                $company->select('id', 'name as company');
            }]);
        }
        return $user;
    }
    /**
     * parse the form from json to array
     * @return array
     */
    public function ticketFormBuilder($form)
    {
        $json            = $this->getTicketFormJson($form, true);
        $array           = json_decode($json, true);
        $array_title_key = collect($array)->keyBy('unique')->toArray();
        $result          = $this->parseTicketFormArray($array_title_key);
        return $result;
    }
    
   
    /**
     * returns [ticket_id , key , content] from ticket_form_data table for editable custom_fields
     * @return array
     */ 
    
    public function ticketCustomFormBuilderType($form,$id)
     {

      $custom_form_data = \App\Model\helpdesk\Ticket\Ticket_Form_Data::where('ticket_id', $id)->select(['ticket_id', 'key', 'content'])->get();
        return $custom_form_data;
        
    }
    /**
     * get values in array after
     * @param array $array
     * @return array
     */
    public function parseTicketFormArray($array)
    {
        $result = [];
        foreach ($array as $key => $value) {
            $result[$key] = $this->parseParent($value, $key);
        }
        return $result;
    }
    /**
     * parse the parent field is it is a nested field
     * @param array $value
     * @param string $key
     * @param string $parent
     * @param string $child
     * @param string $option_value
     * @return array
     */
    public function parseParent($value, $key = "", $parent = "", $child = "", $option_value
    = "")
    {
        //dd($value);
        $agent       = checkArray('agentRequiredFormSubmit', $value);
        $client      = checkArray('customerRequiredFormSubmit', $value);
        $label       = checkArray('agentlabel', $value);
        $agent_label = "";
        if ($label && is_array($label)) {
            $agent_label = head($label)['label'];
        }
        if (is_string($label)) {
            $agent_label = $label;
        }
        $result['agent_label'] = $agent_label;
        $result['agent']       = $agent;
        $result['client']      = $client;
        $result['parent']      = $parent;
        $result['label']       = $child;
        $result['option']      = $option_value;
        $options               = checkArray('options', $value);
        if ($options && count($options) > 0) {
            $array = $this->parseOptions($options, $key);
            if (is_array($array)) {
                $result = array_merge($result, $array);
            }
        }
        return $result;
    }
    /**
     * 
     * @param array $options
     * @param string $parent
     * @return type
     */
    public function parseOptions($options, $parent = "")
    {
        $result = [];
        foreach ($options as $option) {
            $nodes        = checkArray('nodes', $option);
            $option_value = checkArray('optionvalue', $option);
            if ($nodes && checkArray('0', $nodes)) {
                foreach ($nodes as $node) {
                    $result['child'][$node['unique']] = $this->parseParent($node, $node['agentlabel'], $parent, $node['agentlabel'], $option_value);
                }
            }
        }
        return $result;
    }
    public function saveRequired($form = 'ticket')
    {
        \App\Model\Custom\Required::
                where('form', $form)
                ->delete();
        $array = $this->ticketFormBuilder($form);
        foreach ($array as $parent => $values) {
            $this->saveOptions($parent, $values, $form);
        }
    }
    public function saveOptions($key, $values, $form, $option = 'required', $parent_id
    = "")
    {
        $required     = [];
        $child        = checkArray('child', $values);
        $option_value = checkArray('option', $values);
        if (!is_string($option_value)) {
            $option_value = head($option_value)['option'];
        }
        $required['option'] = $option_value;
        if (checkArray('agent', $values)) {
            $required['agent'] = $option;
        }
        if (checkArray('client', $values)) {
            $required['client'] = $option;
        }
        if ($parent_id) {
            $required['parent'] = $parent_id;
        }
        if ($required) {

            if (!is_string($key)) {
                $key = head($key)['label'];
            }
            $required['field'] = $key;
            $required['form']  = $form;
            $required['label'] = checkArray('agent_label', $values);
            $required_model    = \App\Model\Custom\Required::updateOrCreate($required);
            if ($child) {
                $parent_field_name = $key;
                $this->saveChild($child, $parent_field_name, $required_model, $form);
            }
        }
    }
    public function saveChild($child, $parent_field_name, $model, $form, $option_value
    = "")
    {
        foreach ($child as $key => $values) {
            $option = "required_if:$parent_field_name";
            $this->saveOptions($key, $values, $form, $option, $model->id);
        }
    }
    public function captchaValidation($captcha = "")
    {

        $google_secret_key = \App\Model\helpdesk\Settings\commonSettings::where('option_name', '=', 'google secret key')->select('option_value')->first();

        if ($captcha && $google_secret_key) {
            $post_data = http_build_query(
                    array(
                        'secret'   => $google_secret_key->option_value,
                        'response' => $captcha,
                        'remoteip' => $_SERVER['REMOTE_ADDR']
                    )
            );
            $opts      = array('http' =>
                array(
                    'method'  => 'POST',
                    'header'  => 'Content-type: application/x-www-form-urlencoded',
                    'content' => $post_data
                )
            );

            $context  = stream_context_create($opts);
            $response = file_get_contents('https://www.google.com/recaptcha/api/siteverify', false, $context);
            $result   = json_decode($response);
            if (!$result->success) {
                return false;
            }
            else {
                return true;
            }
        }
        else {

            return false;
        }
    }
}
