<?php

namespace App\Model\kb;

use App\BaseModel;

class Footer4 extends BaseModel
{
    protected $table = 'footer4';
    protected $fillable = ['title', 'footer'];
}
