<?php

namespace App\Http\Requests\kb;

use App\Http\Requests\Request;

class CategoryRequest extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {

         if ($this->input('new_catagory') == 1) {
           // $id = $this->segment(2);
         
               return [
            'catagory_name'        => 'required|max:50|unique:kb_category,name',
            'catagory_description' => 'required|max:250',
            'display_order'      => 'required|unique:kb_category',
         
        ];

          }
          else{


        // $id = $this->segment(2);
        return [
            'name'        => 'required|max:50|unique:kb_category',
            'description' => 'required|max:250',
            'display_order'      => 'required|unique:kb_category',
         
        ];
         }
    }
}
