<?php

namespace App\Http\Controllers\Agent\helpdesk;

// controllers
use App\Http\Controllers\Controller;
// requests
use App\Http\Requests\helpdesk\OrganizationRequest;
/* include organization model */
use App\Http\Requests\helpdesk\OrganizationUpdate;
// models
/* Define OrganizationRequest to validate the create form */
use App\Model\helpdesk\Agent_panel\Organization;
use App\Model\helpdesk\Agent_panel\OrganizationDepartment;
use App\Model\helpdesk\Agent_panel\User_org;
/* Define OrganizationUpdate to validate the create form */
use App\User;
// classes
use Exception;
use Lang;
use Illuminate\Http\Request;
use Datatables;
use DB;

/**
 * OrganizationController
 * This controller is used to CRUD organization detail.
 *
 * @author      Ladybird <info@ladybirdweb.com>
 */
class OrganizationController extends Controller {

    protected $ticket_policy;

    /**
     * Create a new controller instance.
     * constructor to check
     * 1. authentication
     * 2. user roles
     * 3. roles must be agent.
     *
     * @return void
     */
    public function __construct() {
        // checking for authentication
        $this->middleware('auth');
        // checking if the role is agent
        $this->middleware('role.agent');
        $this->ticket_policy = new \App\Policies\TicketPolicy();
    }

    /**
     * Display a listing of the resource.
     *
     * @param type Organization $org
     *
     * @return type Response
     */
    public function index() {
        try {
            $table = \ Datatable::table()
                    ->addColumn(
                            Lang::get('lang.name'), Lang::get('lang.phone'), Lang::get('lang.action'))  // these are the column headings to be shown
                    ->noScript();
            /* get all values of table organization */
            return view('themes.default1.agent.helpdesk.organization.index', compact('table'));
        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }

    /**
     * This function is used to display the list of Organizations.
     *
     * @return datatable
     */
    public function org_list(Request $request) {
        // dd($request->all());
        $organization_list = \DB::table('organization')->select('name', 'website', 'phone', 'id');
        // chumper datable package call to display Advance datatable
        return Datatables::of($organization_list)
                        ->removeColumn('id', 'website')
                        ->editColumn('name', function($model) {
                            if (strlen($model->name) > 30) {

                                // return '<a href="'.route('organizations.show', $model->id).'" class="btn btn-primary btn-xs">'.mb_substr($model->name, 0, 30, 'UTF-8') . '...</a>';

                                return '<a  href="' . route('organizations.show', $model->id) . '" title="' . $model->name . '">' . mb_substr($model->name, 0, 30, 'UTF-8') . '...</a>';

                                // return '<p title="' . $model->name . '">' . mb_substr($model->name, 0, 30, 'UTF-8') . '...</p>';
                            } else {


                                return '<a  href="' . route('organizations.show', $model->id) . '" title="' . $model->name . '">' . $model->name . '</a>';


                                // return $model->name;
                            }
                        })
                        ->addColumn('action', function($model) {
                            return '<span  data-toggle="modal" data-target="#deletearticle' . $model->id . '"><a href="#" ><button class="btn btn-primary btn-xs"></a><i class="fa fa-trash" style="color:white;">&nbsp; </i> </i> ' . \Lang::get('lang.delete') . ' </button></span>&nbsp;&nbsp;'
                                    . '<a href="' . route('organizations.edit', $model->id) . '" class="btn btn-primary btn-xs"><i class="fa fa-edit" style="color:white;">&nbsp;&nbsp; </i>' . \Lang::get('lang.edit') . '</a>&nbsp;&nbsp;'
                                    . '<a href="' . route('organizations.show', $model->id) . '" class="btn btn-primary btn-xs"><i class="fa fa-eye" style="color:white;">&nbsp;&nbsp; </i>' . \Lang::get('lang.view') . '</a>
                <div class="modal fade" id="deletearticle' . $model->id . '">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                <h4 class="modal-title">' . Lang::get('lang.delete') . '</h4>
                            </div>
                            <div class="modal-body">
                                ' . Lang::get('lang.confirm-to-proceed') . '
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default pull-left" data-dismiss="modal" id="dismis2"><i class="fa fa-times" aria-hidden="true">&nbsp;&nbsp;</i>' . Lang::get('lang.close') . '</button>
                                <a href="' . route('org.delete', $model->id) . '"><button class="btn btn-danger"><i class="fa fa-trash" aria-hidden="true">&nbsp;&nbsp;</i>' . Lang::get('lang.delete') . '</button></a>
                            </div>
                        </div><!-- /.modal-content -->
                    </div><!-- /.modal-dialog -->
                </div>';
                        })
                        ->make();
    }

    /**
     * Show the form for creating a new organization.
     *
     * @return type Response
     */
    public function create() {
        try {
            return view('themes.default1.agent.helpdesk.organization.create');
        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }

    /**
     * Store a newly created organization in storage.
     *
     * @param type Organization        $org
     * @param type OrganizationRequest $request
     *
     * @return type Redirect
     */
    public function store(Organization $org, OrganizationRequest $request) {
        try {
            /* Insert the all input request to organization table */
            /* Check whether function success or not */
            // if ($org->fill($request->input())->save() == true) {
            //     /* redirect to Index page with Success Message */
            //     return redirect('organizations')->with('success', Lang::get('lang.organization_created_successfully'));
            // } else {
            //     /* redirect to Index page with Fails Message */
            //     return redirect('organizations')->with('fails', Lang::get('lang.organization_can_not_create'));
            // }
            // dd($request);
            $list_of_domains = $request->domain;
            if ($list_of_domains) {
                foreach ($list_of_domains as $list_of_domain) {
                    $querys = DB::table('organization')
                                    ->where('domain', '!=', "")
                                    ->whereRaw('FIND_IN_SET(?,domain)', [$list_of_domain])
                                    ->pluck('id as org_id')->toArray();

                    if ($querys) {
                        return redirect()->back()->with('fails', Lang::get('lang.domain_name_already_taken'));
                    }
                }
            }
            $orgss = new Organization();
            $orgss->name = $request->name;
            $orgss->phone = $request->phone;
            $orgss->website = $request->website;
            $orgss->address = $request->address;
            $orgss->internal_notes = $request->internal_notes;
            $list_of_domain_name = $request->domain;

            if ($list_of_domain_name) {
                $domain_name_string = implode(",", $list_of_domain_name);
                $orgss->domain = $domain_name_string;
            } else {
                $orgss->domain = "";
            }


            if ($request->client_Code) {


                $orgss->client_Code = $request->client_Code;
                $orgss->phone1 = $request->phone1;
                $orgss->line_of_business = $request->line_of_business;
                $orgss->relation_type = $request->relation_type;
                $orgss->branch = $request->branch;
                $orgss->fax = $request->fax;
            }
            $orgss->save();
            return redirect('organizations')->with('success', Lang::get('lang.organization_saved_successfully'));
        } catch (Exception $e) {
            /* redirect to Index page with Fails Message */
            return redirect('organizations')->with('fails', Lang::get('lang.organization_can_not_create'));
        }
    }

    /**
     * Display the specified organization.
     *
     * @param type              $id
     * @param type Organization $org
     *
     * @return type view
     */
    public function show($id, Organization $org) {
        try {
            /* select the field by id  */
            $orgs = $org->whereId($id)->first();
            $org_heads_check = User_org::where('org_id', '=', $id)->where('role', '!=', 'members')->select('user_id')->get();
            if (!$org_heads_check->isEmpty()) {

                $org_heads_ids = User_org::where('org_id', '=', $id)->where('role', '!=', 'members')->pluck('user_id')->toArray();
                foreach ($org_heads_ids as $org_heads_id) {
                    $org_heads_emails[] = user::where('id', '=', $org_heads_id)->pluck('id')->first();
                }
            } else {
                $org_heads_emails = 0;
            }

            $ticket_policy = $this->ticket_policy;
            $org_heads = User_org::where('org_id', '=', $id)->where('role', '!=', 'members')->select('user_id')->get();
            if (!$org_heads->isEmpty()) {

                foreach ($org_heads as $org_head) {

                    $userss[] = User::where('id', '=', $org_head->user_id)->select('id', 'email', 'user_name', 'phone_number', 'first_name', 'last_name')->first();
                }
            } else {
                $userss = 0;
            }
            $user = User::all();

            /* To view page */
            return view('themes.default1.agent.helpdesk.organization.show', compact('user', 'orgs', 'userss', 'org_heads_emails', 'ticket_policy'));
        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }

    /**
     * Show the form for editing the specified organization.
     *
     * @param type              $id
     * @param type Organization $org
     *
     * @return type view
     */
    public function edit($id, Organization $org) {
        try {
            /* select the field by id  */
            $orgs = $org->whereId($id)->first();
            if ($orgs->domain) {
                $selected_domain_name = explode(",", $orgs->domain);
            } else {
                $selected_domain_name = " ";
            }
            // dd($selected_domain_name);
            // dd($orgs->phone);
            /* To view page */
            return view('themes.default1.agent.helpdesk.organization.edit', compact('orgs', 'selected_domain_name'));
        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }

    /**
     * Update the specified organization in storage.
     *
     * @param type                    $id
     * @param type Organization       $org
     * @param type OrganizationUpdate $request
     *
     * @return type Redirect
     */
    public function update($id, Organization $org, OrganizationUpdate $request) {
        try {
            /* select the field by id  */
            // $orgs = $org->whereId($id)->first();
            // /* update the organization table   */
            // /* Check whether function success or not */
            // if ($orgs->fill($request->input())->save() == true) {
            //     /* redirect to Index page with Success Message */
            //     return redirect('organizations')->with('success', Lang::get('lang.organization_updated_successfully'));
            // } else {
            //     /* redirect to Index page with Fails Message */
            //     return redirect('organizations')->with('fails', Lang::get('lang.organization_can_not_update'));
            // }
            $list_of_domains = $request->domain;
            if ($list_of_domains) {
                foreach ($list_of_domains as $list_of_domain) {
                    $querys = DB::table('organization')
                                    ->where('id', '!=', $id)
                                    ->where('domain', '!=', "")
                                    ->whereRaw('FIND_IN_SET(?,domain)', [$list_of_domain])
                                    ->pluck('id as org_id')->toArray();

                    if ($querys) {
                        return redirect()->back()->with('fails', Lang::get('lang.domain_name_already_taken'));
                    }
                }
            }
            $orgss = $org->whereId($id)->first();
            $orgss->name = $request->name;
            $orgss->phone = $request->phone;
            $orgss->website = $request->website;
            $orgss->address = $request->address;
            $orgss->internal_notes = $request->internal_notes;
            $list_of_domain_name = $request->domain;
            if ($list_of_domain_name) {
                $domain_name_string = implode(",", $list_of_domain_name);
                $orgss->domain = $domain_name_string;
            } else {

                $orgss->domain = "";
            }

            if ($request->client_Code) {
                $orgss->client_Code = $request->client_Code;
                $orgss->phone1 = $request->phone1;
                $orgss->line_of_business = $request->line_of_business;
                $orgss->relation_type = $request->relation_type;
                $orgss->branch = $request->branch;
                $orgss->fax = $request->fax;
            }
            $orgss->save();
            // $emailDomainOnly = preg_replace('/.+@/', '', $all_user->email);
            // dd($all_user);
            return redirect('organizations')->with('success', Lang::get('lang.organization_updated_successfully'));
        } catch (Exception $e) {
            //            dd($e);
            /* redirect to Index page with Fails Message */
            return redirect('organizations')->with('fails', $e->getMessage());
        }
    }

    /**
     * Delete a specified organization from storage.
     *
     * @param type int $id
     *
     * @return type Redirect
     */
    public function destroy($id, Organization $org, User_org $user_org) {
        try {
            /* select the field by id  */
            $orgs = $org->whereId($id)->first();
            $user_orgs = $user_org->where('org_id', '=', $id)->get();
            foreach ($user_orgs as $user_org) {
                $user_org->delete();
            }
            /* Delete the field selected from the table */
            /* Check whether function success or not */
            $orgs->delete();
            /* redirect to Index page with Success Message */
            return redirect('organizations')->with('success', Lang::get('lang.organization_deleted_successfully'));
        } catch (Exception $e) {
            /* redirect to Index page with Fails Message */
            return redirect('organizations')->with('fails', $e->getMessage());
        }
    }

    public function getHrdname(Request $request, $org_id) {
        try {
            $term = trim($request->q);
            if (empty($term)) {
                return \Response::json([]);
            }

            $orgs = Organization::select('id', 'domain')->where('id', '=', $org_id)->first();
            $user_orga_relations = \App\Model\helpdesk\Agent_panel\User_org::where('org_id', '=', $orgs->id)->pluck('user_id')->toArray();
            $users = $user_orga_relations;
            if ($orgs['domain'] != '') {
                $str = str_replace(",", '|@', '@' . $orgs['domain']);
                $domain_users = \App\User::select('id')->where('role', '=', 'user')->whereRaw("email REGEXP '" . $str . "'")->whereNOtIn('id', $users);
                $domain_users = $domain_users->where('is_delete', '!=', 1)->where('ban', '!=', 1)->get()->toArray();
                if (count($domain_users) > 0) {
                    $users = array_merge($users, array_column($domain_users, 'id'));
                }
            }

            $org_user = \App\User::wherein('id', $users)->where('email', 'LIKE', '%' . $term . '%')->select('email', 'id')->get();
            $formatted_tags = [];
            foreach ($org_user as $org) {
                $formatted_orgs[] = ['id' => $org->id, 'text' => $org->email];
            }
            return \Response::json($formatted_orgs);
        } catch (\Exception $e) {
            // returns if try fails with exception meaagse
            return \Response::json([]);
        }
    }

    public function Head_Org(Request $request) {

        $org_manager_user_id = $request->user;
        // dd($emails);
        if (!$org_manager_user_id) {
            return redirect()->back()->with('fails1', Lang::get('lang.please_select_manager'));
        }

        $update = User_org::where('org_id', '=', $request->org_id)->update(array('role' => 'members'));
        foreach ($org_manager_user_id as $userid) {
            $check_org_belongs_to = User_org::where('org_id', '=', $request->org_id)->where('user_id', '=', $userid)->where('role', '=', 'members')->first();


            if (!$check_org_belongs_to) {
                $org_head = new User_org();
                $org_head->org_id = $request->org_id;
                $org_head->user_id = $userid;
                $org_head->role = 'manager';
                $org_head->save();
            } else {

                $org_head = User_org::where('org_id', '=', $request->org_id)->where('user_id', '=', $userid)->where('role', '=', 'members')->first();

                $org_head->role = 'manager';
                $org_head->save();
            }
        }

        // route('organizations.show', $model->id)
        return redirect()->back()->with('success1', Lang::get('lang.organization_updated_successfully'));
    }

    public function EditHead_Org(Request $request) {



        $org_manager_user_id = $request->user;
        // dd($emails);
        if (!$org_manager_user_id) {
            $reir_org = User_org::where('org_id', '=', $request->org_id)->update(array('role' => 'members'));

            return redirect()->back()->with('success1', Lang::get('lang.organization_updated_successfully'));
        }

        $update = User_org::where('org_id', '=', $request->org_id)->update(array('role' => 'members'));
        foreach ($org_manager_user_id as $userid) {
            $check_org_belongs_to = User_org::where('org_id', '=', $request->org_id)->where('user_id', '=', $userid)->where('role', '=', 'members')->first();

            if (!$check_org_belongs_to) {
                $org_head = new User_org();
                $org_head->org_id = $request->org_id;
                $org_head->user_id = $userid;
                $org_head->role = 'manager';
                $org_head->save();
            } else {

                $org_head = User_org::where('org_id', '=', $request->org_id)->where('user_id', '=', $userid)->where('role', '=', 'members')->first();

                $org_head->role = 'manager';
                $org_head->save();
            }
        }

        // route('organizations.show', $model->id)
        return redirect()->back()->with('success1', Lang::get('lang.organization_updated_successfully'));
    }

    /**
     * Display the specified organization.
     *
     * @param type              $id
     * @param type Organization $org
     *
     * @return type view
     */
    public function HeadDelete(Request $request) {
        try {
            $user_id = $request->user_id;
            $org_head = User_org::where('org_id', '=', $orgs_id)->where('user_id', '=', $user_id)->delete();
            // return redirect('themes.default1.agent.helpdesk.organization.show')->with('success', Lang::get('lang.organization_maneger_delete_successfully'));
            return 'maneger successfully delete';
        } catch (Exception $e) {
            return redirect()->back()->with('fails', $e->getMessage());
        }
    }

    /**
     * get the report of organizations.
     *
     * @param type $id
     * @param type $date111
     * @param type $date122
     *
     * @return type array
     */
    public function orgChartData($id, $date111 = '', $date122 = '') {

// $a = array($id);
// $result = array_reduce($a,array());
// dd($result);
//         dd(explode(",",$id));
        $date11 = strtotime($date122);
        $date12 = strtotime($date111);
        if ($date11 && $date12) {
            $date2 = $date12;
            $date1 = $date11;
        } else {
            // generating current date
            $date2 = strtotime(date('Y-m-d'));
            $date3 = date('Y-m-d');
            $format = 'Y-m-d';
            // generating a date range of 1 month
            $date1 = strtotime(date($format, strtotime('-1 month' . $date3)));
        }
        $return = '';
        $last = '';
        for ($i = $date1; $i <= $date2; $i = $i + 86400) {
            $thisDate = date('Y-m-d', $i);

            $user_orga_relation_id = '';

            $user_orga_relations = User_org::where('org_id', '=', $id)->pluck('user_id')->ToArray();


            if ($user_orga_relations) {


                foreach ($user_orga_relations as $user_orga_relation) {
                    $user_orga_relation_id[] = $user_orga_relation;
                }
                $created = \DB::table('tickets')->select('created_at')->whereIn('user_id', $user_orga_relation_id)->where('created_at', 'LIKE', '%' . $thisDate . '%')->count();
                $closed = \DB::table('tickets')->select('closed_at')->whereIn('user_id', $user_orga_relation_id)->where('closed_at', 'LIKE', '%' . $thisDate . '%')->count();
                $reopened = \DB::table('tickets')->select('reopened_at')->whereIn('user_id', $user_orga_relation_id)->where('reopened_at', 'LIKE', '%' . $thisDate . '%')->count();
            } else {
                $created = 0;
                $closed = 0;
                $reopened = 0;
            }
            $value = ['date' => $thisDate, 'open' => $created, 'closed' => $closed, 'reopened' => $reopened];
            $array = array_map('htmlentities', $value);
            $json = html_entity_decode(json_encode($array));
            $return .= $json . ',';
        }
        $last = rtrim($return, ',');
        $users = User::whereId($id)->first();

        return '[' . $last . ']';
    }

    public function getOrgAjax(Request $request) {
        $org = new Organization();
        $q = $request->input('term');
        $orgs = $org->where('name', 'LIKE', '%' . $q . '%')
                ->select('name as label', 'id as value')
                ->get()
                ->toJson();
        return $orgs;
    }

    /**
     * This function is used autofill organizations name .
     *
     * @return datatable
     */
    public function organizationAutofill() {
        return view('themes.default1.agent.helpdesk.organization.getautocomplete');
    }

    public function createOrgApi(OrganizationRequest $request) {
        try {

            $list_of_domains = $request->domain;

            if ($list_of_domains) {

                foreach ($list_of_domains as $list_of_domain) {
                    $querys = DB::table('organization')
                                    ->where('domain', '!=', "")
                                    ->whereRaw('FIND_IN_SET(?,domain)', [$list_of_domain])
                                    ->pluck('id as org_id')->toArray();

                    if ($querys) {
                        $fail = Lang::get('lang.domain_name_already_taken');
                        return response()->json(['message1' => $fail], 500);
                        return redirect()->back()->with('fails', Lang::get('lang.domain_name_already_taken'));
                    }
                }
            }


            $domain = $request->domain;
            if ($domain) {
                $domain_name = implode(",", $domain);
            } else {
                $domain_name = " ";
            }

            $default = ['name', 'phone', 'website', 'address', 'head', 'internal_notes', 'domain', 'department'];
            $extra = $request->except($default);
            $org = new Organization();
            $org->name = $request->name;
            $org->phone = $request->phone;
            $org->address = $request->address;
            $org->head = $request->head;
            $org->internal_notes = $request->internal_notes;
            $org->save();
            $organization = Organization::where('id', '=', $org->id)->first();
            $organization->domain = $domain_name;

            $organization->save();

            $department = $request->department;
            if ($department) {
                $department_names = $request->department;
                foreach ($department_names as $department_name) {
                    $org_dept = new OrganizationDepartment();
                    $org_dept->org_id = $organization->id;
                    $org_dept->org_deptname = $department_name;
                    $org_dept->business_hours_id = null;
                    $org_dept->save();
                }
            } else {
                $department_name = " ";
            }

            if (count($extra) > 0) {

                foreach ($extra as $key => $value) {
                    $org->extraField()->create([
                        'key' => $key,
                        'value' => $value
                    ]);
                }
            }

            // $model = $org->create($request->input());
            // if (count($extra) > 0) {
            //     foreach ($extra as $key => $value) {
            //         $model->extraField()->create([
            //             'key' => $key,
            //             'value' => $value
            //         ]);
            //     }
            // }
            return response()->json(['message' => Lang::get('lang.organization_saved_successfully')]);
        } catch (\Exception $e) {
            dd($e);
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    public function editOrgApi($id) {
        $org = Organization::
                with(['extraField' => function($q) {
                $q->select('value', 'key', 'org_id')->pluck('value', 'key')->toArray();
            }])
                ->whereId($id)
                ->first();


        if ($org->extraField) {
            $org->extraField->transform(function($value) {
                return [$value->key => $value->value];
            });
        }


        if ($org->domain) {
            $org_domains = explode(",", $org->domain);
        } else {
            $org_domains = "";
        }
        $org_dept = OrganizationDepartment::where('org_id', '=', $id)->pluck('org_deptname')->toArray();


        $response = ['organization_details' => $org->toArray(), 'org_dept' => $org_dept, 'org_domain' => $org_domains];
        return response()->json($response);

        return $org;
    }

    public function updateOrgApi($id, OrganizationUpdate $request) {
        try {
            // $default = ['name', 'phone', 'website', 'address', 'head', 'internal_notes'];
            // $extra   = $request->except($default);
            // $org     = Organization::find($id);
            // $org->fill($request->input());
            $list_of_domains = $request->domain;

            if ($list_of_domains) {

                foreach ($list_of_domains as $list_of_domain) {
                    $querys = DB::table('organization')
                                    ->where('id', '!=', $id)
                                    ->where('domain', '!=', "")
                                    ->whereRaw('FIND_IN_SET(?,domain)', [$list_of_domain])
                                    ->pluck('id')->toArray();

                    if ($querys) {
                        $fail = Lang::get('lang.domain_name_already_taken');
                        return response()->json(['message' => $fail], 500);
                    }
                }
            }


            $domain = $request->domain;
            if ($domain) {
                $domain_name = implode(",", $domain);
            } else {
                $domain_name = " ";
            }



            $default = ['name', 'phone', 'website', 'address', 'head', 'internal_notes', 'domain', 'department'];
            $extra = $request->except($default);
            $org = Organization::where('id', '=', $id)->first();
            $org->name = $request->name;
            $org->phone = $request->phone;
            $org->address = $request->address;
            $org->head = $request->head;
            $org->internal_notes = $request->internal_notes;
            $org->save();
            $organization = Organization::where('id', '=', $org->id)->first();
            $organization->domain = $domain_name;
            $organization->save();

            // $del_org_dept=OrganizationDepartment::where('org_id','=',$organization->id)->delete();
            $department = $request->department;
            if ($department) {
                $department_names = $request->department;

                $organization_dept_ids = \DB::table('organization_dept')->whereIn('org_deptname', $request->department)->pluck('id');
                $delete = OrganizationDepartment::select('id')->whereNotIn('id', $organization_dept_ids)->where('org_id', '=', $organization->id)->delete();

                foreach ($department_names as $department_name) {
                    $org_dept = OrganizationDepartment::updateOrCreate(['org_deptname' => $department_name, 'org_id' => $organization->id]);
                    // $org_dept_check=OrganizationDepartment();
                    // $org_dept=new OrganizationDepartment();
                    //         $org_dept->org_id=$organization->id;
                    //         $org_dept->org_deptname=$department_name;
                    //         $org_dept->business_hours_id=null;
                    //         $org_dept->save();
                }
            } else {
                $department_name = " ";
            }


            // $model = $org->create($request->input());


            if (count($extra) > 0) {
                // dd($extra);
                $org->extraField()->where('org_id', '=', $id)->delete();
                foreach ($extra as $key => $value) {

                    $org->extraField()->Create([
                        'key' => $key,
                        'value' => $value
                    ]);
                }
            }


            // if (count($extra) > 0) {
            //  $org->extraField()->where('org_id','=',$id)->delete();
            //     foreach ($extra as $key => $value) {
            //        $org->extraField()->Create(['org_id' => $id], [
            //             'key' => $key,
            //             'value' => $value
            //         ]);
            //     }
            // }
            return response()->json(['message' => Lang::get('lang.organization_updated_successfully')]);
        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    /**
     * 
     * @param type $id
     * @param \Illuminate\Http\Request $request
     */
    public function changeDept($id, Request $request) { {

            $dept_id = $request->dept_id;
            $new_dept = $request->change_org_dept;

            $update = OrganizationDepartment::where('org_id', '=', $id)->where('id', '=', $dept_id)->first();
            $update->org_deptname = $new_dept;
            $update->save();
            if ($request->business_hour) {
                $update_business_hours = OrganizationDepartment::where('id', '=', $update->id)->first();
                $update_business_hours->business_hours_id = $request->business_hour;
                $update_business_hours->save();
            }
            return redirect()->back()->with('success1', Lang::get('lang.updated_successfully'));
        }
    }

}
