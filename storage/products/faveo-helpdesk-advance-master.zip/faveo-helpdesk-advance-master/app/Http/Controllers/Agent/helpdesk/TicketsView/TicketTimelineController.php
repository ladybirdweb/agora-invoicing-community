<?php
namespace App\Http\Controllers\Agent\helpdesk\TicketsView;

use Lang;
use App\Model\helpdesk\Ticket\Ticket_Thread as TicketThread;
use App\Model\helpdesk\Ticket\Tickets;
use App\Http\Controllers\Agent\helpdesk\TicketsView\TicketsCategoryController;
use Illuminate\Http\Request;
use App\Model\helpdesk\Settings\Plugin;
use DB;
use Illuminate\Database\Eloquent\Builder as QueryBuilder;
use App\User;
use App\Model\helpdesk\Agent\Teams;
use Crypt;

/**
 * handles ticket timeline data, mainly ticket specific details and ticket threads
 * @author avinash kumar <avinash.kumar@ladybirdweb.com>
 */
class TicketTimelineController extends TicketsCategoryController
{

    /**
     * Gets ticket specific details of the passed ticketId
     * @param integer $ticketId       Id of the required ticket
     * @return array                  Ticket with passed ticketId if success else failure response
     */
    public function ticketDetails($ticketId)
    {
        //query for allowed ticket by logged in user
        $allowedTicketQuery = $this->allTicketsQuery();

        //building baseQuery for the ticket
        $baseQuery = $allowedTicketQuery->where('id', $ticketId)->select('id', 'ticket_number', 'user_id', 'dept_id', 'team_id', 'priority_id', 'sla'
            , 'help_topic_id', 'assigned_to', 'source', 'isanswered', 'status', 'type', 'created_at', 'updated_at', 'duedate');
        $ticket = $this->getForiegnKeyDataForTicket($baseQuery);

        if (!$ticket) {
            return errorResponse(Lang::get('lang.no-ticket-found'));
        }
        $tickets = Tickets::where('id',$ticketId)->select('assigned_to','team_id')->first();
        $assgnAgent = ($tickets->assigned_to) ? User::where('id',$tickets->assigned_to)->first() :null;
        $assgnTeam = ($tickets->team_id) ? Teams::where('id',$tickets->team_id)->value('name') :'Unassigned';
        $displayName = ($assgnAgent) ? $assgnAgent->fullName : $assgnTeam;



        $formattedTicket = $this->formatTicket($ticket)->toArray();

        unset($ticket['due'], $ticket['created'], $ticket['updated']);
        $formattedTicket['assigned'] = $displayName;

        return successResponse('', ['ticket' => $formattedTicket]);
    }

    /**
     * gets count for tasks
     * @param integer $ticketId  
     * @return integer|null           null if calender plugin is off else integer count og tasks for current ticket
     */
    private function taskCount($ticketId)
    {
        $calender = Plugin::where('name', 'Calendar')->where('status', 1)->first();
        if ($calender) {
            return DB::table('tasks')->where('ticket_id', $ticketId)->count();
        }
        return null;
    }

    /**
     * Gets foriegn key data for ticket. (this method is ticketDetails specific and should not be used by other methods.)
     * @param object $ticketQuery     BaseQuery for the ticket.
     * @return array                  Data for after querying all the foriegn keys from DB
     */
    private function getForiegnKeyDataForTicket($ticketQuery)
    {
        $ticketQuery = $ticketQuery->with(['statuses:id,name', 'types:id,name', 'priority:priority_id,priority as name,priority_color', 'departments:id,name',
            'slaPlan:id,name', 'departments:id,name', 'sources:id,name', 'user:id,first_name,last_name,user_name,email',
            'assignedTeam:id,name', 'helptopic:id,topic as name',
            'assigned:id,first_name',
            'firstThread:id,ticket_id,title',
            'lastThread' => function($q) {
                $q->select('ticket_id', 'user_id')->with('user:id,first_name,last_name,user_name');
            },
            'collaborator' => function($q) {
                $q->select('id', 'ticket_id', 'user_id')->with('userBelongs:id,first_name,last_name,user_name,email');
            }]);

        $ticketQuery = $this->customFieldQueryForTicket($ticketQuery);

        return $ticketQuery->first();
    }

    /**
     * Formats the passed ticket by removing paramters that are not reuired in the final response
     * @param object $ticket          Ticket data
     * @return array                  Formats and returns the formatted ticket
     */
    private function formatTicket($ticket)
    {

        $ticket['title'] = utfEncoding($ticket['firstThread']['title']);
        $ticket['last_replier'] = $ticket['lastThread']['user'];

        $this->formatCollaborators($ticket);

        $ticket['source'] = $ticket['sources'];

        unset($ticket['user_id'], $ticket['user_id'], $ticket['team_id'], $ticket['dept_id'], $ticket['priority_id'], $ticket['sla'], $ticket['type']
            , $ticket['help_topic_id'], $ticket['assigned_to'], $ticket['firstThread'], $ticket['lastThread'], $ticket['sources']);

        $ticket['status'] = $ticket['statuses'];
        $ticket['type'] = $ticket['types'];
        $ticket['priority']['id'] = $ticket['priority']['priority_id'];
        $ticket['task_count'] = $this->taskCount($ticket['id']);

        $ticket['is_overdue'] = Tickets::isOverdue($ticket['duedate']);
        $ticket['due_today'] = Tickets::isDueToday($ticket['duedate'], agentTimeZone());

        unset($ticket['statuses'], $ticket['types'], $ticket['priority']['priority_id']);

        //formatting custom fields
        $this->formatCustomFields($ticket);

        return $ticket;
    }

    /**
     * formats collaborators in ticket and unsets unncessary fields
     * @param Tickets &$ticket    $ticket with collaborators
     * @return null
     */
    private function formatCollaborators(Tickets &$ticket)
    {
        $collaborators = [];

        foreach ($ticket['collaborator'] as $collaborator) {
            $collaborator['userBelongs']['collaborator_id'] = $collaborator['id'];
            array_push($collaborators, $collaborator['userBelongs']);
        }

        $ticket['collaborators'] = $collaborators;

        unset($ticket['collaborator']);
    }

    /**
     * formats custom field by removing custom field entries where label is null(uses pass by reference)
     * @param Tickets &$ticket  ticket pass by reference
     * @return null
     */
    private function formatCustomFields(Tickets &$ticket)
    {
        foreach ($ticket->formdata as $key => $formData) {
            if (!$formData->label) {
                unset($ticket->formdata[$key]);
                continue;
            }
            unset($formData['ticket_id']);
        }
    }

    private function getTagsAndLabels()
    {
        //will be handled after the release
    }

    /**
     * Appends custom form field query to the passed query
     * @param  QueryBuilder $ticketQuery  base query for ticket
     * @return QueryBuilder               query after appending custom
     */
    private function customFieldQueryForTicket(QueryBuilder $ticketQuery)
    {
//        return $ticketQuery;
        return $ticketQuery->with('formdata:id,key,ticket_id,content');
    }

    /**
     * Returns all the threads of ticketId passed
     * @param integer $ticketId     Id of the asked ticket
     * @param object $request     
     * @return array                Threads if success else failure response   
     */
    public function ticketThreads($ticketId, Request $request)
    {

        $allowedTickets = $this->allTicketsQuery();
        $limit = $request->input('limit') ? $request->input('limit') : 10;

        //checking ticket in user's ticket access domain
        $ticket = $allowedTickets->where('id', $ticketId)->select('id', 'dept_id', 'created_at')->first();


        //if ticket is not found in user's access domain
        if (!$ticket) {
            return errorResponse(Lang::get('lang.no-ticket-found'));
        }

        //relationship is one to one but relation
        $department = $ticket->department->name;

        $threadData = TicketThread::where('ticket_id', $ticketId)
                ->select('id', 'user_id', 'title', 'body', 'thread_type', 'created_at', 'is_internal')
                ->with('attach')
                ->with('user:id,first_name,last_name,email,user_name,role,profile_pic')
                ->with(['ratings.ratingType' => function($q) use ($department) {
                        $q->select('id', 'name', 'rating_scale')->where('rating_area', 'Comment Area')
                        ->where(function($q2) use ($department) {
                                $q2->where('restrict', $department)->orWhere('restrict', "");
                            });
                    }])->orderBy('id', 'DESC')
                ->paginate($limit)->toArray();
        //toArray is required to format pagination, else can't handle

        $threadData['threads'] = $threadData['data'];

        //appending ticket's created at time to the threadData object
        $threadData['ticket_created_at'] = $ticket['created_at']->format('Y-m-d h:i:s');

        $threadData['threads'] = $this->getIconDetailsForThreadCreator($threadData['threads']);

        unset($threadData['data'], $threadData['first_page_url'], $threadData['last_page_url'], $threadData['next_page_url'], $threadData['prev_page_url'], $threadData['path']);

        return successResponse('', $threadData);
    }

    /**
     * gets name based on the passed userData.
     * @param object|array $userData        User data with information regarding his first_name, last_name and user_name OR (null or emptyarray)
     *                                      if null is given name will be returned as 'System'
     * @return string                       Name
     */
    private function getName($userData)
    {
        if (!$userData || !count($userData)) {
            return 'System';
        } else {
            $name = $userData['first_name'] ? $userData['first_name'] . ' ' . $userData['last_name'] : $userData['user_name'];
            return $name;
        }
    }

    /**
     * Appends icon details to ticket threads based on the person( 'user','agent/admin' or null (is_internal) ) who created it.
     * NOTE: It is made only because front-end asked for. It serves no special purpose and should not be re-used
     * @param $threads    Ticket with threads
     * @return
     */
    private function getIconDetailsForThreadCreator($threads)
    {
        $formattedThread = [];
        foreach ($threads as $thread) {
            $user = $thread['user'];
            unset($thread['user'], $thread['user_id']);

            $thread['user'] = [];
            $thread['user']['name'] = $this->getName($user);

            //gets rating details in formatted form
            $thread['ratings'] = $this->formatRatings($thread['ratings']);

            if ($thread['is_internal']) {
                $thread['icon_class'] = $user ? (
                    ($thread['thread_type'] == 'note') ? 'fa fa-comment bg-gray' : 'fa fa-history bg-gray'
                    ) : 'fa fa-tag bg-gray';
                $thread['posted_by'] = ($thread['thread_type'] == 'note') ? 'Agent' : 'System';
                $thread['user']['profile_pic'] = $user ? $user['profile_pic'] : assetLink("image","system");
                $thread['user']['id'] = null;
            } else {
                $thread['icon_class'] = ($user['role'] == 'user') ? 'fa fa-comment bg-aqua' : 'fa fa-comments-o bg-yellow';
                $thread['posted_by'] = ($user['role'] == 'user') ? 'Customer' : 'Agent';
                $thread['user']['id'] = $user['id'];
                $thread['user']['profile_pic'] = $user['profile_pic'];
            }
            array_push($formattedThread, $thread);
        }
        return $formattedThread;
    }

    /**
     * formats ratings and remove ratings value if rating_type is found as null (in non-departmental case)
     * @param object $ratings       ratings array
     * @return formatted ratings array
     */
    private function formatRatings($ratings)
    {
        $ratingArray = [];
        foreach ($ratings as $rating) {
            $ratingObject = [];
            //only include fields if rating_type is not null (will be null in case )
            if ($rating['rating_type']) {
                $ratingObject['name'] = $rating['rating_type']['name'];
                $ratingObject['value'] = $rating['rating_value'];
                $ratingObject['scale'] = $rating['rating_type']['rating_scale'];
                array_push($ratingArray, $ratingObject);
            }
        }
        return $ratingArray;
    }

    /**
     * made for vue frontend to work with user-data
     * NOTE: must be deleted once login functionality is implemented in vue
     * @return Response     Success with user data if logged in else failure
     */
    public function getLoggedInUserInfo()
    {
        $user = \Auth::user();
        $user['timezone'] = Timezone::where('id', $user->agent_tzone)->first()->name;

        //date-format
        $user['date_format'] = dateformat();

        return successResponse('', $user);
    }

    /**
     * Gets attachment as image or downloaded file
     * @param integer $id   id of the attachment
     * @return file
     */
    public function getAttachment($id)
    {
        // decrypt id, if invalid decryption then abort 
        try{
            $id = Crypt::decrypt($id);
        
            $attachment = \App\Model\helpdesk\Ticket\Ticket_attachments::where('id', '=', $id)->first();
            if (mime($attachment->type) == true && $attachment->type != 'application/octet-stream') {
                echo "<img src=data:$attachment->type;base64," . $attachment->file . ">";
            } else {

                $file = ($attachment->driver == 'database') ? base64_decode($attachment->file) :
                file_get_contents($attachment->path . DIRECTORY_SEPARATOR . $attachment->name);

                return response($file)
                    ->header('Cache-Control', 'no-cache private')
                    ->header('Content-Description', 'File Transfer')
                    ->header('Content-Type', $attachment->type)
                    ->header('Content-length', strlen($file))
                    ->header('Content-Disposition', 'attachment; filename=' . $attachment->name)
                    ->header('Content-Transfer-Encoding', 'binary');
            }
        } catch (\Exception $e){
            return errorResponse(Lang::get('lang.file_not_found'));
        }
    }
}
