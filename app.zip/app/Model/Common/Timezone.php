<?php

namespace App\Model\Common;

use Illuminate\Database\Eloquent\Model;
use App\BaseModel;
class Timezone extends BaseModel
{
    protected $table = 'timezone';
}
