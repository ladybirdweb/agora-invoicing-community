<?php
namespace App\Http\Controllers\Agent\helpdesk\TicketsView;

use App\Http\Controllers\Controller;
use App\Model\helpdesk\Ticket\Tickets;
use Illuminate\Http\Request;
use App\Policies\TicketPolicy;
use App\Model\helpdesk\Settings\Plugin;
use App\Model\helpdesk\Settings\CommonSettings;
use Lang;
use DB;
use Config;
use Cache;
use Auth;
use App\Model\helpdesk\Workflow\ApprovalWorkflowTicket;
use App\Model\helpdesk\Manage\UserType;

/**
 * Handles all the actions or action-related data for a user, while handling a ticket
 * @author avinash kumar <avinash.kumar@ladybirdweb.com>
 */
class TicketsActionOptionsController extends Controller
{

    /**
     * Request from the API call will be assigned to this property
     * @var Request
     */
    private $request;

    public function __construct(Request $request)
    {
        $this->request = $request;
        $this->middleware(['auth', 'role.agent']);
    }

    /**
     * gets subject of mergable tickets
     * @return array    array of mergable tickets subject or error response
     */
    public function getSubjectOfTicketsToBeMerged()
    {
        //if recieves a single ticket-id
        $ticketId = $this->request->input('ticket-id');

        //if recieves array
        $ticketIds = $this->request->input('ticket-ids');
        if ($ticketId) {
            return $this->getMergeableTicketsByTicketId($ticketId);
        }

        if ($ticketIds) {
            return $this->getMergeableTicketsByTicketIds($ticketIds);
        }

        return errorResponse(Lang::get('lang.fails'));
    }

    /**
     * finds mergable tickets based on the given ticket Id.
     * @param integer $ticketId     ticket id
     * @return Response             success response with tickets data if success else error response
     */
    private function getMergeableTicketsByTicketId($ticketId)
    {
        //first get userId of ticket
        $ticket = Tickets::where('id', $ticketId)->select('user_id', 'status')->first();
        $userId = $ticket->user_id;
        $statusId = $ticket->statuses()->first()->type()->first()->name;

        $tickets = Tickets::with(['firstThread' => function($q) {
                        $q->select('ticket_id', 'title');
                    }])->where('user_id', $userId)
                ->whereIn('status', getStatusArray($statusId))->select('id')->get();

        $ticketsCount = $tickets->count();
        if ($ticketsCount == 1) {
            return errorResponse(Lang::get('lang.no_mergeable_tickets_found'));
        }

        $formattedTickets = [];
        foreach ($tickets as $ticket) {
            array_push($formattedTickets, $this->formatTicketNoAndFirstThread($ticket->id));
        }
        return successResponse('', $formattedTickets);
    }

    /**
     * Checks if the given ticket Ids are mergable or not. If they are, it gives back the data related to those tickets
     *
     * @param array $ticketIds      array of ticketIds which are supposed to be merged.
     * @return Response             success response with tickets data if success else error response
     */
    private function getMergeableTicketsByTicketIds($ticketIds)
    {
        $ticketsCountInRequest = count($ticketIds);
        $firstTicketId = $ticketIds[0]; //getting first ticketId
        $firstTicket = Tickets::where('id', $firstTicketId)->select('user_id', 'status')->first();
        $userId = $firstTicket->user_id;
        $statusId = $firstTicket->statuses()->first()->type()->first()->name;
        $tickets = Tickets::with(['firstThread' => function($q) {
                        $q->select('ticket_id', 'title');
                    }])->whereIn('id', $ticketIds)
                ->whereIn('status', getStatusArray($statusId))
                ->get();

        $ticketsCountInDB = $tickets->count();
        $ticketsCount = $tickets->count();
        if ($ticketsCount == 1) {
            return errorResponse(Lang::get('lang.no_mergeable_tickets_found'));
        }
        $formattedTickets = [];
        foreach ($tickets as $ticket) {
            array_push($formattedTickets, $this->formatTicketNoAndFirstThread($ticket->id));
        }
        return successResponse('', $formattedTickets);
    }
    /**
     * Format ticket response
     *
     * @param string $ticketId 
     * @return Response             
     */
    private function formatTicketNoAndFirstThread(string $ticketId){

      $tickets = Tickets::where('id',$ticketId)->get();
      
        foreach ($tickets as $ticket) {
          $response = "#".$ticket->ticket_number.'('.$ticket['firstThread']->title.')';
          $formattedTickets = (['ticket_id'=>$ticketId,'title'=>$response]);
        }
      return $formattedTickets;
    }

    /**
     * Gets list of actions as allowed(true) or not-allowed(false) for logged in user. for eg. if the logged in user is allowed to change status
     * @return Response array       success response with array of permissions
     */
    public function getActionList(Request $request)
    {
        $ticketId = $request->ticket_id;
        $ticketPolicy = new TicketPolicy();
        //check if calander plugin is activated
        $calender = Plugin::where('name', 'Calendar')->where('status', 1)->first();
        $hasCalanderActivated = $calender ? true : false;

        $allowedActions = [
            'assign' => $ticketPolicy->assign(),
            'transfer' => $ticketPolicy->transfer(),
            'edit' => $ticketPolicy->edit(),
            'reassign' => $ticketPolicy->reAssigningTickets(),
            'change_duedate' => $ticketPolicy->changeDuedate(),
            'ban' => $ticketPolicy->ban(),
            'has_calender' => $hasCalanderActivated,
            'time_track' => isTimeTrack(),

            'allowed_enforce_approval_workflow'=> $this->isEnforceApprovalWorkflowAllowed($ticketId),
            'allowed_approval_action'=> $this->isApprovalActionAllowed($ticketId),
            'view_approval_progress'=> $this->isApprovalProgressVisible($ticketId),
            'block_ticket_actions'=> $this->shallBlockAllTicketActions($ticketId),
        ];

        return successResponse('', ['actions' => $allowedActions]);
    }

    private function shallBlockAllTicketActions($ticketId)
    {
      $wasApprovalEnforced = ApprovalWorkflowTicket::where('ticket_id', $ticketId)
          ->where('status','PENDING')->count();
      return ($wasApprovalEnforced && Auth::user()->role != 'admin');
    }

    /**
     * If enforcing approval workflow is allowed
     * NOTE: this method is seperate because there are some future enhancements(permissions) that has to be
     * built in PHASE-2
     * @param  int $ticketId
     * @return boolean
     */
    private function isEnforceApprovalWorkflowAllowed($ticketId)
    {
      $isApprovalWorkflowAllowed = ApprovalWorkflowTicket::where('ticket_id', $ticketId)
          ->where('status','PENDING')->count();

      return (!$isApprovalWorkflowAllowed && (new TicketPolicy)->applyApprovalWorkflow());
    }

    /**
     * If approving/denying a ticket is allowed
     * NOTE: this method is seperate because there are some future enhancements(permissions) that has to be
     * built in PHASE-2
     * @param  int $ticketId
     * @return boolean
     */
    private function isApprovalActionAllowed($ticketId)
    {
      //will be only allowed if there is a workflow for the ticket and user role `admin`
      // if the user is there in the list of action takers in current level, (check team lead and department manager also)
      $userId = Auth::user()->id;
      $ticket = Tickets::select('id','dept_id','team_id')->where('id', $ticketId)->first();
      $approvalWorflowForTicket = ApprovalWorkflowTicket::where('ticket_id', $ticketId)
          ->where('status','PENDING')->first();

      if(!$approvalWorflowForTicket){
        return false;
      }

      $activelevelForTicket = $approvalWorflowForTicket->approvalLevels()->where('is_active', 1)->first();

      if(!$activelevelForTicket){
        return false;
      }

      $approverStatuses = $activelevelForTicket->approverStatuses()->where('status','PENDING')->get();
      //check if user is in the list as user
      if(isDepartmentManager($ticket, $userId)){
        $userTypeId = UserType::where('name','department_manager')->first()->id;
        return (bool)$approverStatuses->where('approver_id',$userTypeId)
          ->where('approver_type','App\Model\helpdesk\Manage\UserType')->count();
      }

      if(isTeamLead($ticket, $userId)){
        $userTypeId = UserType::where('name','team_lead')->first()->id;
        return (bool)$approverStatuses->where('approver_id',$userTypeId)
          ->where('approver_type','App\Model\helpdesk\Manage\UserType')->count();
      }

      return (bool)$approverStatuses->where('approver_id',$userId)
        ->where('approver_type','App\User')->count();
    }

    /**
     * If approval prgress should be visible
     * NOTE: this method is seperate because there are some future enhancements(permissions) that has to be
     * built in PHASE-2
     * @param  int  $ticketId
     * @return boolean
     */
    private function isApprovalProgressVisible($ticketId)
    {
      //will be only allowed if there is a workflow for the ticket
      return (bool)ApprovalWorkflowTicket::where('ticket_id', $ticketId)->count();
    }

    /**
     * Delete all selected tickets and related data from database forever
     * @param Request $request  request object
     * @return Response         success response with message if success else error response
     */
    public function deleteTicketsAndRelatedDataFromDB(Request $request)
    {
        if ($request->filled('ticket-ids')) {
            if (!is_array($request->get('ticket-ids')) || count($request->get('ticket-ids')) == 0) {
                return errorResponse('incorrect input format');
            }
            $tickets = Tickets::whereIn('id', $request->get('ticket-ids'));
            if ($tickets->count() == 0) {
                return errorResponse(Lang::get('lang.not_found'));
            }
            $tickets->each(function($ticket) {
                $ticket->delete(); //Elequent event is handling deletion of related models
            });
            return successResponse(Lang::get('lang.hard-delete-success-message'));
        }
        return errorResponse(Lang::get('lang.select-ticket'));
    }

    /**
     * gets ticket related setting data
     * @return Response       contains ticket settings data
     */
    public function ticketSettings()
    {
        $headerClass = DB::table('system_portal')->select('agent_header_color')->first()->agent_header_color;

        //tickets table bar color
        $tableBarColor = Config::get("theme.header-color.$headerClass");

        //tickets per page
        $ticketsPerPage = (Cache::has('ticket_per_page')) ? Cache::get('ticket_per_page') : 10;

        // Time track additional features
        $settings = (new CommonSettings)->getStatus('time_track_option');

        $timeTrack = empty($settings) ? 0 : $settings;

        return successResponse('', ['table_bar_color' => $tableBarColor, 'ticket_per_page' => $ticketsPerPage, 'time_track' => $timeTrack]);
    }
}
