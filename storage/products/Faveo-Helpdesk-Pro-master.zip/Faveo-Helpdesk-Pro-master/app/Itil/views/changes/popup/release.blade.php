<?php
$sd_release_status = \App\Itil\Models\Releases\SdReleasestatus::pluck('name', 'id')->toArray();
$sd_release_priorities = \App\Itil\Models\Releases\SdReleasepriorities::pluck('name', 'id')->toArray();
$sd_release_types = App\Itil\Models\Releases\SdReleasetypes::pluck('name', 'id')->toArray();
$sd_locations = App\Itil\Models\Releases\SdLocations::pluck('title', 'id')->toArray();
if(isAsset()==true){
    $assets = \App\Itil\Models\Assets\SdAssets::pluck('name', 'id')->toArray();
}
?>
<div class="modal fade" id="releasenew{{$change->id}}">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Release</h4>
                {!! Form::open(['url'=>'service-desk/changes/release/'.$change->id,'method'=>'post','files'=>true]) !!}
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="form-group col-md-6 {{ $errors->has('subject') ? 'has-error' : '' }}">
                        <label for="Subject" class="control-label">{{Lang::get('itil::lang.subject')}}</label><span class="text-red"> *</span>
                        {!! Form::text('subject',null,['class'=>'form-control','required'=>'required']) !!}
                        <!--<input type="text" name="subject" class="form-control" id="" placeholder="Subject....">-->

                    </div>
                    <div class="form-group col-md-6 {{ $errors->has('plan_start_date') ? 'has-error' : '' }}">

                        <label for="inputEmail3" class="control-label">{{Lang::get('itil::lang.planed_start_date')}}</label>
                        {!! Form::text('planned_start_date',null,['class'=>'form-control','id'=>'plan_start_date']) !!}
                        <!--<input type="text" name="plan_start_date" class="form-control" id="startdate" placeholder="Startdate">-->
                    </div>
                    <div class="form-group col-md-6 {{ $errors->has('plan_end_date') ? 'has-error' : '' }}">
                        <label for="inputEmail3" class="control-label">{{Lang::get('itil::lang.planed_end_date')}}</label>
                        {!! Form::text('planned_end_date',null,['class'=>'form-control','id'=>'plan_end_date']) !!}
                        <!--<input type="text"  name="plan_end_date" class="form-control" id="enddate" placeholder="Enddate">-->
                    </div>
                    <div class="form-group col-md-6 {{ $errors->has('status') ? 'has-error' : '' }}">
                        <label class=" control-label">{{Lang::get('itil::lang.status')}}</label>
                        {!! Form::select('status_id',$sd_release_status,null,['class'=>'form-control']) !!}

                    </div>
                    <div class="form-group col-md-6 {{ $errors->has('priority') ? 'has-error' : '' }}">
                        <label class=" control-label">{{Lang::get('itil::lang.priority')}}</label>
                        {!! Form::select('priority_id',$sd_release_priorities,null,['class'=>'form-control']) !!}

                    </div>
                    <div class="form-group col-md-6 {{ $errors->has('releasetype') ? 'has-error' : '' }}">
                        <label class=" control-label">{{Lang::get('itil::lang.type')}}</label>
                        {!! Form::select('release_type_id',$sd_release_types,null,['class'=>'form-control']) !!}

                    </div>
                    
                     <?php
                $location = App\Location\Models\Location::all(); //for dropdown showing all location
                ?>
                    
                    <div class="form-group col-md-6 {{ $errors->has('location') ? 'has-error' : '' }}">
                        <label class="control-label">{{Lang::get('itil::lang.location')}}</label>
                        {!! Form::select('location_id', [Lang::get('lang.location')=>$location->pluck('title','id')->toArray()],$change->location_id,['class'=>'form-control']) !!}

                    </div>
                    @if(isAsset()==true)
                    <div class="form-group col-md-6 {{ $errors->has('asset') ? 'has-error' : '' }}">
                        <label for="inputEmail3" class="control-label">{{Lang::get('itil::lang.assets')}}</label>
                        {!! Form::select('asset[]',$assets,null,['class'=>'form-control','multiple'=>true]) !!}
                        <!--<input type="text" name="build_plan" class="form-control" placeholder="Build plan" id="provider-json">-->
                    </div>
                    @endif
                    <div class="form-group col-md-12 {{ $errors->has('description') ? 'has-error' : '' }}">
                        <label for="description" class="control-label">{{Lang::get('itil::lang.description')}}</label><span class="text-red"> *</span>
                        {!! Form::textarea('description',null,['class'=>'form-control','required'=>'required']) !!}
                        <!--<textarea class="form-control textarea" name="description" placeholder="Description....."  id="description"></textarea>-->
                    </div>
                    

                    <div class="form-group col-md-6 {{ $errors->has('attachments') ? 'has-error' : '' }}">
                        <label for="inputEmail3" class="control-label">{{Lang::get('itil::lang.attachment')}}{{Lang::get('lang.maximum_upload_file_size_is_2MB')}}</label>
                        {!! Form::file('attachments[]',['multiple'=>true,'class'=>'file-data']) !!}
                        <!--<input type="text" name="build_plan" class="form-control" placeholder="Build plan" id="provider-json">-->
                    </div>

                </div>
            </div>
            <div class="modal-footer">
                <button type="button" id="close" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <input type="submit" class="btn btn-primary" value="{{Lang::get('lang.save')}}">
                {!! Form::close() !!}
            </div>
            <!-- /Form -->
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<script type="text/javascript">
 $(".box-primary").on('change',".file-data", function(){
  
            if(this.files[0].size > 2048*1024){
                $(this).parent().find(".file-error").empty()
                $(this).parent().append("<p class='file-error' style='color:red'>cannot upload files more than 2 MB</p>")
                $(this).val('');
            }
        else{
            $(this).parent().find(".file-error").empty()
        }
   });
 </script>