<template>
    <span class="log-mail-status" :id="'mail-status-' + data.id" :class="['badge', badgeClass]">
      {{lang(data.status).toUpperCase()}}
    </span>
</template>

<script type="text/javascript">

	import axios from "axios";

	export default {

		name:"mail-status",

		description: "status of the mail",

		props: {
			data : { type : Object, required : true }
		},

		data(){
			return {
				showModal:false,
			}
		},

    computed : {
      badgeClass(){
        switch(this.data.status){

          case "sent":
            return "btn-success";

          case "accepted":
            return "btn-success";

          case "queued":
            return "btn-warning";

          case "rejected":
            return "btn-danger";

          case "failed":
            return "btn-danger";

          default:
            return "btn-primary";
        }
      }
    }

	};

</script>

<style type="text/css">
  .log-mail-status{
    min-width : 65px;
  }
</style>
