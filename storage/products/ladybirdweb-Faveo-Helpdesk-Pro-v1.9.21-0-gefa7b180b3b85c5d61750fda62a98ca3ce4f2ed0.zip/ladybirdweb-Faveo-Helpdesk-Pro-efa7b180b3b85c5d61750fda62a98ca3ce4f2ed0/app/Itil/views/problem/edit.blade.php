@extends('themes.default1.agent.layout.agent')
@section('content')

<section class="content-heading-anchor">
    <h2>
        {{Lang::get('itil::lang.edit_problem')}} 
    </h2>

</section>


<!-- Main content -->
{!! Form::model($problem,['url'=>'service-desk/problem/'.$problem->id,'method'=>'patch','files'=>true,'id'=>'Form']) !!}
<div class="box box-primary">
    <div class="box-header with-border">
        <h4> 
            {{str_limit($problem->subject,20)}}  
            <a href="{{url('service-desk/problem/'.$problem->id.'/show')}}" class="btn btn-default">{{Lang::get('itil::lang.show')}}</a>
        </h4>
        @if (count($errors) > 0)
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
        @endif
<div class="alert alert-success alert-dismissable" style="display: none;">
    <i class="fa  fa-check-circle"></i>
    <span class="success-msg"></span>
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    
</div>
        @if(Session::has('success'))
        <div class="alert alert-success alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            {{Session::get('success')}}
        </div>
        @endif
        <!-- fail message -->
        @if(Session::has('fails'))
        <div class="alert alert-danger alert-dismissable">
            <i class="fa fa-ban"></i>
            <b>{{Lang::get('message.alert')}}!</b> {{Lang::get('message.failed')}}.
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            {{Session::get('fails')}}
        </div>
        @endif
        
    </div><!-- /.box-header -->
    <!-- form start -->

    <!--<form action="{!!URL::route('service-desk.problem.postcreate')!!}"  method="post" role="form">-->
    <div class="box-body">

        <div class="row">
            <!--<div class="col-md-6">-->

            <div class="form-group col-md-6 {{ $errors->has('subject') ? 'has-error' : '' }} ">
                <label class="control-label">{{Lang::get('itil::lang.subject')}}</label><span class="text-red"> *</span>
                {!! Form::text('subject',null,['class'=>'form-control']) !!}
                <!--<input type="text" class="form-control" name="subject" id="inputPassword3" value="From">-->
            </div>

            <div class="form-group col-md-6 {{ $errors->has('from') ? 'has-error' : '' }}">
                <label for="inputPassword3" class="control-label">{{Lang::get('itil::lang.from')}}</label><span class="text-red"> *</span>
                {!! Form::select('from',$from,null,['class'=>'form-control','placeholder'=>'Email address']) !!}
                <!--<input type="text" class="form-control" name="from" id="inputPassword3" value="From">-->
            </div>

            <div class="form-group col-md-6 {{ $errors->has('department') ? 'has-error' : '' }}">
                <label class="control-label">{{Lang::get('itil::lang.department')}}</label>
                {!! Form::select('department',$departments,null,['class'=>'form-control']) !!}
                <!--<input type="text" class="form-control" name="department" id="inputPassword3" value="Department">-->

            </div> 

            <div class="form-group col-md-6 {{ $errors->has('impact_id') ? 'has-error' : '' }}">
                <label class="control-label">{{Lang::get('itil::lang.impact')}}</label>
                {!! Form::select('impact_id',$impact_ids,null,['class'=>'form-control']) !!}
            </div>

            <div class="form-group col-md-6 {{ $errors->has('status_type_id') ? 'has-error' : '' }}">
                <label class="control-label">{{Lang::get('itil::lang.status')}}</label>
                {!! Form::select('status_type_id',$status_type_ids,null,['class'=>'form-control']) !!}
            </div>
           <!--  <div class="form-group col-md-6 {{ $errors->has('location_type_id') ? 'has-error' : '' }}">
                <label class="control-label">{{Lang::get('itil::lang.location_type_id')}}</label>
                {!! Form::select('location_type_id',$location_type_ids,null,['class'=>'form-control']) !!}
            </div> -->
                  <div class="form-group col-md-6 {{ $errors->has('location_type_id') ? 'has-error' : '' }}">
               
                 <?php
          $location=App\Location\Models\Location::all();//for dropdown showing all location
          ?>

                {!! Form::label('location',Lang::get('lang.location')) !!} <span class="text-red"> *</span>
                {!! Form::select('location_type_id', [Lang::get('lang.location')=>$location->pluck('title','id')->toArray()],$problem->location_type_id,['class' => 'form-control select']) !!}
            </div>
            <div class="form-group col-md-6 {{ $errors->has('priority_id') ? 'has-error' : '' }}">
                <label class="control-label">{{Lang::get('itil::lang.priority')}}</label>
                {!! Form::select('priority_id',$priority_ids,null,['class'=>'form-control']) !!}
            </div>

            {{--<div class="form-group col-md-6 {{ $errors->has('group') ? 'has-error' : '' }}">
                <label class="control-label">{{Lang::get('itil::lang.select_group')}}</label>
                {!! Form::select('group',$group_ids,null,['class'=>'form-control']) !!}
            </div>--}}


            <div class="form-group col-md-6{{ $errors->has('assigned') ? 'has-error' : '' }}">
                <label class="control-label">{{Lang::get('itil::lang.assigned-to')}}</label>
                {!! Form::select('assigned_id',$assigned_ids,null,['class'=>'form-control']) !!}
            </div>

            @if(isAsset()==true)
            <div class="form-group col-md-6{{ $errors->has('assets') ? 'has-error' : '' }}">
                <label class="control-label">{{Lang::get('itil::lang.attach-asset')}}</label>
                {!! Form::select('asset',null,['class'=>'form-control']) !!}
            </div>
            @endif

            <div class="form-group col-md-12 {{ $errors->has('description') ? 'has-error' : '' }}">
                <label for="internal_notes" class="control-label">{{Lang::get('itil::lang.description')}}</label><span class="text-red"> *</span>
                {!! Form::textarea('description',null,['class'=>'form-control','id'=>'ckeditor']) !!}
                <!--<textarea class="form-control textarea" placeholder="Description" name="description" rows="7" id="" style="width: 97%; margin-left:14px;"></textarea>-->
            </div>
 
     <?php

        $attachment =DB::table('sd_attachments')->where('owner', '=','sd_problem:'.$problem->id)->first();

         if(isset($attachment))
                $value = $attachment->value;
            if ($attachment) {
                $value = $attachment->value;
            } else {
                $value = "";
            }

     ?>
             
      <div class="form-group col-md-6{{ $errors->has('attachment') ? 'has-error' : '' }}">
                <label class="control-label">{{Lang::get('itil::lang.attachment')}}{{Lang::get('lang.maximum_upload_file_size_is_2MB')}}</label>
                {!! Form::file('attachment[]',['class'=>'file-data']) !!}
  @if   (isset($attachment))
        <div class="alert alert-dismissable row">
            <div class="col-md-6 col-sm-6 col-xs-6" style='width:200px;padding:0px !important'>
                <a href="{{url('service-desk/download/'.$attachment->id.'/'.$attachment->owner.'/attachment')}}">
                    <span class="mailbox-attachment-icon" style="background-color:#fff;text-align:left:width:200px;padding:0px" >
                        <img style="max-width:150px;height:133px;object-fit:contain;" src="{{url('service-desk/download/'.$attachment->id.'/'.$attachment->owner.'/attachment')}}">
                    </span>
                    <div class="mailbox-attachment-info" style='width:150px;padding:0px !important;margin-left: 25px;'>
                        <span style="color: green;"">
                            <b style="word-wrap: break-word;">{!!$attachment->value!!}</b>
                            <br/>
                            <p>{{\App\Itil\Controllers\UtilityController::getAttachmentSize($attachment->size)}}</p>
                        </span>

                    </div>
                </a>
            </div>
            <div class="col-md-4 col-sm-4 col-xs-4 pull-left" style='width:200px;padding-left:0px !important'>
                <button type="button" class="close pull-left" data-dismiss="alert" aria-hidden="true" style="color:red;"> <i class="fa fa-trash"></i></button>
                <input type="hidden" name="uploadfile" id="uploadfile" value="{!! $value!!}">           
           </div>
        </div>
@endif


            </div>

        </div>   
        <!--</div>-->
        <!--/row-->
    </div>
    <div class="box box-footer">   {!!Form::button('<i class="fa fa-refresh" aria-hidden="true">&nbsp;&nbsp;</i>'.Lang::get('itil::lang.update'),['type' => 'submit', 'class' =>'btn btn-primary','id'=>'submit'])!!}
<!--        {!! Form::submit(Lang::get('itil::lang.edit_problem'),['class'=>'btn btn-success']) !!}-->
<!--       <button type="submit" id="submit" class="btn btn-primary" data-loading-text="<i class='fa fa-refresh fa-spin fa-1x fa-fw'>&nbsp;</i> updating..."><i class="fa fa-refresh">&nbsp;&nbsp;</i>{!!Lang::get('itil::lang.update')!!}</button>   -->
        {!! Form::close() !!}
    </div>
</div><!--submit button-->
<script>
            $('#Form').submit(function () {
        var btn = $('#submit');
        btn[0].innerHTML = "<i class='fa fa-refresh fa-spin fa-1x fa-fw'></i>Updating...";
        $('#submit').attr('disabled','disabled');
    });
     $('#submit').attr('disabled','disabled');
    $('#Form').on('input',function(){
        $('#submit').removeAttr('disabled');
    });
    $('#Form').on('change',':input',function(){
        $('#submit').removeAttr('disabled');
    });
 </script>

<!-- team lead -->


<script type="text/javascript">
    $(document).ready(function() {
        $('.fa-trash').click(function(){                  
            var currentValue = $('#uploadfile').val();
            $.ajax({
            type: 'post',
            url: '{{route("uploadfile.problem.delete",$problem->id)}}',
            data: {
                "_token": "{{ csrf_token() }}",
                filename: currentValue
            
            },
         
            success: function (result) {
              
                $('.success-msg').html(result);
                $('.alert-success').css('display', 'block');
                setInterval(function(){
                    $('.alert-success').slideUp( 4000, function() {});
                }, 500);
                location.reload();
            }
        });
        });         
    });
</script>

@stop
