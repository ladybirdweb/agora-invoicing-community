<?php

return [
    /*
      |----------------------------------------------------------------------------------------
      | General Pages [English(en)]
      |----------------------------------------------------------------------------------------
      |
      | The following language lines are used in all general issues to translate
      | some words in view to English. You are free to change them to anything you want to
      | customize your views to better match your application.
      |
     */
    /**
     * common
     */
     'helptopic_type'=>'Helptopic type',
     'helptopic_type_linking'=>'Helptopic type linking',
     'helptopic_and_type_linking'=>'Helptopic and type linking',
    'edit'=>'Edit',
    'save' => 'save',
      'if_enabled_on_the_ticket_create_edit_page_only_those_type_will_show_which_are_linked_to_selected_helptopic_if_none_linked_all_ticket_type_will_show'=>"If enabled on the ticket create/edit page,only those type will show which are linked to selected helptopic,if none linked,all ticket type will show",
    
   
    
];
