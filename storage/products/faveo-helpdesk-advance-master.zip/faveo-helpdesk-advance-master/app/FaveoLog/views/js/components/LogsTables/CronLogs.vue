<template>
	
	<div>

		<div class="box-container">
						
			<div class="box-header with-border with-switch">
						
				<h3 for="cron logs" id="cron_logs_title" class="box-title">{{lang('cron_logs')}}</h3>
						
			</div>

			<div class="box-body">

				<div class="row">
						
					<date-time-field id="cron_date" :label="lang('start_time_date_range')" 
						:value="cron_created_date" 
						type="datetime" 
						:time-picker-options="timeOptions"
						name="cron_created_date" 
						:required="false"
						:onChange="onChange" range 
						:currentYearDate="false" 
						format="YYYY-MM-DD HH:mm:ss" classname="col-xs-6" 
						:clearable="true" :disabled="false" :confirm="true" >
					</date-time-field>
				</div>

				<div class="row">

					<logs-table v-if="!options.length"
						:category_ids="category_ids" 
						:created_at_start="created_at_start" 
						:created_at_end="created_at_end" 
						:cron_start_time_start="cron_start_time_start"
						:cron_start_time_end="cron_start_time_end"
						:columns="columns" :options="options" :apiUrl="apiUrl" id="cron_logs_title">
					</logs-table>
				</div>
			</div>						
		</div>
	</div>
</template>

<script>

	import axios from 'axios';

	import moment from 'moment'

	import { mapGetters } from 'vuex'
	
	export default {

		props : {

			category_ids : { type : Array, default : ()=>[] },

			created_at_start : { type : String, default : '' },

			created_at_end : { type : String, default : '' },
		},

		data() {

			return {

				columns : [],

				options : {},

				apiUrl : '/api/logs/cron' ,

				columns: ['category', 'message', 'start_time', 'created_at'],

				options : {},

				cron_created_date : {},

				cron_start_time_start : '',

				cron_start_time_end : '',

				timeOptions:{
						start: '00:00',
						step: '00:30',
						end: '23:30'
				},

				moment : moment
			}
		},

		beforeMount(){
			const self = this;
			this.options = {

				headings: { 

					category: 'Category', 

					start_time: 'Start time', 

					message: 'Message',

					created_at: 'Created At/End time'
				},

				columnsClasses : { 

					message : 'cron-log-message',

					created_at : 'cron-created'
				},

				texts: { filter: '', limit: '' },

				templates: {

					category(h,row){

						return row.category.name
					},

					start_time(h, row) {
						
						return self.formattedTime(row.start_time)
					},

					end_time(h, row) {
						
						return self.formattedTime(row.end_time)
					},

					created_at(h, row) {
						
						return self.formattedTime(row.created_at)
					},

				},

				sortable:  ['category', 'start_time', 'end_time', 'message', 'created_at'],

				filterable:  ['category', 'start_time', 'end_time', 'message', 'created_at'],
				
				pagination:{chunk:5,nav: 'fixed',edge:true},

				requestAdapter(data) {

					return {
					
						sort_field: data.orderBy,
					
						sort_order: data.ascending ? 'desc' : 'asc',
					
						search_query:data.query,
					
						page:data.page,
					
						limit:data.limit,

					}
				},
				responseAdapter({data}) {
					return {
						
						data: data.data.data,

						count: data.data.total
					
					}
				},
			}
		},

		computed:{
			...mapGetters(['formattedTime','formattedDate'])
		},

		methods : {

			onChange(value,name){

				this[name] = value

				this.cron_start_time_start = value[0] !== null ? moment(value[0]).format('YYYY-MM-DD+HH:mm:ss') : '';;
				
				this.cron_start_time_end = value[1] !== null ? moment(value[1]).format('YYYY-MM-DD+HH:mm:ss') : '';;
			}
		},

		components : {

			'date-time-field': require('components/MiniComponent/FormField/DateTimePicker'),

			'logs-table': require('./ReusableComponent/LogsTable.vue')
		}
	};
</script>

<style>
	.cron-log-message{
		width:30% !important;
		word-break: break-all;
	}

	.cron-created{
		width:25% !important;
		word-break: break-all;
	}

</style>