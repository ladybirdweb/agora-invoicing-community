<?php

namespace App\FaveoLog\controllers;

use App\FaveoLog\Model\MailLog;
use App\FaveoLog\Model\CronLog;
use App\FaveoLog\Model\LogCategory;
use App\FaveoLog\Model\ExceptionLog;
use App\Model\helpdesk\Ticket\Tickets;
use Config;
use App\User;

/**
 * Handles all write related operations while logging
 * NOTE: while passing any category, please make sure that this category exists in LogSeeder.php
 * @author avinash kumar <avinash.kumar@ladybirdweb.com>
 */
class LogWriteController
{

  /**
   * Logs cron related data
   * @param  string $startTime time when cron was initiated
   * @param  string $endTime   time at which cron was ended
   * @param  string $category  cron category
   * @param  string $message   any extra message that is needed to be passed
   * @return null
   */
  public function cron($startTime, $endTime, $category = 'default', $message = '')
  {
    //query into category table
    $category = LogCategory::where('name',$category)->first();
    return $category->cron()->create(['start_time'=>$startTime, 'end_time'=>$endTime, 'message'=>$message]);
  }

  /**
   * Logs exception along with trace
   * @param Exception|object $e exception
   * @param string $category  category to which it belongs
   * @return null
   */
  public function exception($e, $category ='default')
  {
    $category = LogCategory::where('name',$category)->first();

    return $category->exception()->create([
      'message'=>$e->getMessage(), 'file'=>$e->getFile(), 'line'=>$e->getLine(),
      'trace'=> nl2br($e->getTraceAsString())
    ]);
  }

  /**
   * Logs fetched mail
   * @param array $mail   associative array of email with keys : 'from','subject','body','referee_id'
   * @param string $fetcherEmail  emailId from which mail has been fetched
   * @return null
   */
  public function fetchedMail($mail, $fetcherEmail)
  {
      // category will be mail-fetch
      // message id from email_thread table, from where ticketId can be obtained. It will be null in case where
      // ticket is not created
      $category = LogCategory::where('name','mail-fetch')->first();

      // in case of fetched mail we need the email from whom it was fetched
      return $category->mail()->create([
        // need email from which it was fetched
        'sender_mail'=> $mail['from'], 'reciever_mail'=> $fetcherEmail, 'subject'=> $mail['subject'],
        'body'=>$mail['body'],'referee_type'=>'mail', 'source'=>'mail', 'referee_id'=> $mail['message_id'],
      ]);
  }

  /**
   * Logs mail related data
   * @param  string $senderMail   the person from whom mail is getting sent
   * @param  string $recieverMail the person to whom mail is getting sent
   * @param  string $subject      subject of the mail
   * @param  string $body         body of the mail
   * @param  string $refereeId    id of the referee. For eg. if a user gets created, it will be user_id
   *                              if a ticket gets created, it will be ticket_id
   * @param  string $refereeType 'user' or 'ticket'
   * @param  string $source       source can be the place from which action has been initiated.
   *                              for eg. if a user is created via mail, source will be mail,
   *                              if agent-panel then agent-panel
   *                              if client-panel then client-panel
   *                              if same goes for tickets too.
   *                              One exception is ticket recur
   * @return null
   */
  public function sentMail($senderMail, $recieverMail, $subject, $body, $refereeId, $refereeType, $categoryName = '', $status='',$source="default" )
  {
     // sender, reciever, body, messageId,
     // referee_id/type Ticket/User
     // $categoryType can be user or ticket
     // $categoryId can be
     $categoryName = $categoryName ? $categoryName : 'default';
     $category = LogCategory::where('name', $categoryName)->first();

     return $category->mail()->create([
       'sender_mail'=> $senderMail,'reciever_mail'=> $recieverMail,'subject'=> $subject,
       'body'=> $body, 'referee_id'=> $refereeId, 'referee_type'=> $refereeType, 'status' => $status, 'source'=>$source
     ]);
  }


  /**
   * Logs mail by category by detecting if it is a mail sent for ticket
   * @param  string $from     the email from which mail is getting sent
   * @param  string $to       the email to which mail is getting sent
   * @param  string $subject  Subject of the mail
   * @param  string $body     body of the mail
   * @param  Ticket_thread|string $thread   thread of the ticket
   * @param  string $templateVariables  it can be used to extract information regarding the mail and update in the mail
   * @return null
   */
  public function logMailByCategory($from, $to, $subject, $body, $templateVariables, $templateType = '')
  {
    $refereeId = '';
    $refereeType = '';

    if(!$templateVariables){
      $refereeType = 'diagnostics';
    }

    else {
      if(is_array($templateVariables)){
          if(array_key_exists('ticket_number', $templateVariables)){
            $this->updateRefereeDetailsForTicket($refereeId, $refereeType, $templateVariables);
          }

          elseif(array_key_exists('new_user_email', $templateVariables)){
            $this->updateRefereeDetailsForUser($refereeId, $refereeType, $templateVariables);
          }
      }
    }

    $category = $this->getLogCategoryByTemplateType($templateType);

    return $this->sentMail($from, $to, $subject, $body, $refereeId, $refereeType, $category, 'queued');
  }

  /**
   * Updates sent mail log
   * @param  string $logIdentifier  id of the log
   * @return null
   */
  public function updateSentMailLog($logIdentifier, $status)
  {
    MailLog::find($logIdentifier)->update(['status' => $status]);
  }

  /**
   * updates refereeId and refereeeType for ticket
   * @param  string $refereeId
   * @param  string $refereeType
   * @return null
   */
  private function updateRefereeDetailsForTicket(&$refereeId, &$refereeType, $templateVariables)
  {
    $ticketNumber = $templateVariables['ticket_number'];
    $ticketId = Tickets::where('ticket_number', $templateVariables['ticket_number'])->value('id');
    $ticketUrl = Config::get('app.url').'/thread'."/".$ticketId;
    $refereeId = "<a href=".$ticketUrl." target=_blank>" . $ticketNumber . "</a>";
    if(!$ticketId){
        $refereeId = 'invalid_ticket_number';
    }
    $refereeType = 'ticket';
  }

  /**
   * updates refereeId and refereeeType based for user
   * @param  string $refereeId
   * @param  string $refereeType
   * @return null
   */
  private function updateRefereeDetailsForUser(&$refereeId, &$refereeType, $templateVariables)
  {
    $userEmail = $templateVariables['new_user_email'];
    $userId = User::where('email', $userEmail)->value('id');

    // if user id is not null then only this should happen
    $userUrl = Config::get('app.url').'/user'."/".$userId;
    $refereeId = "<a href=".$userUrl." target=_blank>" . $userEmail . "</a>";

    if(!$userId){
      $refereeId = 'invalid_user';
    }
    $refereeType = 'user';
  }

  /**
   * gets ticket category by ticket scenarios
   * @param string $scenario
   * @return string
   */
  private function getLogCategoryByTemplateType($scenario) : string
  {
    $categoriesForTemplates = require(app_path().DIRECTORY_SEPARATOR.'FaveoLog'.DIRECTORY_SEPARATOR
        .'config'.DIRECTORY_SEPARATOR.'templateCategory.php');

    if(array_key_exists($scenario, $categoriesForTemplates)){
        return $categoriesForTemplates[$scenario];
    }

    return 'default';
  }
}
