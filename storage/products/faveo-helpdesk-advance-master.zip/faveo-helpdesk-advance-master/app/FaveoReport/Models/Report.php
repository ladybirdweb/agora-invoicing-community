<?php

namespace App\FaveoReport\Models;

use Illuminate\Database\Eloquent\Model;

class Report extends Model
{
    protected $fillable = ['file', 'ext', 'type', 'hash', 'expired_at', 'user_id', 'is_completed'];

    /**
     * Relation with \App\User
     */
    public function user()
    {
        return $this->belongsTo(\App\User::class);
    }
}
