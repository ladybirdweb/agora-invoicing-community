<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;

class RecurCommand extends Command
{

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'ticket:recur';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Execute ticket recurring command';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }
    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        if (isInstall()) {
            try {
                $this->ticketRecurController()->recur();
                loging('recurring-ticket', 'recurring done at ' . \Carbon\Carbon::now()->tz(timezone()) . '. timezone is  ' . timezone());
            } catch (\Exception $exception) {
                loging('recurring-ticket', $exception->getMessage() . ' Line=>' . $exception->getLine() . " File=>" . $exception->getFile());
            }
        }
    }
    public function ticketRecurController()
    {
        $recur = new \App\Http\Controllers\Admin\helpdesk\TicketRecurController();
        return $recur;
    }
}
