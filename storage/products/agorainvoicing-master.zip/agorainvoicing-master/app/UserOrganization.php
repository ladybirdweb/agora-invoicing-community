<?php

namespace App;

class UserOrganization extends BaseModel
{
    protected $table = 'user_org_relationship';
}
